"""M4 for C4: cell-count extrapolation from measured constants.
Model of the relative gap near R5: g(p) = 1/2 (p-p0)^T Ht (p-p0), Ht = H_chart/F*
(Hessian measured by hessian_r5.py, transformed to the chart).
Zeroth order (domain monotonicity, measured in tangent_bound.py Part B):
   certified half-width d0(p) = 0.20 * g(p)               [sup-norm cube]
PAQC (measured in paqc.py): a cube of half-width rho centred at p is certified iff
   min_{corners s} g(p + rho s) - C rho^2 > 0,   C = 3.0 (measured loss constant)
Count  N = int dV / (2 d(p))^6  over the shell r0 < |p-p0| < r1 (Monte Carlo).
Own code, MEAS-01/C4.  Model only: valid while the quadratic model of g holds.
"""
import itertools, sys
import numpy as np
from mps import regular

F = 18.919104286209568
H = np.load("hessian_r5.npy")
P = regular(5); e = P[1] - P[0]; s = np.linalg.norm(e); phi = np.arctan2(e[1], e[0])
Rm = np.array([[np.cos(phi), -np.sin(phi)], [np.sin(phi), np.cos(phi)]])
B = np.zeros((10, 6))
for j, k in enumerate((2, 3, 4)):
    B[2 * k:2 * k + 2, 2 * j:2 * j + 2] = s * Rm
Ht = B.T @ H @ B / F
CORN = np.array(list(itertools.product([-1, 1], repeat=6)), float)
C = float(sys.argv[1]) if len(sys.argv) > 1 else 3.0
rng = np.random.default_rng(5)


def g(x):
    return 0.5 * np.einsum("...i,ij,...j->...", x, Ht, x)


def rho_paqc(x):
    lo, hi = 0.0, np.linalg.norm(x)
    for _ in range(40):
        mid = 0.5 * (lo + hi)
        if g(x[None, :] + mid * CORN).min() - C * mid ** 2 > 0:
            lo = mid
        else:
            hi = mid
    return lo


def shell_count(r0, r1, n=4000, method="paqc"):
    # sample uniformly in the shell volume
    u = rng.normal(size=(n, 6)); u /= np.linalg.norm(u, axis=1)[:, None]
    rr = (r0 ** 6 + rng.random(n) * (r1 ** 6 - r0 ** 6)) ** (1 / 6)
    X = u * rr[:, None]
    vol = np.pi ** 3 / 6 * (r1 ** 6 - r0 ** 6)
    if method == "paqc":
        d = np.array([rho_paqc(x) for x in X])
    else:
        d = 0.20 * g(X)
    w = 1.0 / (2 * d) ** 6
    return vol * w.mean(), vol * w.std() / np.sqrt(n)


print("chart Hessian/F eigenvalues:", np.round(np.linalg.eigvalsh(Ht), 4))
for (r0, r1) in ((0.05, 0.1), (0.1, 0.2), (0.2, 0.4)):
    n0, s0 = shell_count(r0, r1, method="zeroth")
    n1, s1 = shell_count(r0, r1, n=1500, method="paqc")
    print("shell [%.2f,%.2f]: zeroth-order ~ %.2e cells (+-%.0e) | PAQC(C=%.1f) ~ %.2e cells (+-%.0e)" % (r0, r1, n0, s0, C, n1, s1))
# PAQC count per factor-2 shell is scale invariant in this model:
n1, _ = shell_count(0.001, 0.002, n=1500, method="paqc")
print("PAQC count per factor-2 shell at r~0.001: %.2e (scale-free check)" % n1)
