"""Hessian of F(x) = lambda_1(P(x)) * Area(P(x)) at the regular pentagon (unit
circumradius), x = 10 vertex coordinates.  Central finite differences on the
float64 MPS solver.  Own code, MEAS-01/C4.  Not rigorous."""
import time, sys
import numpy as np
from mps import PolyMPS, regular, poly_area

K = 14
h = float(sys.argv[1]) if len(sys.argv) > 1 else 2e-3
V0 = regular(5)
lam0_guess = 18.9191042862095681 / poly_area(V0)
cache = {}


def F(x):
    key = tuple(np.round(x, 15))
    if key in cache:
        return cache[key]
    V = x.reshape(5, 2)
    m = PolyMPS(V, K=K)
    lam = m.solve(lam0_guess, width=2e-2, ngrid=9)
    val = lam * poly_area(V)
    cache[key] = val
    return val


t0 = time.time()
x0 = V0.reshape(-1)
F0 = F(x0)
print("F0 =", F0, " (hp value 18.9191042862095681)", flush=True)
nd = 10
H = np.zeros((nd, nd))
E = np.eye(nd) * h
fp = [F(x0 + E[i]) for i in range(nd)]
fm = [F(x0 - E[i]) for i in range(nd)]
grad = (np.array(fp) - np.array(fm)) / (2 * h)
for i in range(nd):
    H[i, i] = (fp[i] - 2 * F0 + fm[i]) / h ** 2
for i in range(nd):
    for j in range(i + 1, nd):
        fpp = F(x0 + E[i] + E[j]); fmm = F(x0 - E[i] - E[j])
        fpm = F(x0 + E[i] - E[j]); fmp = F(x0 - E[i] + E[j])
        H[i, j] = H[j, i] = (fpp - fpm - fmp + fmm) / (4 * h * h)
print("grad norm (should be ~0):", np.linalg.norm(grad))
ev, evec = np.linalg.eigh(H)
print("all 10 Hessian eigenvalues:", np.array2string(ev, precision=5))
# trivial directions: translations, rotation, scaling
P = V0
tx = np.tile([1, 0], 5); ty = np.tile([0, 1], 5)
rot = np.column_stack([-P[:, 1], P[:, 0]]).reshape(-1)
sc = P.reshape(-1)
T = np.column_stack([tx, ty, rot, sc])
Qt, _ = np.linalg.qr(T)
Pperp = np.eye(nd) - Qt @ Qt.T
Hq = Pperp @ H @ Pperp
evq = np.linalg.eigvalsh(Hq)
print("Hessian on complement of similarities (6 nontrivial):", np.array2string(np.sort(evq)[4:], precision=6))
print("trivial-direction residual |H T|:", np.linalg.norm(H @ Qt))
# DD-01 comparison: move vertex 0 by 5% of circumradius radially / tangentially
for name, d in (("radial", np.r_[P[0], np.zeros(8)]), ("tangential", np.r_[[-P[0, 1], P[0, 0]], np.zeros(8)])):
    d = 0.05 * d / np.linalg.norm(d)
    print("quadratic model, vertex moved 5%% %s: dF/F = %.4f%%" % (name, 100 * 0.5 * d @ H @ d / F0))
print("evals:", len(cache), " time %.1fs" % (time.time() - t0))
np.save("hessian_r5.npy", H)
