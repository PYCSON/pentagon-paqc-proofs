"""M3 pilot #2 for C4: piecewise-affine transplantation + quasi-concavity (PAQC).

Fix a reference pentagon P0 (regular, area A0) with its centroid fan T_1..T_5.
For a pentagon P (scaled to area A0) let Phi_P: P0 -> P be the piecewise-affine
map sending the fan of P0 to the centroid fan of P, D_k = D Phi_P on T_k,
J_k = det D_k, G_k = J_k D_k^{-1} D_k^{-T}.  Then exactly
    lambda_1(P) = Lam(G, J) := inf_v  sum_k int_{T_k} grad v^T G_k grad v
                                     / sum_k J_k int_{T_k} v^2 .
Lam is an infimum of ratios of linear functions of (G,J), hence QUASI-CONCAVE
in (G,J); it is increasing in each G_k (Loewner order), decreasing in each J_k,
and Lam(sG,J) = s Lam(G,J), Lam(G,sJ) = Lam(G,J)/s.  Consequently, for corner
pentagons P_c (area A0) and convex weights alpha:
   if (1-e) sum_c alpha_c G_c,k <= G_P,k   and   (1+e') sum_c alpha_c J_c,k >= J_P,k  (all k)
   then  F(P) >= (1-e)/(1+e') * min_c F(P_c),        F = lambda_1 * area.
e, e' are explicit algebraic functions (second order in the cell size).
Only point evaluations F(P_c) are needed: no gradients, no Hessian bounds.

This script measures, for 6-D cubes (half-width rho) of the chart
v0=(0,0), v1=(1,0), (v2,v3,v4) free, the certified lower bound
   LB = (1-e_max)/(1+e'_max) * min_corners F
with e_max, e'_max estimated by dense SAMPLING of the cube (not interval-rigorous)
and multilinear weights alpha.  Float64 MPS eigenvalues; NOT rigorous.
Own code, MEAS-01/C4.
"""
import itertools, sys, time
import numpy as np
from mps import PolyMPS, regular, poly_area

FSTAR = 18.919104286209568108
rng = np.random.default_rng(7)

P0 = regular(5)
A0 = poly_area(P0)
c0 = P0.mean(axis=0)
E0inv = [np.linalg.inv(np.column_stack([P0[k] - c0, P0[(k + 1) % 5] - c0])) for k in range(5)]


def pent(p):
    V = np.array([[0, 0], [1, 0], [p[0], p[1]], [p[2], p[3]], [p[4], p[5]]], float)
    s = np.sqrt(A0 / poly_area(V))
    return V * s


def GJ(V):
    c = V.mean(axis=0)
    G = np.zeros((5, 2, 2)); J = np.zeros(5)
    for k in range(5):
        D = np.column_stack([V[k] - c, V[(k + 1) % 5] - c]) @ E0inv[k]
        Jk = np.linalg.det(D)
        Di = np.linalg.inv(D)
        G[k] = Jk * Di @ Di.T
        J[k] = Jk
    return G, J


def F(V, guess=None):
    m = PolyMPS(V, K=11)
    g = (guess if guess is not None else FSTAR) / A0
    lam = m.solve(g, width=0.04, ngrid=13)
    return lam * A0


CORN = np.array(list(itertools.product([-1, 1], repeat=6)), float)


def eps_for(u, Gc, Jc, GP, JP):
    a = np.prod((1 + CORN * u[None, :]) / 2, axis=1)       # multilinear weights
    S = np.einsum("c,ckij->kij", a, Gc)
    T = a @ Jc
    e = -np.inf
    for k in range(5):
        # largest e with (1-e) S_k <= G_P,k  <=>  1-e <= lam_min(S^-1/2 G S^-1/2)
        L = np.linalg.cholesky(S[k])
        Li = np.linalg.inv(L)
        mu = np.linalg.eigvalsh(Li @ GP[k] @ Li.T).min()
        e = max(e, 1 - mu)
    ep = np.max(JP / T) - 1
    return e, ep


def cube_bound(p, rho, nsamp=4000, check=0):
    t0 = time.time()
    Vc = [pent(p + rho * s) for s in CORN]
    Gc = np.zeros((64, 5, 2, 2)); Jc = np.zeros((64, 5))
    for i, V in enumerate(Vc):
        Gc[i], Jc[i] = GJ(V)
    Fc = np.array([F(V) for V in Vc])
    emax, epmax = -np.inf, -np.inf
    for _ in range(nsamp):
        u = rng.uniform(-1, 1, 6)
        if rng.random() < 0.3:   # also sample faces/edges
            idx = rng.random(6) < 0.5
            u[idx] = np.sign(u[idx])
        GP, JP = GJ(pent(p + rho * u))
        e, ep = eps_for(u, Gc, Jc, GP, JP)
        emax, epmax = max(emax, e), max(epmax, ep)
    LB = (1 - emax) / (1 + epmax) * Fc.min()
    out = dict(rho=rho, Fmin=Fc.min(), Fmax=Fc.max(), emax=emax, epmax=epmax, LB=LB, t=time.time() - t0)
    if check:
        viol = 0
        for _ in range(check):
            u = rng.uniform(-1, 1, 6)
            Fp = F(pent(p + rho * u))
            viol = max(viol, LB - Fp)
        out["max(LB-F) over checks"] = viol
    return out


def r5_params():
    R = regular(5, R=1 / (2 * np.sin(np.pi / 5)), rot=-np.pi / 2 - np.pi / 5)
    R = R - R[0]
    e = R[1] - R[0]
    ang = np.arctan2(e[1], e[0])
    Rm = np.array([[np.cos(-ang), -np.sin(-ang)], [np.sin(-ang), np.cos(-ang)]])
    R = R @ Rm.T
    return R[2:].reshape(-1)


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "r5"
    p0 = r5_params()
    print("F(R5) via chart:", F(pent(p0)))
    if mode == "r5":
        # cube CENTRED at the regular pentagon: is LB >= F* (local minimality certificate)?
        for rho in [float(x) for x in sys.argv[2:]] or [0.003, 0.01, 0.03]:
            o = cube_bound(p0, rho, nsamp=3000, check=3)
            print("centre=R5 rho=%.4f  minF-F*=%.3e  e=%.3e e'=%.3e  LB-F*=%.3e  (%.0fs)" % (
                rho, o["Fmin"] - FSTAR, o["emax"], o["epmax"], o["LB"] - FSTAR, o["t"]), o.get("max(LB-F) over checks"), flush=True)
    else:
        # off-centre cells: compare with zeroth-order d0 ~ 0.2*gap (Part B)
        r = float(sys.argv[2]); ndir = int(sys.argv[3])
        for t in range(ndir):
            d = rng.normal(size=6); d /= np.linalg.norm(d)
            p = p0 + r * d
            Fp = F(pent(p))
            gap = Fp / FSTAR - 1
            d0 = 0.2 * gap
            best = None
            for mult in (1, 4, 16, 64):
                rho = mult * d0
                o = cube_bound(p, rho, nsamp=1500, check=2)
                ok = o["LB"] > FSTAR
                print("  r=%.2f gap=%.2e rho=%.2e (%dx d0) LB-F*=%.2e e=%.1e e'=%.1e ok=%s viol=%.1e (%.0fs)" % (
                    r, gap, rho, mult, o["LB"] - FSTAR, o["emax"], o["epmax"], ok, o["max(LB-F) over checks"], o["t"]), flush=True)
                if ok:
                    best = mult
                else:
                    break
            print(" -> largest certified multiple of d0:", best, flush=True)
