"""High-precision lambda_1 of the regular pentagon (unit edge) by D5-symmetric
particular solutions + collocation determinant root (Fox-Henrici-Moler style).
Own code, MEAS-01/C4.  mpmath.  Not rigorous (no FHM bound evaluated here)."""
import sys, time
import mpmath as mp

dps = int(sys.argv[1]) if len(sys.argv) > 1 else 40
mp.mp.dps = dps
Ms = [int(a) for a in sys.argv[2:]] or [10, 14, 18, 22]

n = 5
s = mp.mpf(1)                         # edge length
R = s / (2 * mp.sin(mp.pi / n))       # circumradius
V = [(R * mp.cos(2 * mp.pi * j / n + mp.pi / 2), R * mp.sin(2 * mp.pi * j / n + mp.pi / 2)) for j in range(n)]
alpha = 3 * mp.pi / 5
pa = mp.pi / alpha                    # 5/3


def frame(j):
    p = V[j]
    a = V[(j + 1) % n]
    phi0 = mp.atan2(a[1] - p[1], a[0] - p[0])
    return p, phi0


def local(P, j):
    p, phi0 = frame(j)
    dx, dy = P[0] - p[0], P[1] - p[1]
    r = mp.sqrt(dx * dx + dy * dy)
    th = mp.atan2(dy, dx) - phi0
    while th < -mp.mpf('1e-30'):
        th += 2 * mp.pi
    while th > 2 * mp.pi - mp.mpf('1e-30'):
        th -= 2 * mp.pi
    if th > alpha + 1:          # wrapped tiny negative
        th -= 2 * mp.pi
    return r, th


def colloc_points(M):
    # half edge from V0 to midpoint of edge V0V1, excluding endpoints; Chebyshev-ish
    a, b = V[0], V[1]
    mid = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
    pts = []
    for i in range(M):
        t = (1 - mp.cos(mp.pi * (i + mp.mpf(1) / 2) / M)) / 2   # (0,1)
        pts.append((a[0] + t * (mid[0] - a[0]), a[1] + t * (mid[1] - a[1])))
    return pts


def build(lam, pts, M):
    k = mp.sqrt(lam)
    A = mp.matrix(len(pts), M)
    loc = [[local(P, j) for j in range(n)] for P in pts]
    for i, P in enumerate(pts):
        for m in range(M):
            nu = (2 * m + 1) * pa
            v = 0
            for j in range(n):
                r, th = loc[i][j]
                v += mp.besselj(nu, k * r) * mp.sin(nu * th)
            A[i, m] = v
    return A


def F(lam, pts, M):
    A = build(lam, pts, M)
    # column scaling for conditioning of the determinant
    for m in range(M):
        cmax = max(abs(A[i, m]) for i in range(A.rows))
        if cmax != 0:
            for i in range(A.rows):
                A[i, m] /= cmax
    return mp.det(A)


jones = mp.mpf('10.996427084559806648')
for M in Ms:
    t0 = time.time()
    pts = colloc_points(M)
    x0 = mp.mpf('10.9964270845598')
    x1 = x0 * (1 + mp.mpf('1e-10'))
    f0, f1 = F(x0, pts, M), F(x1, pts, M)
    for it in range(30):
        x2 = x1 - f1 * (x1 - x0) / (f1 - f0)
        x0, f0 = x1, f1
        x1, f1 = x2, F(x2, pts, M)
        if abs(x1 - x0) < mp.mpf(10) ** (-dps + 5):
            break
    print("M=%d  lam*s^2 = %s   diff vs Jones(20 digits) = %s   t=%.1fs" % (
        M, mp.nstr(x1, dps - 5), mp.nstr(x1 - jones, 5), time.time() - t0), flush=True)

# area-pi normalisation for comparison with Jones Table III
A_unit = mp.mpf(5) / 4 / mp.tan(mp.pi / 5)
lam_api = x1 * A_unit / mp.pi
print("area-pi lambda =", mp.nstr(lam_api, dps - 8))
print("Jones T.III    = 6.022137932042633878298008710054242967005305340448557982078846736673784801348686")
print("lambda*Area    =", mp.nstr(x1 * A_unit, dps - 8))
