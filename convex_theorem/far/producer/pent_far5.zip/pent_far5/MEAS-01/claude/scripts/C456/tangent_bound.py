"""M3 pilot for C4: a Hessian-free global lower bound for lambda_1 from the
Brunn-Minkowski concavity of lambda_1^{-1/2} (Brascamp-Lieb 1976) and the first
variation of lambda_1 under Minkowski addition (Colesanti / Jerison):

  for convex L and a convex polygon K with normals n_i,
      lambda_1(L) >= 4 lambda_1(K)^3 / ( sum_i w_i h_L(n_i) )^2,
  w_i = int_{edge_i} (d_n u_K)^2 ds,  ||u_K||_2 = 1,  h_L = support function.

Part A: numerically check the inequality and the identities
        sum w_i n_i = 0 (translation),  sum w_i h_K(n_i) = 2 lambda (Rellich).
Part B: compare certified-cell sizes in the 6-D pentagon parameter space
        (v0=(0,0), v1=(1,0) fixed; v2,v3,v4 free; sup-norm box of half-width d)
        for  (0) domain monotonicity: lambda(L) >= lambda(Q),  Q = {<x,n_i> <= max_box h_L(n_i)}
        and  (1) the tangent bound above,
        both times area lower bound A_min over the box (multi-affine -> corners).
Own code, MEAS-01/C4.  Float64; NOT rigorous (pilot measures sizes only).
"""
import itertools, time, sys
import numpy as np
from mps import PolyMPS, regular, poly_area

FSTAR = 18.919104286209568108   # lambda_1 * Area of the regular pentagon (our hp value)
rng = np.random.default_rng(1)


def eig(V, K=12, guess=None):
    m = PolyMPS(V, K=K)
    A = abs(poly_area(V))
    g = guess if guess is not None else 19.5 / A
    lam = m.solve(g, width=0.35 if guess is None else 0.03, ngrid=41 if guess is None else 11)
    return lam, m


def support(Vl, n):
    return np.max(Vl @ n.T, axis=0)       # h_L(n_i) for all normals (rows of n)


def tangent_data(V, K=12):
    lam, m = eig(V, K)
    w, nrm, hs = m.edge_w()
    return lam, w, nrm, hs


def bound_tangent(lam, w, nrm, VL):
    S = np.dot(w, support(VL, nrm))
    return 4 * lam ** 3 / S ** 2


# ---------------- Part A ----------------
def partA():
    print("== Part A: identities and validity of the tangent bound")
    Ks = [regular(5), np.array([[0, 0], [1, 0], [1.3, 0.7], [0.4, 1.2], [-0.3, 0.6]])]
    for V in Ks:
        lam, w, nrm, hs = tangent_data(V)
        print(" K lam=%.12f  |sum w n|=%.2e  sum w h / (2 lam) - 1 = %.2e" % (
            lam, np.linalg.norm(w @ nrm), np.dot(w, hs) / (2 * lam) - 1))
        worst = 1e9
        for scale in (0.01, 0.03, 0.1, 0.3):
            for t in range(6):
                VL = V + scale * rng.normal(size=V.shape)
                if poly_area(VL) <= 0:
                    continue
                # convexity check
                from scipy.spatial import ConvexHull
                if len(ConvexHull(VL).vertices) < 5:
                    continue
                lamL, _ = eig(VL)
                b = bound_tangent(lam, w, nrm, VL)
                worst = min(worst, lamL - b)
                print("   pert %.2f: lam(L)=%.8f bound=%.8f  rel deficit=%.2e" % (scale, lamL, b, (lamL - b) / lamL))
        # some far-away shapes
        for VL, name in ((np.array([[0, 0], [1, 0], [1, 1], [0, 1.]]), "square"), (regular(3), "triangle"), (regular(12), "12-gon")):
            lamL, _ = eig(VL, K=10)
            b = bound_tangent(lam, w, nrm, VL)
            print("   %s: lam=%.6f bound=%.6f ok=%s" % (name, lamL, b, b <= lamL * (1 + 1e-9)))


# ---------------- Part B ----------------
def pent_from_p(p):
    return np.array([[0, 0], [1, 0], [p[0], p[1]], [p[2], p[3]], [p[4], p[5]]])


CORN = np.array(list(itertools.product([-1, 1], repeat=6)), float)


def box_stats(p, d, nrm):
    """max over box corners of h_L(n_i) (vector) and min area."""
    Hmax = np.full(len(nrm), -np.inf)
    Amin = np.inf
    for c in CORN:
        VL = pent_from_p(p + d * c)
        Hmax = np.maximum(Hmax, support(VL, nrm))
        Amin = min(Amin, poly_area(VL))
    return Hmax, Amin


def box_tangent_LB(p, d, lam, w, nrm):
    Smax = -np.inf
    Amin = np.inf
    for c in CORN:
        VL = pent_from_p(p + d * c)
        Smax = max(Smax, np.dot(w, support(VL, nrm)))
        Amin = min(Amin, poly_area(VL))
    return 4 * lam ** 3 / Smax ** 2 * Amin


def poly_from_halfplanes(nrm, H):
    n = len(nrm)
    V = []
    for i in range(n):
        a, b = nrm[i - 1], nrm[i]
        M = np.array([a, b])
        V.append(np.linalg.solve(M, [H[i - 1], H[i]]))
    return np.array(V)


def box_dommono_LB(p, d, nrm, lam_guess):
    Hmax, Amin = box_stats(p, d, nrm)
    Q = poly_from_halfplanes(nrm, Hmax)
    lamQ, _ = eig(Q, K=10, guess=lam_guess * (poly_area(pent_from_p(p)) / poly_area(Q)))
    return lamQ * Amin


def max_cell(fun, d_hi=0.2, iters=14):
    """largest d with fun(d) > FSTAR (bisection in log d)."""
    lo, hi = 1e-7, d_hi
    if fun(lo) <= FSTAR:
        return 0.0
    if fun(hi) > FSTAR:
        return hi
    for _ in range(iters):
        mid = np.sqrt(lo * hi)
        if fun(mid) > FSTAR:
            lo = mid
        else:
            hi = mid
    return lo


def partB(nsamp=10):
    print("== Part B: cell sizes, zeroth order vs tangent bound")
    R5 = regular(5, R=1 / (2 * np.sin(np.pi / 5)), rot=-np.pi / 2 - np.pi / 5)
    R5 = R5 - R5[0]  # v0 at origin
    # rotate so v1-v0 = (1,0)
    e = R5[1] - R5[0]
    ang = np.arctan2(e[1], e[0])
    Rm = np.array([[np.cos(-ang), -np.sin(-ang)], [np.sin(-ang), np.cos(-ang)]])
    R5 = R5 @ Rm.T
    p0 = R5[2:].reshape(-1)
    print(" R5 params", np.round(p0, 6), "check v1", np.round(R5[1], 12))
    rows = []
    for r in (0.3, 0.15, 0.08, 0.04, 0.02):
        for s in range(nsamp):
            dirn = rng.normal(size=6)
            dirn /= np.linalg.norm(dirn)
            p = p0 + r * dirn
            V = pent_from_p(p)
            from scipy.spatial import ConvexHull
            if poly_area(V) <= 0 or len(ConvexHull(V).vertices) < 5:
                continue
            t0 = time.time()
            lam, w, nrm, hs = tangent_data(V)
            F = lam * poly_area(V)
            gap = F / FSTAR - 1
            d1 = max_cell(lambda d: box_tangent_LB(p, d, lam, w, nrm))
            d0 = max_cell(lambda d: box_dommono_LB(p, d, nrm, lam), iters=10)
            rows.append((r, gap, d0, d1))
            print(" r=%.2f gap=%.3e  d0=%.3e  d1=%.3e  d1/d0=%.2f  (%.1fs)" % (r, gap, d0, d1, d1 / max(d0, 1e-12), time.time() - t0), flush=True)
    np.save("partB_rows.npy", np.array(rows))
    return rows


if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "AB"
    t0 = time.time()
    if "A" in which:
        partA()
    if "B" in which:
        partB(int(sys.argv[2]) if len(sys.argv) > 2 else 4)
    print("total %.1fs" % (time.time() - t0))
