"""M2 for C5: Cohn-Elkies-type LP upper bound for TRANSLATIVE packings of the
regular tetrahedron T (target: Dostert-Guzman-Oliveira-Vallentin 2017, <= 0.3745;
lattice optimum 18/49 = 0.367347).  Own code, MEAS-01/C5.

Theorem used (Cohn-Elkies for a convex body K): if f is continuous, integrable,
real and even, f(x) <= 0 for x outside int(K-K), fhat >= 0 and fhat(0) > 0, then
the translative packing density of K is <= vol(K) f(0)/fhat(0).

T = conv{(1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)}  (vol 8/3);  T-T = cuboctahedron
C = {max|x_i| <= 2, sum|x_i| <= 4}, symmetric under O_h.  Basis: O_h-symmetrised
products of even Hermite functions h_a(sqrt(2 pi) x1) h_b(..x2) h_c(..x3), which are
Fourier eigenfunctions with eigenvalue (-1)^((a+b+c)/2).  The body is scaled by s.
Constraints are imposed on SAMPLE points only -> the value is NOT a rigorous bound
(a rigorous version needs a sign certificate on the continuum, cf. Dostert et al.).
"""
import sys, time, itertools
import numpy as np
from scipy.optimize import linprog

D = int(sys.argv[1]) if len(sys.argv) > 1 else 24
svals = [float(x) for x in sys.argv[2:]] or [0.45, 0.55, 0.65]
rng = np.random.default_rng(3)


def herm_funcs(nmax, y):
    """normalised Hermite functions h_0..h_nmax at points y (array)."""
    H = np.zeros((nmax + 1,) + y.shape)
    H[0] = np.pi ** -0.25 * np.exp(-y ** 2 / 2)
    if nmax >= 1:
        H[1] = np.sqrt(2) * y * H[0]
    for n in range(1, nmax):
        H[n + 1] = np.sqrt(2 / (n + 1)) * y * H[n] - np.sqrt(n / (n + 1)) * H[n - 1]
    return H


# basis: sorted triples of even numbers a>=b>=c with a+b+c <= D
trip = [(a, b, c) for a in range(0, D + 1, 2) for b in range(0, a + 1, 2) for c in range(0, b + 1, 2) if a + b + c <= D]
eig = np.array([(-1) ** ((a + b + c) // 2) for a, b, c in trip], float)
print("D=%d basis size %d" % (D, len(trip)), flush=True)


def design(X):
    """matrix [npts, nbasis] of O_h-symmetrised basis functions at points X (n,3)."""
    Y = np.sqrt(2 * np.pi) * X
    Hs = [herm_funcs(D, Y[:, i]) for i in range(3)]
    M = np.zeros((len(X), len(trip)))
    for j, (a, b, c) in enumerate(trip):
        perms = set(itertools.permutations((a, b, c)))
        v = 0
        for (p, q, r) in perms:
            v = v + Hs[0][p] * Hs[1][q] * Hs[2][r]
        M[:, j] = v / len(perms)
    return M


def fund(X):
    X = np.abs(X)
    return -np.sort(-X, axis=1)          # x1 >= x2 >= x3 >= 0


def outside(X, s):
    X = np.abs(X)
    return (X.max(1) >= 2 * s) | (X.sum(1) >= 4 * s)


def run(s, R=3.6, n_out=8000, n_hat=8000, rounds=8):
    """cutting-plane LP: add violated fresh sample points until violations are tiny."""
    P = fund(rng.uniform(-R, R, (6 * n_out, 3)))
    P = P[(np.linalg.norm(P, axis=1) <= R) & outside(P, s)][:n_out]
    B = fund(rng.normal(size=(6000, 3)))
    t = s / np.maximum(B.max(1) / 2, B.sum(1) / 4)
    Xo = np.vstack([P, B * t[:, None]])
    Q = fund(rng.uniform(-R, R, (6 * n_hat, 3)))
    Q = np.vstack([Q[np.linalg.norm(Q, axis=1) <= R][:n_hat], np.zeros((1, 3))])
    Mo = design(Xo); Mh = design(Q) * eig[None, :]
    m0 = design(np.zeros((1, 3)))[0]
    for rd in range(rounds):
        A_ub = np.vstack([Mo, -Mh]); b_ub = np.zeros(len(A_ub))
        res = linprog(m0, A_ub=A_ub, b_ub=b_ub, A_eq=(m0 * eig)[None, :], b_eq=[1.0],
                      bounds=[(-1e4, 1e4)] * len(trip), method="highs")
        if res.status != 0:
            return None, res.message
        Pc = fund(rng.uniform(-R, R, (120000, 3)))
        Pc = Pc[(np.linalg.norm(Pc, axis=1) <= R) & outside(Pc, s)]
        Bc = fund(rng.normal(size=(20000, 3))); tc = s / np.maximum(Bc.max(1) / 2, Bc.sum(1) / 4)
        Pc = np.vstack([Pc, Bc * tc[:, None]])
        Mc = design(Pc); vf = Mc @ res.x
        Qc = fund(rng.uniform(-R, R, (120000, 3))); Qc = Qc[np.linalg.norm(Qc, axis=1) <= R]
        Mqc = design(Qc) * eig[None, :]; vh = Mqc @ res.x
        mf, mh = vf.max(), -vh.min()
        print("    s=%.3f round %d: bound=%.6f  max f_out=%.1e  max -fhat=%.1e" % (s, rd, 8 / 3 * s ** 3 * res.fun, mf, mh), flush=True)
        if mf < 1e-8 and mh < 1e-8:
            break
        Mo = np.vstack([Mo, Mc[vf > 0]]); Mh = np.vstack([Mh, Mqc[vh < 0]])
    return 8 / 3 * s ** 3 * res.fun, (mf, mh)


t0 = time.time()
for s in svals:
    b, info = run(s)
    print("s=%.3f  bound=%s  (max f outside on fresh pts=%s, max -fhat=%s)  t=%.0fs" % (
        s, b, None if b is None else "%.2e" % info[0], None if b is None else "%.2e" % info[1], time.time() - t0), flush=True)
print("reference: Dostert et al. 2017 bound 0.3745 ; lattice 18/49 = %.6f" % (18 / 49))
