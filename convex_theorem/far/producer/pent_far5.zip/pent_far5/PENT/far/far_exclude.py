"""Far-region exclusion for CONVEX pentagons, computer-assisted (Claude, 2026-10-31).  Own code, arb ball arithmetic.

Longest-edge chart: v0=(0,0), v1=(1,0) is a longest edge, polygon strictly convex and counter-clockwise, free vertices
v2=(x0,x1), v3=(x2,x3), v4=(x4,x5).  Every convex pentagon has such a representative (relabel cyclically so that a
longest edge is v0v1, rotate/scale).  Constraints of a representative: all 15 orientation determinants > 0 and
|v1v2|, |v2v3|, |v3v4|, |v4v0| <= 1.  Hence y_i > 0 (all vertices left of the line v0v1), x2 in [0,2], y2 in [0,1],
x4 in [-1,1], y4 in [0,1], x3 in [-1,2], y3 in [0,2] (|v3 - v2| <= 1 and |v3 - v4| <= 1): the root box.

Branch-and-bound over boxes X of the root box (exact binary64 endpoints, arb intervals).  A leaf is
  INVALID   if for EVERY point of X some representative constraint fails (an orientation determinant has upper <= 0,
            or some non-base edge has |e|^2 lower > 1): X contains no representative;
  EXCLUDED  if one of the following holds uniformly on X (each implies F(P) = lambda_1(P) |P| > F*_up for every convex P
            in X, so no such P can beat the regular pentagon):
      (Q4_j)  dropping the half-plane of edge j: the lines of edges j-1, j+1 meet beyond edge j (cross(n_{j-1}, n_{j+1}) > 0),
              the convex quadrilateral Q = P u tri(V_j, w, V_{j+1}) contains P, and A(P) (1 - th4) - th4 T_j > 0,
              th4 = F*_up/(2 pi^2): by domain monotonicity and Polya-Szego (n=4) F(P) >= 2 pi^2 A(P)/A(Q) > F*_up;
      (Q3_abc) the half-planes of edges a, b, c bound a triangle T (all three consecutive normal crosses > 0) and
              A(P) - th3 A(T) > 0, th3 = F*_up sqrt(3)/(4 pi^2) (Polya-Szego n=3: F >= 4 pi^2/sqrt 3 for triangles);
      (HP)    Per^2 - kappa A > 0, kappa = 16 F*_up/pi^2: Hersch-Protter lambda_1 >= pi^2/(4 r_in^2) for convex domains and
              r_in <= 2A/Per give F >= pi^2 Per^2/(16 A);
  REMAINING otherwise once X is small: these boxes cover the set K that still needs PAQC cells.
Output: jsonl.gz of all leaves (box, label, criterion), summary json.  F*_up = 18.919134195733918 (rig_paqc v6).
Usage: python3 far_exclude.py OUTDIR [coarse=0.25] [fine=0.0625]
"""
import sys, os, json, gzip, time, heapq, itertools
import numpy as np
from flint import arb, ctx
ctx.prec = 80
FSTAR_UP = arb('18.919134195733918')
PI = arb.pi()
TH4 = FSTAR_UP / (2 * PI * PI)
TH3 = FSTAR_UP * arb(3).sqrt() / (4 * PI * PI)
KAPPA = 16 * FSTAR_UP / (PI * PI)
ROOT = [(0.0, 2.0), (0.0, 1.0), (-1.0, 2.0), (0.0, 2.0), (-1.0, 1.0), (0.0, 1.0)]
HP2 = os.environ.get('FAR_HP2', '0') == '1'      # 2026-11-10 EXPERIMENT (classify, HP2 test); off by default


def iv(lo, hi):
    return arb(lo).union(arb(hi))


def sub(a, b): return (a[0] - b[0], a[1] - b[1])
def cross(a, b): return a[0] * b[1] - a[1] * b[0]
def dot(a, b): return a[0] * b[0] + a[1] * b[1]
def nn(x): return abs(x)          # nonnegative enclosure of a square-type quantity


class J1:
    """first-order jet: value and gradient w.r.t. the 6 chart coordinates (arb balls)."""
    __slots__ = ('v', 'g')
    def __init__(self, v, g=None):
        self.v = v; self.g = g if g is not None else [arb(0)] * 6
    def __add__(s, o):
        if not isinstance(o, J1): o = J1(arb(o))
        return J1(s.v + o.v, [a + b for a, b in zip(s.g, o.g)])
    __radd__ = __add__
    def __neg__(s): return J1(-s.v, [-a for a in s.g])
    def __sub__(s, o): return s + (-o if isinstance(o, J1) else J1(-arb(o)))
    def __rsub__(s, o): return (-s) + o
    def __mul__(s, o):
        if not isinstance(o, J1): return J1(s.v * o, [a * o for a in s.g])
        return J1(s.v * o.v, [s.v * b + o.v * a for a, b in zip(s.g, o.g)])
    __rmul__ = __mul__
    def __truediv__(s, o):
        if not isinstance(o, J1): return J1(s.v / o, [a / o for a in s.g])
        q = s.v / o.v
        return J1(q, [(a - q * b) / o.v for a, b in zip(s.g, o.g)])
    def sqrt(s):
        r = s.v.sqrt(); return J1(r, [a / (2 * r) for a in s.g])


def _jsub(a, b): return (a[0] - b[0], a[1] - b[1])
def _jcross(a, b): return a[0] * b[1] - a[1] * b[0]
def _jdot(a, b): return a[0] * b[0] + a[1] * b[1]


def _funcs(X):
    """all exclusion functions as jets, for coordinate jets X (point or box)."""
    one = J1(arb(1)); zero = J1(arb(0))
    V = [(zero, zero), (one, zero), (X[0], X[1]), (X[2], X[3]), (X[4], X[5])]
    A = sum((_jcross(V[i], V[(i + 1) % 5]) for i in range(5)), zero) * arb(0.5)
    L = []
    for i in range(5):
        t = _jsub(V[(i + 1) % 5], V[i]); n = (t[1], -t[0]); L.append((n, _jdot(n, V[i])))
    out = {}
    for j in range(5):
        (n1, c1), (n2, c2) = L[(j - 1) % 5], L[(j + 1) % 5]
        det = _jcross(n1, n2)
        out['det4_%d' % j] = det
        try:
            w = ((c1 * n2[1] - c2 * n1[1]) / det, (n1[0] * c2 - n2[0] * c1) / det)
            T = -_jcross(_jsub(V[(j + 1) % 5], V[j]), _jsub(w, V[j])) * arb(0.5)
            out['Q4_%d' % j] = A * (1 - TH4) - T * TH4
        except ZeroDivisionError:
            pass
    for a, b, c in itertools.combinations(range(5), 3):
        dets = [_jcross(L[p][0], L[q][0]) for p, q in ((a, b), (b, c), (c, a))]
        out['det3_%d%d%d' % (a, b, c)] = dets
        try:
            def meet(p, q):
                (n1, c1), (n2, c2) = L[p], L[q]; d = _jcross(n1, n2)
                return ((c1 * n2[1] - c2 * n1[1]) / d, (n1[0] * c2 - n2[0] * c1) / d)
            pab, pbc, pca = meet(a, b), meet(b, c), meet(c, a)
            AT = _jcross(_jsub(pbc, pab), _jsub(pca, pab)) * arb(0.5)
            out['Q3_%d%d%d' % (a, b, c)] = A - AT * TH3
        except ZeroDivisionError:
            pass
    try:
        per = zero
        for i in range(5):
            t = _jsub(V[(i + 1) % 5], V[i]); per = per + (t[0] * t[0] + t[1] * t[1]).sqrt()
        out['HP'] = per * per - A * KAPPA
    except (ZeroDivisionError, ValueError):
        pass
    out['A'] = A
    return out


def _mvf_lower(fc, fb, rad):
    """mean-value form: f(x) >= f(c) - sum_i |df/dx_i (box)| r_i  (valid if f is C^1 on the box)."""
    lo = fc.v
    for gi, ri in zip(fb.g, rad):
        lo = lo - abs(gi) * ri
    return lo


def classify(box, rep=True):
    """rep=False (2026-11-12, cut-chart cover): the box is not in the representative frame (base = longest edge), so
    the edge-length test is skipped; INVALID then only means 'no convex pentagon in the box' (orientation)."""
    X = [iv(lo, hi) for lo, hi in box]
    V = [(arb(0), arb(0)), (arb(1), arb(0)), (X[0], X[1]), (X[2], X[3]), (X[4], X[5])]
    # ---- representative constraints (natural interval extension; quadratic, adequate)
    for i in range(5):
        t = sub(V[(i + 1) % 5], V[i])
        for j in range(5):
            if j in (i, (i + 1) % 5):
                continue
            if cross(t, sub(V[j], V[i])).upper() <= 0:
                return 'INVALID', 'orient%d%d' % (i, j)
    for i in range(1, 5) if rep else ():
        t = sub(V[(i + 1) % 5], V[i]); e2 = nn(t[0]) * nn(t[0]) + nn(t[1]) * nn(t[1])
        if e2.lower() > 1:
            return 'INVALID', 'edge%d' % i
    # ---- HP2 (2026-11-10): Hersch-Protter with a perimeter LOWER bound that needs no square root of a ball containing 0:
    # for convex P, Per >= 2 diam >= 2 |v0 v1| = 2, and Per >= sum_i sqrt(max(0, lower |e_i|^2)); so F >= pi^2 Per^2/(16 A)
    # > F*_up whenever Per_lo^2 > kappa A_hi.  Catches the thin / collapsing shapes (area < pi^2/(4 F*_up) = 0.1304) where
    # an edge length interval contains 0 and the HP test below returns nan (seen: far depth probe, L8-L9 unresolved cells
    # with area 0.03-0.05 and an edge of length ~0.01).
    if HP2:
        A_box = abs(sum((cross(V[i], V[(i + 1) % 5]) for i in range(5)), arb(0))) / 2
        per_lo = arb(0)
        for i in range(5):
            t = sub(V[(i + 1) % 5], V[i]); e2 = nn(t[0]) * nn(t[0]) + nn(t[1]) * nn(t[1]); l2 = e2.lower()
            if l2 > 0:
                per_lo += arb(l2).sqrt().lower()
        per_lo = arb(max(per_lo.lower(), 2))
        if (per_lo * per_lo - KAPPA * arb(A_box.upper())).lower() > 0:
            return 'EXCLUDED', 'HP2'
    # ---- exclusion tests, natural interval extension first (robust near degenerations, no derivatives) ...
    try:
        Fn = _funcs([J1(X[i]) for i in range(6)])
        for j in range(5):
            if 'Q4_%d' % j in Fn and Fn['det4_%d' % j].v.lower() > 0 and Fn['Q4_%d' % j].v.lower() > 0:
                return 'EXCLUDED', 'Q4_%d' % j
        for a, b, c in itertools.combinations(range(5), 3):
            k = '%d%d%d' % (a, b, c)
            if 'Q3_' + k in Fn and all(d.v.lower() > 0 for d in Fn['det3_' + k]) and Fn['Q3_' + k].v.lower() > 0:
                return 'EXCLUDED', 'Q3_' + k
        if 'HP' in Fn and Fn['HP'].v.lower() > 0:
            return 'EXCLUDED', 'HP'
    except (ZeroDivisionError, ValueError):
        pass
    # ---- ... then the mean-value form (centre point jets + box gradient enclosures)
    cen = [(lo + hi) / 2 for lo, hi in box]; rad = [arb((hi - lo) / 2) for lo, hi in box]
    unit = lambda i: [arb(1) if k == i else arb(0) for k in range(6)]
    try:
        Fc = _funcs([J1(arb(cen[i]), unit(i)) for i in range(6)])
        Fb = _funcs([J1(X[i], unit(i)) for i in range(6)])
    except (ZeroDivisionError, ValueError):
        return 'OPEN', None
    def pos(key):
        if key not in Fc or key not in Fb:
            return False
        a, b = Fc[key], Fb[key]
        return _mvf_lower(a, b, rad) > 0
    for j in range(5):
        if pos('det4_%d' % j) and pos('Q4_%d' % j):
            return 'EXCLUDED', 'Q4_%d' % j
    for a, b, c in itertools.combinations(range(5), 3):
        k = '%d%d%d' % (a, b, c)
        if all(_mvf_lower(dc, db, rad) > 0 for dc, db in zip(Fc['det3_' + k], Fb['det3_' + k])) and pos('Q3_' + k):
            return 'EXCLUDED', 'Q3_' + k
    if pos('HP'):
        return 'EXCLUDED', 'HP'
    return 'OPEN', None


def float_excluded(x):
    """float version of the exclusion tests at a point (heuristic for refinement only)."""
    V = np.array([[0, 0], [1, 0], [x[0], x[1]], [x[2], x[3]], [x[4], x[5]]], float)
    for i in range(5):
        t = V[(i + 1) % 5] - V[i]
        for j in range(5):
            if j not in (i, (i + 1) % 5) and t[0] * (V[j] - V[i])[1] - t[1] * (V[j] - V[i])[0] <= 0:
                return True       # not a representative
    if any(np.sum((V[(i + 1) % 5] - V[i]) ** 2) > 1 for i in range(1, 5)):
        return True
    A = 0.5 * sum(V[i][0] * V[(i + 1) % 5][1] - V[i][1] * V[(i + 1) % 5][0] for i in range(5))
    th4 = float(TH4.mid()); th3 = float(TH3.mid()); ka = float(KAPPA.mid())
    Ls = [((V[(i + 1) % 5] - V[i])[1], -(V[(i + 1) % 5] - V[i])[0]) for i in range(5)]
    Ls = [(np.array(n), np.array(n) @ V[i]) for i, n in enumerate(Ls)]
    cr = lambda a, b: a[0] * b[1] - a[1] * b[0]
    for j in range(5):
        (n1, c1), (n2, c2) = Ls[(j - 1) % 5], Ls[(j + 1) % 5]; d = cr(n1, n2)
        if d > 0:
            w = np.array([(c1 * n2[1] - c2 * n1[1]) / d, (n1[0] * c2 - n2[0] * c1) / d])
            T = -cr(V[(j + 1) % 5] - V[j], w - V[j]) / 2
            if A * (1 - th4) - th4 * T > 0:
                return True
    for a, b, c in itertools.combinations(range(5), 3):
        if all(cr(Ls[p][0], Ls[q][0]) > 0 for p, q in ((a, b), (b, c), (c, a))):
            def meet(p, q):
                (n1, c1), (n2, c2) = Ls[p], Ls[q]; d = cr(n1, n2)
                return np.array([(c1 * n2[1] - c2 * n1[1]) / d, (n1[0] * c2 - n2[0] * c1) / d])
            P1, P2, P3 = meet(a, b), meet(b, c), meet(c, a)
            if A - th3 * cr(P2 - P1, P3 - P1) / 2 > 0:
                return True
    per = sum(np.linalg.norm(V[(i + 1) % 5] - V[i]) for i in range(5))
    return per * per - ka * A > 0


_RNG = np.random.default_rng(12345)


def all_samples_excluded(box):
    """heuristic only: True if the centre, the 64 corners and 16 random points are all float-excluded (or invalid)."""
    lo = np.array([a for a, b in box]); hi = np.array([b for a, b in box])
    pts = [(lo + hi) / 2] + [np.where(np.array(s) > 0, hi, lo) for s in itertools.product((-1, 1), repeat=6)] + \
          [lo + (hi - lo) * _RNG.random(6) for _ in range(16)]
    return all(float_excluded(x) for x in pts)


def run_chunk(args):
    box0, coarse, fine, path = args
    W0 = np.array([hi - lo for lo, hi in ROOT])
    stack = [tuple(box0)]
    counts = {'INVALID': 0, 'EXCLUDED': 0, 'REMAINING': 0}; vol = {'INVALID': 0.0, 'EXCLUDED': 0.0, 'REMAINING': 0.0}
    crit = {}; n = 0
    with gzip.open(path, 'wt') as fh:
        while stack:
            box = stack.pop(); n += 1
            lab, why = classify(box)
            w = np.array([hi - lo for lo, hi in box]); rel = w / W0
            if lab == 'OPEN':
                wmax = float(rel.max())
                if wmax <= fine * 1.0000001:
                    lab = 'REMAINING'
                elif wmax <= coarse * 1.0000001 and not all_samples_excluded(box):
                    lab = 'REMAINING'
            if lab == 'OPEN':
                i = int(np.argmax(rel)); lo, hi = box[i]; mid = (lo + hi) / 2
                b1 = list(box); b1[i] = (lo, mid); b2 = list(box); b2[i] = (mid, hi)
                stack.append(tuple(b1)); stack.append(tuple(b2))
                continue
            counts[lab] += 1; vol[lab] += float(np.prod(w))
            key = why.split('_')[0] if (why and lab == 'EXCLUDED') else (why[:6] if why else 'none')
            crit[key] = crit.get(key, 0) + 1
            fh.write(json.dumps([box, lab, why]) + '\n')
    return dict(nodes=n, counts=counts, vol=vol, crit=crit)


def main():
    out = sys.argv[1]; coarse = float(sys.argv[2]) if len(sys.argv) > 2 else 0.25; fine = float(sys.argv[3]) if len(sys.argv) > 3 else 0.0625
    workers = int(sys.argv[4]) if len(sys.argv) > 4 else 2
    os.makedirs(out, exist_ok=True)
    chunks = []
    for bits in itertools.product((0, 1), repeat=6):        # 64 root chunks (one bisection per coordinate)
        b = []
        for (lo, hi), s_ in zip(ROOT, bits):
            mid = (lo + hi) / 2; b.append((lo, mid) if s_ == 0 else (mid, hi))
        chunks.append((b, coarse, fine, os.path.join(out, 'leaves_%02d.jsonl.gz' % len(chunks))))
    t0 = time.time()
    from multiprocessing import Pool
    tot = {'nodes': 0, 'counts': {}, 'vol': {}, 'crit': {}}
    with Pool(workers) as pool:
        for k, r in enumerate(pool.imap_unordered(run_chunk, chunks)):
            tot['nodes'] += r['nodes']
            for f in ('counts', 'vol', 'crit'):
                for a, b in r[f].items():
                    tot[f][a] = tot[f].get(a, 0) + b
            print('chunk', k + 1, '/64', r['counts'], round(time.time() - t0), 's', flush=True)
    total = float(np.prod([hi - lo for lo, hi in ROOT]))
    summ = dict(root=ROOT, coarse=coarse, fine=fine, nodes=tot['nodes'], counts=tot['counts'], volume=tot['vol'],
                root_volume=total, volume_fraction={k: v / total for k, v in tot['vol'].items()}, criteria=tot['crit'],
                sec=round(time.time() - t0, 1), note='K (convex representatives not excluded) is contained in the union of REMAINING boxes')
    json.dump(summ, open(os.path.join(out, 'summary.json'), 'w'), indent=1)
    print(json.dumps(summ), flush=True)


if __name__ == '__main__':
    main()
