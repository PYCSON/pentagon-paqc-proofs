"""Far-region exclusion probe (float, NOT rigorous): which convex pentagons are excluded by
 (a) half-plane subsets: P = intersection of 5 edge half-planes; any 4 (3) of them with bounded intersection Q give a convex
     quadrilateral (triangle) Q containing P, so F(P) >= l*_4 A(P)/A(Q)  (l*_4 = 2 pi^2, Polya-Szego n=4)
     resp. F(P) >= l*_3 A(P)/A(Q)  (l*_3 = 4 pi^2/sqrt 3, n=3);
 (b) Hersch-Protter for convex domains: lambda_1 >= pi^2 / (4 r_in^2).
How far (chart distance r, minimised over the 10 labelings) can a NON-excluded convex pentagon be from the regular one?"""
import sys, itertools, numpy as np
from scipy.optimize import linprog, minimize
sys.path.insert(0, '<sandbox>/research-hub/lines/D-topics/probes/PENT/local/t1_sweep')
from run_t1sweep import r5_params
FS = 18.919134195733918; L4 = 2 * np.pi ** 2; L3 = 4 * np.pi ** 2 / np.sqrt(3)
XS = r5_params()

def verts(x): return np.array([[0, 0], [1, 0], [x[0], x[1]], [x[2], x[3]], [x[4], x[5]]], float)
def area(V): return 0.5 * sum(V[i][0] * V[(i + 1) % len(V)][1] - V[i][1] * V[(i + 1) % len(V)][0] for i in range(len(V)))
def convex_ccw(V):
    n = len(V)
    for i in range(n):
        a, b, c = V[i], V[(i + 1) % n], V[(i + 2) % n]
        if (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]) <= 1e-12: return False
    return True
def lines(V):  # half-plane n.x <= c for each edge (CCW polygon: interior on the left)
    out = []
    for i in range(5):
        a, b = V[i], V[(i + 1) % 5]; t = b - a; nrm = np.array([t[1], -t[0]]); out.append((nrm, nrm @ a))
    return out
def meet(l1, l2):
    M = np.array([l1[0], l2[0]])
    if abs(np.linalg.det(M)) < 1e-14: return None
    return np.linalg.solve(M, [l1[1], l2[1]])
def tri_area(a, b, c): return abs((b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])) / 2
def contained_polys(V):
    """areas of the convex quadrilaterals / triangles obtained by dropping 1 / 2 edge half-planes, when bounded."""
    L = lines(V); quads = []; tris = []
    for j in range(5):            # drop edge j: lines j-1 and j+1 meet at w beyond edge j?
        w = meet(L[(j - 1) % 5], L[(j + 1) % 5])
        if w is not None and L[j][0] @ w > L[j][1] + 1e-12:
            quads.append(area(V) + tri_area(V[j], w, V[(j + 1) % 5]))
    for S in itertools.combinations(range(5), 3):     # keep 3 lines: bounded iff their triangle is the feasible region
        a = meet(L[S[0]], L[S[1]]); b = meet(L[S[1]], L[S[2]]); c = meet(L[S[0]], L[S[2]])
        if a is None or b is None or c is None: continue
        g = (a + b + c) / 3
        if all(L[i][0] @ g <= L[i][1] + 1e-12 for i in S):
            tris.append(tri_area(a, b, c))
    return quads, tris
def inradius(V):
    L = lines(V); A = np.array([[n[0], n[1], np.linalg.norm(n)] for n, _ in L]); b = np.array([c for _, c in L])
    r = linprog([0, 0, -1], A_ub=A, b_ub=b, bounds=[(None, None), (None, None), (0, None)])
    return r.x[2]
def bound(x):
    V = verts(x)
    if not convex_ccw(V): return None
    A = area(V); best = 0.0; which = ''
    quads, tris = contained_polys(V)
    for aq in quads:
        if L4 * A / aq > best: best, which = L4 * A / aq, 'quad'
    for at in tris:
        if L3 * A / at > best: best, which = L3 * A / at, 'tri'
    hp = np.pi ** 2 * A / (4 * inradius(V) ** 2)
    if hp > best: best, which = hp, 'HP'
    # strip: a convex polygon of minimal width w lies in a strip of width w, lambda_1 >= pi^2 / w^2 (domain monotonicity)
    w = min(max(abs((V[(i + 1) % 5] - V[i])[0] * (V[j] - V[i])[1] - (V[(i + 1) % 5] - V[i])[1] * (V[j] - V[i])[0]) / np.linalg.norm(V[(i + 1) % 5] - V[i]) for j in range(5)) for i in range(5))
    st = np.pi ** 2 * A / w ** 2
    if st > best: best, which = st, 'strip'
    return best, which
def chart(V):  # 10 labelings -> chart points
    out = []
    for W in (V, V[::-1] * np.array([1, -1])):    # reflection keeps CCW after reversing order
        W = np.array(W)
        for s in range(5):
            U = np.roll(W, -s, axis=0); U = U - U[0]; e = U[1]; z = complex(e[0], e[1])
            Z = (U[:, 0] + 1j * U[:, 1]) / z
            out.append(np.array([Z[2].real, Z[2].imag, Z[3].real, Z[3].imag, Z[4].real, Z[4].imag]))
    return out
def rdist(x): return min(np.linalg.norm(y - XS) for y in chart(verts(x)))

rng = np.random.default_rng(1)
N = int(sys.argv[1]) if len(sys.argv) > 1 else 20000
import time; T0 = time.time()
keep = []; nconv = 0; ex = {'quad': 0, 'tri': 0, 'HP': 0, 'strip': 0}
for _ in range(N):
    x = XS + rng.normal(size=6) * rng.choice([0.3, 0.7, 1.5])
    b = bound(x)
    if b is None: continue
    nconv += 1
    if b[0] > FS: ex[b[1]] += 1
    else: keep.append(x)
    if _ % 2000 == 0: print('  ..', _, round(time.time() - T0), 's', flush=True)
rs = np.array([rdist(x) for x in keep])
print('samples', N, 'convex', nconv, 'excluded by', ex, 'NOT excluded', len(keep))
print('r of not-excluded: quantiles 50/90/99/max', np.round(np.percentile(rs, [50, 90, 99, 100]), 3))
# push outward: maximise r subject to not excluded (penalty), from the 20 farthest survivors
def obj(x):
    b = bound(x)
    if b is None or b[0] > FS: return 10.0
    return -rdist(x)
far = []
for i in np.argsort(-rs)[:20]:
    r = minimize(obj, keep[i], method='Nelder-Mead', options=dict(maxiter=1500, xatol=1e-5, fatol=1e-7))
    if r.fun < 0: far.append((-r.fun, r.x))
far.sort(key=lambda t: -t[0])
print('max r of a non-excluded convex pentagon (local search):', round(far[0][0], 4))
V = verts(far[0][1]); print('  its vertices', np.round(V, 3).tolist(), 'bound', bound(far[0][1]))
