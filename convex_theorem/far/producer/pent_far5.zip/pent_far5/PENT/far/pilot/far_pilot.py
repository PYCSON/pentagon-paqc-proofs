"""Far-region pilot, step 2: rigorous branch-and-bound on sampled dyadic sub-boxes (Claude, 2026-11-06).
The leaf proofs are rigorous ball arithmetic; the pilot's purpose is to MEASURE the cost structure of the far region
(nodes, table corners, narrow-band volume), not to certify the far region.

Chart and root: the longest-edge chart of ../far_exclude.py.  Leaf types (ARCH_V2.md section 5):
  INVALID   no representative in the box (far_exclude.classify);
  NEAR      some labelling h has sup |phi_h(x) - c|^2 < 9/25 on the box (plan_cells.phi_box_mv, outward-rounded floats):
            every pentagon of the box has d(P) < 3/5, so it belongs to the near region or N;
  CONST     excluded by a constant criterion: Q4 (= S with Polya's 2 pi^2), Q3, HP (far_exclude.classify, natural and
            mean-value forms), F*_up = 18.919134195733914;
  T         excluded by the quadrilateral table: L * r_lo > F*_up with L the min of the certified min-corner bounds of the
            dyadic table cells (side S0) meeting the 4-D enclosure X4 of the normalised enclosing quadrilateral
            (dimdesc.box_geometry, with the endpoints additionally rounded OUTWARD here: gap G11);
  BAND      still open with max half-width <= band_hw: left to the five-gon PAQC (its cost is estimated separately from
            the narrow-band measurements of ../qtable/band_probe.py);
  BUDGET    still open when the node budget of the box is exhausted.
Pilot boxes: dyadic sub-boxes of depth D (bisection i cuts coordinate i mod 6) chosen PROPORTIONAL TO THEIR FAR-K
VOLUME (uniform far-K points of far_strata.py's classification, each mapped to its box), so that
    total cost of the K-carrying boxes  ~  (mean over sampled boxes of cost / K-volume of the box) * total K-volume.
Table: on-disk, shared, resumable (region_exclude.Table, corners.jsonl + cells.jsonl in OUT/table/).
T modes: --tmode rig  certified table cells (corner certificates, slow);  --tmode fem  FLOAT PROXY of the table: cell
bound = 0.96 * FEM F(Q) at the cell centre (lam1(Q, 8) * |Q|; the P1 value at n = 8 is about 1.2% above the n = 24
value and the measured min-corner cell loss at side 1/32 is 1-3%); the geometry of every leaf stays rigorous, only the table value is a stand-in, so the fem mode measures the
B&B structure (leaf widths, cells touched = the table that the rigorous run would have to certify) without paying
for the corners.  --maxcells caps the number of table cells a box may query (wider X4 -> split).
Usage: python3 far_pilot.py OUT [--D 16] [--nboxes 8] [--seed 2] [--budget 60000] [--band-hw 0.03] [--S0 0.03125]
                           [--maxtw 0.5] [--maxcells 4096] [--tmode fem|rig] [--sroute 0.003] [--workers 2] [--K 8] [--nseg 300] [--hours 1.9] [--only i,j]"""
import os, sys, json, math, time, itertools, argparse
import numpy as np
from multiprocessing import Pool
HERE = os.path.dirname(os.path.abspath(__file__))
for p in ('..', os.path.join('..', 'qtable'), os.path.join('..', '..', 'v2_cover'), os.path.join('..', '..', 'v2_quad')):
    sys.path.insert(0, os.path.join(HERE, p))
from flint import arb
import far_exclude as FE
import plan_cells as PC
import pentquad as PQ
import dimdesc as DD
import region_exclude as RE
import far_strata as FS
from fem_check import lam1

FSTAR_UP = '18.919134195733914'
FE.FSTAR_UP = arb(FSTAR_UP); FE.TH4 = FE.FSTAR_UP / (2 * FE.PI * FE.PI)
FE.TH3 = FE.FSTAR_UP * arb(3).sqrt() / (4 * FE.PI * FE.PI); FE.KAPPA = 16 * FE.FSTAR_UP / (FE.PI * FE.PI)
DD.FUP = arb(FSTAR_UP)
INF = float('inf')
NEAR2 = arb(9) / arb(25)


def near(lo, hi):
    """some h with sup |phi_h(x) - c|^2 < 9/25 on the box (h = 0 is the identity)."""
    for h in range(10):
        enc = PC.phi_box_mv(lo, hi, h)
        if enc is None:
            continue
        olo, ohi = enc; s = arb(0)
        for i in range(6):
            a = arb(olo[i]) - arb(float(PC.C[i])); b = arb(ohi[i]) - arb(float(PC.C[i]))
            s += arb(max((a * a).upper(), (b * b).upper()))
        if s < NEAR2:
            return h
    return None


def geometry_safe(lo, hi, k, rot):
    """dimdesc.box_geometry with its float endpoints rounded outward (r_lo down, X4 box outward): gap G11."""
    g = DD.box_geometry(lo, hi, k, rot)
    if not g['ok']:
        return g
    g['r_lo'] = math.nextafter(g['r_lo'], -INF); g['r_arb'] = arb(g['r_lo'])
    g['lo4'] = [math.nextafter(v, -INF) for v in g['lo4']]; g['hi4'] = [math.nextafter(v, INF) for v in g['hi4']]
    return g


def best_k_rot(lo, hi):
    """deleted edge with the largest float area ratio at the centre, base edge = longest edge of Q (float choice; the
    rigorous geometry is then computed for that (k, rot) only)."""
    x = (np.array(lo) + np.array(hi)) / 2; qc = FS.quad_chart_point(x)
    if qc is None:
        return None
    k, rot, x4, ratio = qc
    # dimdesc's rotation convention: Q = [V[k+2], V[k+3], V[k-1], W] rolled by rot
    return k, rot, ratio


def pick_boxes(D, nboxes, seed, M=400000):
    """far-K points of the root box (float classification of far_strata), each mapped to its depth-D box;
    boxes are then drawn in proportion to their point counts (= far-K volume)."""
    rng = np.random.default_rng(seed); lo = np.array([a for a, b in FE.ROOT]); hi = np.array([b for a, b in FE.ROOT])
    X = lo + (hi - lo) * rng.random((M, 6)); v = FS.valid_mask(X); Xv = X[v]; d = FS.dist_c(Xv); far = Xv[d >= 0.6]
    ex = np.array([FE.float_excluded(x) for x in far], bool); K = far[~ex]
    widths = (hi - lo) / 2.0 ** np.array([sum(1 for i in range(D) if i % 6 == c) for c in range(6)])
    idx = np.floor((K - lo) / widths).astype(int); keys = [tuple(r) for r in idx]
    cnt = {}
    for key in keys:
        cnt[key] = cnt.get(key, 0) + 1
    ks = list(cnt); w = np.array([cnt[k] for k in ks], float); w /= w.sum()
    chosen = rng.choice(len(ks), size=min(nboxes, len(ks)), replace=False, p=w)
    out = []
    for ci in chosen:
        key = ks[ci]; blo = lo + np.array(key) * widths; bhi = blo + widths
        out.append(dict(key=list(map(int, key)), lo=blo.tolist(), hi=bhi.tolist(), K_points=int(cnt[key]), K_share=cnt[key] / len(K),
                        K_vol=cnt[key] / len(K) * 0.0))
    info = dict(M=M, valid=int(v.sum()), far=int(len(far)), farK=int(len(K)), K_vol_est=len(K) / M * float(np.prod(hi - lo)),
                boxes_with_K=len(ks), box_vol=float(np.prod(widths)))
    for b in out:
        b['K_vol'] = b['K_share'] * info['K_vol_est']
    return out, info


class FemTable:
    """float proxy of the quadrilateral table (see module docstring); same cell keys as region_exclude.Table."""
    def __init__(self, out, S0):
        self.S0 = S0; self.fl = os.path.join(out, 'cells_fem.jsonl'); self.cells = {}; self.corners = {}; self.corner_sec = 0.0
        if os.path.exists(self.fl):
            for line in open(self.fl):
                d = json.loads(line); self.cells[tuple(d['key'])] = d['LB']
        self.fem_sec = 0.0

    def side(self, lev):
        return self.S0 / 2 ** lev

    def cells_for(self, lo4, hi4, lev):
        s = self.side(lev)
        rng = [range(math.floor(lo4[i] / s), math.floor(hi4[i] / s) + 1) for i in range(4)]
        return [(lev,) + idx for idx in itertools.product(*rng)]

    def missing_corners(self, keys):
        return {}

    def add_corners(self, results):
        pass

    def cell_lb(self, key):
        if key in self.cells:
            return self.cells[key]
        s = self.side(key[0]); mid = [(i + 0.5) * s for i in key[1:]]
        Q = np.array([[0, 0], [1, 0], [mid[0], mid[1]], [mid[2], mid[3]]], float); t = time.time()
        try:
            LB = 0.96 * lam1(Q, 8) * abs(PQ.area(Q))
        except Exception:
            LB = None
        self.fem_sec += time.time() - t; self.cells[key] = LB
        with open(self.fl, 'a') as f:
            f.write(json.dumps(dict(key=list(key), LB=LB)) + '\n')
        return LB


def run_box(b, a, T, pool, fh):
    lo0, hi0 = b['lo'], b['hi']; t0 = time.time(); nodes = 0
    counts = {}; vol = {}; crit = {}; tgeom = 0.0; tcls = 0.0; tnear = 0.0; cells_touched = set(); corners0 = len(T.corners)
    wave = [(lo0, hi0, 0)]
    def leaf(lo, hi, st, why=None, extra=None):
        v = float(np.prod(np.array(hi) - np.array(lo))); counts[st] = counts.get(st, 0) + 1; vol[st] = vol.get(st, 0.0) + v
        if why:
            crit[why] = crit.get(why, 0) + 1
        fh.write(json.dumps(dict(box=b['key'], lo=lo, hi=hi, status=st, why=why, **(extra or {}))) + '\n')
    stop = False
    while wave and not stop:
        nxt = []; pend = []
        for lo, hi, depth in wave:
            nodes += 1
            if nodes > a.budget:
                leaf(lo, hi, 'BUDGET'); continue
            t = time.time(); lab, why = FE.classify([(lo[i], hi[i]) for i in range(6)]); tcls += time.time() - t
            if lab == 'INVALID':
                leaf(lo, hi, 'INVALID', why); continue
            if lab == 'EXCLUDED':
                leaf(lo, hi, 'CONST', why); continue
            t = time.time(); h = near(lo, hi); tnear += time.time() - t
            if h is not None:
                leaf(lo, hi, 'NEAR', 'h%d' % h); continue
            hw = max((hi[i] - lo[i]) / 2 for i in range(6))
            kr = best_k_rot(lo, hi)
            if kr is not None:
                k, rot, ratio_c = kr
                s_route = 2 * math.pi ** 2 * ratio_c > float(FSTAR_UP) * (1 + a.sroute)
                if not s_route:
                    t = time.time(); g = geometry_safe(lo, hi, k, rot); tgeom += time.time() - t
                    if g['ok']:
                        if DD.TWO_PI2 * g['r_arb'] > DD.FUP:
                            leaf(lo, hi, 'CONST', 'S_mv'); continue
                        widths = [g['hi4'][i] - g['lo4'][i] for i in range(4)]
                        if max(widths) <= a.maxtw:
                            keys = T.cells_for(g['lo4'], g['hi4'], 0)
                            if len(keys) <= a.maxcells:
                                pend.append((lo, hi, depth, k, g, keys)); continue
            if hw <= a.band_hw:
                leaf(lo, hi, 'BAND'); continue
            nxt += [(l_, h_, d_) for l_, h_, d_, q_ in RE.split(lo, hi, depth, 0)]
        need = {}
        for item in pend:
            need.update(T.missing_corners(item[5]))
        if need:
            tc = time.time()
            for one in pool.imap_unordered(RE.corner_job, [(k_, v_, a.K, a.nseg) for k_, v_ in need.items()], chunksize=1):
                T.add_corners([one])
            T.corner_sec += time.time() - tc
        for lo, hi, depth, k, g, keys in pend:
            cells_touched.update(keys)
            lbs = [T.cell_lb(key) for key in keys]; req = float((DD.FUP / g['r_arb']).upper())
            if all(L is not None for L in lbs) and min(lbs) > req:
                leaf(lo, hi, 'T', 'k%d' % k, dict(r_lo=g['r_lo'], L=min(lbs), ncells=len(keys))); continue
            hw = max((hi[i] - lo[i]) / 2 for i in range(6))
            if hw <= a.band_hw:
                leaf(lo, hi, 'BAND', 'T_short', dict(r_lo=g['r_lo'], L=min([L for L in lbs if L is not None], default=None))); continue
            nxt += [(l_, h_, d_) for l_, h_, d_, q_ in RE.split(lo, hi, depth, 0)]
        fh.flush(); wave = nxt
        if a.hours and time.time() - a.t_start > 3600 * a.hours:
            for lo, hi, depth in wave:
                leaf(lo, hi, 'STOPPED')
            stop = True
    v0 = float(np.prod(np.array(hi0) - np.array(lo0)))
    return dict(box=b['key'], K_vol=b['K_vol'], K_points=b['K_points'], box_vol=v0, nodes=nodes, counts=counts, vol=vol, crit=crit,
                vol_frac={k: v / v0 for k, v in vol.items()}, corners_new=len(T.corners) - corners0, cells_touched=len(cells_touched),
                sec=round(time.time() - t0, 1), sec_classify=round(tcls, 1), sec_near=round(tnear, 1), sec_geometry=round(tgeom, 1),
                sec_fem=round(getattr(T, 'fem_sec', 0.0), 1), tmode=a.tmode,
                complete=not stop and counts.get('BUDGET', 0) == 0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('out'); ap.add_argument('--D', type=int, default=16); ap.add_argument('--nboxes', type=int, default=8)
    ap.add_argument('--seed', type=int, default=2); ap.add_argument('--budget', type=int, default=60000)
    ap.add_argument('--band-hw', type=float, default=0.03); ap.add_argument('--S0', type=float, default=1 / 32)
    ap.add_argument('--maxtw', type=float, default=0.5); ap.add_argument('--sroute', type=float, default=0.003)
    ap.add_argument('--maxcells', type=int, default=4096); ap.add_argument('--tmode', default='fem')
    ap.add_argument('--workers', type=int, default=2); ap.add_argument('--K', type=int, default=8); ap.add_argument('--nseg', type=int, default=300)
    ap.add_argument('--hours', type=float, default=1.9); ap.add_argument('--only', default='')
    a = ap.parse_args(); a.t_start = time.time()
    os.makedirs(os.path.join(a.out, 'table'), exist_ok=True)
    bf = os.path.join(a.out, 'pilot_boxes.json')
    if os.path.exists(bf):
        B = json.load(open(bf))
    else:
        boxes, info = pick_boxes(a.D, a.nboxes, a.seed)
        B = dict(boxes=boxes, info=info, args={k: v for k, v in vars(a).items() if k != 't_start'}); json.dump(B, open(bf, 'w'), indent=1)
    rf = os.path.join(a.out, 'results.jsonl')
    done = {tuple(json.loads(l)['box']) for l in open(rf)} if os.path.exists(rf) else set()
    T = RE.Table(os.path.join(a.out, 'table'), a.S0) if a.tmode == 'rig' else FemTable(os.path.join(a.out, 'table'), a.S0); pool = Pool(a.workers)
    only = [int(v) for v in a.only.split(',')] if a.only else None
    with open(os.path.join(a.out, 'leaves.jsonl'), 'a') as fh, open(rf, 'a') as rfh:
        for i, b in enumerate(B['boxes']):
            if tuple(b['key']) in done or (only is not None and i not in only):
                continue
            r = run_box(b, a, T, pool, fh); r['i'] = i
            rfh.write(json.dumps(r) + '\n'); rfh.flush(); print(json.dumps(r), flush=True)
            if a.hours and time.time() - a.t_start > 3600 * a.hours:
                print('time budget reached', flush=True); break
    pool.close()


if __name__ == '__main__':
    main()
