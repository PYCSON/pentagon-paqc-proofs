"""Far-region pilot, step 3: extrapolate the measured costs to the whole far region (Claude, 2026-11-06; ESTIMATE).

Inputs: OUT/results.jsonl (per pilot box: nodes, leaf volumes, corners, seconds), OUT/pilot_boxes.json (boxes drawn in
proportion to their far-K volume, K_vol_est), far_strata.json (FEM narrow-band share), OUT/table/corners.jsonl.
Horvitz-Thompson: the boxes were drawn with probability p_b = K_points_b / sum K_points, so
    sum over all K-carrying boxes of X_b  ~  mean_b (X_b / K_vol_b) * K_vol_est.
Costs (seconds) are the pilot machine's (sandbox: one corner certificate ~2.5 s, one node ~4 ms); the user's machine
measured 1.2-2.5 s per corner on v2_region.  The narrow band (BAND leaves) is priced with the five-gon PAQC of
../qtable/band_probe.py: rho = 0.03 cells, ~1 new corner (5 s sandbox) + T1 per cell, cells = volume / 0.06^6.
Usage: python3 far_pilot_analyze.py OUT [--corner-sec 2.5] [--band-cell-sec 12]"""
import sys, os, json, argparse
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('out'); ap.add_argument('--corner-sec', type=float, default=2.5)
    ap.add_argument('--band-cell-sec', type=float, default=12.0); a = ap.parse_args()
    R = [json.loads(l) for l in open(os.path.join(a.out, 'results.jsonl'))]
    B = json.load(open(os.path.join(a.out, 'pilot_boxes.json'))); KV = B['info']['K_vol_est']
    S = json.load(open(os.path.join(HERE, 'far_strata.json'))) if os.path.exists(os.path.join(HERE, 'far_strata.json')) else None
    ht = lambda f: float(np.mean([f(r) / r['K_vol'] for r in R])) * KV
    tot = dict(boxes=len(R), complete=sum(r['complete'] for r in R), K_vol_est=KV,
               nodes=ht(lambda r: r['nodes']), node_sec=ht(lambda r: r['sec'] - 0.0),
               corners=ht(lambda r: r['corners_new']), cells=ht(lambda r: r['cells_touched']),
               band_vol=ht(lambda r: r['vol'].get('BAND', 0.0)), open_vol=ht(lambda r: r['vol'].get('BUDGET', 0.0) + r['vol'].get('STOPPED', 0.0)),
               T_vol=ht(lambda r: r['vol'].get('T', 0.0)), CONST_vol=ht(lambda r: r['vol'].get('CONST', 0.0)),
               NEAR_vol=ht(lambda r: r['vol'].get('NEAR', 0.0)), INVALID_vol=ht(lambda r: r['vol'].get('INVALID', 0.0)))
    band_cells = tot['band_vol'] / 0.06 ** 6
    days = dict(bb_nodes=tot['node_sec'] / 86400, table_corners=tot['corners'] * a.corner_sec / 86400,
                band_paqc=band_cells * a.band_cell_sec / 86400)
    days['total'] = sum(days.values())
    per_box = [dict(i=r['i'], K_vol=r['K_vol'], nodes=r['nodes'], sec=r['sec'], corners=r['corners_new'], cells=r['cells_touched'],
                    vol_frac={k: round(v, 4) for k, v in r['vol_frac'].items()}, complete=r['complete']) for r in R]
    out = dict(totals=tot, band_cells=band_cells, cpu_days=days, per_box=per_box,
               strata=(S['strata'] if S else None), fem_margin=(S['fem_margin'] if S else None),
               note='Horvitz-Thompson over boxes drawn proportional to far-K volume; sandbox seconds; corners are not shared between pilot boxes, so the corner total is an upper estimate')
    json.dump(out, open(os.path.join(a.out, 'analysis.json'), 'w'), indent=1)
    print(json.dumps({k: v for k, v in out.items() if k != 'per_box'}, indent=1))
    for p in per_box:
        print(p)


if __name__ == '__main__':
    main()
