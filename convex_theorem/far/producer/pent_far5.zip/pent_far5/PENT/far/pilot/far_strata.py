"""Far-region pilot, step 1: float stratification of the longest-edge root box (Claude, 2026-11-06; float, ESTIMATE).

Root box of ../far_exclude.py (volume 24) split into 2^D dyadic sub-boxes (D bisections, cycling through the six
coordinates).  In each sub-box M uniform points are classified:
  valid    longest-edge representative (15 orientation determinants > 0, four non-base edges of length <= 1);
  near     d(P) = min_h |phi_h(x) - c| < 3/5  (c = plan_cells.C, the near region handles these);
  far      d(P) >= 3/5;
  const    far and excluded by the constant criteria (Q4 = S with 2 pi^2, Q3, HP: far_exclude.float_excluded);
  K        far, valid, not const-excluded: needs the quadrilateral table (T) or a PAQC cell.
Strata of sub-boxes: E (no valid point), N (valid points, none far-K), K (some far-K points).  The rigorous pilot
(far_pilot.py) samples sub-boxes from each stratum; the stratum sizes give the extrapolation weights.
Also: the 4-D quadrilateral-chart image of the far-K points (deleted edge k = max area ratio, base = longest edge of Q)
and how many dyadic table cells of side S0 they touch (coverage curve: cells(n) for growing n, to see saturation),
plus the FEM table-bound margin F(Q)|P|/|Q| / F*_up (narrow band = margin <= 1 + delta).
Usage: python3 far_strata.py [--D 10] [--M 1500] [--seed 1] [--S0 0.03125]   -> far_strata.json"""
import sys, os, json, math, time, itertools, argparse
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..')); sys.path.insert(0, os.path.join(HERE, '..', '..', 'v2_cover'))
sys.path.insert(0, os.path.join(HERE, '..', '..', 'v2_quad')); sys.path.insert(0, os.path.join(HERE, '..', 'qtable'))
import far_exclude as FE
import plan_cells as PC
import pentquad as PQ
from fem_check import lam1

ROOT = FE.ROOT
FUP = PQ.FSTAR_UP


def dyadic_boxes(D):
    """2^D sub-boxes: bisection i (0-based) cuts coordinate i mod 6."""
    boxes = [[list(b) for b in ROOT]]
    for i in range(D):
        c = i % 6; nb = []
        for b in boxes:
            lo, hi = b[c]; m = (lo + hi) / 2
            b1 = [list(x) for x in b]; b1[c] = [lo, m]; b2 = [list(x) for x in b]; b2[c] = [m, hi]
            nb += [b1, b2]
        boxes = nb
    return boxes


def valid_mask(X):
    N = len(X); V = np.zeros((N, 5, 2)); V[:, 1, 0] = 1; V[:, 2] = X[:, 0:2]; V[:, 3] = X[:, 2:4]; V[:, 4] = X[:, 4:6]
    ok = np.ones(N, bool)
    for i in range(5):
        t = V[:, (i + 1) % 5] - V[:, i]
        for j in range(5):
            if j in (i, (i + 1) % 5):
                continue
            u = V[:, j] - V[:, i]; ok &= (t[:, 0] * u[:, 1] - t[:, 1] * u[:, 0]) > 0
    for i in range(1, 5):
        t = V[:, (i + 1) % 5] - V[:, i]; ok &= (t ** 2).sum(1) <= 1
    return ok


def dist_c(X):
    O = PC.orbit_np(X); return np.linalg.norm(O - PC.C, axis=2).min(0)


def quad_chart_point(x):
    """(k, rot, x4, ratio) for the deleted edge with the largest |P|/|Q| and the base edge = longest edge of Q."""
    V = PQ.verts(x); A = PQ.area(V); best = None
    for k in range(5):
        q = PQ.quad(V, k)
        if q is None:
            continue
        Q, ear = q; ratio = A / (A + ear)
        if best is None or ratio > best[0]:
            best = (ratio, k, Q)
    if best is None:
        return None
    ratio, k, Q = best
    # pentquad.quad returns (V[k+2], V[k+3], V[k-1], W); rotate so that the longest edge is q0 q1
    L = [np.linalg.norm(Q[(i + 1) % 4] - Q[i]) for i in range(4)]; rot = int(np.argmax(L))
    Qr = np.roll(Q, -rot, axis=0)
    return k, rot, PQ.quad_chart(Qr), ratio


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--D', type=int, default=10); ap.add_argument('--M', type=int, default=1500)
    ap.add_argument('--seed', type=int, default=1); ap.add_argument('--S0', type=float, default=1 / 32)
    ap.add_argument('--fem', type=int, default=3000, help='far-K points given a FEM table-bound margin')
    a = ap.parse_args(); rng = np.random.default_rng(a.seed); t0 = time.time()
    boxes = dyadic_boxes(a.D); rows = []; K4 = []; Kx = []
    for bi, b in enumerate(boxes):
        lo = np.array([x[0] for x in b]); hi = np.array([x[1] for x in b])
        X = lo + (hi - lo) * rng.random((a.M, 6))
        v = valid_mask(X); nv = int(v.sum()); row = dict(i=bi, valid=nv / a.M, far=0.0, near=0.0, const=0.0, K=0.0)
        if nv:
            Xv = X[v]; d = dist_c(Xv); far = d >= 0.6
            row['near'] = float((~far).sum()) / a.M; row['far'] = float(far.sum()) / a.M
            ex = np.array([FE.float_excluded(x) for x in Xv[far]], bool) if far.any() else np.zeros(0, bool)
            row['const'] = float(ex.sum()) / a.M; row['K'] = float((~ex).sum()) / a.M
            for x in Xv[far][~ex]:
                Kx.append(x)
        row['stratum'] = 'E' if nv == 0 else ('K' if row['K'] > 0 else 'N')
        rows.append(row)
        if bi % 128 == 0:
            print('box', bi, '/', len(boxes), round(time.time() - t0), 's', flush=True)
    vol_box = float(np.prod([hi - lo for lo, hi in ROOT])) / len(boxes)
    strata = {}
    for s in ('E', 'N', 'K'):
        R = [r for r in rows if r['stratum'] == s]
        strata[s] = dict(boxes=len(R), volume=len(R) * vol_box, valid_vol=sum(r['valid'] for r in R) * vol_box,
                         far_vol=sum(r['far'] for r in R) * vol_box, K_vol=sum(r['K'] for r in R) * vol_box,
                         near_vol=sum(r['near'] for r in R) * vol_box)
    # 4-D image of the far-K points and table-cell coverage curve
    Kx = np.array(Kx); rng.shuffle(Kx); cells = set(); curve = []; q4 = []
    for n, x in enumerate(Kx, 1):
        qc = quad_chart_point(x)
        if qc is None:
            continue
        k, rot, x4, ratio = qc; q4.append(x4)
        cells.add(tuple(int(math.floor(v / a.S0)) for v in x4))
        if n in (250, 500, 1000, 2000, 4000, 8000, 16000) or n == len(Kx):
            curve.append((n, len(cells)))
    q4 = np.array(q4)
    margins = []
    for x in Kx[:a.fem]:
        qc = quad_chart_point(x)
        if qc is None:
            continue
        k, rot, x4, ratio = qc
        Q = np.array([[0, 0], [1, 0], [x4[0], x4[1]], [x4[2], x4[3]]], float)
        try:
            FQ = lam1(Q, 24) * abs(PQ.area(Q)); margins.append(FQ * ratio / FUP)
        except Exception:
            pass
    margins = np.array(margins)
    out = dict(D=a.D, M=a.M, seed=a.seed, S0=a.S0, boxes=len(boxes), box_volume=vol_box, strata=strata,
               farK_points=int(len(Kx)), q4_quantiles={str(j): np.percentile(q4[:, j], [1, 5, 25, 50, 75, 95, 99]).round(4).tolist() for j in range(4)},
               table_cells_touched_curve=curve,
               fem_margin=dict(n=int(len(margins)), quantiles=np.percentile(margins, [1, 5, 10, 25, 50, 75, 90]).round(4).tolist(),
                               share_le_1=float((margins <= 1).mean()), share_le_1_02=float((margins <= 1.02).mean()),
                               share_le_1_05=float((margins <= 1.05).mean())),
               sec=round(time.time() - t0, 1), rows=rows)
    json.dump(out, open(os.path.join(HERE, 'far_strata.json'), 'w'), indent=1)
    print(json.dumps({k: v for k, v in out.items() if k != 'rows'}, indent=1))


if __name__ == '__main__':
    main()
