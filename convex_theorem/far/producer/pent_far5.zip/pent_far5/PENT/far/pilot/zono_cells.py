"""Zonotope enclosure of the 4-D quadrilateral chart image of a 6-D box, and the table cells it meets
(Claude, 2026-11-07; prototype for the far-region production planner, FAR_PILOT.md section 4.3).

Mean-value form: X4(x) in X4(c) + sum_j J_j(B) (x_j - c_j), J(B) the interval Jacobian (dimdesc Duals).  Splitting
J(B) = J_mid + [-J_rad, J_rad]:
    X4(B)  subset  Z := X4(c) + sum_j g_j [-1, 1]  (+)  box(-m, m),
    g_j = J_mid[:, j] * r_j   (six generators),   m_i = sum_j J_rad_ij * r_j + rad(X4_c_i)   (remainder box).
Z (+) box is a zonotope with 10 generators (the four m_i e_i included).  A table cell (4-D box) meets it iff no facet
normal separates them (separating axis theorem, both convex): facet normals of a 4-D zonotope are the normals to all
triples of generators.  The bounding box of Z (+) box is the usual mean-value box, so the cells kept are a subset of
dimdesc's cells_for.  Float with a relative pad (prototype; the production version pads with outward rounding).

measure(): on the BUDGET leaves of a pilot run, compare cells in the box vs cells meeting the zonotope, and the T
success rate (FEM proxy) with either set.   Usage: python3 zono_cells.py OUT [--n 150] [--seed 0]"""
import sys, os, json, math, itertools, argparse
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import far_pilot as FP
from flint import arb
import dimdesc as DD

PAD = 1e-9


def zonotope(lo6, hi6, k, rot):
    """returns dict(c=4-vector, G=(4,6) generators, m=4-vector remainder half-widths, bbox lo/hi) or None."""
    xb = [DD.ival(lo6[i], hi6[i]) for i in range(6)]
    turns, P, C, ratio, X4 = DD._geom(xb, k, rot)
    if not all(t > 0 for t in turns) or not (C > 0) or not (P > 0):
        return None
    cen = [arb(float((lo6[i] + hi6[i]) / 2)) for i in range(6)]
    rad = [max(abs(float(lo6[i]) - float(cen[i].mid())), abs(float(hi6[i]) - float(cen[i].mid()))) for i in range(6)]
    _, _, _, r_c, X4_c = DD._geom(cen, k, rot)
    xd = [DD.Dual(xb[i], [arb(1) if j == i else arb(0) for j in range(6)]) for i in range(6)]
    _, _, _, r_d, X4_d = DD._geom(xd, k, rot)
    c = np.array([float(X4_c[j].mid()) for j in range(4)]); m = np.array([float(X4_c[j].rad()) for j in range(4)])
    G = np.zeros((4, 6))
    for i in range(4):
        for j in range(6):
            gj = X4_d[i].g[j]; G[i, j] = float(gj.mid()) * rad[j]; m[i] += float(gj.rad()) * rad[j]
    m = m * (1 + PAD) + PAD
    ext = np.abs(G).sum(1) + m
    # the natural extension X4 is a second enclosure: intersect the bounding boxes
    nlo = np.array([float(X4[j].lower()) for j in range(4)]); nhi = np.array([float(X4[j].upper()) for j in range(4)])
    return dict(c=c, G=G, m=m, lo=np.maximum(c - ext, nlo), hi=np.minimum(c + ext, nhi), r_lo=math.nextafter(float(r_c.lower()) - 0, -math.inf), r_c=r_c, r_d=r_d)


def normals(G, m):
    """facet normals of the zonotope with generators G (4x6) and the axis box m: null vectors of generator triples."""
    gens = [G[:, j] for j in range(6)] + [m[i] * np.eye(4)[i] for i in range(4) if m[i] > 0]
    N = []
    for a, b, c in itertools.combinations(range(len(gens)), 3):
        M = np.array([gens[a], gens[b], gens[c]])          # 3 x 4
        n = np.array([(-1) ** i * np.linalg.det(np.delete(M, i, axis=1)) for i in range(4)])
        s = np.linalg.norm(n)
        if s > 1e-14:
            N.append(n / s)
    return np.array(N) if N else np.zeros((0, 4))


def cells_meeting(z, S0, lev=0):
    """keys (lev, i0..i3) of the dyadic cells of side S0/2^lev meeting the zonotope (SAT filter of the bbox cells)."""
    s = S0 / 2 ** lev; lo, hi = z['lo'], z['hi']
    rng = [range(math.floor(lo[i] / s), math.floor(hi[i] / s) + 1) for i in range(4)]
    idx = np.array(list(itertools.product(*rng)), dtype=float)
    if len(idx) == 0:
        return []
    N = normals(z['G'], z['m'])
    if len(N) == 0:
        return [(lev,) + tuple(int(v) for v in r) for r in idx]
    # support of the zonotope along n: n.c +- (sum_j |n.g_j| + sum_i |n_i| m_i)
    zc = N @ z['c']; zh = np.abs(N @ z['G']).sum(1) + np.abs(N) @ z['m']
    zlo, zhi = zc - zh - PAD, zc + zh + PAD
    # support of each cell along n: n.centre +- sum_i |n_i| s/2
    cc = (idx + 0.5) * s; ch = (np.abs(N) * (s / 2)).sum(1)      # (nN,)
    proj = cc @ N.T                                                # (ncells, nN)
    keep = ((proj + ch) >= zlo) & ((proj - ch) <= zhi)
    keep = keep.all(1)
    return [(lev,) + tuple(int(v) for v in r) for r in idx[keep]]


def measure(out, n, seed):
    import far_strata as FS
    L = [json.loads(l) for l in open(os.path.join(out, 'leaves.jsonl'))]
    B = [d for d in L if d['status'] == 'BUDGET']
    T = FP.FemTable(os.path.join(out, 'table'), 1 / 32)
    rng = np.random.default_rng(seed); rows = []
    for i in rng.choice(len(B), min(n, len(B)), replace=False):
        d = B[i]; lo, hi = d['lo'], d['hi']; kr = FP.best_k_rot(lo, hi)
        if kr is None:
            continue
        k, rot, _ = kr; z = zonotope(lo, hi, k, rot)
        if z is None:
            continue
        nb = int(np.prod([math.floor(z['hi'][j] / (1 / 32)) - math.floor(z['lo'][j] / (1 / 32)) + 1 for j in range(4)]))
        if nb > 20000:
            rows.append(dict(w=max(np.array(hi) - np.array(lo)), nbox=nb, nzono=None)); continue
        keys = cells_meeting(z, 1 / 32); need = float(FP.FSTAR_UP) / z['r_lo']
        allk = T.cells_for(z['lo'].tolist(), z['hi'].tolist(), 0)
        lb_box = [T.cell_lb(key) for key in allk]; lb_z = [T.cell_lb(key) for key in keys]
        ok_box = all(v is not None for v in lb_box) and min(lb_box) > need
        ok_z = all(v is not None for v in lb_z) and min(lb_z) > need
        rows.append(dict(w=float(max(np.array(hi) - np.array(lo))), nbox=len(allk), nzono=len(keys), T_box=bool(ok_box), T_zono=bool(ok_z)))
        print(rows[-1], flush=True)
    R = [r for r in rows if r['nzono'] is not None]
    print('leaves', len(rows), 'measured', len(R), 'cells box -> zonotope: median ratio %.1f' % np.median([r['nbox'] / max(1, r['nzono']) for r in R]),
          'T success box %d / zono %d of %d' % (sum(r['T_box'] for r in R), sum(r['T_zono'] for r in R), len(R)))
    json.dump(rows, open(os.path.join(out, 'zono_measure.json'), 'w'), indent=1)


if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('out'); ap.add_argument('--n', type=int, default=150); ap.add_argument('--seed', type=int, default=0)
    a = ap.parse_args(); measure(a.out, a.n, a.seed)
