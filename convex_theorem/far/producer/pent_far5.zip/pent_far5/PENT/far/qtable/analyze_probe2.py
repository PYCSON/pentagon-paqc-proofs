import json, numpy as np
rows = [json.loads(l) for l in open('<sandbox>/reflex_test/quad_table_probe2.jsonl')]
r = np.array([x['r'] for x in rows]); t = np.array([x['table_bound'] for x in rows]) / 18.919134; F = np.array([x['F'] for x in rows]) / 18.919134
print('samples', len(rows))
bins = [0, 0.3, 0.45, 0.6, 0.75, 0.9, 1.1, 1.4, 3]
print('r bin        n   F/F* med  table/F*>1.002  >1.02  >1.05')
for a, b in zip(bins, bins[1:]):
    m = (r >= a) & (r < b)
    if m.sum() == 0: continue
    print('[%.2f,%.2f) %4d   %.3f       %3d (%3.0f%%)   %3d    %3d' % (a, b, m.sum(), np.median(F[m]), (t[m] > 1.002).sum(), 100 * (t[m] > 1.002).mean(), (t[m] > 1.02).sum(), (t[m] > 1.05).sum()))
print('overall excluded(>1.002) %.0f%%, (>1.05) %.0f%%' % (100 * (t > 1.002).mean(), 100 * (t > 1.05).mean()))
bad = [x for x in rows if x['table_bound'] / 18.919134 <= 1.02]
print('not excluded at 2%%: %d; their r: %s; F/F*: %s' % (len(bad), np.round(sorted(x['r'] for x in bad), 2), np.round(sorted(x['F'] / 18.919134 for x in bad), 3)))
