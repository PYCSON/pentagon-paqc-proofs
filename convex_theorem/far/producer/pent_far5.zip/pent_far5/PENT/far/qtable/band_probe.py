"""PAQC (T1, convex gate) on the far 'band': uniform K samples with r >= 0.6 that the quadrilateral/triangle table bound
does NOT exclude (probe 2).  For each: largest certified rho among the list (tried from large to small)."""
import sys, json, numpy as np
sys.path.insert(0, '.')
import run_t1sweep as W
W.PRM = json.load(open('params_far.json')); W.PRM['max_boxes'] = 6000
rows = [json.loads(l) for l in open('<sandbox>/reflex_test/quad_table_probe2.jsonl')]
band = [r for r in rows if r['r'] >= 0.6 and r['table_bound'] / 18.919134 <= 1.002]
k, m = int(sys.argv[1]), int(sys.argv[2])          # worker k of m
rng = np.random.default_rng(5)
for i, rec in enumerate(band):
    if i % m != k: continue
    p = np.array(rec['x'])
    for rho in (0.03, 0.02, 0.014):
        o = W.test_rho(p, rho, rng)
        print(json.dumps(dict(i=i, r=rec['r'], F=rec['F'], table=rec['table_bound'], **{q: o.get(q) for q in ('rho', 'ok', 'why', 'boxes', 'bb_sec', 'sec', 'precheck', 'mincorner_LB')})), flush=True)
        if o.get('ok'): break
