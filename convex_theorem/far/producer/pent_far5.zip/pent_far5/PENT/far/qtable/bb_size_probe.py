"""Float estimate of how large the 6-D exclusion boxes can be in the table route: at sample x (probe 2, r >= 0.6,
excluded), b(x) = lambda_1(Q_j(x)) |P(x)| for the best dropped edge j; sup-norm box of half-width d keeps b > F*(1+delta)
if d < (b - F*(1+delta)) / sum_i |db/dx_i|  (first order).  Box count ~ vol(K_far) * mean (2d)^-6."""
import sys, json, numpy as np
sys.path.insert(0, '<sandbox>/reflex_test')
from quad_table_probe import verts, area, containing, lam, FS
rows = [json.loads(l) for l in open('<sandbox>/reflex_test/quad_table_probe2.jsonl')]
far = [r for r in rows if r['r'] >= 0.6 and r['table_bound'] / FS > 1.002]
rng = np.random.default_rng(2); pick = rng.choice(len(far), size=int(sys.argv[1]), replace=False)
def best(x, jfix=None):
    V = verts(x); A = area(V); out = []
    for idx, (kind, Q) in enumerate(containing(V)):
        out.append((lam(Q, 16) * A, idx))
    return max(out)
h = 0.004; res = []
for t, k in enumerate(pick):
    x = np.array(far[k]['x']); b0, j = best(x)
    g = np.zeros(6)
    for i in range(6):
        e = np.zeros(6); e[i] = h
        bp = best(x + e)[0]; bm = best(x - e)[0]; g[i] = (bp - bm) / (2 * h)
    for delta in (0.01, 0.03):
        d = (b0 - FS * (1 + delta)) / np.abs(g).sum()
        res.append(dict(r=far[k]['r'], b=b0, delta=delta, d=d, gnorm1=np.abs(g).sum()))
    print(t, 'r %.3f b/F* %.3f |grad|_1 %.2f d(1%%) %.4f d(3%%) %.4f' % (far[k]['r'], b0 / FS, np.abs(g).sum(), res[-2]['d'], res[-1]['d']), flush=True)
json.dump(res, open('<sandbox>/reflex_test/bb_size_probe.json', 'w'))
vol = 0.106
for delta in (0.01, 0.03):
    ds = np.array([q['d'] for q in res if q['delta'] == delta]); ds = np.maximum(ds, 1e-4)
    for shrink in (1, 2):
        n = vol * np.mean((2 * ds / shrink) ** -6.0)
        print('delta %.2f, interval shrink %d: median d %.4f, boxes ~ %.2e' % (delta, shrink, np.median(ds), n))
