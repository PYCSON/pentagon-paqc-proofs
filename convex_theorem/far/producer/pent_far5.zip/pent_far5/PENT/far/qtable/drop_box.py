"""Rigorous 'dimension-descent' box exclusion, outer-QUADRILATERAL version (own code, 2026-11-01).
For a 6-D box B = p +- d (v0v1 chart) and a dropped edge j: Qhat = intersection of the 4 half-planes
{y : n_i.y <= H_i}, i != j, n_i = unit outward normals of the CENTRE pentagon's edges, H_i = max over the box of the
support of P(x) in direction n_i (exact: vertices vary in coordinate rectangles).  Then P(x) is contained in Qhat for every
x in B (checked rigorously at all 64 corners, vertex by vertex), so lambda_1(P(x)) >= lambda_1(Qhat) and
F(P(x)) >= lambda_lo(Qhat) * A_min(B), A_min = min of the multiaffine area over the 64 corners."""
import sys, itertools, time, numpy as np
sys.path.insert(0, '<sandbox>/research-hub/lines/D-topics/probes/MEAS-01/claude/scripts/C456')
sys.path.insert(0, '<sandbox>/reflex_test')
import rig_box
from rig_box import A, arb, certify_polygon, pent, CORN
from fem_check import lam1
FSTAR_UP = arb('18.919134195733918')
def certify_box_drop(p, d, j, K=8, nseg=400):
    V = pent(p); keep = [i for i in range(5) if i != j]
    nr = {}
    for i in keep:
        e = V[(i + 1) % 5] - V[i]; nr[i] = np.array([e[1], -e[0]]) / np.hypot(*e)
    H = {}
    for i in keep:
        vals = [V[0] @ nr[i], V[1] @ nr[i]] + [V[m] @ nr[i] + d * (abs(nr[i][0]) + abs(nr[i][1])) for m in (2, 3, 4)]
        H[i] = max(vals) + 1e-12
    Q = []
    for a, b in zip(keep, keep[1:] + keep[:1]):          # consecutive kept lines meet at a vertex of Qhat
        M = np.array([nr[a], nr[b]])
        if abs(np.linalg.det(M)) < 1e-9: return dict(fail='parallel')
        Q.append(np.linalg.solve(M, [H[a], H[b]]))
    Q = np.array(Q)
    # Qhat must be a bounded convex quadrilateral, CCW (check orientation of consecutive vertices)
    for i in range(4):
        a, b, c = Q[i], Q[(i + 1) % 4], Q[(i + 2) % 4]
        if (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]) <= 0: return dict(fail='unbounded or not convex')
    for i in range(4):                                     # rigorous containment of every corner pentagon's vertices
        q0, q1 = Q[i], Q[(i + 1) % 4]
        for s in CORN:
            for v in pent(p + d * s):
                cr = (A(q1[0]) - A(q0[0])) * (A(v[1]) - A(q0[1])) - (A(q1[1]) - A(q0[1])) * (A(v[0]) - A(q0[0]))
                if not cr >= 0: return dict(fail='containment')
    Amin = None
    for s in CORN:
        L = pent(p + d * s); xs = [A(v[0]) for v in L]; ys = [A(v[1]) for v in L]
        ar = sum(xs[i] * ys[(i + 1) % 5] - xs[(i + 1) % 5] * ys[i] for i in range(5)) / 2
        Amin = ar if Amin is None else arb(min(Amin.lower(), ar.lower()))
    g1, g2 = lam1(Q, 20), lam1(Q, 40); guess = g2 - (g1 - g2) / 3
    cQ = certify_polygon(Q, K, guess, nseg=nseg, width=0.02)
    if not cQ['ok_index']: return dict(fail='index')
    F_lo = cQ['lam_lo'] * Amin
    return dict(Q=Q.tolist(), F_lo=F_lo, certified=bool(F_lo > FSTAR_UP), mu=cQ['mu'], Amin=Amin)
if __name__ == '__main__':
    import json
    sys.path.insert(0, '<sandbox>/run3b_test'); import run_t1sweep as W
    cid = int(sys.argv[1])
    rec = [json.loads(l) for l in open('<sandbox>/run3b_test/centres_far_K.jsonl') if json.loads(l)['id'] == cid][0]
    p = W.r5_params() + rec['r'] * np.array(rec['d'])
    for d in [float(v) for v in sys.argv[2:]]:
        for j in range(5):
            t0 = time.time(); r = certify_box_drop(p, d, j)
            if 'fail' in r: print(cid, 'd %.3f drop %d: %s' % (d, j, r['fail']), flush=True); continue
            print(cid, 'd %.3f drop %d: F_lo %s  mu %s  certified %s  (%.0fs)' % (d, j, r['F_lo'].str(8), r['mu'].str(3), r['certified'], time.time() - t0), flush=True)
