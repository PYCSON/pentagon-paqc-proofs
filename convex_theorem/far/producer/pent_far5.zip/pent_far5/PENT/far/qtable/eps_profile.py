"""Float profile of the exact sector distortion e_k(u) = lam_max(S_k^-1 (S_k - G_k)) over a cell (planning only)."""
import sys, json, itertools, numpy as np
sys.path.insert(0, '<sandbox>/run3b_test')
import run_t1sweep as W
R5 = np.array([[0, 0], [1, 0], [1.3090169943749472, 0.9510565162951535], [0.5, 1.5388417685876266], [-0.30901699437494745, 0.9510565162951536]])
c0 = R5.mean(0); E = [np.array([R5[k] - c0, R5[(k + 1) % 5] - c0]).T for k in range(5)]
def verts(x): return np.array([[0, 0], [1, 0], x[0:2], x[2:4], x[4:6]], float)
def D(x):
    V = verts(x); c = V.mean(0)
    return [np.array([V[k] - c, V[(k + 1) % 5] - c]).T @ np.linalg.inv(E[k]) for k in range(5)]
def G(Dk): J = np.linalg.det(Dk); Xi = np.linalg.inv(Dk); return J * Xi @ Xi.T
CORN = np.array(list(itertools.product([-1, 1], repeat=6)), float)
rng = np.random.default_rng(0)
for cid, rho in [(10000, 0.05), (10000, 0.02), (10001, 0.04), (10001, 0.02)]:
    rec = [json.loads(l) for l in open('<sandbox>/run3b_test/centres_far_K.jsonl') if json.loads(l)['id'] == cid][0]
    p = W.r5_params() + rec['r'] * np.array(rec['d'])
    Dc = [D(p + rho * s) for s in CORN]; Gc = [[G(d[k]) for k in range(5)] for d in Dc]
    emax = np.zeros(5)
    for _ in range(3000):
        u = rng.uniform(-1, 1, 6); al = np.prod((1 + CORN * u) / 2, axis=1)
        Du = D(p + rho * u)
        for k in range(5):
            S = sum(a * g[k] for a, g in zip(al, Gc)); H = S - G(Du[k])
            emax[k] = max(emax[k], max(np.linalg.eigvals(np.linalg.solve(S, H)).real))
    V = verts(p); c = V.mean(0)
    a = np.array([abs(np.linalg.det(np.array([V[k] - c, V[(k + 1) % 5] - c]))) / 2 for k in range(5)]); a /= a.sum()
    el = np.array([np.linalg.norm(V[(k + 1) % 5] - V[k]) for k in range(5)])
    print('%d rho %.2f  max_u e_k %s  area frac %s  edge len %s  | max e %.4f  area-weighted %.4f' % (
        cid, rho, np.round(emax, 4), np.round(a, 3), np.round(el, 3), emax.max(), (a * emax).sum()))
