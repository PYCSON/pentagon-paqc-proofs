"""P1 FEM upper bound for lambda_1 on a star-shaped polygon (fan mesh from the vertex centroid), uniform refinement."""
import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as sla
def fan_mesh(V, n):
    c = V.mean(axis=0); pts = {}; P = []; T = []
    def idx(q):
        key = (round(q[0], 13), round(q[1], 13))
        if key not in pts:
            pts[key] = len(P); P.append(q)
        return pts[key]
    for k in range(len(V)):
        a, b = V[k], V[(k + 1) % len(V)]
        g = lambda i, j: idx(c + (i / n) * (a - c) + (j / n) * (b - c))
        for i in range(n):
            for j in range(n - i):
                T.append((g(i, j), g(i + 1, j), g(i, j + 1)))
                if i + j < n - 1:
                    T.append((g(i + 1, j), g(i + 1, j + 1), g(i, j + 1)))
    return np.array(P), np.array(T)
def lam1(V, n):
    P, T = fan_mesh(V, n); N = len(P)
    I = []; J = []; Kv = []; Mv = []
    for t in T:
        X = P[t]; B = np.array([X[1] - X[0], X[2] - X[0]]).T
        ar = abs(np.linalg.det(B)) / 2
        G = np.linalg.inv(B).T @ np.array([[-1, 1, 0], [-1, 0, 1]])
        Ke = ar * G.T @ G; Me = ar / 12 * (np.ones((3, 3)) + np.eye(3))
        for a in range(3):
            for b in range(3):
                I.append(t[a]); J.append(t[b]); Kv.append(Ke[a, b]); Mv.append(Me[a, b])
    K = sp.csr_matrix((Kv, (I, J)), (N, N)); M = sp.csr_matrix((Mv, (I, J)), (N, N))
    # boundary nodes: on polygon edges
    bd = np.zeros(N, bool)
    for k in range(len(V)):
        a, b = V[k], V[(k + 1) % len(V)]; e = b - a
        cr = np.abs(e[0] * (P[:, 1] - a[1]) - e[1] * (P[:, 0] - a[0])) / np.hypot(*e)
        tt = ((P - a) @ e) / (e @ e)
        bd |= (cr < 1e-11) & (tt > -1e-12) & (tt < 1 + 1e-12)
    fr = np.where(~bd)[0]
    w = sla.eigsh(K[fr][:, fr], k=1, M=M[fr][:, fr], sigma=0, which='LM', return_eigenvectors=False)
    return w[0]
