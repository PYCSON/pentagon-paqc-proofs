"""Float feasibility probe (NOT rigorous): would certified lower bounds for F over QUADRILATERALS and TRIANGLES
(low-dimensional tables, instead of the Polya-Szego constants 2 pi^2 and 4 pi^2/sqrt3) exclude much more of the far set K?
For each far K sample P: for every containing quadrilateral/triangle Q (drop 1/2 edge half-planes), F(P) >= lambda_1(Q)|P|.
lambda_1 by P1 FEM on two meshes + Richardson (estimate)."""
import sys, json, itertools, time, numpy as np
sys.path.insert(0, '<sandbox>/reflex_test'); sys.path.insert(0, '<sandbox>/run3b_test')
from fem_check import lam1
import run_t1sweep as W
FS = 18.919134195733918
def verts(x): return np.array([[0, 0], [1, 0], x[0:2], x[2:4], x[4:6]], float)
def area(V): return 0.5 * sum(V[i][0] * V[(i + 1) % len(V)][1] - V[i][1] * V[(i + 1) % len(V)][0] for i in range(len(V)))
def lines(V):
    n = len(V); out = []
    for i in range(n):
        a, b = V[i], V[(i + 1) % n]; t = b - a; nrm = np.array([t[1], -t[0]]); out.append((nrm, nrm @ a))
    return out
def meet(l1, l2):
    M = np.array([l1[0], l2[0]])
    if abs(np.linalg.det(M)) < 1e-14: return None
    return np.linalg.solve(M, [l1[1], l2[1]])
def ccw(V): return V if area(V) > 0 else V[::-1].copy()
def containing(V):
    L = lines(V); out = []
    for j in range(5):
        w = meet(L[(j - 1) % 5], L[(j + 1) % 5])
        if w is not None and L[j][0] @ w > L[j][1] + 1e-12:
            out.append(('quad', ccw(np.array([V[(j - 1) % 5], w, V[(j + 2) % 5], V[(j + 3) % 5]]))))
    for S in itertools.combinations(range(5), 3):
        a = meet(L[S[0]], L[S[1]]); b = meet(L[S[1]], L[S[2]]); c = meet(L[S[0]], L[S[2]])
        if a is None or b is None or c is None: continue
        g = (a + b + c) / 3
        if all(L[i][0] @ g <= L[i][1] + 1e-12 for i in S):
            out.append(('tri', ccw(np.array([a, b, c]))))
    return out
def lam(V, n=20):
    l1, l2 = lam1(V, n), lam1(V, 2 * n); return l2 - (l1 - l2) / 3
if __name__ == '__main__':
    rows = [json.loads(l) for l in open('<sandbox>/run3b_test/centres_far_K.jsonl')]
    out = open('<sandbox>/reflex_test/quad_table_probe.jsonl', 'w'); t0 = time.time()
    for i, rec in enumerate(rows):
        p = W.r5_params() + rec['r'] * np.array(rec['d']); V = verts(p); A = area(V)
        FP = lam(V) * A
        best = 0; bw = None; ps = 0
        for kind, Q in containing(V):
            AQ = area(Q); b = lam(Q) * A
            psb = (2 * np.pi ** 2 if kind == 'quad' else 4 * np.pi ** 2 / np.sqrt(3)) * A / AQ
            ps = max(ps, psb)
            if b > best: best, bw = b, kind
        rr = dict(id=rec['id'], r=rec['r'], F=FP, ps_bound=ps, table_bound=best, which=bw, excluded=bool(best > FS * 1.002))
        out.write(json.dumps(rr) + '\n'); out.flush()
        if i % 20 == 0: print(i, rr, '%.0fs' % (time.time() - t0), flush=True)
