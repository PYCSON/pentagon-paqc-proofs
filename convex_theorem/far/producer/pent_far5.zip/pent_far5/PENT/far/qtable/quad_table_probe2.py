"""Float probe 2 (NOT rigorous): P(excluded by the quadrilateral/triangle table bound | chart distance r) on fresh uniform
samples of the convex far set K (longest-edge chart root box, all edges <= 1, not excluded by the Polya-Szego-constant
bounds).  Tells how far out PAQC must cover if the far region is handled by low-dimensional F-tables."""
import sys, json, time, numpy as np
sys.path.insert(0, '<sandbox>/reflex_test')
from quad_table_probe import verts, area, lines, containing, lam, FS
from scipy.optimize import linprog
sys.path.insert(0, '<sandbox>/run3b_test')
import run_t1sweep as W
XS = W.r5_params(); L4 = 2 * np.pi ** 2; L3 = 4 * np.pi ** 2 / np.sqrt(3)
def convex_ccw(V):
    for i in range(5):
        a, b, c = V[i], V[(i + 1) % 5], V[(i + 2) % 5]
        if (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]) <= 1e-12: return False
    return True
def inradius(V):
    L = lines(V); A = np.array([[n[0], n[1], np.linalg.norm(n)] for n, _ in L]); b = np.array([c for _, c in L])
    return linprog([0, 0, -1], A_ub=A, b_ub=b, bounds=[(None, None), (None, None), (0, None)]).x[2]
def chart(V):
    out = []
    for Wv in (V, V[::-1] * np.array([1, -1])):
        Wv = np.array(Wv)
        for s in range(5):
            U = np.roll(Wv, -s, axis=0); U = U - U[0]; z = complex(U[1][0], U[1][1]); Z = (U[:, 0] + 1j * U[:, 1]) / z
            out.append(np.array([Z[2].real, Z[2].imag, Z[3].real, Z[3].imag, Z[4].real, Z[4].imag]))
    return out
if __name__ == '__main__':
    rng = np.random.default_rng(int(sys.argv[1]) if len(sys.argv) > 1 else 7)
    lo = np.array([0, 0, -1, 0, -1, 0.]); hi = np.array([2, 1, 2, 2, 1, 1.])
    out = open('<sandbox>/reflex_test/quad_table_probe2.jsonl', 'a'); t0 = time.time(); n = 0
    while n < int(sys.argv[2]) if len(sys.argv) > 2 else 300:
        x = rng.uniform(lo, hi); V = verts(x)
        if not convex_ccw(V): continue
        if max(np.linalg.norm(V[(i + 1) % 5] - V[i]) for i in range(5)) > 1 + 1e-12: continue
        A = area(V); cont = containing(V); ps = 0
        for kind, Q in cont:
            ps = max(ps, (L4 if kind == 'quad' else L3) * A / area(Q))
        ps = max(ps, np.pi ** 2 * A / (4 * inradius(V) ** 2))
        if ps > FS: continue
        r = min(np.linalg.norm(y - XS) for y in chart(V))
        best = 0; bw = None
        for kind, Q in cont:
            b = lam(Q) * A
            if b > best: best, bw = b, kind
        FP = lam(V) * A
        out.write(json.dumps(dict(x=list(x), r=r, F=FP, ps_bound=ps, table_bound=best, which=bw)) + '\n'); out.flush(); n += 1
        if n % 25 == 0: print(n, 'r %.3f F %.3f table %.3f' % (r, FP, best), '%.0fs' % (time.time() - t0), flush=True)
