"""PAQC min-corner cell certificate for convex n-gons (n = 3, 4, 5, ...), own code, Claude 2026-11-01.

Generalises probes/PENT/scripts/rig_paqc.py (n = 5, the v1.0 code, left untouched) to any n so that a certified table of
lower bounds for F(Q) = lambda_1(Q)|Q| over QUADRILATERALS (n = 4, a 4-dimensional chart) can be built for the
'dimension-descent' exclusion of far pentagons (far/README.md, 11-01).  Same mathematics as the paper (Lemmas 1-3,
Theorem 4, min-corner form):
  chart  V_0 = (0,0), V_1 = (1,0), V_2..V_{n-1} = x  (DIM = 2n - 4 coordinates), cell = box with exact binary64 endpoints;
  reference = regular n-gon, fan from the vertex centroid; D_k affine, J_k multiaffine;
  convexity gate on the 2^DIM corners (n(n-2) multiaffine half-plane determinants);
  eps_k from the matrix Efron-Stein bound with the lower metric G_l (v5), interpolation error of f_k = J_k/A;
  F(Q) >= factor * min_c F_c^L,  F_c^L from rig_box.certify_polygon (MPS + FHM + Hong-Krahn-Szego, mu < 1 enforced).
Status: prototype, NOT yet reviewed by the second party."""
import os, sys, itertools, time
import numpy as np
from flint import arb, ctx
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', '..', 'scripts'))
import rig_paqc as R5                     # n-independent helpers (2x2 matrix algebra, lower_metric, f_down/f_up); sets prec 96
import rig_box
from mps import regular, poly_area
from rig_paqc import inv2, mul2, det2, sq, lam_min_sym2, lam_max_sym2, gen_lam_max, amin, amax, lower_metric, f_down

A = lambda x: arb(float(x))


class Chart:
    def __init__(self, n):
        self.n = n; self.dim = 2 * n - 4; self.nc = 2 ** self.dim
        self.CORN = np.array(list(itertools.product([-1, 1], repeat=self.dim)), float)
        P0 = regular(n)
        P0a = [[A(v[0]), A(v[1])] for v in P0]
        c0 = [sum(v[0] for v in P0a) / n, sum(v[1] for v in P0a) / n]
        E = [[[P0a[k][0] - c0[0], P0a[(k + 1) % n][0] - c0[0]], [P0a[k][1] - c0[1], P0a[(k + 1) % n][1] - c0[1]]] for k in range(n)]
        self.Einv = []; self.a0 = []
        for k in range(n):
            Ei, dE = inv2(E[k]); self.Einv.append(Ei); self.a0.append(abs(dE) / 2)
        self.BK = self._Bmats()

    def verts(self, x):
        xs = [A(v) if not isinstance(v, arb) else v for v in x]
        return [[arb(0), arb(0)], [arb(1), arb(0)]] + [[xs[2 * m], xs[2 * m + 1]] for m in range(self.n - 2)]

    def Dmats(self, V):
        n = self.n
        c = [sum(v[0] for v in V) / n, sum(v[1] for v in V) / n]
        return [mul2([[V[k][0] - c[0], V[(k + 1) % n][0] - c[0]], [V[k][1] - c[1], V[(k + 1) % n][1] - c[1]]], self.Einv[k])
                for k in range(n)]

    def _Bmats(self):
        n = self.n
        B = [[None] * self.dim for _ in range(n)]
        for i in range(self.dim):
            dV = [[arb(0), arb(0)] for _ in range(n)]
            dV[2 + i // 2][i % 2] = arb(1)
            dc = [sum(v[0] for v in dV) / n, sum(v[1] for v in dV) / n]
            for k in range(n):
                M = [[dV[k][0] - dc[0], dV[(k + 1) % n][0] - dc[0]], [dV[k][1] - dc[1], dV[(k + 1) % n][1] - dc[1]]]
                B[k][i] = mul2(M, self.Einv[k])
        return B

    def cell_endpoints(self, p, rho):
        lo = np.array([float(np.float64(p[i]) - np.float64(rho)) for i in range(self.dim)])
        hi = np.array([float(np.float64(p[i]) + np.float64(rho)) for i in range(self.dim)])
        return lo, hi

    def cell_corners(self, lo, hi):
        return [np.where(s > 0, hi, lo) for s in self.CORN]

    def convexity_gate(self, lo, hi):
        n = self.n; mn = None
        for x in self.cell_corners(lo, hi):
            V = self.verts(x)
            for i in range(n):
                a, b = V[i], V[(i + 1) % n]
                for j in range(n):
                    if j in (i, (i + 1) % n):
                        continue
                    c = V[j]
                    d = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
                    mn = d if mn is None else arb(min(mn.lower(), d.lower()))
        return arb(mn.lower())

    def geometry_bound(self, p, rho):
        lo, hi = self.cell_endpoints(p, rho)
        return self.geometry_bound_box(lo, hi)

    def geometry_bound_box(self, lo, hi):
        """same as geometry_bound for a cell given by explicit binary64 endpoints (grid cells share exact corners)."""
        n, dim, nc = self.n, self.dim, self.nc
        lo = np.asarray(lo, float); hi = np.asarray(hi, float)
        cg = self.convexity_gate(lo, hi)
        if not (cg > 0):
            return dict(ok=False, why='convexity gate failed')
        corners = self.cell_corners(lo, hi)
        Ds = [self.Dmats(self.verts(x)) for x in corners]
        out = {'convexity_gate_min': float(cg.lower())}
        m_list = []
        for k in range(n):
            Jc = [det2(D[k]) for D in Ds]
            if not all(j > 0 for j in Jc):
                return dict(ok=False, why='corner J<=0')
            Xc = [inv2(D[k])[0] for D in Ds]
            Gc = [[[Jc[c] * (sq(Xc[c][0][0]) + sq(Xc[c][0][1])), Jc[c] * (Xc[c][0][0] * Xc[c][1][0] + Xc[c][0][1] * Xc[c][1][1])],
                   [Jc[c] * (Xc[c][0][0] * Xc[c][1][0] + Xc[c][0][1] * Xc[c][1][1]), Jc[c] * (sq(Xc[c][1][0]) + sq(Xc[c][1][1]))]]
                  for c in range(nc)]
            Jmax = amax(Jc); tmin = amin(Jc)
            Gl, which = lower_metric(Gc)
            if Gl is None or not (lam_min_sym2(Gl) > 0):
                return dict(ok=False, why='Gl not PD')
            Gli = inv2(Gl)[0]
            Rsum = [[arb(0), arb(0)], [arb(0), arb(0)]]; dev = arb(0)
            for i in range(dim):
                bit = 1 << (dim - 1 - i)          # itertools.product order: coordinate 0 is the most significant bit
                dXs = [[[Xc[c][a][b] - Xc[c ^ bit][a][b] for b in range(2)] for a in range(2)] for c in range(nc) if not (c & bit)]
                Rm = [[sum(d[a][b] for d in dXs) / (nc // 2) for b in range(2)] for a in range(2)]
                T = mul2(Rm, [[Rm[0][0], Rm[1][0]], [Rm[0][1], Rm[1][1]]])
                Rsum = [[Rsum[a][b] + T[a][b] for b in range(2)] for a in range(2)]
                vals = []
                for d in dXs:
                    dd = [[d[a][b] - Rm[a][b] for b in range(2)] for a in range(2)]
                    vals.append(lam_max_sym2(mul2(mul2([[dd[0][0], dd[1][0]], [dd[0][1], dd[1][1]]], Gli), dd)))
                dev += amax(vals)
            main = gen_lam_max(Rsum, Gl)
            best = None
            for tau in (0.003, 0.01, 0.03, 0.1, 0.3, 1.0):
                v = (1 + arb(tau)) / 4 * main + (1 + 1 / arb(tau)) / 4 * dev
                best = v if best is None else arb(min(best.upper(), v.upper()))
            eps = Jmax * best
            delta = sum(sq(hw_ / 2) * abs(det2(self.BK[k][i])) for i, hw_ in enumerate([A(hi[j]) - A(lo[j]) for j in range(dim)]))
            if not (tmin - delta > 0):
                return dict(ok=False, why='J may vanish')
            m_list.append((1 - eps) * tmin / (tmin + delta))
            out['k%d' % k] = dict(eps=float(eps.upper()), delta_over_t=float((delta / tmin).upper()))
        m = amin(m_list)
        errmax = arb(0)
        mid = [float((lo[i] + hi[i]) / 2) for i in range(dim)]
        hw = [A(hi[i]) - A(lo[i]) for i in range(dim)]
        for sub in self.CORN:
            xbox = [(A(lo[i]).union(A(mid[i])) if sub[i] < 0 else A(mid[i]).union(A(hi[i]))) for i in range(dim)]
            for i in range(dim):
                a_, b_ = (lo[i], mid[i]) if sub[i] < 0 else (mid[i], hi[i])
                assert xbox[i].lower() <= a_ and xbox[i].upper() >= b_
            r_ = self._interp_err_box(xbox, hw)
            if r_ is None:
                return dict(ok=False, why='J box not positive')
            errmax = arb(max(errmax.upper(), r_.upper()))
        factor = m * (1 - errmax)
        out.update(m=float(m.lower()), interp_err=float(errmax.upper()), factor=float(factor.lower()))
        return dict(ok=True, factor=arb(factor.lower()), info=out)

    def _interp_err_box(self, xbox, hw):
        n, dim = self.n, self.dim
        Dbox = self.Dmats(self.verts(xbox))
        Jb = [det2(Dbox[k]) for k in range(n)]
        Aw = sum(self.a0[j] * Jb[j] for j in range(n))
        for k in range(n):
            if not (Jb[k] > 0):
                return None
        errmax = arb(0)
        BK = self.BK
        for k in range(n):
            fmin = arb((Jb[k] / Aw).lower())
            err = arb(0)
            for i in range(dim):
                Ji = [Dbox[j][1][1] * BK[j][i][0][0] - Dbox[j][1][0] * BK[j][i][0][1] - Dbox[j][0][1] * BK[j][i][1][0] + Dbox[j][0][0] * BK[j][i][1][1]
                      for j in range(n)]
                Jii = [2 * det2(BK[j][i]) for j in range(n)]
                Ai = sum(self.a0[j] * Ji[j] for j in range(n)); Aii = sum(self.a0[j] * Jii[j] for j in range(n))
                f2 = Jii[k] / Aw - 2 * Ji[k] * Ai / sq(Aw) - Jb[k] * Aii / sq(Aw) + 2 * Jb[k] * sq(Ai) / (sq(Aw) * Aw)
                err += sq(hw[i]) / 8 * abs(f2)
            errmax = arb(max(errmax.upper(), (err / fmin).upper()))
        return errmax

    def corner_F(self, x, Fguess, K=8, nseg=300, width=0.03):
        V = np.array([[0, 0], [1, 0]] + [[x[2 * m], x[2 * m + 1]] for m in range(self.n - 2)], float)
        r = rig_box.certify_polygon(V, K, Fguess / poly_area(V), nseg=nseg, width=width)
        if not r['ok_index']:
            return None, r
        return f_down(r['lam_lo'] * r['area']), r

    def certify_cell(self, p, rho, Fguess, K=8, nseg=300):
        """min-corner form: returns dict with LB = factor * min_c F_c^L (rigorous lower bound of F on the whole cell)."""
        t0 = time.time()
        g = self.geometry_bound(p, rho)
        if not g['ok']:
            return dict(ok=False, why=g['why'])
        lo, hi = self.cell_endpoints(p, rho)
        Fl = []
        for x in self.cell_corners(lo, hi):
            F, r = self.corner_F(x, Fguess, K, nseg)
            if F is None:
                return dict(ok=False, why='corner index/mu')
            Fl.append(F)
        LB = g['factor'] * amin([arb(v) for v in Fl])
        return dict(ok=True, LB=f_down(LB), factor=float(g['factor'].lower()), Fmin=min(Fl), info=g['info'], sec=round(time.time() - t0, 1))

    def certify_box_cached(self, lo, hi, Fguess, cache, K=8, nseg=300):
        """min-corner form on an explicit box; corner lower bounds are taken from / stored in `cache`
        (dict keyed by the exact binary64 corner coordinates), so neighbouring grid cells share corner certificates."""
        t0 = time.time()
        g = self.geometry_bound_box(lo, hi)
        if not g['ok']:
            return dict(ok=False, why=g['why'])
        Fl = []; new = 0
        for x in self.cell_corners(np.asarray(lo, float), np.asarray(hi, float)):
            key = tuple(repr(float(v)) for v in x)
            if key not in cache:
                F, r = self.corner_F(x, Fguess, K, nseg)
                cache[key] = F; new += 1
            if cache[key] is None:
                return dict(ok=False, why='corner index/mu')
            Fl.append(cache[key])
        LB = g['factor'] * amin([arb(v) for v in Fl])
        return dict(ok=True, LB=f_down(LB), factor=float(g['factor'].lower()), new_corners=new, sec=round(time.time() - t0, 1))
