"""Shared-corner grid test (n = 4): a 3x3x3x3 block of cells of half-width 0.02 around the containing quadrilateral of far
centre 10000.  Measures corner reuse and time per cell."""
import sys, time, itertools, numpy as np
sys.path.insert(0, '.')
import rig_paqc_n as PN
C4 = PN.Chart(4)
q = np.array([1.1896, 0.6870, 0.7689, 0.6267]); h = 0.04          # chart point of the 10000 quad (rounded), cell side
cache = {}; t0 = time.time(); res = []
nodes = [[float(q[i] + (k - 1.5) * h) for k in range(4)] for i in range(4)]     # exact binary64 grid nodes, shared
for idx in itertools.product(range(3), repeat=4):
    lo = np.array([nodes[i][idx[i]] for i in range(4)]); hi = np.array([nodes[i][idx[i] + 1] for i in range(4)])
    r = C4.certify_box_cached(lo, hi, 24.06, cache)
    res.append(r); print(idx, {k: r.get(k) for k in ('ok', 'why', 'LB', 'new_corners', 'sec')}, flush=True)
ok = [r for r in res if r['ok']]
print('cells %d ok %d, unique corners %d (unshared would be %d), total %.0f s = %.1f s/cell, min LB %.4f' % (
    len(res), len(ok), len(cache), 16 * len(res), time.time() - t0, (time.time() - t0) / len(res), min(r['LB'] for r in ok)))
