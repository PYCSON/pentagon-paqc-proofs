import sys, numpy as np
sys.path.insert(0, '<sandbox>/research-hub/lines/D-topics/probes/MEAS-01/claude/scripts/C456')
import rig_box
from flint import arb
PI = arb.pi()
for name, V, exact in [('unit square', np.array([[0, 0], [1, 0], [1, 1], [0, 1.]]), 2 * PI ** 2),
                       ('equilateral triangle', np.array([[0, 0], [1, 0], [0.5, np.sqrt(3) / 2]]), 16 * PI ** 2 / 3),
                       ('2x1 rectangle', np.array([[0, 0], [2, 0], [2, 1], [0, 1.]]), PI ** 2 * (1 / 4 + 1))]:
    r = rig_box.certify_polygon(V, 8, float(exact.mid()) * 1.001, nseg=300, width=0.01)
    print('%-22s lam~ %.12f exact %.12f  in [%s, %s]  mu %s index %s' % (name, float(r['lam']), float(exact.mid()), r['lam_lo'].str(10), r['lam_hi'].str(10), r['mu'].str(3), r['ok_index']))
    assert r['lam_lo'] < exact < r['lam_hi'] or not r['ok_index']
print('ok')
