import sys, json, time, numpy as np
sys.path.insert(0, '.')
import rig_paqc_n as PN
R5 = PN.R5
d = json.load(open('../../G1/cell_liu_point_rho0.025_v6.json')); p = np.array(d['p'])
t0 = time.time(); g5 = R5.geometry_bound(p, 0.025); gn = PN.Chart(5).geometry_bound(p, 0.025)
print('n=5 regression: rig_paqc factor %.15f  rig_paqc_n factor %.15f  identical %s (%.0fs)' % (
    float(g5['factor'].lower()), float(gn['factor'].lower()), float(g5['factor'].lower()) == float(gn['factor'].lower()), time.time() - t0), flush=True)
C4 = PN.Chart(4)
sqp = np.array([1.0, 1.0, 0.0, 1.0])          # unit square in the chart: V2 = (1,1), V3 = (0,1)
for rho in (0.005, 0.01):
    r = C4.certify_cell(sqp, rho, 2 * np.pi ** 2)
    print('square cell rho %.3f: %s' % (rho, {k: r.get(k) for k in ('ok', 'why', 'LB', 'factor', 'Fmin', 'sec')}), flush=True)
