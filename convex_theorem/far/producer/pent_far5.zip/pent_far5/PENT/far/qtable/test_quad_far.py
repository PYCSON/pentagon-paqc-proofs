import sys, json, time, numpy as np
sys.path.insert(0, '.'); sys.path.insert(0, '<sandbox>/run3b_test')
import rig_paqc_n as PN
from quad_table_probe import verts, area, containing, lam
import run_t1sweep as W
def to_chart(Q):
    """similarity-normalise a CCW quadrilateral: longest edge -> (0,0)-(1,0); returns the 4 chart coordinates."""
    n = len(Q); j = max(range(n), key=lambda i: np.linalg.norm(Q[(i + 1) % n] - Q[i]))
    U = np.roll(Q, -j, axis=0); U = U - U[0]; z = complex(*U[1]); Z = (U[:, 0] + 1j * U[:, 1]) / z
    return np.array([Z[2].real, Z[2].imag, Z[3].real, Z[3].imag])
C4 = PN.Chart(4)
for cid in (10000, 10031):
    rec = [json.loads(l) for l in open('<sandbox>/run3b_test/centres_far_K.jsonl') if json.loads(l)['id'] == cid][0]
    V = verts(W.r5_params() + rec['r'] * np.array(rec['d'])); AP = area(V)
    best = max(((lam(Q) * AP, Q) for kind, Q in containing(V) if kind == 'quad'), key=lambda t: t[0])
    Q = best[1]; q = to_chart(Q); FQ = lam(Q) * area(Q)
    print(cid, 'best quad bound %.4f, F(Q) ~ %.4f, |P|/|Q| %.4f, chart q %s' % (best[0], FQ, AP / area(Q), np.round(q, 4)), flush=True)
    for rho in (0.02, 0.05, 0.1):
        r = C4.certify_cell(q, rho, FQ)
        print('   rho %.2f: %s' % (rho, {k: r.get(k) for k in ('ok', 'why', 'LB', 'factor', 'Fmin', 'sec')}), flush=True)
