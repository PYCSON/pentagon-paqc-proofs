import sys, numpy as np
sys.path.insert(0, '.')
import rig_paqc_n as PN
C3 = PN.Chart(3)
eq = np.array([0.5, np.sqrt(3) / 2])
for rho in (0.01, 0.05):
    r = C3.certify_cell(eq, rho, 4 * np.pi ** 2 / np.sqrt(3))
    print('equilateral cell rho %.2f: %s   (F(eq) = 4 pi^2/sqrt3 = %.6f)' % (rho, {k: r.get(k) for k in ('ok', 'why', 'LB', 'factor', 'Fmin', 'sec')}, 4 * np.pi ** 2 / np.sqrt(3)), flush=True)
