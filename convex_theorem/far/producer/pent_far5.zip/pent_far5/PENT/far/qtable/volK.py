"""Monte Carlo volume of the convex far set K in the longest-edge chart (uniform in the root box, volume 24)."""
import sys, numpy as np
sys.path.insert(0, '<sandbox>/reflex_test')
from quad_table_probe2 import convex_ccw, inradius, chart, XS, L4, L3
from quad_table_probe import verts, area, containing, FS
rng = np.random.default_rng(int(sys.argv[2]) if len(sys.argv) > 2 else 3)
lo = np.array([0, 0, -1, 0, -1, 0.]); hi = np.array([2, 1, 2, 2, 1, 1.]); N = int(sys.argv[1])
nconv = 0; rs = []
for _ in range(N):
    x = rng.uniform(lo, hi); V = verts(x)
    if not convex_ccw(V): continue
    if max(np.linalg.norm(V[(i + 1) % 5] - V[i]) for i in range(5)) > 1 + 1e-12: continue
    nconv += 1
    A = area(V); ps = 0
    for kind, Q in containing(V): ps = max(ps, (L4 if kind == 'quad' else L3) * A / area(Q))
    ps = max(ps, np.pi ** 2 * A / (4 * inradius(V) ** 2))
    if ps > FS: continue
    rs.append(min(np.linalg.norm(y - XS) for y in chart(V)))
rs = np.array(rs)
print('N', N, 'convex+longest-edge', nconv, 'vol %.4f' % (24 * nconv / N), '| K (not PS-excluded)', len(rs), 'vol(K) %.4f' % (24 * len(rs) / N))
for a, b in [(0, 0.3), (0.3, 0.6), (0.6, 0.9), (0.9, 3)]:
    m = ((rs >= a) & (rs < b)).sum(); print('  r in [%.1f,%.1f): %d  vol %.5f' % (a, b, m, 24 * m / N))
