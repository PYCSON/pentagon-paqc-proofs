"""G1 second cell: a sweep-run2 centre at r ~ 0.1; choose rho by float corners, then certify rigorously."""
import json, sys, numpy as np
import rig_paqc as R
sys.path.insert(0, R.C456)
from mps import PolyMPS, poly_area, regular
RUN2 = sys.argv[1]
recs = [json.loads(l) for l in open(RUN2)]
rec = min(recs, key=lambda x: abs(x['r'] - 0.1))
def r5_params():
    Rg = regular(5, R=1 / (2 * np.sin(np.pi / 5)), rot=-np.pi / 2 - np.pi / 5)
    Rg = Rg - Rg[0]; e = Rg[1] - Rg[0]; ang = np.arctan2(e[1], e[0])
    Rm = np.array([[np.cos(-ang), -np.sin(-ang)], [np.sin(-ang), np.cos(-ang)]])
    return (Rg @ Rm.T)[2:].reshape(-1)
p = np.round(r5_params() + rec['r'] * np.array(rec['d']), 12)
def Ff(x):
    V = np.array([[0,0],[1,0],[x[0],x[1]],[x[2],x[3]],[x[4],x[5]]], float); a = poly_area(V)
    m = PolyMPS(V, K=11); return m.solve(18.95 / a, width=0.04, ngrid=13) * a
print('centre id', rec['id'], 'r', rec['r'], 'float gap', rec['gap'], 'run2 float-T1 rho', rec['rho_pass'], flush=True)
best = None
for rho in [0.004, 0.006, 0.008, 0.010, 0.012]:
    g = R.geometry_bound(p, rho)
    if not g['ok']:
        print(rho, g['why']); break
    fac = float(g['factor'].lower())
    Fmin = min(Ff(p + rho * s) for s in R.CORN)
    LB = fac * (Fmin - 0.006)          # 0.006 ~ allowance for the rigorous corner loss (mu ~ 2.4e-4 relative)
    ok = LB > float(R.FSTAR_UP.upper())
    print('rho %.3f factor %.6f Fmin(float) %.5f LB(with allowance) %.5f pass %s' % (rho, fac, Fmin, LB, ok), flush=True)
    if ok: best = rho
    else: break
print('chosen rho', best, flush=True)
if best:
    print(json.dumps(R.certify_cell(p, best, workers=2)), flush=True)
