"""Component breakdown of the producer's box bound on a few accepted leaves (Claude, 2026-10-31), as a DEBUGGING
reference for an independent replayer (numbers only; do not copy code).  Usage: python3 leaf_debug_reference.py CERT_v6.json OUT.json"""
import sys, json
import numpy as np
from flint import arb
import rig_paqc as R, rig_t1 as T
d = json.load(open(sys.argv[1]))
p = np.array(d['p']); rho = d['rho']
Fl = [arb(R.cert_F_lo(c)) for c in d['corner_certificates']]
cd = T.CellData(p, rho, Fl, emode=d.get('emode', 'es'))
leaves = d['T1']['leaves']
order = sorted(range(len(leaves)), key=lambda i: leaves[i][3])
pick = sorted(set([0, 1, 2] + order[:2]))
out = []
for i in pick:
    cen, rad, tau, lbrec = leaves[i]
    ra = [arb(float(r)) for r in rad]
    (Qc, Ec, Xc), (Qb, Eb, Xb) = cd.jets(cen, rad)
    rec = dict(leaf_index=i, centre=cen, radius=rad, tau_used=tau, producer_lower=lbrec, Q=[], eps=[])
    for k in range(5):
        g = sum(float(abs(Qc[k].g[j]).upper()) * rad[j] for j in range(6))
        h = sum(float(abs(Qb[k].h[a][b]).upper()) * rad[a] * rad[b] / 2 for a in range(6) for b in range(6))
        rec['Q'].append(dict(k=k, centre_value=float(Qc[k].v.mid()), grad_term=g, hess_term=h,
                             box_value_hull=[float(Qb[k].v.lower()), float(Qb[k].v.upper())]))
        if Ec is not None and tau is not None:
            t = arb(tau); best = None
            for mc, mb in Ec[k][0]:
                jc = mc * (1 + t) + Ec[k][1][0] * (1 + 1 / t); jb = mb * (1 + t) + Ec[k][1][1] * (1 + 1 / t)
                up, _ = T._taylor(jc, jb, ra, +1)
                if best is None or float(up.upper()) < best[0]:
                    best = (float(up.upper()), float(jc.v.mid()))
            rec['eps'].append(dict(k=k, centre_value=best[1], taylor_upper=best[0]))
    lb, con, _, tau2 = T.box_lower(cd, cen, rad, (0.03, 0.1, 0.3))
    rec['recomputed_lower'] = float(lb.lower())
    out.append(rec)
json.dump(dict(source=sys.argv[1], note='Q_k = A N_k / J_k; eps = (1+tau) main + (1+1/tau) dev (Efron-Stein, AM-GM/trace lam_max majorant); '
               'Taylor: f(c) -/+ sum|f_i(c)| r_i -/+ 1/2 sum |f_ij|_box r_i r_j.  Note box_value_hull of Q is NOT used by the bound.',
               leaves=out), open(sys.argv[2], 'w'), indent=1)
for r in out:
    print(r['leaf_index'], 'Q0 centre %.6f grad %.2e hess %.2e | hull %s' % (r['Q'][0]['centre_value'], r['Q'][0]['grad_term'], r['Q'][0]['hess_term'], r['Q'][0]['box_value_hull']), 'lower', r['recomputed_lower'])
