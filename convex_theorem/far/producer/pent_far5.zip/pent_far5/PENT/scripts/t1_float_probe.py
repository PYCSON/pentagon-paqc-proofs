"""Float probe: how much would a rigorous T1 (Theorem A, u-dependent matrix Efron-Stein eps) gain over min-corner?"""
import json, sys, itertools, numpy as np
sys.path.insert(0, '../../MEAS-01/claude/scripts/C456')
from mps import PolyMPS, poly_area, regular
P0 = regular(5); c0 = P0.mean(0)
E = [np.column_stack([P0[k] - c0, P0[(k + 1) % 5] - c0]) for k in range(5)]
Einv = [np.linalg.inv(e) for e in E]; a0 = np.array([abs(np.linalg.det(e)) / 2 for e in E])
CORN = np.array(list(itertools.product([-1, 1], repeat=6)), float)
def Dm(x):
    V = np.array([[0,0],[1,0],[x[0],x[1]],[x[2],x[3]],[x[4],x[5]]]); c = V.mean(0)
    return [np.column_stack([V[k]-c, V[(k+1)%5]-c]) @ Einv[k] for k in range(5)]
def Ff(x):
    V = np.array([[0,0],[1,0],[x[0],x[1]],[x[2],x[3]],[x[4],x[5]]], float); a = poly_area(V)
    return PolyMPS(V, K=11).solve(18.95/a, width=0.04, ngrid=13) * a
FS = 18.919134195733914
def probe(p, rho, Fcor, nsamp=4000, rng=np.random.default_rng(0)):
    xs = [p + rho*s for s in CORN]; Dc = [Dm(x) for x in xs]
    Jc = np.array([[np.linalg.det(D[k]) for k in range(5)] for D in Dc])     # 64x5
    Ac = Jc @ a0; lam = Fcor / Ac
    out = []
    pre = []
    for k in range(5):
        X = [np.linalg.inv(D[k]) for D in Dc]; G = [Jc[c,k]*X[c]@X[c].T for c in range(64)]
        Gcen = sum(G)/64; eta = max(np.abs(np.linalg.eigvalsh(g-Gcen)).max() for g in G); Gl = Gcen - eta*np.eye(2)
        L = np.linalg.cholesky(Gl); Li = np.linalg.inv(L)
        RR = []; dev = []
        for i in range(6):
            bit = 1 << (5-i); d = [X[c]-X[c^bit] for c in range(64) if not c & bit]; Rm = sum(d)/32
            RR.append(Li @ Rm @ Rm.T @ Li.T); dev.append(max(np.linalg.eigvalsh(Li@(q-Rm)@(q-Rm).T@Li.T).max() for q in d))
        pre.append((Jc[:,k].max(), RR, np.array(dev)))
    def eps(k, pq):
        Jmax, RR, dev = pre[k]
        main = np.linalg.eigvalsh(sum(pq[i]*RR[i] for i in range(6))).max(); dv = pq @ dev
        return Jmax * min((1+t)*main + (1+1/t)*dv for t in (0.003,0.01,0.03,0.1,0.3,1.0))
    def bound_T1(u, paired):
        a = np.prod((1 + CORN*u)/2, axis=1); pq = (1 - u*u)/4
        JP = a @ Jc; AP = JP @ a0
        ek = [eps(k, pq) for k in range(5)]
        Q = [AP * (a @ (lam*Jc[:,k])) / JP[k] for k in range(5)]
        if paired:      # GPT T1_SCALE_NEUTRAL "Theorem A" as stated (per-sector pairing) -- NOT valid, kept for comparison
            return min((1 - ek[k]) * Q[k] for k in range(5))
        return (1 - max(ek)) * min(Q)      # correct: corner Rayleigh bound holds only for the SUM over sectors
    us = [np.zeros(6)] + [rng.uniform(-1,1,6) for _ in range(nsamp)] + [rng.choice([-1,1],6)*rng.uniform(0.5,1,6) for _ in range(nsamp//4)]
    return min(bound_T1(u, False) for u in us), min(bound_T1(u, True) for u in us)
p = np.array(json.load(open('../G1/cell_r0.1_id71_rho0.008_v1.json'))['p'])
import os
CACHE = os.environ.get('T1CACHE', 't1_corner_cache.json'); cache = json.load(open(CACHE)) if os.path.exists(CACHE) else {}
for rho in [float(r) for r in (sys.argv[1:] or ['0.012', '0.014', '0.016'])]:
    key = '%.6f' % rho
    if key not in cache:
        cache[key] = [Ff(p + rho*s) for s in CORN]; json.dump(cache, open(CACHE, 'w'))
    Fcor = np.array(cache[key]) - 0.0003
    t1, t1p = probe(p, rho, Fcor, nsamp=1500)
    print('id71 rho %.3f  T1 (correct, global eps) margin %+.5f | per-sector-paired margin %+.5f  (minF-F* %+.5f)' % (rho, t1 - FS, t1p - FS, Fcor.min() - FS), flush=True)
