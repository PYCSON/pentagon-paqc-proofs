"""Head-to-head pilot: PAQC (float, non-rigorous) at Liu's binding outer cell on the v* ray.
Liu: x5 = regular pentagon inscribed in unit circle, v*_j = sqrt(5/3)[delta_j0 (1,0) - (1,0)/5 - x5_j/5],
Q_t = (G(x5+t v*) - G(x5))/t^2, binding Temple cell t in [0.22953, 0.23445], accepted direction radius 9.84e-4.
"""
import sys, numpy as np
sys.path.insert(0, '<sandbox>/research-hub/lines/D-topics/probes/MEAS-01/claude/scripts/C456')
import paqc
from mps import poly_area
x5 = np.array([[np.cos(2*np.pi*j/5), np.sin(2*np.pi*j/5)] for j in range(5)])
v = np.zeros((5, 2)); v[0, 0] = 1.0
v = v - np.array([1.0, 0]) / 5 - x5 / 5
v *= np.sqrt(5/3)
print('|v*| =', np.linalg.norm(v), ' <v,x5> =', np.sum(v*x5), ' sum v =', v.sum(axis=0))
def to_chart(V):
    # rotate/translate/scale so that V0=(0,0), V1=(1,0); return free coords V2..V4
    V = V - V[0]; e = V[1]; s = np.linalg.norm(e); a = np.arctan2(e[1], e[0])
    R = np.array([[np.cos(-a), -np.sin(-a)], [np.sin(-a), np.cos(-a)]])
    W = (V @ R.T) / s
    return W[2:].reshape(-1)
G0 = paqc.FSTAR
mode = sys.argv[1]
if mode == 'ray':
    for t in [0.05, 0.1, 0.15, 0.2, 0.232, 0.3, 0.4, 0.5, 0.6, 0.6725]:
        P = x5 + t * v
        p = to_chart(P)
        Fv = paqc.F(paqc.pent(p))
        print('t=%.4f  G-G0=%.4e  Q_t=%.5f  chart-dist=%.4f' % (t, Fv - G0, (Fv - G0) / t**2, np.linalg.norm(p - paqc.r5_params())), flush=True)
else:
    t = float(sys.argv[2])
    p = to_chart(x5 + t * v)
    Fp = paqc.F(paqc.pent(p)); gap = Fp / G0 - 1
    print('t=%.4f gap(rel)=%.3e chart-dist=%.4f' % (t, gap, np.linalg.norm(p - paqc.r5_params())), flush=True)
    for rho in [float(x) for x in sys.argv[3:]]:
        o = paqc.cube_bound(p, rho, nsamp=1500, check=2)
        print('  rho=%.2e  LB-F*=%.3e ok=%s e=%.2e e\'=%.2e  minF-F*=%.3e (%.0fs)' % (rho, o['LB'] - G0, o['LB'] > G0, o['emax'], o['epmax'], o['Fmin'] - G0, o['t']), flush=True)
