"""Near-region continuum cost by radius band, identity and relabelled (Claude, 2026-11-06; ESTIMATE, D_half, box counts,
split + split2 re-tests merged, pair = mean of members).  Used by ARCH_V2.md section 4.  Usage: python3 band_cost.py"""
import sys, os, json, math
import numpy as np
sys.argv=['plan_cost.py','--zd2']
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import plan_cost as PCo
VA=PCo.VA; RC=VA.RC
r3 = VA.merge_zd({json.loads(l)['id']: json.loads(l) for l in open(os.path.join(VA.T1, 'results_run3', 'results.jsonl'))}, 'run3')
cs = {json.loads(l)['id']: json.loads(l) for l in open(os.path.join(VA.T1, 'centres_run2.jsonl'))}
strata = json.load(open(os.path.join(PCo.L, 'orbit_valid', 'strata.json')))
gp,_,_=VA.gains(os.path.join(VA.OP,'results_all98.jsonl'),os.path.join(VA.OP,'centres_orbit.jsonl'),r3,'pilot')
gv,_,_=VA.gains(os.path.join(PCo.L,'orbit_valid','out_sandbox','results.jsonl'),os.path.join(PCo.L,'orbit_valid','centres_valid.jsonl'),r3,'valid')
G=dict(gv); G.update(gp)
for name,s in strata.items():
    lo,hi=s['band']; nb=sum(1 for x in r3.values() if lo<=x['r']<hi)
    f=VA.K*math.log(hi/lo)/nb/86400*VA.HALF
    bins={}
    for i,x in r3.items():
        if lo<=x['r']<hi and RC.in_D(RC.XS+x['r']*np.array(cs[i]['d']))[0]:
            c=VA.best_density(x)*(2*x['r'])**6*f
            b=round(math.floor(x['r']*10)/10,1); bins.setdefault(b,[0,0,0]); bins[b][0]+=c; bins[b][1]+=c/max(1,G.get(i,1)); bins[b][2]+=1
    print(name, {k:[round(v[0]),round(v[1]),v[2]] for k,v in sorted(bins.items())})
