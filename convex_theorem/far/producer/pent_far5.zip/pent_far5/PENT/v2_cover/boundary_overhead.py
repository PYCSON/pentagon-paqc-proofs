"""Boundary overhead of a box-cell cover of the Dirichlet domain D (Claude, 2026-11-04; an ESTIMATE, not a proof).

run3_cost.py estimates the continuum proxy  int_{D cap band} c(y) dy  (c = cost per chart volume of a PAQC cell of the
best passing size at y).  A real cover uses whole cells, so every cell that meets D is paid in full.  For a cell grid of
half-width rho with a random offset, the expected cost is  int_{D (+) box_rho} c(y) dy, where (+) is the Minkowski sum
(the points y whose box of half-width rho(y) meets D).  This program estimates the ratio
    Theta = int_{D (+) box} c / int_D c
from the run3 sample (all centres of a band, in or out of D, are a sample of the band's shell measure):
  A (dilation):  sum over centres y whose box meets D of c(y)  /  sum over centres y in D of c(y);
                 'meets D' is tested by 4096 uniform points in the box plus local minimisation of
                 h(x) = |x - x*| - min_g |phi_g(x) - x*|  (h <= 0 iff x in D) from the 4 best points;
                 95% bootstrap interval over the band's centres (4000 resamples);
  descriptive:   cost-weighted mean fraction of the centred box of half-width rho that lies in D (4096 points).
                 (A '1 / fill fraction' cross-check was tried and dropped: many expensive centres sit on thin parts of D
                 where the fraction is ~0, so that estimator has no usable variance.)
Cost units: T = 29.25 + KAPPA * boxes, KAPPA = 0.067 s/box (see ../local/orbit_valid/PROGRESS.md).
The band ends (r = 0.05: the excluded neighbourhood; r = 0.6: the near/far seam) are not part of this ratio.
Usage: python3 boundary_overhead.py [--seed 1]"""
import sys, os, json, math
import numpy as np
from scipy.optimize import minimize
HERE = os.path.dirname(os.path.abspath(__file__))
T1 = os.path.join(HERE, '..', 'local', 't1_sweep')
XS = np.array([1.3090169943749472, 0.9510565162951535, 0.49999999999999994, 1.5388417685876266,
               -0.30901699437494745, 0.9510565162951536])
KAPPA = 0.067
BANDS = [(0.05, 0.2), (0.2, 0.6)]
IDX = []
for k in range(5):
    for rev in (False, True):
        IDX.append(([(k - j) % 5 for j in range(5)] if rev else [(k + j) % 5 for j in range(5)], rev))


def orbit_dist(X):
    """X: (N, 6) chart points -> (10, N) distances of the 10 relabelled chart points to x* (same order as run3_cost.orbit)."""
    X = np.atleast_2d(X); N = len(X)
    z = np.stack([np.zeros(N), np.ones(N), X[:, 0] + 1j * X[:, 1], X[:, 2] + 1j * X[:, 3], X[:, 4] + 1j * X[:, 5]], 1)
    out = []
    for idx, rev in IDX:
        w = z[:, idx]; u = (w - w[:, :1]) / (w[:, 1:2] - w[:, :1])
        if rev:
            u = np.conj(u)
        y = np.stack([u[:, 2].real, u[:, 2].imag, u[:, 3].real, u[:, 3].imag, u[:, 4].real, u[:, 4].imag], 1)
        out.append(np.linalg.norm(y - XS, axis=1))
    return np.array(out)


def hD(X):
    d = orbit_dist(X)
    return d[0] - d[1:].min(0)


def best_cell(rec):
    b = None
    for t in rec['tests']:
        if t.get('ok'):
            T = 29.25 + KAPPA * (t.get('boxes') or 0); dens = T / (2 * t['rho']) ** 6
            if b is None or dens < b[0]:
                b = (dens, t['rho'])
    return b


def box_meets_D(y, rho, rng, m=4096):
    P = y + rho * rng.uniform(-1, 1, (m, 6))
    h = hD(P)
    if (h <= 0).any():
        return True
    for k in np.argsort(h)[:4]:
        res = minimize(lambda x: float(hD(x[None])[0]), P[k], method='L-BFGS-B',
                       bounds=[(a - rho, a + rho) for a in y], options=dict(maxiter=200))
        if res.fun <= 0:
            return True
    return False


def centred_fraction(y, rho, rng, m=4096):
    return float((hD(y + rho * rng.uniform(-1, 1, (m, 6))) <= 0).mean())


def main():
    seed = int(sys.argv[sys.argv.index('--seed') + 1]) if '--seed' in sys.argv else 1
    rng = np.random.default_rng(seed)
    r3 = {json.loads(l)['id']: json.loads(l) for l in open(os.path.join(T1, 'results_run3', 'results.jsonl'))}
    cs = {json.loads(l)['id']: json.loads(l) for l in open(os.path.join(T1, 'centres_run2.jsonl'))}
    rep = {}; rows_all = []
    for lo, hi in BANDS:
        rows = []
        for i, x in r3.items():
            if not lo <= x['r'] < hi:
                continue
            y = XS + cs[i]['r'] * np.array(cs[i]['d'])
            inD = bool(hD(y[None])[0] <= 1e-15)
            b = best_cell(x)
            if b is None:
                rows.append(dict(id=i, r=x['r'], inD=inD, dens=None)); continue
            dens, rho = b
            meets = inD or box_meets_D(y, rho, rng)
            fr = centred_fraction(y, rho, rng) if inD else None
            rows.append(dict(id=i, r=x['r'], inD=inD, meets=bool(meets), dens=dens, rho=rho, frac=fr))
        ok = [w for w in rows if w['dens'] is not None]
        num = np.array([w['dens'] * w['meets'] for w in ok]); den = np.array([w['dens'] * w['inD'] for w in ok])
        th = num.sum() / den.sum(); bs = []
        for _ in range(4000):
            k = rng.integers(0, len(ok), len(ok)); bs.append(num[k].sum() / max(den[k].sum(), 1e-300))
        inn = [w for w in ok if w['inD']]
        fw = sum(w['dens'] * w['frac'] for w in inn) / sum(w['dens'] for w in inn)
        key = '[%.2f,%.2f)' % (lo, hi)
        rep[key] = dict(centres=len(rows), in_D=len(inn), box_meets_D=int(sum(w['meets'] for w in ok)),
                        no_pass_skipped=[w['id'] for w in rows if w['dens'] is None], theta=round(float(th), 3),
                        theta_95=[round(float(v), 3) for v in np.percentile(bs, [2.5, 97.5])],
                        cost_weighted_centred_fraction_in_D=round(fw, 3))
        print(json.dumps({key: rep[key]}), flush=True); rows_all += [dict(band=key, **w) for w in rows]
    with open(os.path.join(HERE, 'boundary_overhead_rows.jsonl'), 'w') as f:
        for w in rows_all:
            f.write(json.dumps(w) + '\n')
    json.dump(rep, open(os.path.join(HERE, 'boundary_overhead.json'), 'w'), indent=1)


if __name__ == '__main__':
    main()
