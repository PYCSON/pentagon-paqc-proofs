"""Two fundamental domains for the inner band, priced from the run3 sample alone (Claude, 2026-11-04; an ESTIMATE).

  D   : Dirichlet domain (the labelling closest to x*), used so far;
  D_E : longest-edge domain: edge V0V1 is a longest edge (|V_{k+1} - V_k| <= 1 for k = 1..4) and |V2 - V1| >= |V0 - V4|
        (orientation tie-break).  Both are fundamental domains of the 10 relabellings (one representative per shape).
Shapes are put in bands by the labelling-invariant r_D = min over the 10 labellings of |phi_g(x) - x*|.  The run3 centres
are log-uniform in s = |y - x*| on [0.02, 0.6] with uniform directions, so for any chart region W inside s < 0.6
    int_W T(y) / (2 rho(y))^6 dy  ~  sum over s-strata [a, b) of  (pi^3/64) ln(b/a) mean_{centres in [a, b)} 1_W T q^-6
(q = rho / s; T = 29.25 + 0.067 * boxes at the best passing size).  For shapes with r_D in [0.05, 0.2) every D_E
representative has s < 0.6 (checked below on the sample), so the inner band is fully inside the sampled range; the outer
band is not (D_E representatives can lie beyond s = 0.6) and is not estimated here.
For each domain: the continuum proxy (CPU-days) and the boundary ratio Theta (centres whose box of half-width rho meets
the domain / centres in the domain, cost-weighted; boxes tested as in boundary_overhead.py), with 95% bootstrap intervals.
Usage: python3 domain_compare.py [--seed 1]"""
import sys, os, json, math
import numpy as np
from scipy.optimize import minimize
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import boundary_overhead as B
K = math.pi ** 3 / 64
STRATA = [(0.02, 0.05), (0.05, 0.2), (0.2, 0.6)]


def verts(X):
    X = np.atleast_2d(X); N = len(X)
    return np.stack([np.zeros(N), np.ones(N), X[:, 0] + 1j * X[:, 1], X[:, 2] + 1j * X[:, 3], X[:, 4] + 1j * X[:, 5]], 1)


def hE(X):
    """<= 0 iff X in D_E: max of (e_k - 1) for k = 1..4 and (e_4 - e_1)."""
    z = verts(X); e = np.abs(np.roll(z, -1, axis=1) - z)          # e[:, k] = |V_{k+1} - V_k|
    return np.max(np.stack([e[:, 1] - 1, e[:, 2] - 1, e[:, 3] - 1, e[:, 4] - 1, e[:, 4] - e[:, 1]], 1), 1)


def meets(h, y, rho, rng, m=4096):
    P = y + rho * rng.uniform(-1, 1, (m, 6)); v = h(P)
    if (v <= 0).any():
        return True
    for k in np.argsort(v)[:4]:
        res = minimize(lambda x: float(h(x[None])[0]), P[k], method='L-BFGS-B', bounds=[(a - rho, a + rho) for a in y],
                       options=dict(maxiter=200))
        if res.fun <= 0:
            return True
    return False


def main():
    seed = int(sys.argv[sys.argv.index('--seed') + 1]) if '--seed' in sys.argv else 1
    rng = np.random.default_rng(seed)
    r3 = {json.loads(l)['id']: json.loads(l) for l in open(os.path.join(B.T1, 'results_run3', 'results.jsonl'))}
    cs = {json.loads(l)['id']: json.loads(l) for l in open(os.path.join(B.T1, 'centres_run2.jsonl'))}
    nstr = {s: sum(1 for x in r3.values() if s[0] <= x['r'] < s[1]) for s in STRATA}
    rows = []
    for i, x in r3.items():
        st = next(s for s in STRATA if s[0] <= x['r'] < s[1] or (s == STRATA[-1] and x['r'] <= 0.6))
        y = B.XS + cs[i]['r'] * np.array(cs[i]['d'])
        rD = float(B.orbit_dist(y[None]).min())
        b = B.best_cell(x)
        w = K * math.log(st[1] / st[0]) / nstr[st] / 86400                  # days per (T q^-6) unit for this stratum
        row = dict(id=i, s=x['r'], rD=rD, w=w, inD=bool(B.hD(y[None])[0] <= 1e-15), inE=bool(hE(y[None])[0] <= 0))
        if b is not None:
            dens, rho = b
            row.update(v=dens * (2 * x['r']) ** 6, rho=rho)
            if 0.03 <= rD < 0.25:                                            # only boxes that can matter for the inner band
                row['meetD'] = row['inD'] or meets(B.hD, y, rho, rng)
                row['meetE'] = row['inE'] or meets(hE, y, rho, rng)
        rows.append(row)
    inner = [w for w in rows if 0.05 <= w['rD'] < 0.2]
    print('inner-band shapes in the sample: in D %d, in D_E %d; max s of a D_E point with r_D < 0.2: %.3f'
          % (sum(w['inD'] for w in inner), sum(w['inE'] for w in inner), max(w['s'] for w in inner if w['inE'])))
    bad = [w['id'] for w in inner if (w['inD'] or w['inE']) and 'v' not in w]
    print('inner-band domain centres with no passing size:', bad)
    rep = {}
    for dom in ('D', 'E'):
        A = [w for w in inner if 'v' in w]
        num = np.array([w['w'] * w['v'] * w['meet' + dom] for w in A]); den = np.array([w['w'] * w['v'] * w['in' + dom] for w in A])
        bs = []; bp = []
        for _ in range(4000):
            k = rng.integers(0, len(A), len(A)); bs.append(num[k].sum() / max(den[k].sum(), 1e-300)); bp.append(den[k].sum())
        rep[dom] = dict(proxy_days=round(float(den.sum())), proxy_95=[round(float(v)) for v in np.percentile(bp, [2.5, 97.5])],
                        theta=round(float(num.sum() / den.sum()), 3), theta_95=[round(float(v), 3) for v in np.percentile(bs, [2.5, 97.5])],
                        cover_days=round(float(num.sum())))
        print(dom, rep[dom], flush=True)
    json.dump(rep, open(os.path.join(HERE, 'domain_compare.json'), 'w'), indent=1)


if __name__ == '__main__':
    main()
