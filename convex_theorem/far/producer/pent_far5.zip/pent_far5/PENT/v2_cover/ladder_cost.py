"""Overhead of the size ladder and of first-attempt failures, from the sample3 measurements (Claude, 2026-11-08;
an ESTIMATE, not a proof).  The continuum cost (valid_analyze.best_density, the basis of the published 465-590 CPU-day
figure) gives every shape its cheapest measured passing size with the v1.0 corner cost (29.25 s per cell).  The
production planner cannot: cells come in dyadic sizes rho_L = 5 / 2^(L+2) (a cube is split into 64 children, the
volume ladder has factor 64), the level is chosen by rho_target = q * r with q the MEDIAN cheapest-size ratio of the
band (near_planner.rho_target), and a cell whose first T1 fails is split after spending its whole B&B budget.  Neither
effect is in theta (domain-boundary overhead only, theta_fpsi_rig.py) nor in plan_cost.py.  This program simulates
the planner's rule on every measured shape:
  boxes(rho): log-log interpolation between the shape's tested sizes; below the smallest tested size, if the min-corner
              form passed there it is assumed to pass at every smaller size (no B&B), otherwise boxes are extrapolated
              with slope beta = 12 (GPT PENT-07) and floored at 1;
  threshold : the shape passes at rho iff rho <= rho*, rho* in [rho_T1, rho_fail) (largest tested pass, smallest
              tested failure; the gap is ~9%); the expectation is taken over 5 quantiles of rho* in the gap;
  cost of a cell that passes            : CORNER + KAPPA * boxes(rho)
  cost of a cell that fails and is split: KAPPA * FAIL_BOXES + (children) * cost(next ladder size)
              children = 2^(6/steps): steps = 1 is the dyadic cube (64 children, volume / 64 per step), steps = 2
              splits three axes (8 children, volume / 8), steps = 3 two axes (4), steps = 6 one axis (2); the shape's
              behaviour on a box is modelled by the cube of the same volume (equal 'effective rho'), optimistic for
              elongated boxes.  The parent's corners are reused by the children, so a failure wastes only its B&B.
Planner density of a shape = expected cost / (2 rho_ladder)^6 with rho_ladder the largest ladder size <= q r;
oracle density = min over ladder sizes <= rho* of cost / volume (a planner that knew each shape's cheapest size);
ideal (published) density = best_density with CORNER 29.25.  Band totals weight each centre by r^6 (log-uniform r,
shell measure r^5 dr, as run3_cost) and the near-region CPU-days use the sample3 bands and overheads:
   days = 79 * inner_factor * 3.05 + 100 * outer_factor * 2.22   (inner identity, outer best labelling; theta rigorous)
Usage: python3 ladder_cost.py [--corner 10] [--results PATH] [--centres PATH]"""
import sys, os, json, math
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
KAPPA = 0.067; CORNER = 10.0; BETA = 12.0; PUBLISHED_CORNER = 29.25
INNER_DAYS, OUTER_DAYS, TH_IN, TH_OUT = 79.0, 100.0, 3.05, 2.22


def rho_ladder(target, steps):
    """largest ladder size (5/4) 2^(-k/steps) <= target (k = steps * L, L the dyadic level, for a cube)"""
    k = 0
    while 1.25 * 2 ** (-k / steps) > target:
        k += 1
    return 1.25 * 2 ** (-k / steps)


class Shape:
    def __init__(self, rec, corner):
        self.corner = corner; self.r = rec['r']; ts = sorted(rec['tests'], key=lambda t: t['rho'])
        self.ok = [(t['rho'], t['boxes'], t['mincorner_ok']) for t in ts if t.get('ok')]
        self.bad = [t['rho'] for t in ts if not t.get('ok')]
        self.rho_T1 = max(t[0] for t in self.ok); self.rho_fail = min(self.bad) if self.bad else None
        self.thresholds = [self.rho_T1] if self.rho_fail is None else [self.rho_T1 + (self.rho_fail - self.rho_T1) * (k + 0.5) / 5 for k in range(5)]

    def ideal(self, corner):
        return min((corner + KAPPA * b) / (2 * rho) ** 6 for rho, b, _ in self.ok)

    def boxes(self, rho):
        pts = [(math.log(r_), math.log(max(b, 1))) for r_, b, _ in self.ok]
        x = math.log(rho)
        if x <= pts[0][0]:
            if self.ok[0][2]:
                return 0.0
            return max(1.0, math.exp(pts[0][1] + BETA * (x - pts[0][0])))
        if x >= pts[-1][0]:
            sl = (pts[-1][1] - pts[-2][1]) / (pts[-1][0] - pts[-2][0]) if len(pts) >= 2 else BETA
            return math.exp(pts[-1][1] + sl * (x - pts[-1][0]))
        return math.exp(np.interp(x, [p[0] for p in pts], [p[1] for p in pts]))

    def cell_cost(self, rho):
        return self.corner + KAPPA * self.boxes(rho)

    def cost_thr(self, rho, thr, steps, fail_boxes, depth=0):
        if rho <= thr * (1 + 1e-12) or depth > 60:
            return self.cell_cost(rho)
        return KAPPA * fail_boxes + 2 ** (6 // steps) * self.cost_thr(rho * 2 ** (-1.0 / steps), thr, steps, fail_boxes, depth + 1)

    def planner_density(self, q, steps, fail_boxes):
        rho = rho_ladder(q * self.r, steps)
        return sum(self.cost_thr(rho, t, steps, fail_boxes) for t in self.thresholds) / len(self.thresholds) / (2 * rho) ** 6

    def first_try_fails(self, q, steps):
        rho = rho_ladder(q * self.r, steps)
        return sum(1 for t in self.thresholds if rho > t) / len(self.thresholds)

    def oracle_density(self, steps):
        best = None
        for thr in self.thresholds:
            rho = rho_ladder(thr, steps); b = None
            for _ in range(40):
                d = self.cell_cost(rho) / (2 * rho) ** 6
                b = d if b is None else min(b, d); rho *= 2 ** (-1.0 / steps)
                if rho < 1e-4:
                    break
            best = b if best is None else best + b
        return best / len(self.thresholds)


def load(corner, res, cen):
    C = {json.loads(l)['id']: json.loads(l) for l in open(cen)}
    R = [json.loads(l) for l in open(res)]
    R = [r for r in R if r['status'] == 'ok' and any(t.get('ok') for t in r['tests'])]
    inner = [Shape(r, corner) for r in R if C[r['id']]['band'] == 'inner' and C[r['id']]['g'] == 0]
    best = {}
    for r in R:
        c = C[r['id']]
        if c['band'] != 'outer':
            continue
        s = Shape(r, corner); w = s.ideal(PUBLISHED_CORNER) * (c.get('detJ') or 1.0)   # labelling comparison in the original chart
        if c['orig'] not in best or w < best[c['orig']][0]:
            best[c['orig']] = (w, s)
    return inner, [s for _, s in best.values()]


def main():
    a = sys.argv[1:]
    corner = float(a[a.index('--corner') + 1]) if '--corner' in a else CORNER
    res = a[a.index('--results') + 1] if '--results' in a else os.path.join(HERE, '..', 'local', 'sample3', 'results_20261107', 'results.jsonl')
    cen = a[a.index('--centres') + 1] if '--centres' in a else os.path.join(HERE, '..', 'local', 'sample3', 'centres_sample3.jsonl')
    inner, outer = load(corner, res, cen)
    den_in = sum(s.r ** 6 * s.ideal(PUBLISHED_CORNER) for s in inner); den_out = sum(s.r ** 6 * s.ideal(PUBLISHED_CORNER) for s in outer)
    W = lambda shapes, f: sum(s.r ** 6 * f(s) for s in shapes)
    days = lambda fi, fo: INNER_DAYS * fi * TH_IN + OUTER_DAYS * fo * TH_OUT
    out = dict(corner=corner, n_inner=len(inner), n_outer_best=len(outer), published_days_lower=days(1, 1), rows=[])
    print('corner cost per cell %.2f s (published ideal used %.2f); factors are relative to the published ideal; days = 79*in*3.05 + 100*out*2.22 = %.0f at factor 1'
          % (corner, PUBLISHED_CORNER, days(1, 1)))
    fi = W(inner, lambda s: s.ideal(corner)) / den_in; fo = W(outer, lambda s: s.ideal(corner)) / den_out
    print('continuum ideal with this corner cost: inner %.2f outer %.2f -> %.0f CPU-days' % (fi, fo, days(fi, fo)))
    out['ideal_this_corner'] = dict(inner=fi, outer=fo, days=days(fi, fo))
    for steps in (1, 2, 3, 6):
        oi = W(inner, lambda s: s.oracle_density(steps)) / den_in; oo = W(outer, lambda s: s.oracle_density(steps)) / den_out
        print('== %d split step(s) per halving (%d children): oracle inner %.2f outer %.2f -> %.0f CPU-days' % (steps, 2 ** (6 // steps), oi, oo, days(oi, oo)))
        out['rows'].append(dict(steps=steps, kind='oracle', inner=oi, outer=oo, days=days(oi, oo)))
        for fb in (6000, 3000, 1000):
            for qi, qo in ((0.147, 0.055), (0.125, 0.047), (0.176, 0.066)):
                pi = W(inner, lambda s: s.planner_density(qi, steps, fb)) / den_in; po = W(outer, lambda s: s.planner_density(qo, steps, fb)) / den_out
                ffi = sum(s.first_try_fails(qi, steps) for s in inner) / len(inner); ffo = sum(s.first_try_fails(qo, steps) for s in outer) / len(outer)
                print('   fail_boxes %4d q=(%.3f, %.3f): inner %.2f outer %.2f -> %4.0f CPU-days   first-try failures %.0f%% / %.0f%%'
                      % (fb, qi, qo, pi, po, days(pi, po), 100 * ffi, 100 * ffo))
                out['rows'].append(dict(steps=steps, kind='planner', fail_boxes=fb, q_inner=qi, q_outer=qo, inner=pi, outer=po, days=days(pi, po), fail_share=(ffi, ffo)))
    json.dump(out, open(os.path.join(HERE, 'ladder_cost.json'), 'w'), indent=1)


if __name__ == '__main__':
    main()
