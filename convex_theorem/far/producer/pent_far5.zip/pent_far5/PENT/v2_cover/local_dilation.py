"""Local boundary ratio of a box cover, for D and for the relabelled domain D' (Claude, 2026-11-04; an ESTIMATE).

boundary_overhead.py estimates Theta = vol_c(D (+) box) / vol_c(D) from the run3 sample, which only exists in the
identity chart near D.  The relabelled domain D' (each shape represented by its chosen labelling) lies elsewhere, where
we only have the pilot / validation measurements.  This program uses a LOCAL version of the same ratio around each
measured point y of a domain W with cell half-width rho (assumed constant nearby):
    theta_loc(y) = #{u in U : box(u, rho) meets W} / #{u in U : u in W},   U = 256 uniform points of box(y, 3 rho),
('meets' by 512 uniform points in the box, no local minimisation, so theta_loc is a slight underestimate), and the
cost-weighted mean over the measured points of a band.  Run on D with the run3 centres it calibrates against
boundary_overhead.py; run on D' it estimates the boundary ratio after relabelling.
D' near a relabelled point y = phi_g(x) is taken to be phi_g(D) (D with both mirror copies, so the ratio is that of
phi_g(D_half) up to the axis-aligned mirror cut) (the rule is assumed constant near x, so switches
between labellings are NOT included -- a lower estimate for D'); z in phi_g(D) iff orbit(rep_D(z))[g] = z.
Units: T = 29.25 + 0.067 * boxes.  Usage: python3 local_dilation.py [--seed 1]"""
import sys, os, json, math
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import boundary_overhead as B
L = os.path.join(HERE, '..', 'local')
BANDS = B.BANDS


def orbit_pts(X):
    X = np.atleast_2d(X); N = len(X)
    z = np.stack([np.zeros(N), np.ones(N), X[:, 0] + 1j * X[:, 1], X[:, 2] + 1j * X[:, 3], X[:, 4] + 1j * X[:, 5]], 1)
    out = []
    for idx, rev in B.IDX:
        w = z[:, idx]; u = (w - w[:, :1]) / (w[:, 1:2] - w[:, :1])
        if rev:
            u = np.conj(u)
        out.append(np.stack([u[:, 2].real, u[:, 2].imag, u[:, 3].real, u[:, 3].imag, u[:, 4].real, u[:, 4].imag], 1))
    return np.array(out)                                         # (10, N, 6)


def in_image(Z, g):
    """Z in phi_g(D)?  D contains every shape twice (x and its mirror phi_3(x), at equal distance from x*; see
    MIRROR.md), so both tied representatives are tried."""
    if g == 0:
        return B.hD(Z) <= 1e-12
    O = orbit_pts(Z); d = np.linalg.norm(O - B.XS, axis=2); dm = d.min(0)
    out = np.zeros(len(Z), bool)
    for j in range(10):
        cand = d[j] <= dm + 1e-12
        if not cand.any():
            continue
        back = orbit_pts(O[j, cand])[g]
        out[np.where(cand)[0]] |= np.linalg.norm(back - Z[cand], axis=1) < 1e-9 * (1 + np.linalg.norm(Z[cand], axis=1))
    return out


def theta_loc(y, rho, g, rng, nu=256, nm=512):
    U = y + 3 * rho * rng.uniform(-1, 1, (nu, 6))
    inW = in_image(U, g)
    meet = np.zeros(nu, bool)
    for k in range(nu):
        meet[k] = inW[k] or in_image(U[k] + rho * rng.uniform(-1, 1, (nm, 6)), g).any()
    return meet.sum() / max(inW.sum(), 1), int(inW.sum())


def best(rec):
    return B.best_cell(rec)


def load(p):
    return {json.loads(l)['id']: json.loads(l) for l in open(os.path.join(L, p))}


def main():
    seed = int(sys.argv[sys.argv.index('--seed') + 1]) if '--seed' in sys.argv else 1
    rng = np.random.default_rng(seed)
    r3 = load('t1_sweep/results_run3/results.jsonl'); cs = load('t1_sweep/centres_run2.jsonl')
    # relabelled points: best measured labelling per original centre (pilot + validation)
    pts = {}
    for cf, rf in (('orbit_pilot/centres_orbit.jsonl', 'orbit_pilot/results_all98.jsonl'),
                   ('orbit_valid/centres_valid.jsonl', 'orbit_valid/out_sandbox/results.jsonl')):
        C = load(cf); R = load(rf)
        for cid, c in C.items():
            if cid not in R or best(R[cid]) is None:
                continue
            dens, rho = best(R[cid]); v = c['detJ'] * dens                # cost per ORIGINAL chart volume
            o = c['orig']
            if o not in pts or v < pts[o]['v']:
                pts[o] = dict(v=v, g=c['g'], y=B.XS + c['r'] * np.array(c['d']), rho=rho)
    rep = {}
    for lo, hi in BANDS:
        key = '[%.2f,%.2f)' % (lo, hi); res = {}
        # D, calibration on run3 centres in D
        num = den = 0.0; n = 0
        for i, x in r3.items():
            if not lo <= x['r'] < hi:
                continue
            y = B.XS + cs[i]['r'] * np.array(cs[i]['d'])
            if B.hD(y[None])[0] > 1e-15:
                continue
            dens, rho = best(x); t, _ = theta_loc(y, rho, 0, rng); num += dens * t; den += dens; n += 1
        res['D_run3'] = dict(points=n, theta_loc=round(num / den, 3))
        # D' at the measured centres: chosen labelling if it beats identity, else identity
        numI = denI = numR = denR = 0.0; m = 0
        for o, p in pts.items():
            if not lo <= r3[o]['r'] < hi:
                continue
            c0, rho0 = best(r3[o]); yI = B.XS + cs[o]['r'] * np.array(cs[o]['d'])
            tI, _ = theta_loc(yI, rho0, 0, rng); numI += c0 * tI; denI += c0
            if p['v'] < c0:
                tR, _ = theta_loc(p['y'], p['rho'], p['g'], rng); cR = p['v']
            else:
                tR, cR = tI, c0
            numR += cR * tR; denR += cR; m += 1
        res['measured_centres'] = dict(points=m, theta_loc_identity=round(numI / denI, 3), theta_loc_relabelled=round(numR / denR, 3))
        rep[key] = res; print(key, json.dumps(res), flush=True)
    json.dump(rep, open(os.path.join(HERE, 'local_dilation.json'), 'w'), indent=1)


if __name__ == '__main__':
    main()
