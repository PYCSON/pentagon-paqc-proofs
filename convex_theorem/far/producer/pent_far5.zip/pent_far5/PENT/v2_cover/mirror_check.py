"""Mirror check (Claude, 2026-11-04).  Prints:
 (1) for each relabelling g, max_x | |phi_g(x) - x*| - |x - x*| | over 2000 random chart points: g = 3 (vertex order
     1,0,4,3,2 + conjugation = the mirror in the perpendicular bisector of V0V1) gives 0 to rounding, i.e. phi_3 is a
     linear isometry of the chart fixing x*:  phi_3(x0..x5) = (1-x4, x5, 1-x2, x3, 1-x0, x1);
 (2) the exact mirror pairs: phi_3(phi_g(x)) = phi_h(x) for all x  ->  pairs (0,3) (1,8) (2,5) (4,7) (6,9);
 (3) the share of run3 centres in D and in D_half = D cap {x2 >= 1/2} (D contains both x and phi_3(x));
 (4) measured cost ratios between the two members of a mirror pair (pilot + validation), and the T1 outcomes
     'exception:ZeroDivisionError()' (Jet.recip of an enclosure containing 0, which aborts the whole test) in run3,
     the pilot and the validation.
Usage: python3 mirror_check.py"""
import sys, os, json, math, collections
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import boundary_overhead as B
sys.path.insert(0, B.T1)
import run3_cost as RC
L = os.path.join(HERE, '..', 'local')
PAIR = {0: 3, 3: 0, 1: 8, 8: 1, 2: 5, 5: 2, 4: 7, 7: 4, 6: 9, 9: 6}


def load(p):
    return {json.loads(l)['id']: json.loads(l) for l in open(os.path.join(L, p))}


def main():
    rng = np.random.default_rng(7)
    X = B.XS + rng.normal(size=(2000, 6)) * 0.1
    d = B.orbit_dist(X)
    print('(1) max | d_g - d_0 |:', ' '.join('g%d %.1e' % (g, abs(d[g] - d[0]).max()) for g in range(10)))
    y = X[0]; z = np.array(RC.orbit(y)[3]); lin = np.array([1 - y[4], y[5], 1 - y[2], y[3], 1 - y[0], y[1]])
    print('    phi_3 formula check: %.1e' % np.abs(z - lin).max())
    x = X[1]; O = np.array(RC.orbit(x)); pairs = {}
    for g in range(10):
        w = np.array(RC.orbit(O[g])[3]); h = int(np.linalg.norm(O - w, axis=1).argmin()); pairs[g] = h
    print('(2) phi_3 . phi_g = phi_h:', pairs, '(expected', PAIR, ')')
    r3 = load('t1_sweep/results_run3/results.jsonl'); cs = load('t1_sweep/centres_run2.jsonl')
    nD = nH = 0
    for i in r3:
        p = B.XS + cs[i]['r'] * np.array(cs[i]['d'])
        if B.hD(p[None])[0] <= 1e-12:
            nD += 1; nH += p[2] >= 0.5
    print('(3) run3 centres: %d, in D %d (%.0f%%), in D_half %d (%.0f%%)' % (len(r3), nD, 100 * nD / len(r3), nH, 100 * nH / len(r3)))

    def bd(rec):
        b = None
        for t in rec['tests']:
            if t.get('ok'):
                v = (29.25 + 0.067 * (t.get('boxes') or 0)) / (2 * t['rho']) ** 6; b = v if b is None else min(b, v)
        return b
    lr = []
    for cf, rf in (('orbit_pilot/centres_orbit.jsonl', 'orbit_pilot/results_all98.jsonl'),
                   ('orbit_valid/centres_valid.jsonl', 'orbit_valid/out_sandbox/results.jsonl')):
        C = load(cf); R = load(rf)
        for cid, c in C.items():
            g = c['g']; mid = 100 * c['orig'] + PAIR[g]
            if g < PAIR[g] and cid in R and mid in R and bd(R[cid]) and bd(R[mid]):
                lr.append(abs(math.log(bd(R[cid]) / bd(R[mid]))))
    lr = np.array(lr)
    print('(4) mirror pairs measured: %d; cost ratio quantiles 50/75/90/max: %s' % (len(lr), np.round(np.exp(np.percentile(lr, [50, 75, 90, 100])), 2)))
    for p in ('t1_sweep/results_run3/results.jsonl', 'orbit_pilot/results_all98.jsonl', 'orbit_valid/out_sandbox/results.jsonl'):
        n = t = e = above = 0
        for rec in load(p).values():
            n += 1; ok = [u['rho'] for u in rec['tests'] if u.get('ok')]; hit = False
            for u in rec['tests']:
                t += 1
                if 'ZeroDivision' in (u.get('why') or ''):
                    e += 1; hit = hit or (ok and u['rho'] > min(ok))
            above += bool(hit)
        print('    %s: %d records, %d tests, %d ZeroDivisionError tests; records with one above a passing size: %d' % (p, n, t, e, above))


if __name__ == '__main__':
    main()
