"""Rigorous cell planner for the near-region cover, and its overhead on sample blocks (Claude, 2026-11-05; the planner
logic is meant for production, the block measurement is an ESTIMATE of the cover overhead).

Domain.  c = the symmetric base point (x*_0, x*_1, 1/2, x*_3, 1 - x*_0, x*_1) in exact floats: phi_3 (the mirror, a linear
isometry of the chart) fixes c exactly, so with
    D_c = {x : |x - c| <= |phi_h(x) - c| for every labelling h}   and   D_half = D_c cap {x_2 >= 1/2}
every pentagon has a representative in D_half (the orbit point closest to c, or its mirror; no rounding of x* is
involved, any base point gives a fundamental-domain cover, and an exactly phi_3-fixed one makes the mirror cut valid).
The near region is r_D = min_h |phi_h(x) - c| in [0.05, 0.6); in D_half, r_D = |x - c|.

Cover.  For a labelling g, a cell grid of side s in chart g (cells [s i, s (i + 1)]^6), and a set R_g of chart-g cells
(a block), the cell c is NEEDED unless it is proved that phi_g^{-1}(c) misses D_half cap shell.  Proof attempts
(excluded()) on ball-arithmetic enclosures of the pre-image of c or of sub-boxes of c (bisection of the widest side,
at most BUDGET boxes per cell):  x_2 < 1/2 on the whole box;  |x - c|^2 >= 0.36 or < 0.0025 on the whole box;  or some
h with sup |phi_h(x) - c|^2 < inf |x - c|^2 on the box.  Every needed cell is certified, so every pentagon with a
representative x in D_half cap shell and phi_g(x) in R_g is covered (DESIGN.md section 2).  A float pre-check (M
random points of c mapped back; any point inside -> needed at once) only saves work: including a cell is always safe.

Measurement (--measure): for each measured relabelled centre (pilot + validation, best measured labelling g, its best
passing half-width rho) and for run3 identity centres (--identity), a grid-aligned block of n^6 chart-g cells of side
s = 2^floor(log2(2 rho)) around the centre; Monte Carlo (MC points) gives the fraction f of the block inside
phi_g(D_half cap shell).  Overheads:  theta_float = (cells with a float point inside) / (f n^6)   (geometry only),
theta_rig = (needed cells) / (f n^6)   (what the rigorous planner certifies).  Cost-weighted per band.
Usage: python3 plan_cells.py --measure [--identity] [--n 4] [--budget 16] [--m 48] [--mc 40000] [--seed 1] [--limit K]
       [--natural] (natural-extension enclosures only) [--double-enclosure] (old test: enclose the pre-image, then map it again)"""
import sys, os, json, math, time
import numpy as np
from flint import arb, acb
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import boundary_overhead as BO

XS = BO.XS
C = np.array([XS[0], XS[1], 0.5, XS[3], 1.0 - XS[0], XS[1]])        # exact floats; phi_3(C) = C exactly
IDX = BO.IDX
INF = float('inf')


def orbit_np(X):
    """(N,6) -> (10,N,6) float chart images."""
    X = np.atleast_2d(X); N = len(X)
    z = np.stack([np.zeros(N), np.ones(N), X[:, 0] + 1j * X[:, 1], X[:, 2] + 1j * X[:, 3], X[:, 4] + 1j * X[:, 5]], 1)
    out = []
    for idx, rev in IDX:
        w = z[:, idx]; u = (w - w[:, :1]) / (w[:, 1:2] - w[:, :1])
        if rev:
            u = np.conj(u)
        out.append(np.stack([u[:, 2].real, u[:, 2].imag, u[:, 3].real, u[:, 3].imag, u[:, 4].real, u[:, 4].imag], 1))
    return np.array(out)


def _inverse_table():
    rng = np.random.default_rng(0); x = C + 0.05 * rng.normal(size=6); O = orbit_np(x[None])[:, 0]
    inv = []
    for g in range(10):
        back = orbit_np(O[g][None])[:, 0]; inv.append(int(np.linalg.norm(back - x, axis=1).argmin()))
    return inv


INV = _inverse_table()
PHI = None            # set below to phi_box_mv (default) or phi_box ('--natural')


MIRROR_FREE = [h for h in range(1, 10) if h != 3]      # phi_3 is an exact isometry fixing C: d_3 == d_0 identically


def inside_float(X):
    """float test of D_half cap shell (with base point C).  The condition for h = 3 holds with equality everywhere
    (phi_3 is the mirror, an exact isometry fixing C), so it is left out: testing it in floating point lets rounding
    noise reject about a third of the region (bug found by the independent check of 2026-11-06, fixed here)."""
    O = orbit_np(X); d = np.linalg.norm(O - C, axis=2)
    return (X[:, 2] >= 0.5) & (d[0] >= 0.05) & (d[0] < 0.6) & (d[0] <= d[MIRROR_FREE].min(0))


def _down(v):
    return math.nextafter(float(v), -INF)


def _up(v):
    return math.nextafter(float(v), INF)


def iv(l, h):
    return arb(l).union(arb(h))


def phi_box(lo, hi, g):
    """rigorous enclosure (float lo, hi, rounded outward) of phi_g over the identity... any chart box; None if undefined."""
    z = [acb(0), acb(1)] + [acb(iv(lo[2 * j], hi[2 * j]), iv(lo[2 * j + 1], hi[2 * j + 1])) for j in range(3)]
    idx, rev = IDX[g]; w = [z[i] for i in idx]; den = w[1] - w[0]
    if den.real.contains(0) and den.imag.contains(0):
        return None
    olo = []; ohi = []
    for j in (2, 3, 4):
        u = (w[j] - w[0]) / den
        if rev:
            u = u.conjugate()
        for part in (u.real, u.imag):
            if not part.is_finite():
                return None
            olo.append(_down(part.lower())); ohi.append(_up(part.upper()))
    return olo, ohi


def phi_box_mv(lo, hi, g):
    """mean-value form: phi(m) + J(box) (z - m), J the complex Jacobian enclosed over the box (holomorphic part; the
    conjugation of reversed labellings is applied at the end); intersected with the natural extension phi_box."""
    nat = phi_box(lo, hi, g)
    if nat is None:
        return None
    zb = [acb(0), acb(1)] + [acb(iv(lo[2 * j], hi[2 * j]), iv(lo[2 * j + 1], hi[2 * j + 1])) for j in range(3)]
    mid = [(l + h) / 2 for l, h in zip(lo, hi)]
    zm = [acb(0), acb(1)] + [acb(arb(mid[2 * j]), arb(mid[2 * j + 1])) for j in range(3)]
    dz = [None, None] + [zb[k] - zm[k] for k in (2, 3, 4)]                      # exact enclosure of z - m
    idx, rev = IDX[g]
    a, b = idx[0], idx[1]
    Db = zb[b] - zb[a]; Dm = zm[b] - zm[a]
    olo = []; ohi = []
    for j in (2, 3, 4):
        c = idx[j]
        um = (zm[c] - zm[a]) / Dm
        ub = (zb[c] - zb[a]) / Db
        # du = sum_k du/dz_k dz_k over the variable vertices k in {2,3,4}; du/dw_c = 1/D, du/dw_a = (u-1)/D, du/dw_b = -u/D
        du = acb(0)
        for k in (2, 3, 4):
            jk = acb(0)
            if k == c:
                jk += 1 / Db
            if k == a:
                jk += (ub - 1) / Db
            if k == b:
                jk -= ub / Db
            du += jk * dz[k]
        u = um + du
        if rev:
            u = u.conjugate()
        for part in (u.real, u.imag):
            if not part.is_finite():
                return nat
            olo.append(_down(part.lower())); ohi.append(_up(part.upper()))
    lo2 = [max(p, q) for p, q in zip(olo, nat[0])]; hi2 = [min(p, q) for p, q in zip(ohi, nat[1])]
    return lo2, hi2


def d2(lo, hi):
    """[inf, sup] of |x - C|^2 over the box (arb, rigorous)."""
    lo_s = arb(0); hi_s = arb(0)
    for i in range(6):
        a = arb(lo[i]) - arb(C[i]); b = arb(hi[i]) - arb(C[i])
        if a > 0:
            lo_s += a * a; hi_s += b * b
        elif b < 0:
            lo_s += b * b; hi_s += a * a
        else:
            m = a * a if (a * a) > (b * b) else b * b
            hi_s += m
    return lo_s.lower(), hi_s.upper()


def excluded(lo, hi):
    if hi[2] < 0.5:
        return True
    l0, h0 = d2(lo, hi)
    if l0 >= 0.36 or h0 < 0.0025:
        return True
    for h in range(1, 10):
        E = PHI(lo, hi, h)
        if E is None:
            continue
        _, hh = d2(*E)
        if hh < l0:
            return True
    return False


def jet_box(lo, hi, g):
    """phi_g at the box midpoint (arb), the range over the box (arb intervals), and the real 6x6 Jacobian enclosed
    over the box (arb), all rigorous.  None if undefined."""
    zb = [acb(0), acb(1)] + [acb(iv(lo[2 * j], hi[2 * j]), iv(lo[2 * j + 1], hi[2 * j + 1])) for j in range(3)]
    mid = [(l + h) / 2 for l, h in zip(lo, hi)]
    zm = [acb(0), acb(1)] + [acb(arb(mid[2 * j]), arb(mid[2 * j + 1])) for j in range(3)]
    idx, rev = IDX[g]; a, b = idx[0], idx[1]
    Db = zb[b] - zb[a]; Dm = zm[b] - zm[a]
    if (Db.real.contains(0) and Db.imag.contains(0)) or (Dm.real.contains(0) and Dm.imag.contains(0)):
        return None
    val = []; rng_ = []; J = [[None] * 6 for _ in range(6)]
    for t, j in enumerate((2, 3, 4)):
        c = idx[j]
        um = (zm[c] - zm[a]) / Dm; ub = (zb[c] - zb[a]) / Db
        sgn = -1 if rev else 1
        val += [um.real, sgn * um.imag]; rng_ += [ub.real, sgn * ub.imag]
        for kk, k in enumerate((2, 3, 4)):
            jk = acb(0)
            if k == c:
                jk += 1 / Db
            if k == a:
                jk += (ub - 1) / Db
            if k == b:
                jk -= ub / Db
            # real Jacobian of (Re U, Im U) wrt (Re z_k, Im z_k); conjugation flips the Im row
            J[2 * t][2 * kk] = jk.real; J[2 * t][2 * kk + 1] = -jk.imag
            J[2 * t + 1][2 * kk] = sgn * jk.imag; J[2 * t + 1][2 * kk + 1] = sgn * jk.real
    for v in val + rng_ + [x for row in J for x in row]:
        if not v.is_finite():
            return None
    return val, rng_, J


def diff_upper(jk, jg, lo, hi):
    """rigorous upper bound over the box of |phi_k - c|^2 - |phi_g - c|^2 (mean-value form)."""
    vk, rk, Jk = jk; vg, rg, Jg = jg
    f = arb(0)
    for j in range(6):
        f += (vk[j] - C[j]) ** 2 - (vg[j] - C[j]) ** 2
    up = f.upper()
    for i in range(6):
        gi_ = arb(0)
        for j in range(6):
            gi_ += 2 * ((rk[j] - C[j]) * Jk[j][i] - (rg[j] - C[j]) * Jg[j][i])
        up = up + abs(gi_).upper() * arb((hi[i] - lo[i]) / 2).upper()
    return up


def excluded_chart(lo, hi, g):
    """chart-g box [lo, hi] (no double enclosure): its pre-image is x = phi_{g'}(z), g' = INV[g], and the orbit of x is
    {phi_k(z)}, so every test uses one enclosure per labelling k of the chart-g box itself."""
    gi = INV[g]
    if gi == 0:
        # identity chart: the box itself, no enclosure.  sup x_2 <= 1/2 excludes: a point with x_2 = 1/2 on the box's
        # upper face also lies in the neighbouring box above (same partition, or the next grid cell), which cannot be
        # excluded because it contains that point.
        E0 = (list(lo), list(hi))
        if E0[1][2] <= 0.5:
            return True
    else:
        E0 = PHI(lo, hi, gi)
        if E0 is None:
            return False
        if E0[1][2] < 0.5:
            return True
    l0, h0 = d2(*E0)
    if l0 >= 0.36 or h0 < 0.0025:
        return True
    Es = {}
    for k in range(10):
        if k == gi:
            continue
        E = PHI(lo, hi, k)
        if E is None:
            continue
        _, hk = d2(*E)
        if hk < l0:
            return True
        Es[k] = hk
    if DIFF:                                                     # difference form, tried on the most promising k first
        jg = jet_box(lo, hi, gi)
        if jg is None:
            return False
        for k in sorted(Es, key=lambda k: Es[k])[:3]:
            jk = jet_box(lo, hi, k)
            if jk is not None and diff_upper(jk, jg, lo, hi) < 0:
                return True
    return False


def cell_needed(lo, hi, g, budget, rng, m):
    """chart-g cell [lo, hi]: True unless pre-image provably misses D_half cap shell."""
    gi = INV[g]
    U = np.array(lo) + (np.array(hi) - np.array(lo)) * rng.uniform(0, 1, (m, 6))
    if inside_float(orbit_np(U)[gi]).any():
        return True, 'float'
    stack = [(list(lo), list(hi))]; used = 0
    while stack:
        a, b = stack.pop(); used += 1
        if used > budget:
            return True, 'budget'
        if DIRECT:
            if excluded_chart(a, b, g):
                continue
        else:
            P = PHI(a, b, gi)
            if P is not None and excluded(*P):
                continue
        k = int(np.argmax(np.array(b) - np.array(a))); mid = (a[k] + b[k]) / 2
        b1 = list(b); b1[k] = mid; a2 = list(a); a2[k] = mid
        stack += [(a, b1), (a2, b)]
    return False, 'excluded'


def block_measure(y, g, rho, n, budget, m, mc, rng):
    s = 2.0 ** math.floor(math.log2(2 * rho))
    base = np.floor(y / (n * s)) * n * s                                  # grid-aligned block containing y
    if (y - base).min() < 0:
        base -= n * s
    cnt = dict(float=0, budget=0, excluded=0, rigorous_needed=0)
    t0 = time.time()
    import itertools
    for idx in itertools.product(range(n), repeat=6):
        lo = base + s * np.array(idx); hi = lo + s
        need, why = cell_needed(lo.tolist(), hi.tolist(), g, budget, rng, m)
        cnt[why] += 1
        if need and why != 'float':
            cnt['rigorous_needed'] += 1
    Z = base + n * s * rng.uniform(0, 1, (mc, 6))
    f = inside_float(orbit_np(Z)[INV[g]]).mean()
    cells = n ** 6
    return dict(s=s, f=float(f), cells=cells, counts=cnt, sec=round(time.time() - t0, 1),
                theta_float=(cnt['float'] / (f * cells)) if f > 0 else None,
                theta_rig=((cnt['float'] + cnt['budget']) / (f * cells)) if f > 0 else None)


def jdet(X, g, h=1e-6):
    """|det D phi_g| at identity-chart points X (float, central differences)."""
    J = np.zeros((len(X), 6, 6))
    for a in range(6):
        e = np.zeros(6); e[a] = h
        J[:, :, a] = (orbit_np(X + e)[g] - orbit_np(X - e)[g]) / (2 * h)
    return np.abs(np.linalg.det(J))


def flood(g, s, r1, r2, budget, m, rng, nseed=400, mcn=200000, max_cells=400000, log=None, margin=None):
    """EXACT count (up to the exclusion budget) of the chart-g cells of side s needed to cover phi_g(D_half cap
    {r in [r1, r2)}) with the rule 'label g everywhere'.  A cell belongs to the band if the identity pre-image of its
    centre has r in [r1, r2) (cells at the band edges are shared with the neighbouring bands, as in a production cover
    at one cell size).  Breadth-first search over face neighbours from seed cells; a cell is needed if a float point of
    it maps into D_half cap shell, or if excluded_chart cannot exclude it within the budget; only float-hit cells are
    expanded.  The search travels through cells whose centre pre-image has r within 'margin' (default 1 s / mean
    stretch) of the band, so that thin bands stay connected; only in-band cells are counted.  Continuum reference: chart-g volume of the band = E[|det D phi_g|] * vol(D_half cap band), by Monte Carlo.
    theta = needed * s^6 / that volume."""
    gi = INV[g]
    # Monte Carlo volume of D_half cap band (identity chart) and mean |det| there
    u = rng.uniform(0, 1, mcn); r = (r1 ** 6 + u * (r2 ** 6 - r1 ** 6)) ** (1 / 6)
    d = rng.normal(size=(mcn, 6)); d /= np.linalg.norm(d, axis=1)[:, None]; X = C + r[:, None] * d
    ins = inside_float(X); share = ins.mean()
    vol_shell = math.pi ** 3 / 6 * (r2 ** 6 - r1 ** 6)
    vol_id = vol_shell * share
    dets = jdet(X[ins][:4000], g) if g else np.ones(1)
    vol_g = vol_id * float(dets.mean())
    seeds = orbit_np(X[ins][:nseed])[g]
    if margin is None:
        margin = 1.0 * s / float(dets.mean()) ** (1 / 6)
    seen = set(); queue = []
    for y in seeds:
        k = tuple(np.floor(y / s).astype(int))
        if k not in seen:
            seen.add(k); queue.append(k)
    cnt = dict(float=0, budget=0, excluded=0, out_of_band=0)
    t0 = time.time(); qi = 0
    while qi < len(queue) and qi < max_cells:
        k = queue[qi]; qi += 1
        lo = s * np.array(k, float); hi = lo + s
        cen = orbit_np(((lo + hi) / 2)[None])[gi][0]; rc = float(np.linalg.norm(cen - C))
        if not r1 - margin <= rc < r2 + margin:
            cnt['out_of_band'] += 1; continue
        inband = r1 <= rc < r2
        need, why = cell_needed(lo.tolist(), hi.tolist(), g, budget, rng, m)
        if inband:
            cnt[why] += 1
        else:
            cnt['travel_' + why] = cnt.get('travel_' + why, 0) + 1
        if why == 'float':
            for ax in range(6):
                for sg in (-1, 1):
                    nb = list(k); nb[ax] += sg; nb = tuple(nb)
                    if nb not in seen:
                        seen.add(nb); queue.append(nb)
        if log and qi % 2000 == 0:
            print(json.dumps(dict(progress=qi, queue=len(queue), counts=cnt, sec=round(time.time() - t0))), file=log, flush=True)
    needed = cnt['float'] + cnt['budget']
    return dict(g=g, s=s, band=[r1, r2], margin=margin, d_half_share=float(share), vol_g=vol_g, mean_det=float(dets.mean()),
                continuum_cells=vol_g / s ** 6, needed=needed, counts=cnt, truncated=qi < len(queue),
                theta_float=cnt['float'] * s ** 6 / vol_g, theta_rig=needed * s ** 6 / vol_g, sec=round(time.time() - t0, 1))


def flood_rg(g, s, a, b, budget, m, rng, nseed=400, mcn=400000, max_cells=600000, log=None):
    """As flood(), but the band is taken in the cell's OWN chart: cells whose centre has r_g = |y - C| in [a, b)
    (relabelled cells scale with r_g, so this is the natural banding of a production cover in chart g).  The search
    travels one cell side beyond the band.  Continuum: chart-g volume of the band times the Monte Carlo share of its
    points whose identity pre-image lies in D_half cap shell (no Jacobian needed)."""
    gi = INV[g]
    u = rng.uniform(0, 1, mcn); r = (a ** 6 + u * (b ** 6 - a ** 6)) ** (1 / 6)
    d = rng.normal(size=(mcn, 6)); d /= np.linalg.norm(d, axis=1)[:, None]; Y = C + r[:, None] * d
    ins = inside_float(orbit_np(Y)[gi]); share = float(ins.mean())
    vol_g = math.pi ** 3 / 6 * (b ** 6 - a ** 6) * share
    seen = set(); queue = []
    for y in Y[ins][:nseed]:
        k = tuple(np.floor(y / s).astype(int))
        if k not in seen:
            seen.add(k); queue.append(k)
    cnt = dict(float=0, budget=0, excluded=0, out_of_band=0)
    t0 = time.time(); qi = 0
    while qi < len(queue) and qi < max_cells:
        k = queue[qi]; qi += 1
        lo = s * np.array(k, float); hi = lo + s
        rc = float(np.linalg.norm((lo + hi) / 2 - C))
        if not a - s <= rc < b + s:
            cnt['out_of_band'] += 1; continue
        inband = a <= rc < b
        need, why = cell_needed(lo.tolist(), hi.tolist(), g, budget, rng, m)
        if inband:
            cnt[why] += 1
        else:
            cnt['travel_' + why] = cnt.get('travel_' + why, 0) + 1
        if why == 'float':
            for ax in range(6):
                for sg in (-1, 1):
                    nb = list(k); nb[ax] += sg; nb = tuple(nb)
                    if nb not in seen:
                        seen.add(nb); queue.append(nb)
        if log and qi % 5000 == 0:
            print(json.dumps(dict(progress=qi, queue=len(queue), counts=cnt, sec=round(time.time() - t0))), file=log, flush=True)
    needed = cnt['float'] + cnt['budget']
    return dict(mode='rg', g=g, s=s, band_rg=[a, b], share_inside=share, vol_g=vol_g, continuum_cells=vol_g / s ** 6,
                needed=needed, counts=cnt, truncated=qi < len(queue), theta_float=cnt['float'] * s ** 6 / vol_g,
                theta_rig=needed * s ** 6 / vol_g, sec=round(time.time() - t0, 1))


def theta_sample(g, s, a, b, budget, m, rng, ncell=2000, nfrac=512):
    """Random-cell estimate of the cover overhead (no traversal, so thin bands are fine): pick ncell grid cells (side s,
    chart g) through uniform points of the chart-g shell band r_g in [a, b); for each, 'needed' (cell_needed: float
    points, then rigorous exclusion within the budget) and the volume fraction f inside phi_g(D_half cap shell) (nfrac
    float points).  theta = sum(needed) / sum(f) (ratio estimator; theta_float uses the float-hit cells only)."""
    gi = INV[g]
    u = rng.uniform(0, 1, ncell); r = (a ** 6 + u * (b ** 6 - a ** 6)) ** (1 / 6)
    d = rng.normal(size=(ncell, 6)); d /= np.linalg.norm(d, axis=1)[:, None]; Y = C + r[:, None] * d
    rows = []; t0 = time.time()
    for y in Y:
        lo = np.floor(y / s) * s; hi = lo + s
        U = lo + s * rng.uniform(0, 1, (nfrac, 6)); f = float(inside_float(orbit_np(U)[gi]).mean())
        need, why = cell_needed(lo.tolist(), hi.tolist(), g, budget, rng, m)
        rows.append((f, int(why == 'float'), int(need)))
    A = np.array(rows, float); n = len(A)
    bs = [];  bf = []
    for _ in range(2000):
        k = rng.integers(0, n, n); bs.append(A[k, 2].sum() / max(A[k, 0].sum(), 1e-12)); bf.append(A[k, 1].sum() / max(A[k, 0].sum(), 1e-12))
    return dict(mode='sample', g=g, s=s, band_rg=[a, b], cells=n, sum_f=float(A[:, 0].sum()), float_hit=int(A[:, 1].sum()),
                needed=int(A[:, 2].sum()), theta_float=float(A[:, 1].sum() / A[:, 0].sum()), theta_rig=float(A[:, 2].sum() / A[:, 0].sum()),
                theta_rig_95=[float(v) for v in np.percentile(bs, [2.5, 97.5])], theta_float_95=[float(v) for v in np.percentile(bf, [2.5, 97.5])],
                sec=round(time.time() - t0, 1))


def theta_rule_sample(g, s, a, b, rng, block=None, ncell=1500, npts=2048):
    """Float-only random-cell estimate of the overhead WITH a labelling rule (switch_overhead.py's predictor rule:
    pointwise, or constant on dyadic blocks of side ~ block * r): W_rule = phi_g({x in D_half cap shell : pair(x) =
    pair(g)}), W_const = phi_g(D_half cap shell).  For each sampled cell: npts float points mapped back; 'meets' if any
    point is in W, f = fraction in W.  Returns theta_const = sum(meets_const)/sum(f_const) and theta_rule likewise;
    both use the same float points, so their ratio (the switch factor) has the same small-sliver bias in both."""
    import switch_overhead as SO
    gi = INV[g]; key = min(g, SO.PAIR[g])
    u = rng.uniform(0, 1, ncell); r = (a ** 6 + u * (b ** 6 - a ** 6)) ** (1 / 6)
    d = rng.normal(size=(ncell, 6)); d /= np.linalg.norm(d, axis=1)[:, None]; Y = C + r[:, None] * d
    mc = fc = mr = fr = 0.0; t0 = time.time()
    for y in Y:
        lo = np.floor(y / s) * s
        U = lo + s * rng.uniform(0, 1, (npts, 6)); X = orbit_np(U)[gi]
        ins = inside_float(X)
        if ins.any():
            mc += 1; fc += ins.mean()
            rule = np.zeros(npts, bool); rule[ins] = SO.rule_pair(X[ins], block) == key
            if rule.any():
                mr += 1; fr += rule.mean()
    return dict(mode='rule_sample', g=g, s=s, band_rg=[a, b], block=block, cells=ncell,
                theta_const=mc / fc if fc else None, theta_rule=mr / fr if fr else None,
                switch_factor=(mr / fr) / (mc / fc) if fc and fr else None, rule_share=fr / fc if fc else None,
                sec=round(time.time() - t0, 1))


def theta_local_exact(y, rho, g, rng, nu=256, npts=2048, budget=128):
    """Local overhead at a measured point y (chart g, measured best half-width rho), as local_dilation.theta_loc but
    with npts float points per box (instead of 512) and a rigorous classification of the boxes with no float hit:
        U = nu uniform points of box(y, 3 rho);  theta = #{u : box(u, rho) meets W} / #{u in W},  W = phi_g(D_half cap shell).
    'meets' (float) = a float point of the box maps into D_half cap shell; 'meets' (rigorous) = float meets or the box
    cannot be excluded within the budget.  Returns (theta_float, theta_rig, #u in W)."""
    gi = INV[g]
    U = y + 3 * rho * rng.uniform(-1, 1, (nu, 6))
    inW = inside_float(orbit_np(U)[gi])
    mf = 0; mr = 0
    for k in range(nu):
        if inW[k]:
            mf += 1; mr += 1; continue
        lo = U[k] - rho; hi = U[k] + rho
        V = lo + 2 * rho * rng.uniform(0, 1, (npts, 6))
        if inside_float(orbit_np(V)[gi]).any():
            mf += 1; mr += 1; continue
        need, why = cell_needed(lo.tolist(), hi.tolist(), g, budget, rng, 8)
        mr += int(need)
    n = max(int(inW.sum()), 1)
    return mf / n, mr / n, int(inW.sum())


def sigma_local(y, rho, g, rng, block, nu=192, npts=1024):
    """Switch factor at a measured point (float counts only): theta_rule / theta_const, where W_const =
    phi_g(D_half cap shell) and W_rule = its part whose pre-image has rule pair = pair(g) (switch_overhead.rule_pair
    with the given block size; block=None: pointwise).  Same U points and box points for both."""
    import switch_overhead as SO
    gi = INV[g]; key = min(g, SO.PAIR[g])
    U = y + 3 * rho * rng.uniform(-1, 1, (nu, 6)); XU = orbit_np(U)[gi]
    inC = inside_float(XU); inR = inC.copy()
    if inC.any():
        inR[inC] = SO.rule_pair(XU[inC], block) == key
    mC = 0; mR = 0
    for k in range(nu):
        if inR[k]:
            mC += 1; mR += 1; continue
        V = U[k] + rho * rng.uniform(-1, 1, (npts, 6)); XV = orbit_np(V)[gi]
        ins = inside_float(XV)
        if inC[k] or ins.any():
            mC += 1
            if ins.any() and (SO.rule_pair(XV[ins], block) == key).any():
                mR += 1
    nC = max(int(inC.sum()), 1); nR = int(inR.sum())
    return mC / nC, (mR / nR if nR else None), int(inC.sum()), nR


def sigma_main(a):
    opt = lambda k, d: type(d)(a[a.index(k) + 1]) if k in a else d
    blk = float(a[a.index('--block') + 1]) if '--block' in a else None
    rng = np.random.default_rng(opt('--seed', 1))
    T = [json.loads(l) for l in open(os.path.join(HERE, 'theta_local_exact_s1.jsonl'))]
    rel = [t for t in T if t['kind'] == 'relabelled' and t['n_in'] > 0]
    Cc = {}
    for cf in ('orbit_pilot/centres_orbit.jsonl', 'orbit_valid/centres_valid.jsonl'):
        Cc.update(load(cf))
    outf = os.path.join(HERE, 'sigma_local_%s.jsonl' % ('point' if blk is None else 'block%g' % blk))
    done = {json.loads(l)['id'] for l in open(outf)} if os.path.exists(outf) else set()
    with open(outf, 'a') as fh:
        for t in rel:
            if t['id'] in done:
                continue
            c = Cc[t['id']]; y = XS + c['r'] * np.array(c['d'])
            t0 = time.time(); tc, tr, nC, nR = sigma_local(y, t['rho'], t['g'], rng, blk)
            row = dict(id=t['id'], g=t['g'], r=t['r'], w=t['w'], theta_const=tc, theta_rule=tr, n_const=nC, n_rule=nR, sec=round(time.time() - t0, 1))
            fh.write(json.dumps(row) + '\n'); fh.flush(); print(json.dumps(row), flush=True)


def local_exact_main(a):
    opt = lambda k, d: type(d)(a[a.index(k) + 1]) if k in a else d
    rng = np.random.default_rng(opt('--seed', 1)); budget = opt('--budget', 128)
    r3 = load('t1_sweep/results_run3/results.jsonl'); cs = load('t1_sweep/centres_run2.jsonl')
    pts = []
    for i, x in r3.items():                                     # identity: run3 centres in D_half (as plan_cells.C)
        y = XS + cs[i]['r'] * np.array(cs[i]['d'])
        if inside_float(y[None])[0] and BO.best_cell(x):
            dens, rho = BO.best_cell(x); pts.append(dict(kind='identity', id=i, g=0, y=y, rho=rho, w=dens * (2 * x['r']) ** 6, r=x['r']))
    best = {}
    for cf, rf in (('orbit_pilot/centres_orbit.jsonl', 'orbit_pilot/results_all98.jsonl'),
                   ('orbit_valid/centres_valid.jsonl', 'orbit_valid/out_sandbox/results.jsonl')):
        Cc = load(cf); R = load(rf)
        for cid, c in Cc.items():
            if cid in R and BO.best_cell(R[cid]):
                dens, rho = BO.best_cell(R[cid]); o = c['orig']; v = c['detJ'] * dens * (2 * r3[o]['r']) ** 6
                if o not in best or v < best[o]['w']:
                    best[o] = dict(kind='relabelled', id=cid, g=c['g'], y=XS + c['r'] * np.array(c['d']), rho=rho, w=v, r=r3[o]['r'])
    for o, p in best.items():
        # the measured point y = phi_g(x) was built from the run3 centre x in D; if x is in the other mirror half
        # (x_2 < 1/2), its D_half representative is x' = phi_3(x) and y = phi_k(x') for k = g o 3: use label k, so that
        # the local domain is W = phi_k(D_half cap shell), which contains y
        x = XS + cs[o]['r'] * np.array(cs[o]['d'])
        if x[2] < 0.5:
            xp = orbit_np(x[None])[3, 0]; O = orbit_np(xp[None])[:, 0]
            p['g'] = int(np.linalg.norm(O - p['y'], axis=1).argmin()); p['mirror_relabel'] = True
    pts += list(best.values())
    if '--identity-reps' in a:
        # identity theta at the D_half representative of every measured centre (phi_3 x when x_2 < 1/2)
        pts = []
        for o in best:
            x = XS + cs[o]['r'] * np.array(cs[o]['d'])
            xr = x if x[2] >= 0.5 else orbit_np(x[None])[3, 0]
            if inside_float(xr[None])[0] and BO.best_cell(r3[o]):
                dens, rho = BO.best_cell(r3[o]); pts.append(dict(kind='identity_rep', id=o, g=0, y=xr, rho=rho, w=dens * (2 * r3[o]['r']) ** 6, r=r3[o]['r']))
    outf = os.path.join(HERE, 'theta_local_exact_s%d.jsonl' % opt('--seed', 1))
    done = {(json.loads(l)['kind'], json.loads(l)['id']) for l in open(outf)} if os.path.exists(outf) else set()
    with open(outf, 'a') as fh:
        for p in pts:
            if (p['kind'], p['id']) in done:
                continue
            t0 = time.time(); tf, tr, nin = theta_local_exact(p['y'], p['rho'], p['g'], rng, budget=budget)
            row = dict(kind=p['kind'], id=p['id'], g=p['g'], r=p['r'], rho=p['rho'], w=p['w'], theta_float=tf, theta_rig=tr, n_in=nin,
                       mirror_relabel=p.get('mirror_relabel', False), meets_float=round(tf * max(nin, 1)), meets_rig=round(tr * max(nin, 1)),
                       sec=round(time.time() - t0, 1))
            fh.write(json.dumps(row) + '\n'); fh.flush(); print(json.dumps(row), flush=True)


def load(p):
    return {json.loads(l)['id']: json.loads(l) for l in open(os.path.join(HERE, '..', 'local', p))}


def main():
    a = sys.argv[1:]
    opt = lambda k, d: type(d)(a[a.index(k) + 1]) if k in a else d
    n, budget, m, mc, seed, limit = opt('--n', 4), opt('--budget', 16), opt('--m', 48), opt('--mc', 40000), opt('--seed', 1), opt('--limit', 10 ** 9)
    rng = np.random.default_rng(seed)
    r3 = load('t1_sweep/results_run3/results.jsonl'); cs = load('t1_sweep/centres_run2.jsonl')
    pts = []
    if '--identity' in a:
        for i, x in r3.items():
            y = XS + cs[i]['r'] * np.array(cs[i]['d'])
            if inside_float(y[None])[0] and BO.best_cell(x):
                dens, rho = BO.best_cell(x); pts.append(dict(id=i, g=0, y=y, rho=rho, w=dens, r=x['r']))
    else:
        best = {}
        for cf, rf in (('orbit_pilot/centres_orbit.jsonl', 'orbit_pilot/results_all98.jsonl'),
                       ('orbit_valid/centres_valid.jsonl', 'orbit_valid/out_sandbox/results.jsonl')):
            Cc = load(cf); R = load(rf)
            for cid, c in Cc.items():
                if cid in R and BO.best_cell(R[cid]):
                    dens, rho = BO.best_cell(R[cid]); v = c['detJ'] * dens; o = c['orig']
                    if o not in best or v < best[o]['w']:
                        best[o] = dict(id=cid, g=c['g'], y=XS + c['r'] * np.array(c['d']), rho=rho, w=v, r=r3[o]['r'])
        pts = list(best.values())
    pts = sorted(pts, key=lambda p: p['id'])[:limit]
    tag = 'identity' if '--identity' in a else 'relabelled'
    outf = os.path.join(HERE, 'plan_cells_%s_n%d_s%d.jsonl' % (tag, n, seed))
    done = {json.loads(l)['id'] for l in open(outf)} if os.path.exists(outf) else set()
    with open(outf, 'a') as fh:
        for p in pts:
            if p['id'] in done:
                continue
            res = block_measure(p['y'], p['g'], p['rho'], n, budget, m, mc, rng)
            res.update(id=p['id'], g=p['g'], r=p['r'], w=p['w'], rho=p['rho'])
            fh.write(json.dumps(res) + '\n'); fh.flush()
            print(json.dumps(res), flush=True)


PHI = phi_box if '--natural' in sys.argv else phi_box_mv
DIFF = '--no-diff' not in sys.argv
DIRECT = '--double-enclosure' not in sys.argv     # default: excluded_chart (one enclosure per labelling)

if __name__ == '__main__':
    if '--sigma' in sys.argv:
        sigma_main(sys.argv)
    elif '--local-exact' in sys.argv:
        local_exact_main(sys.argv)
    elif '--rule-sample' in sys.argv:
        # python3 plan_cells.py --rule-sample G S A B [--block X] [--cells N] [--seed K]
        a = sys.argv; i = a.index('--rule-sample'); g, s_, r1, r2 = int(a[i + 1]), float(a[i + 2]), float(a[i + 3]), float(a[i + 4])
        opt = lambda k, d: type(d)(a[a.index(k) + 1]) if k in a else d
        blk = float(a[a.index('--block') + 1]) if '--block' in a else None
        res = theta_rule_sample(g, s_, r1, r2, np.random.default_rng(opt('--seed', 1)), block=blk, ncell=opt('--cells', 1500))
        print(json.dumps(res))
        open(os.path.join(HERE, 'plan_rule_sample.jsonl'), 'a').write(json.dumps(res) + '\n')
    elif '--sample' in sys.argv:
        # python3 plan_cells.py --sample G S A B [--cells N] [--budget B] [--m M] [--seed K]
        a = sys.argv; i = a.index('--sample'); g, s_, r1, r2 = int(a[i + 1]), float(a[i + 2]), float(a[i + 3]), float(a[i + 4])
        opt = lambda k, d: type(d)(a[a.index(k) + 1]) if k in a else d
        res = theta_sample(g, s_, r1, r2, opt('--budget', 128), opt('--m', 64), np.random.default_rng(opt('--seed', 1)), ncell=opt('--cells', 2000))
        print(json.dumps(res))
        open(os.path.join(HERE, 'plan_sample.jsonl'), 'a').write(json.dumps(res) + '\n')
    elif '--flood-rg' in sys.argv:
        # python3 plan_cells.py --flood-rg G S A B [--budget B] [--m M] [--seed K]
        a = sys.argv; i = a.index('--flood-rg'); g, s_, r1, r2 = int(a[i + 1]), float(a[i + 2]), float(a[i + 3]), float(a[i + 4])
        opt = lambda k, d: type(d)(a[a.index(k) + 1]) if k in a else d
        res = flood_rg(g, s_, r1, r2, opt('--budget', 128), opt('--m', 64), np.random.default_rng(opt('--seed', 1)), log=sys.stderr)
        print(json.dumps(res))
        open(os.path.join(HERE, 'plan_flood.jsonl'), 'a').write(json.dumps(res) + '\n')
    elif '--flood' in sys.argv:
        # python3 plan_cells.py --flood G S R1 R2 [--budget B] [--m M] [--seed K]
        a = sys.argv; i = a.index('--flood'); g, s_, r1, r2 = int(a[i + 1]), float(a[i + 2]), float(a[i + 3]), float(a[i + 4])
        opt = lambda k, d: type(d)(a[a.index(k) + 1]) if k in a else d
        res = flood(g, s_, r1, r2, opt('--budget', 256), opt('--m', 64), np.random.default_rng(opt('--seed', 1)), log=sys.stderr)
        print(json.dumps(res))
        open(os.path.join(HERE, 'plan_flood.jsonl'), 'a').write(json.dumps(res) + '\n')
    elif '--measure' in sys.argv:
        main()
    else:
        print('INV', INV)
