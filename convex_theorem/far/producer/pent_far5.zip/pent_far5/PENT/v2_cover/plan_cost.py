"""Near-region cover cost with EXACT local boundary overheads (Claude, 2026-11-06; an ESTIMATE, not a proof).

Inputs:
  continuum costs and relabelling gains: ../local/orbit_valid/valid_analyze.py machinery (run3 estimator, D_half, box
      counts, pilot + validation strata, ZeroDivisionError re-tests merged; pair = mean of mirror members, or the
      cheaper member with --pairmin);
  local overheads theta (theta_local_exact_s1.jsonl, plan_cells.py --local-exact): for each measured centre, the
      identity overhead at its D_half representative ('identity_rep') and the overhead of its best measured labelling
      ('relabelled'), cost-weighted means per band for run3 identity centres ('identity') used for the unmeasured tail.
      '--rig' uses the rigorous-planner counts (budget 128 sub-boxes per cell), default the float counts.
Plans (per centre i, continuum identity cost c0_i, relabelled c_i = c0_i / gain_i):
  identity      : c0_i * theta_id_i
  relabel-all   : c_i * theta_rel_i * sigma
  per-centre    : min(identity, relabel-all)   (relabel only where it pays after its overhead)
sigma = extra factor for the switches between labellings (SWITCH.md: about 1.3 with a coarse rule, 2.5-2.8 with the
predictor rule; this program does not measure it).  Tail: identity cost of the unmeasured centres times theta_id(band),
times the plan/identity ratio measured on the random stratum B (ratio estimator, bootstrap 95%).
'--zd2' also merges the split2 re-tests (../local/zd_rerun/zd2_results.jsonl).
'--fpsi [F]' (2026-11-06, ARCH_V2.md section 11): the relabelled overhead of a centre is the measured overhead of the
cheapest-representative domain F_psi at its psi-best representative (theta_fpsi.jsonl), times F (default 1; a margin
for the float undercount), and sigma defaults to 1 (switching is part of F_psi's faces).
'--fpsi-file NAME' reads that file instead of theta_fpsi.jsonl (e.g. theta_fpsi_ball1.25.jsonl).
Usage: python3 plan_cost.py [--pairmin] [--rig] [--sigma 1,1.3,2] [--zd2] [--fpsi [F]] [--fpsi-file NAME]"""
import sys, os, json, math
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
L = os.path.join(HERE, '..', 'local')
a = sys.argv[1:]
PAIRMIN = '--pairmin' in a; RIG = '--rig' in a
FPSI = '--fpsi' in a
FPSI_F = float(a[a.index('--fpsi') + 1]) if FPSI and a.index('--fpsi') + 1 < len(a) and not a[a.index('--fpsi') + 1].startswith('--') else 1.0
SIGMAS = [float(v) for v in a[a.index('--sigma') + 1].split(',')] if '--sigma' in a else ([1.0] if FPSI else [1.0, 1.3, 2.0])
ZDF = os.path.join(L, 'zd_rerun', 'zd_results.jsonl') + (',' + os.path.join(L, 'zd_rerun', 'zd2_results.jsonl') if '--zd2' in a else '')
sys.argv = ['valid_analyze.py', '--zd', ZDF] + (['--pairmin'] if PAIRMIN else [])
import importlib.util
spec = importlib.util.spec_from_file_location('VA', os.path.join(L, 'orbit_valid', 'valid_analyze.py'))
VA = importlib.util.module_from_spec(spec); spec.loader.exec_module(VA)


def main():
    RC = VA.RC
    r3 = VA.merge_zd({json.loads(l)['id']: json.loads(l) for l in open(os.path.join(VA.T1, 'results_run3', 'results.jsonl'))}, 'run3')
    cs = {json.loads(l)['id']: json.loads(l) for l in open(os.path.join(VA.T1, 'centres_run2.jsonl'))}
    strata = json.load(open(os.path.join(L, 'orbit_valid', 'strata.json')))
    gp, _, _ = VA.gains(os.path.join(VA.OP, 'results_all98.jsonl'), os.path.join(VA.OP, 'centres_orbit.jsonl'), r3, 'pilot')
    gv, nv, cv = VA.gains(os.path.join(L, 'orbit_valid', 'out_sandbox', 'results.jsonl'), os.path.join(L, 'orbit_valid', 'centres_valid.jsonl'), r3, 'valid')
    G = dict(gv); G.update(gp)
    key = 'theta_rig' if RIG else 'theta_float'
    T = [json.loads(l) for l in open(os.path.join(HERE, 'theta_local_exact_s1.jsonl'))]
    th_rel = {t['id'] // 100: t[key] for t in T if t['kind'] == 'relabelled' and t['n_in'] > 0}
    if FPSI:
        th_rel = {}
        for l in open(os.path.join(HERE, a[a.index('--fpsi-file') + 1] if '--fpsi-file' in a else 'theta_fpsi.jsonl')):
            t = json.loads(l)
            if t['theta_fpsi']:
                th_rel[t['id'] // 100] = t['theta_fpsi'] * FPSI_F
    th_rep = {t['id']: t[key] for t in T if t['kind'] == 'identity_rep' and t['n_in'] > 0}
    rng = np.random.default_rng(1); out = {}
    for name, s in strata.items():
        lo, hi = s['band']; nb = sum(1 for x in r3.values() if lo <= x['r'] < hi)
        f = VA.K * math.log(hi / lo) / nb / 86400 * VA.HALF
        ids = [t for t in T if t['kind'] == 'identity' and lo <= t['r'] < hi and t['n_in'] > 0]
        th_id_band = sum(t['w'] * t[key] for t in ids) / sum(t['w'] for t in ids)
        cost = {}
        for i, x in r3.items():
            if lo <= x['r'] < hi and RC.in_D(RC.XS + x['r'] * np.array(cs[i]['d']))[0]:
                cost[i] = VA.best_density(x) * (2 * x['r']) ** 6 * f
        pil = [i for i in cost if i in gp]; A = s['take_all']; B = [i for i in s['random'] if i in G]; tail = s['tail']
        res = dict(band=[lo, hi], theta_id_band=round(th_id_band, 2), continuum_identity=round(sum(cost.values())),
                   continuum_relabelled_measured=round(sum(cost[i] / max(1.0, G.get(i, 1.0)) for i in pil + A + B)))

        def plan(i, sigma, kind):
            c0 = cost[i]; tid = th_rep.get(i, th_id_band)
            ident = c0 * tid
            if kind == 'identity' or i not in G or i not in th_rel:
                return ident
            rel = c0 / max(1.0, G[i]) * th_rel[i] * sigma
            return rel if kind == 'relabel' else min(ident, rel)
        for kind in ('identity', 'relabel', 'per-centre'):
            for sigma in (SIGMAS if kind != 'identity' else [1.0]):
                meas = sum(plan(i, sigma, kind) for i in pil + A)
                num = np.array([plan(i, sigma, kind) for i in B]); den = np.array([cost[i] * th_rep.get(i, th_id_band) for i in B])
                R = num.sum() / den.sum(); bs = []
                for _ in range(4000):
                    k = rng.integers(0, len(B), len(B)); bs.append(num[k].sum() / den[k].sum())
                tail_id = sum(cost[i] for i in tail) * th_id_band
                tot = meas + tail_id * R
                res['%s%s' % (kind, '' if kind == 'identity' else ' sigma=%g' % sigma)] = dict(
                    days=round(tot), days_95=[round(meas + tail_id * v) for v in np.percentile(bs, [2.5, 97.5])],
                    measured_part=round(meas), tail_part=round(tail_id * R))
        out[name] = res
    tot = {}
    for k in out['outer']:
        if isinstance(out['outer'][k], dict):
            tot[k] = round(out['outer'][k]['days'] + out['inner']['identity']['days']) if k != 'band' else None
    out['near total (inner identity + outer plan)'] = tot
    out['options'] = dict(pairmin=PAIRMIN, rigorous_counts=RIG, sigmas=SIGMAS, zd_files=ZDF, fpsi=FPSI and FPSI_F)
    print(json.dumps(out, indent=1))


if __name__ == '__main__':
    main()
