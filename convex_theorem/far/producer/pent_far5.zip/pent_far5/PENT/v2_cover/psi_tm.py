"""Degree-2 Taylor models for the psi comparison of the near-region planner (Claude, 2026-11-08/09; ARCH_V2 section
12, lever 1).  The mean-value test psi_less_mv overestimates the range of
    f(z) = log psi(phi_h z) - log psi(z),   log psi(x) = 4 log A(x) - 3 log |x - c|^2
by 4-20x on the planner's boxes: the two terms have gradients ~6/|z-c| each that nearly cancel, and interval
arithmetic adds their widths instead.  A Taylor model keeps the cancellation symbolically: every quantity is a
polynomial of degree <= 2 in the scaled box coordinates t in [-1,1]^6 (z_i = m_i + r_i t_i) plus an interval
remainder [-rem, rem]; sums and products of polynomials are exact up to truncation of degrees 3-4 (bounded into the
remainder by |coefficient| since |t_i| <= 1), 1/x and log x are composed through their series in eps = (x - x0)/x0
with the standard remainders |eps|^3/(1-|eps|) and |eps|^3/(3(1-|eps|)), and every floating-point operation adds a
conservative rounding term to the remainder (coefficients in binary64; the bound 4u * (sum|a|)(sum|b|) per product,
2u * (sum|a| + sum|b|) per sum, u = 2^-53, with a final safety factor).  Scalar transcendental constants (log x0,
1/x0) are taken from arb balls, outward.  The chart map u = phi_h(z) is the complex ratio (w_c - w_a)/(w_b - w_a) of
the vertices (plan_cells.orbit_np, boundary_overhead.IDX), computed as N * conj(D) * (1/|D|^2).
Result of psi_less_tm(lo, hi, h): (ok, sup_f, sup_d2_image) -- ok iff the rigorous upper bound of f over the box is
< 0 (then the whole box is not the cheapest representative because labelling h is cheaper everywhere), together with
the upper bound of |phi_h z - c|^2 (the caller still requires the image inside the candidate ball, as for psimv).
Range bound of a polynomial over [-1,1]^6: |c_0| + sum |c_k| (crude; the cancellation already happened in the
coefficients).  Monomial order: 0 = 1; 1..6 = t_i; 7..27 = t_i t_j, i <= j."""
import math, sys, os
import numpy as np
from flint import arb
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import boundary_overhead as BO
import plan_cells as PC

U = 2.0 ** -53
SAFE = 1.0 + 2 ** -40           # multiplicative safety on every remainder update
TINY = 1e-300
N = 28
_QIDX = {}
_k = 7
for _i in range(6):
    for _j in range(_i, 6):
        _QIDX[(_i, _j)] = _k; _k += 1
MONO = [()] + [(i,) for i in range(6)] + [(i, j) for i in range(6) for j in range(i, 6)]
# multiplication table: product of monomials p, q -> index (or -1 if degree > 2)
_P = []; _Q = []; _K = []; _TP = []; _TQ = []
for p in range(N):
    for q in range(N):
        m = tuple(sorted(MONO[p] + MONO[q]))
        if len(m) == 0:
            k = 0
        elif len(m) == 1:
            k = 1 + m[0]
        elif len(m) == 2:
            k = _QIDX[m]
        else:
            k = -1
        if k >= 0:
            _P.append(p); _Q.append(q); _K.append(k)
        else:
            _TP.append(p); _TQ.append(q)
_P = np.array(_P); _Q = np.array(_Q); _K = np.array(_K); _TP = np.array(_TP); _TQ = np.array(_TQ)


class TM:
    __slots__ = ('c', 'rem')

    def __init__(self, c, rem=0.0):
        self.c = c; self.rem = float(rem)

    @staticmethod
    def const(x):
        c = np.zeros(N); c[0] = float(x); return TM(c, 0.0)

    @staticmethod
    def var(i, m, r):
        c = np.zeros(N); c[0] = m; c[1 + i] = r; return TM(c, 0.0)

    def l1(self):
        return float(np.abs(self.c).sum())

    def bound(self):
        """[lo, hi] enclosure of the TM over [-1,1]^6 (crude, rigorous)"""
        s = float(np.abs(self.c[1:]).sum()); e = (s + abs(self.c[0]) + self.rem) * 8 * U + self.rem
        return self.c[0] - s - e - TINY, self.c[0] + s + e + TINY

    def __add__(self, o):
        if isinstance(o, TM):
            c = self.c + o.c
            return TM(c, (self.rem + o.rem + 2 * U * (self.l1() + o.l1())) * SAFE + TINY)
        c = self.c.copy(); c[0] += float(o)
        return TM(c, (self.rem + 2 * U * (abs(self.c[0]) + abs(float(o)))) * SAFE + TINY)

    __radd__ = __add__

    def __neg__(self):
        return TM(-self.c, self.rem)

    def __sub__(self, o):
        return self + (-o if isinstance(o, TM) else -float(o))

    def __rsub__(self, o):
        return (-self) + o

    def scale(self, s):
        s = float(s); c = self.c * s
        return TM(c, (self.rem * abs(s) + 2 * U * float(np.abs(c).sum())) * SAFE + TINY)

    def __mul__(self, o):
        if not isinstance(o, TM):
            return self.scale(o)
        a, b = self.c, o.c
        prod = a[_P] * b[_Q]; c = np.zeros(N); np.add.at(c, _K, prod)
        trunc = float(np.abs(a[_TP] * b[_TQ]).sum())
        la, lb = self.l1(), o.l1()
        rem = trunc + self.rem * lb + o.rem * la + self.rem * o.rem + 4 * U * la * lb + 4 * U * float(np.abs(c).sum())
        return TM(c, rem * SAFE + TINY)

    __rmul__ = __mul__

    def eps_split(self):
        """x = x0 (1 + eps): returns x0 (float), eps (TM with zero constant), e = rigorous bound of |eps|; None if the
        box may contain a sign change of x (x0 - range <= 0 handled by caller)"""
        x0 = float(self.c[0])
        if x0 == 0.0:
            return None
        c = self.c / x0; c[0] = 0.0
        eps = TM(c, (self.rem / abs(x0) + 2 * U * float(np.abs(c).sum())) * SAFE + TINY)
        e = (float(np.abs(c[1:]).sum()) + eps.rem) * (1 + 8 * U) + TINY
        return x0, eps, e

    def inv(self):
        """1/x as a TM; None when |eps| >= 1 (x may vanish)"""
        s = self.eps_split()
        if s is None:
            return None
        x0, eps, e = s
        if not (e < 1.0):
            return None
        e2 = eps * eps
        series = 1.0 - eps + e2                       # 1/(1+eps) = 1 - eps + eps^2 - ...
        R = e ** 3 / (1.0 - e) * (1 + 8 * U) + TINY     # |sum_{k>=3} (-eps)^k| <= e^3/(1-e)
        series = TM(series.c, series.rem + R)
        ix0 = arb(1) / arb(x0)
        res = series.scale(float(ix0.mid()))
        return TM(res.c, (res.rem + float(ix0.rad()) * series.l1() * (1 + 8 * U) + float(ix0.rad()) * series.rem) * SAFE + TINY)

    def log(self):
        """log x as a TM; None unless x > 0 on the box (|eps| < 1 and x0 > 0)"""
        s = self.eps_split()
        if s is None:
            return None
        x0, eps, e = s
        if not (x0 > 0 and e < 1.0):
            return None
        e2 = eps * eps
        series = eps - e2.scale(0.5)                  # log(1+eps) = eps - eps^2/2 + ...
        R = e ** 3 / (3.0 * (1.0 - e)) * (1 + 8 * U) + TINY
        lx0 = arb(x0).log()
        c = series.c.copy(); c[0] += float(lx0.mid())
        return TM(c, (series.rem + R + float(lx0.rad()) + 2 * U * abs(float(lx0.mid()))) * SAFE + TINY)


def box_params(lo, hi):
    """exact binary64 (m, r) with [m - r, m + r] containing [lo, hi] on every axis"""
    m = []; r = []
    for a, b in zip(lo, hi):
        mi = a + (b - a) / 2; ri = (b - a) / 2
        while not (mi - ri <= a and mi + ri >= b):
            ri = math.nextafter(ri, math.inf)
        m.append(mi); r.append(ri)
    return m, r


def chart_tm(lo, hi, h):
    """Taylor models of z (6) and of u = phi_h(z) (6); None if the normalising edge may vanish"""
    m, r = box_params(lo, hi)
    z = [TM.var(i, m[i], r[i]) for i in range(6)]
    zero = TM.const(0.0); one = TM.const(1.0)
    w = [(zero, zero), (one, zero), (z[0], z[1]), (z[2], z[3]), (z[4], z[5])]      # complex vertices (re, im)
    idx, rev = BO.IDX[h]
    a = w[idx[0]]; b = w[idx[1]]
    Dr = b[0] - a[0]; Di = b[1] - a[1]
    D2 = Dr * Dr + Di * Di
    inv = D2.inv()
    if inv is None:
        return None
    u = []
    for j in (2, 3, 4):
        cz = w[idx[j]]
        Nr = cz[0] - a[0]; Ni = cz[1] - a[1]
        re = (Nr * Dr + Ni * Di) * inv
        im = (Ni * Dr - Nr * Di) * inv
        if rev:
            im = -im
        u += [re, im]
    return z, u


def logpsi_tm(x):
    """TM of log psi(x) = 4 log A(x) - 3 log |x - c|^2 for a 6-vector of TMs; also returns the TM of |x - c|^2"""
    A = (x[1] + x[0] * x[3] - x[2] * x[1] + x[2] * x[5] - x[4] * x[3]).scale(0.5)
    d = [x[i] - float(PC.C[i]) for i in range(6)]
    r2 = d[0] * d[0]
    for i in range(1, 6):
        r2 = r2 + d[i] * d[i]
    lA = A.log(); lr = r2.log()
    if lA is None or lr is None:
        return None, r2
    return lA.scale(4.0) - lr.scale(3.0), r2


def psi_less_tm(lo, hi, h):
    """(ok, sup f, sup |phi_h z - c|^2): ok iff sup over the box of log psi(phi_h z) - log psi(z) < 0 rigorously"""
    ct = chart_tm(lo, hi, h)
    if ct is None:
        return False, None, None
    z, u = ct
    lu, r2u = logpsi_tm(u)
    lz, _ = logpsi_tm(z)
    if lu is None or lz is None:
        return False, None, r2u.bound()[1]
    f = lu - lz
    sup = f.bound()[1]
    return bool(sup < 0.0), sup, r2u.bound()[1]


if __name__ == '__main__':
    # self-test: rigorous bounds must contain sampled values on random boxes
    rng = np.random.default_rng(1); C = np.array([float(v) for v in PC.C]); bad = 0; n = 0; tight = []
    for trial in range(300):
        r = rng.uniform(0.02, 0.6); d = rng.normal(size=6); d /= np.linalg.norm(d); m = C + r * d
        hw = rng.uniform(0.002, 0.1) * r
        lo = m - hw; hi = m + hw; h = int(rng.integers(1, 10))
        ok, sup, d2 = psi_less_tm(lo, hi, h)
        if sup is None:
            continue
        Z = rng.uniform(lo, hi, size=(400, 6)); O = PC.orbit_np(Z)[h]
        def lp(X):
            A = (X[:, 1] + X[:, 0] * X[:, 3] - X[:, 2] * X[:, 1] + X[:, 2] * X[:, 5] - X[:, 4] * X[:, 3]) / 2
            return 4 * np.log(A) - 3 * np.log(((X - C) ** 2).sum(1))
        with np.errstate(all='ignore'):
            fv = lp(O) - lp(Z); dv = ((O - C) ** 2).sum(1)
        if not np.all(np.isfinite(fv)):
            continue
        n += 1
        if fv.max() > sup or dv.max() > d2:
            bad += 1
        tight.append((sup - fv.max()) / max(1e-9, fv.max() - fv.min()))
    print('boxes', n, 'violations', bad, 'median overestimate / true range', float(np.median(tight)), '90%', float(np.quantile(tight, 0.9)))
