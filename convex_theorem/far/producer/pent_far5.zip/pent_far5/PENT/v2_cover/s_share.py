"""How much of the near region D_half cap shell is non-convex, nearly flat, or excluded by the S criterion
(Claude, 2026-11-06; float, an ESTIMATE used by ARCH_V2.md section 4).

Points: r log-uniform per band, direction uniform on the 5-sphere, kept if in D_half cap shell (plan_cells.inside_float,
base point plan_cells.C).  For each kept point (up to 20,000 per band): strictly convex or not (five turns > 0); largest
interior angle; S criterion  max_k 2 pi^2 |P| / |Q_k| > F*_up  (Polya's quadrilateral theorem on the enclosing
quadrilateral Q_k, ../v2_quad/pentquad.py), with no margin and with a 0.5% margin.
Usage: python3 s_share.py   (output: s_share.txt)"""
import sys, os, math
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, '..', 'v2_quad'))
import plan_cells as PC
import pentquad as PQ


def main():
    rng = np.random.default_rng(7); N = 600000; F = PQ.FSTAR_UP; TP = 2 * math.pi ** 2
    for lo, hi in [(0.05, 0.1), (0.1, 0.2), (0.2, 0.3), (0.3, 0.4), (0.4, 0.5), (0.5, 0.6)]:
        r = np.exp(rng.uniform(math.log(lo), math.log(hi), N)); d = rng.normal(size=(N, 6)); d /= np.linalg.norm(d, axis=1)[:, None]
        X = PC.C + r[:, None] * d; X = X[PC.inside_float(X)]
        m = min(len(X), 20000); ncv = flat = s0 = s1 = 0
        for x in X[:m]:
            V = PQ.verts(x); e = [V[(i + 1) % 5] - V[i] for i in range(5)]
            if min(PQ.cr(e[i], e[(i + 1) % 5]) for i in range(5)) <= 0:
                ncv += 1; continue
            ang = max(math.degrees(math.pi - math.atan2(PQ.cr(e[i], e[(i + 1) % 5]), np.dot(e[i], e[(i + 1) % 5]))) for i in range(5))
            flat += ang > 170
            A = PQ.area(V); best = max([TP * A / (A + q[1]) for k in range(5) for q in [PQ.quad(V, k)] if q] or [0.0])
            s0 += best > F; s1 += best > F * 1.005
        print('r in [%.2f, %.2f): D_half points %d | non-convex %.4f | largest angle > 170 deg %.4f | S excludes %.4f | '
              'S excludes with 0.5%% margin %.4f' % (lo, hi, len(X), ncv / m, flat / m, s0 / m, s1 / m), flush=True)


if __name__ == '__main__':
    main()
