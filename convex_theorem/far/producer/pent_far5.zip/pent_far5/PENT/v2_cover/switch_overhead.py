"""Boundary ratio of the relabelled cover INCLUDING the switches between labellings (Claude, 2026-11-05; an ESTIMATE).

local_dilation.py estimated the local boundary ratio theta_loc of phi_g(D) around each measured relabelled point,
assuming the labelling rule is constant near the shape (no switches).  Here the rule is explicit and computable
everywhere, so its switch surfaces are included:
    G(x) = the mirror pair (0,3) (1,8) (2,5) (4,7) (6,9) with the largest predictor p = (r_h / r)^6 / |det D phi_h(x)|
           (r = |x - x*|, r_h = |phi_h(x) - x*|; identity has p = 1; labellings with |det| > 10 skipped, as the
           validation), evaluated pointwise ('point'), or at the centre of the dyadic block of side s * r_block
           containing x ('block s', a coarser rule with flat switch faces in the identity chart);
    the cover in chart g must contain every cell meeting W_g = phi_g({x in D : G(x) = pair(g)}).
theta_loc(y) = #{u in U : box(u, rho) meets W_g} / #{u in U : u in W_g},  U = 256 uniform points of box(y, 3 rho),
'meets' by 512 uniform points (no local minimisation: a slight underestimate), cost-weighted over the measured points
of a band, at the chosen labelling's measured cell size.  Compare with the constant-rule value (W_g = phi_g(D)) computed
in the same run with the same random points.  The cost under each rule uses the measured cost of the rule's pair at the
measured centres (mean over the measured mirror members; identity if the rule picks it); a centre whose rule pair was
not measured falls back to identity cost (rare: the predictor's top pair was always measured).
Units: T = 29.25 + 0.067 * boxes.  Usage: python3 switch_overhead.py [--seed 1] [--block 0.5]"""
import sys, os, json, math
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import boundary_overhead as B
import local_dilation as LD
L = os.path.join(HERE, '..', 'local')
PAIR = {0: 3, 3: 0, 1: 8, 8: 1, 2: 5, 5: 2, 4: 7, 7: 4, 6: 9, 9: 6}
KEYS = sorted({min(g, PAIR[g]) for g in range(10)})          # 0, 1, 2, 4, 6


def predictor(X):
    """X (N,6) identity-chart points -> (N,10) predictor p_h (identity 1; |det| > 10 -> 0)."""
    X = np.atleast_2d(X); N = len(X)
    r0 = np.linalg.norm(X - B.XS, axis=1)
    O = LD.orbit_pts(X); rh = np.linalg.norm(O - B.XS, axis=2)          # (10, N)
    z = np.stack([X[:, 0] + 1j * X[:, 1], X[:, 2] + 1j * X[:, 3], X[:, 4] + 1j * X[:, 5]], 1)
    h = 1e-6; Jc = np.zeros((10, N, 3, 3), complex)
    for k in range(3):
        e = np.zeros(3, complex); e[k] = h
        def U(zz):
            XX = np.stack([zz[:, 0].real, zz[:, 0].imag, zz[:, 1].real, zz[:, 1].imag, zz[:, 2].real, zz[:, 2].imag], 1)
            OO = LD.orbit_pts(XX)
            u = OO[:, :, 0::2] + 1j * OO[:, :, 1::2]
            for g, (idx, rev) in enumerate(B.IDX):
                if rev:
                    u[g] = np.conj(u[g])                                    # undo conjugation: holomorphic part
            return u
        Jc[:, :, :, k] = (U(z + e) - U(z - e)) / (2 * h)
    det = np.abs(np.linalg.det(Jc)) ** 2                                    # |det real Jacobian| = |det complex|^2
    p = (rh / r0) ** 6 / det
    p[det > 10] = 0.0; p[0] = 1.0
    return p


def rule_pair(X, block=None):
    X = np.atleast_2d(X)
    if block:
        r0 = np.linalg.norm(X - B.XS, axis=1)
        s = block * np.maximum(r0, 1e-9)
        lev = np.floor(np.log2(s)); side = 2.0 ** lev                      # dyadic side, about block * r
        Xc = (np.floor((X - B.XS) / side[:, None]) + 0.5) * side[:, None] + B.XS
        X = Xc
    p = predictor(X)
    best = np.zeros(len(X), int); bp = np.full(len(X), -1.0)
    for k in KEYS:
        v = np.maximum(p[k], p[PAIR[k]])
        m = v > bp; best[m] = k; bp[m] = v[m]
    return best


def rep_D(Z):
    """for chart-g points Z, a representative in D: the orbit point closest to x* (first of ties)."""
    O = LD.orbit_pts(Z); d = np.linalg.norm(O - B.XS, axis=2); j = d.argmin(0)
    return O[j, np.arange(len(Z))]


def in_W(Z, g, block):
    inD = LD.in_image(Z, g)
    out = np.zeros(len(Z), bool)
    if inD.any():
        out[inD] = rule_pair(rep_D(Z[inD]), block) == min(g, PAIR[g])
    return out


def theta(y, rho, g, rng, block, nu=256, nm=512):
    U = y + 3 * rho * rng.uniform(-1, 1, (nu, 6))
    V = [U[k] + rho * rng.uniform(-1, 1, (nm, 6)) for k in range(nu)]
    res = {}
    for name, f in (('const', lambda Z: LD.in_image(Z, g)), ('rule', lambda Z: in_W(Z, g, block))):
        inW = f(U); meet = inW.copy()
        for k in range(nu):
            if not meet[k]:
                meet[k] = f(V[k]).any()
        res[name] = (meet.sum() / max(inW.sum(), 1), int(inW.sum()))
    return res


def load(p):
    return {json.loads(l)['id']: json.loads(l) for l in open(os.path.join(L, p))}


def main():
    a = sys.argv[1:]
    seed = int(a[a.index('--seed') + 1]) if '--seed' in a else 1
    block = float(a[a.index('--block') + 1]) if '--block' in a else None
    rng = np.random.default_rng(seed)
    r3 = load('t1_sweep/results_run3/results.jsonl'); cs = load('t1_sweep/centres_run2.jsonl')
    meas = {}                                                         # orig -> pair -> list of (cost per orig vol, g, y, rho)
    for cf, rf in (('orbit_pilot/centres_orbit.jsonl', 'orbit_pilot/results_all98.jsonl'),
                   ('orbit_valid/centres_valid.jsonl', 'orbit_valid/out_sandbox/results.jsonl')):
        C = load(cf); R = load(rf)
        for cid, c in C.items():
            if cid in R and B.best_cell(R[cid]) is not None:
                dens, rho = B.best_cell(R[cid])
                meas.setdefault(c['orig'], {}).setdefault(min(c['g'], PAIR[c['g']]), []).append(
                    (c['detJ'] * dens, c['g'], B.XS + c['r'] * np.array(c['d']), rho))
    rep = {}
    for lo, hi in B.BANDS:
        key = '[%.2f,%.2f)' % (lo, hi); acc = dict(c_id=0.0, c_rule=0.0, n_const=0.0, n_rule=0.0, w=0.0, pts=0, unmeasured_rule_pair=0, rule_identity=0)
        for o, pairs in meas.items():
            if not lo <= r3[o]['r'] < hi:
                continue
            x = B.XS + cs[o]['r'] * np.array(cs[o]['d'])
            if B.hD(x[None])[0] > 1e-12:
                continue
            c0, rho0 = B.best_cell(r3[o])
            k = int(rule_pair(x[None], block)[0])
            if k == 0 or k not in pairs:
                acc['unmeasured_rule_pair'] += int(k != 0); acc['rule_identity'] += int(k == 0)
                cR, g, y, rho = c0, 0, x, rho0
            else:
                lst = pairs[k]; cR = sum(v[0] for v in lst) / len(lst); _, g, y, rho = min(lst, key=lambda v: v[0])
            th = theta(y, rho, g, rng, block)
            acc['c_id'] += c0; acc['c_rule'] += cR
            acc['n_const'] += cR * th['const'][0]; acc['n_rule'] += cR * th['rule'][0]; acc['w'] += cR; acc['pts'] += 1
            print(key, o, 'pair', k, 'g', g, 'cost ratio %.3f' % (cR / c0), 'theta const %.2f rule %.2f (in %d / %d)' % (
                th['const'][0], th['rule'][0], th['const'][1], th['rule'][1]), flush=True)
        rep[key] = dict(points=acc['pts'], rule_picks_identity=acc['rule_identity'], rule_pair_unmeasured=acc['unmeasured_rule_pair'],
                        cost_ratio_rule_vs_identity=round(acc['c_rule'] / acc['c_id'], 3),
                        theta_const=round(acc['n_const'] / acc['w'], 3), theta_rule=round(acc['n_rule'] / acc['w'], 3),
                        switch_factor=round(acc['n_rule'] / acc['n_const'], 3))
        print(key, json.dumps(rep[key]), flush=True)
    tag = 'point' if not block else 'block%g' % block
    json.dump(dict(rule=tag, seed=seed, bands=rep), open(os.path.join(HERE, 'switch_overhead_%s_s%d.json' % (tag, seed)), 'w'), indent=1)


if __name__ == '__main__':
    main()
