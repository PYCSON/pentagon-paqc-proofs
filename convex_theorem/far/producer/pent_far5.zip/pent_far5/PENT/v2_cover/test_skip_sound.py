"""Soundness test of the F_psi skip tests (Claude, 2026-11-07): a box that is SKIPPED must contain no point of W.
Random boxes around random points of W (so that many boxes meet W): for each box with a float point in W (npts
uniform points), skippable()/needed() must return 'not skippable'.  Any violation is a bug in the rigorous tests
(or in the float W, which would then be investigated).  Also counts how often skipping succeeds on boxes with no
float hit, for information.  Usage: python3 test_skip_sound.py [--n 3000] [--npts 512] [--seed 1]"""
import sys, os, json, math
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import plan_cells as PC
import theta_fpsi as TF
import theta_fpsi_rig as TR

TF.BALL = 1.25


def main():
    a = sys.argv[1:]
    opt = lambda k, d: type(d)(a[a.index(k) + 1]) if k in a else d
    n, npts, rng = opt('--n', 3000), opt('--npts', 512), np.random.default_rng(opt('--seed', 1))
    # points of W: random shell points mapped to their psi-best representative (ball 1.25), mirrored to z_2 >= 1/2
    pts = []
    while len(pts) < n:
        r = np.exp(rng.uniform(math.log(0.05), math.log(0.6), 4000)); d = rng.normal(size=(4000, 6)); d /= np.linalg.norm(d, axis=1)[:, None]
        X = PC.C + r[:, None] * d; O, dist, psi = TF.psi_orbit(X)
        sel = psi.argmin(0); Z = O[sel, np.arange(len(X))]
        m = Z[:, 2] < 0.5; Z[m] = PC.orbit_np(Z[m])[3]
        Z = Z[TF.inside_W(Z)]; pts += list(Z)
    pts = np.array(pts[:n]); viol = 0; skipped_hit = []; stats = dict(hit=0, hit_skipped=0, nohit=0, nohit_skipped=0)
    for i, z in enumerate(pts):
        rho = float(np.exp(rng.uniform(math.log(0.003), math.log(0.08)))); u = z + rho * rng.uniform(-2, 2, 6)
        lo = u - rho; hi = u + rho; V = lo + 2 * rho * rng.uniform(0, 1, (npts, 6)); hit = TF.inside_W(V).any() or TF.inside_W(u[None])[0]
        why = TR.skippable(lo.tolist(), hi.tolist())
        if why is None:
            need, w = TR.needed(lo.tolist(), hi.tolist(), 256); why = None if need else 'sub:' + w
        if hit:
            stats['hit'] += 1
            if why:
                stats['hit_skipped'] += 1; viol += 1; skipped_hit.append(dict(lo=lo.tolist(), hi=hi.tolist(), why=why))
                print('VIOLATION', why, lo.tolist(), hi.tolist(), flush=True)
        else:
            stats['nohit'] += 1; stats['nohit_skipped'] += bool(why)
        if i % 500 == 499:
            print(i + 1, stats, flush=True)
    print('RESULT', json.dumps(stats), 'violations', viol)
    json.dump(dict(stats=stats, violations=skipped_hit), open(os.path.join(HERE, 'test_skip_sound.json'), 'w'), indent=1)


if __name__ == '__main__':
    main()
