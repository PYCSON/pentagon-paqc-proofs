"""Where does the cover overhead Theta come from?  Decomposition by boundary type (Claude, 2026-11-06; float, ESTIMATE).

Same local model as plan_cells.theta_local_exact (boxes of half-width rho with uniformly random centres u around a
measured point y in chart g; W = phi_g(D_half cap shell); theta = #{boxes meeting W} / #{u in W}), float only (npts
points per box), so the totals are slightly below theta_float.  Every overhead box (centre u outside W, box meets W) is
attributed to the constraint(s) that the pre-image x = phi_g^{-1}(u) violates:
  mirror   x_2 < 1/2 (the identity-chart mirror cut; for g = 0 a grid aligned with x_2 = 1/2 pays nothing for it),
  inner    |x - c| < 0.05,     outer   |x - c| >= 0.6,
  face_h   |phi_h(x) - c| < |x - c|  (the Dirichlet face of labelling h; h = 3 never, see plan_cells.MIRROR_FREE),
a box violating several constraints counts 1/k for each.  Cost-weighted (weights w of theta_local_exact_s1.jsonl) per
kind (identity_rep, relabelled) and band.  Output: theta_decomp.json.
Usage: python3 theta_decomp.py [--nu 192] [--npts 384] [--seed 3]"""
import sys, os, json, math
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import plan_cells as PC


def classify(X):
    """X (N,6) pre-images; returns list of violated-constraint names per row."""
    O = PC.orbit_np(X); d = np.linalg.norm(O - PC.C, axis=2); out = []
    for k in range(len(X)):
        v = []
        if X[k, 2] < 0.5:
            v.append('mirror')
        if d[0, k] < 0.05:
            v.append('inner')
        if d[0, k] >= 0.6:
            v.append('outer')
        for h in PC.MIRROR_FREE:
            if d[h, k] < d[0, k]:
                v.append('face_%d' % h)
        out.append(v)
    return out


def local(y, rho, g, rng, nu, npts):
    gi = PC.INV[g]
    U = y + 3 * rho * rng.uniform(-1, 1, (nu, 6))
    XU = PC.orbit_np(U)[gi]; inW = PC.inside_float(XU); viol = classify(XU)
    att = {}; meets = 0
    for k in range(nu):
        if inW[k]:
            meets += 1; continue
        V = U[k] + rho * rng.uniform(-1, 1, (npts, 6))
        if PC.inside_float(PC.orbit_np(V)[gi]).any():
            meets += 1
            for name in viol[k]:
                att[name] = att.get(name, 0) + 1 / len(viol[k])
    n = int(inW.sum())
    return n, meets, att


def main():
    a = sys.argv[1:]
    opt = lambda k, d: type(d)(a[a.index(k) + 1]) if k in a else d
    nu, npts = opt('--nu', 192), opt('--npts', 384); rng = np.random.default_rng(opt('--seed', 3))
    T = [json.loads(l) for l in open(os.path.join(HERE, 'theta_local_exact_s1.jsonl'))]
    Cc = {}
    for cf in ('orbit_pilot/centres_orbit.jsonl', 'orbit_valid/centres_valid.jsonl'):
        Cc.update(PC.load(cf))
    cs = PC.load('t1_sweep/centres_run2.jsonl')
    acc = {}
    for t in T:
        if t['kind'] not in ('identity_rep', 'relabelled') or t['n_in'] == 0:
            continue
        if t['kind'] == 'relabelled':
            c = Cc[t['id']]; y = PC.XS + c['r'] * np.array(c['d'])
        else:
            x = PC.XS + cs[t['id']]['r'] * np.array(cs[t['id']]['d'])
            y = x if x[2] >= 0.5 else PC.orbit_np(x[None])[3, 0]
        n, m, att = local(y, t['rho'], t['g'], rng, nu, npts)
        if n == 0:
            continue
        band = 'inner' if t['r'] < 0.2 else 'outer'
        A = acc.setdefault((t['kind'], band), dict(w=0.0, theta=0.0, parts={}))
        A['w'] += t['w']; A['theta'] += t['w'] * m / n
        for k, v in att.items():
            A['parts'][k] = A['parts'].get(k, 0.0) + t['w'] * v / n
    res = {}
    for (kind, band), A in sorted(acc.items()):
        parts = {k: round(v / A['w'], 3) for k, v in sorted(A['parts'].items(), key=lambda kv: -kv[1])}
        faces = round(sum(v for k, v in parts.items() if k.startswith('face')), 3)
        res['%s %s' % (kind, band)] = dict(theta=round(A['theta'] / A['w'], 3), overhead=round(A['theta'] / A['w'] - 1, 3),
                                           mirror=parts.get('mirror', 0), inner=parts.get('inner', 0), outer=parts.get('outer', 0),
                                           faces_total=faces, by_face={k: v for k, v in parts.items() if k.startswith('face')})
    json.dump(dict(options=dict(nu=nu, npts=npts, seed=opt('--seed', 3)), result=res), open(os.path.join(HERE, 'theta_decomp.json'), 'w'), indent=1)
    print(json.dumps(res, indent=1))


if __name__ == '__main__':
    main()
