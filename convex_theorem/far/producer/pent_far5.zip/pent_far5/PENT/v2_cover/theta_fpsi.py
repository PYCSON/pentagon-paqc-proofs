"""Cover overhead of the 'cheapest-representative' fundamental domain F_psi (Claude, 2026-11-06; float, ESTIMATE).

Idea (ARCH_V2.md section 11).  A certified cell is a box of the chart R^6; the labelling is only bookkeeping.  If every
label uses the same adaptive dyadic grid and the needed cells of all labels are united, the representative set that is
actually covered is
    W = F_psi cap {z_2 >= 1/2} cap shell,   F_psi = {z : psi(z) <= psi(phi_h z) for every h},
    shell = {0.05 <= d(z) < 0.6},  d(z) = min_h |phi_h z - c|,
for an orbit selection function psi; with psi(z) = A(z)^4 / |z - c|^6 (A = area of P(z)), psi(x) / psi(phi_g x) is
exactly the cost predictor p_g = (r_g / r)^6 / |det D phi_g| of switch_overhead.py (|det D phi_g(x)| = (A(phi_g x) / A(x))^4,
checked numerically), so F_psi picks the predicted cheapest representative of every shape.  psi is phi_3-invariant
(phi_3 is an isometry of the chart fixing c and preserving areas), so the mirror cut is the grid plane z_2 = 1/2 in
EVERY chart, and the Dirichlet faces of D_c are not boundaries of W at all: across them the same chart points stay the
cheapest representatives (only their label name changes).  The only boundaries left are the psi-tie faces and the shell.

Measurement: at the psi-best representative z* of every measured centre (pilot + validation, weights w of
theta_local_exact_s1.jsonl), boxes of half-width rho with random centres u in box(z*, 3 rho), theta = #{boxes meeting
W} / #{u in W} (float, npts points per box), the same local model as plan_cells.theta_local_exact.  rho: the measured
rho of the best measured labelling when z* is that representative or its mirror, else rho_meas * |z* - c| / |y - c|.
Compared with the old per-label accounting at the same centres: theta_const (D_half image, no switching) and theta_rule
(point rule) of sigma_local_point.jsonl.  Output: theta_fpsi.jsonl (per centre) and printed cost-weighted means.
'--ball R1' (2026-11-06, after GPT PENT-11/12): candidates are only the representatives with |z - c| < R1 (a
phi_3-invariant ball that contains the Dirichlet representative, so Lemma 3 still holds), instead of the box R0; output
theta_fpsi_ball<R1>.jsonl.  Reason: with the box, psi = A^4/r^6 often picks representatives far out (up to the box
edge) where no T1 cost has been measured; every measured best representative has |z - c| <= 1.23.
Usage: python3 theta_fpsi.py [--nu 128] [--npts 384] [--seed 5] [--ball R1]"""
import sys, os, json
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import plan_cells as PC


def area(Z):
    """(..., 6) chart points -> polygon areas (V0 = 0, V1 = 1)."""
    x = [np.zeros(Z.shape[:-1]), np.ones(Z.shape[:-1]), Z[..., 0], Z[..., 2], Z[..., 4]]
    y = [np.zeros(Z.shape[:-1]), np.zeros(Z.shape[:-1]), Z[..., 1], Z[..., 3], Z[..., 5]]
    return 0.5 * sum(x[i] * y[(i + 1) % 5] - x[(i + 1) % 5] * y[i] for i in range(5))


BALL = None


def psi_orbit(Z):
    O = PC.orbit_np(Z); dist = np.linalg.norm(O - PC.C, axis=2)
    psi = area(O) ** 4 / dist ** 6
    if BALL is not None:
        psi = np.where(dist < BALL, psi, np.inf)
    return O, dist, psi


def convex(Z):
    """strictly convex, counterclockwise pentagon (all five turns > 0).  2026-11-07: W requires z in Omega; without
    this test the float W contained non-convex shapes (found by test_skip_sound.py: a NONCVX skip of a box with a
    float 'W' point)."""
    V = np.zeros(Z.shape[:-1] + (5, 2)); V[..., 1, 0] = 1; V[..., 2, :] = Z[..., 0:2]; V[..., 3, :] = Z[..., 2:4]; V[..., 4, :] = Z[..., 4:6]
    ok = np.ones(Z.shape[:-1], bool)
    for i in range(5):
        a = V[..., i, :] - V[..., i - 1, :]; b = V[..., (i + 1) % 5, :] - V[..., i, :]
        ok &= (a[..., 0] * b[..., 1] - a[..., 1] * b[..., 0]) > 0
    return ok


def inside_W(Z):
    O, dist, psi = psi_orbit(Z); d = dist.min(0)
    best = np.ones(len(Z), bool)
    for h in PC.MIRROR_FREE:                     # h = 3 ties exactly (mirror), so it is left out, as in inside_float
        best &= psi[0] <= psi[h]
    return best & np.isfinite(psi[0]) & convex(Z) & (Z[:, 2] >= 0.5) & (d >= 0.05) & (d < 0.6)


def theta_W(y, rho, rng, nu, npts):
    U = y + 3 * rho * rng.uniform(-1, 1, (nu, 6)); inW = inside_W(U); m = int(inW.sum())
    for k in np.where(~inW)[0]:
        V = U[k] + rho * rng.uniform(-1, 1, (npts, 6))
        if inside_W(V).any():
            m += 1
    n = int(inW.sum())
    return (m / n if n else None), n


def main():
    a = sys.argv[1:]
    opt = lambda k, d: type(d)(a[a.index(k) + 1]) if k in a else d
    nu, npts = opt('--nu', 128), opt('--npts', 384); rng = np.random.default_rng(opt('--seed', 5))
    global BALL
    BALL = opt('--ball', 0.0) or None
    outname = 'theta_fpsi.jsonl' if BALL is None else 'theta_fpsi_ball%g.jsonl' % BALL
    T = [json.loads(l) for l in open(os.path.join(HERE, 'theta_local_exact_s1.jsonl'))]
    S = {json.loads(l)['id']: json.loads(l) for l in open(os.path.join(HERE, 'sigma_local_point.jsonl'))}
    Cc = {}
    for cf in ('orbit_pilot/centres_orbit.jsonl', 'orbit_valid/centres_valid.jsonl'):
        Cc.update(PC.load(cf))
    cs = PC.load('t1_sweep/centres_run2.jsonl')
    rows = []
    for t in T:
        if t['kind'] != 'relabelled' or t['n_in'] == 0 or t['id'] not in S:
            continue
        o = t['id'] // 100
        x = PC.XS + cs[o]['r'] * np.array(cs[o]['d'])
        if x[2] < 0.5:
            x = PC.orbit_np(x[None])[3, 0]
        O, dist, psi = psi_orbit(x[None]); O = O[:, 0]; psi = psi[:, 0]
        cand = [h for h in range(10) if O[h][2] >= 0.5]
        hb = min(cand, key=lambda h: psi[h]); z = O[hb]
        c = Cc[t['id']]; y = PC.XS + c['r'] * np.array(c['d'])
        same = min(np.linalg.norm(z - y), np.linalg.norm(z - PC.orbit_np(y[None])[3, 0])) < 1e-6
        rho = t['rho'] if same else t['rho'] * np.linalg.norm(z - PC.C) / np.linalg.norm(y - PC.C)
        th, n = theta_W(z, rho, rng, nu, npts)
        s = S[t['id']]
        row = dict(id=t['id'], r=t['r'], w=t['w'], band='inner' if t['r'] < 0.2 else 'outer', psi_best=int(hb),
                   same_as_measured=bool(same), theta_fpsi=th, n_in=n, theta_const=s['theta_const'], theta_rule=s['theta_rule'])
        rows.append(row); print(json.dumps(row), flush=True)
    with open(os.path.join(HERE, outname), 'w') as fh:
        for r in rows:
            fh.write(json.dumps(r) + '\n')
    for band in ('inner', 'outer'):
        R = [r for r in rows if r['band'] == band and r['theta_fpsi'] and r['theta_rule']]
        if not R:
            continue
        W = sum(r['w'] for r in R)
        f = lambda k: sum(r['w'] * r[k] for r in R) / W
        print('%s: %d centres (%d with psi-best = measured best) | cost-weighted theta: F_psi %.2f | old theta_const %.2f, '
              'old theta_rule (point rule) %.2f' % (band, len(R), sum(r['same_as_measured'] for r in R), f('theta_fpsi'),
                                                    f('theta_const'), f('theta_rule')))


if __name__ == '__main__':
    main()
