"""Rigorous cover overhead of the cheapest-representative domain F_psi (ball 1.25) at the measured centres
(Claude, 2026-11-07; the skip tests are rigorous ball arithmetic, the overhead is an ESTIMATE of the planner's count).

W = {z in Omega, |z - c| < 5/4 : psi(z) <= psi(phi_h z) for all h with |phi_h z - c| < 5/4} cap {z_2 >= 1/2}
    cap {1/20 <= d(z) < 3/5},   psi(z) = A(z)^4 / |z - c|^6   (ARCH_V2.md section 11, v0.3).
A box B of the chart can be SKIPPED when one of these holds on all of B (ball arithmetic, outward rounding):
  1. sup z_2 < 1/2;
  2. inf |z - c|^2 >= 25/16  (z outside the candidate ball);
  3. for every h (all ten enclosures defined) inf |phi_h z - c|^2 >= 9/25  (d(z) >= 3/5), or for some h
     sup |phi_h z - c|^2 < 1/400  (d(z) < 1/20);
  4. for some h not in {0, 3}: sup |phi_h z - c|^2 < 25/16 and sup( A_h^4 (r_z^2)^3 - A_z^4 (r_h^2)^3 ) < 0
     (psi(phi_h z) < psi(z), so z is not the cheapest representative; division-free form, GPT PENT-11/12);
  5. some orientation determinant of the pentagon has sup <= 0 (no convex pentagon in B: NONCVX).
Enclosures of phi_h: plan_cells.phi_box_mv; areas by the natural extension on the enclosure boxes.
  4'. (--mv, default on) the same psi test in MEAN-VALUE form on f(z) = log psi(phi_h z) - log psi(z):
      f(B) subset f(m) + sum_i |df/dz_i (B)| r_i,  df/dz = J_h(B)^T grad log psi(u) - grad log psi(z),
      J_h the real Jacobian enclosure of plan_cells.jet_box; skip if sup f(B) < 0.
Same local model as theta_fpsi.py: boxes of half-width rho with uniform centres u in box(z*, 3 rho) around the psi-best
representative z* of each measured centre; theta = #{boxes meeting W} / #{u in W}; 'meets' = a float point of the box
lies in W, or the box cannot be skipped within the sub-box budget.  Output: theta_fpsi_rig.jsonl, printed means.
Usage: python3 theta_fpsi_rig.py [--nu 96] [--npts 256] [--budget 64] [--seed 5] [--only N]"""
import sys, os, json, math, time
import numpy as np
from flint import arb
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import plan_cells as PC
import theta_fpsi as TF

TF.BALL = 1.25
BALL2 = arb(25) / arb(16); NEAR2 = arb(9) / arb(25); INNER2 = arb(1) / arb(400)


def box_area(lo, hi):
    """natural-extension enclosure (arb) of the area of P(z) over the box."""
    z = [PC.iv(lo[i], hi[i]) for i in range(6)]
    return (z[1] + z[0] * z[3] - z[2] * z[1] + z[2] * z[5] - z[4] * z[3]) / 2


def box_d2(lo, hi):
    l, h = PC.d2(lo, hi); return arb(l), arb(h)


def nonconvex(lo, hi):
    z = [PC.iv(lo[i], hi[i]) for i in range(6)]
    V = [(arb(0), arb(0)), (arb(1), arb(0)), (z[0], z[1]), (z[2], z[3]), (z[4], z[5])]
    for i in range(5):
        for j in range(5):
            for k in range(5):
                if i < j < k:
                    d = (V[j][0] - V[i][0]) * (V[k][1] - V[i][1]) - (V[j][1] - V[i][1]) * (V[k][0] - V[i][0])
                    if d.upper() <= 0:
                        return True
    return False


CABS = [abs(complex(float(PC.C[0]), float(PC.C[1]))), abs(complex(float(PC.C[2]), float(PC.C[3]))), abs(complex(float(PC.C[4]), float(PC.C[5])))]


def far_blowup(lo, hi, h):
    """'far' for a labelling whose image enclosure is undefined because the normalising edge D = w_b - w_a may vanish on
    the box (2026-11-09, ARCH_V2 section 13: at coarse levels 97% of the unresolved boxes failed 'far' only for this
    reason).  For every z in the box and every vertex j of the chart, |u_j| = |w_cj - w_a| / |D| >= inf|N_j| / sup|D|,
    so |phi_h z - c| >= |u_j| - |c_j| (c_j the complex vertex of the regular pentagon in the chart); if that is >= 3/5
    for some j the image is far wherever it is defined, and where D = 0 the configuration is degenerate (not a
    pentagon of the problem).  Rigorous arb upper/lower bounds of the complex moduli over the box."""
    z = [PC.iv(lo[i], hi[i]) for i in range(6)]
    W = [(arb(0), arb(0)), (arb(1), arb(0)), (z[0], z[1]), (z[2], z[3]), (z[4], z[5])]
    idx, rev = PC.IDX[h]
    a, b = W[idx[0]], W[idx[1]]
    D2 = (b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2
    Dmax = D2.upper().sqrt() if D2.upper() > 0 else None
    if Dmax is None:
        return False
    for jj, j in enumerate((2, 3, 4)):
        cz = W[idx[j]]; N2 = (cz[0] - a[0]) ** 2 + (cz[1] - a[1]) ** 2
        if not (N2.lower() > 0):
            continue
        umin = N2.lower().sqrt() / Dmax
        if (umin - arb(CABS[jj])).lower() >= arb(3) / arb(5):
            return True
    return False


def skippable(lo, hi):
    if hi[2] < 0.5:
        return 'mirror'
    l0, h0 = box_d2(lo, hi)
    if l0 >= BALL2:
        return 'ball'
    if nonconvex(lo, hi):
        return 'noncvx'
    enc = {}
    for h in range(10):
        enc[h] = (lo, hi) if h == 0 else PC.phi_box_mv(lo, hi, h)
    dl = {}; dh = {}
    for h, E in enc.items():
        if E is not None:
            dl[h], dh[h] = box_d2(*E)
    if all(v >= NEAR2 for v in dl.values()) and all(h in dl or far_blowup(lo, hi, h) for h in range(10)):
        return 'far'
    if any(v < INNER2 for v in dh.values()):
        return 'inner'
    Az = box_area(lo, hi); rz6 = arb(l0) if False else None
    rz2 = PC.iv(l0, h0)
    for h in PC.MIRROR_FREE:
        E = enc.get(h)
        if E is None or not (dh[h] < BALL2):
            continue
        Ah = box_area(*E); rh2 = PC.iv(dl[h], dh[h])
        if (Ah ** 4 * rz2 ** 3 - Az ** 4 * rh2 ** 3).upper() < 0:
            return 'psi%d' % h
        if USE_MV and psi_less_mv(lo, hi, h):
            return 'psimv%d' % h
    return None


def grad_logpsi(z):
    """z: six arb (intervals or thin); returns (A, r2, grad of log psi = 4 grad A / A - 3 * 2 (z - c) / r2) or None."""
    A = (z[1] + z[0] * z[3] - z[2] * z[1] + z[2] * z[5] - z[4] * z[3]) / 2
    dz = [z[i] - arb(float(PC.C[i])) for i in range(6)]; r2 = sum((d * d for d in dz), arb(0))
    if not (A > 0) or not (r2 > 0):
        return None
    gA = [z[3] / 2, (1 - z[2]) / 2, (z[5] - z[1]) / 2, (z[0] - z[4]) / 2, -z[3] / 2, z[2] / 2]
    return A, r2, [4 * gA[i] / A - 6 * dz[i] / r2 for i in range(6)]


def psi_less_mv(lo, hi, h):
    """sup over B of log psi(phi_h z) - log psi(z) < 0 by the mean-value form (rigorous)."""
    jb = PC.jet_box(lo, hi, h)
    if jb is None:
        return False
    um, ur, J = jb
    mid = [arb((lo[i] + hi[i]) / 2) for i in range(6)]; zb = [PC.iv(lo[i], hi[i]) for i in range(6)]
    gz_m = grad_logpsi(mid); gu_m = grad_logpsi(um); gz_B = grad_logpsi(zb); gu_B = grad_logpsi(ur)
    if None in (gz_m, gu_m, gz_B, gu_B):
        return False
    fm = 4 * gu_m[0].log() - 3 * gu_m[1].log() - 4 * gz_m[0].log() + 3 * gz_m[1].log()
    rad = [arb((hi[i] - lo[i]) / 2) for i in range(6)]; spread = arb(0)
    for i in range(6):
        gi = sum((J[k][i] * gu_B[2][k] for k in range(6)), arb(0)) - gz_B[2][i]
        spread += abs(gi) * rad[i]
    return (fm + spread).upper() < 0


USE_MV = True
RS = None            # seam radius of the mixed domain (None = pure F_psi); set by --mix R


def skippable_inner(lo, hi, Rs2):
    """W_inner = D_half cap {1/400 <= |x-c|^2 < Rs2} (identity labelling, Dirichlet domain): box skippable when
    sup x_2 < 1/2, or inf |x-c|^2 >= Rs2, or sup |x-c|^2 < 1/400, or NONCVX, or some h not in {0,3} has
    sup(|phi_h x - c|^2 - |x - c|^2) < 0 (x is then not the Dirichlet representative)."""
    if hi[2] < 0.5:
        return 'mirror'
    l0, h0 = box_d2(lo, hi)
    if l0 >= Rs2:
        return 'outer_seam'
    if h0 < INNER2:
        return 'inner'
    if nonconvex(lo, hi):
        return 'noncvx'
    cand = []
    for h in PC.MIRROR_FREE:
        E = PC.phi_box_mv(lo, hi, h)
        if E is None:
            continue
        lh, hh = box_d2(*E)
        if hh < l0:
            return 'dir%d' % h
        cand.append((float(hh.lower()), h))
    jg = PC.jet_box(lo, hi, 0)
    if jg is not None:
        for _, h in sorted(cand)[:3]:
            jk = PC.jet_box(lo, hi, h)
            if jk is not None and PC.diff_upper(jk, jg, lo, hi) < 0:
                return 'dirmv%d' % h
    return None


def skippable_mix(lo, hi):
    """mixed domain W_inner (Dirichlet, d < RS) union W_outer (F_psi, d >= RS): skippable iff both parts are."""
    Rs2 = arb(RS) * arb(RS)
    a = skippable_inner(lo, hi, Rs2)
    if a is None:
        return None
    global INNER2
    saved = INNER2; INNER2 = Rs2          # for W_outer the lower shell radius is RS, not 1/20
    try:
        b = skippable(lo, hi)
    finally:
        INNER2 = saved
    return None if b is None else a + '+' + b


def needed(lo, hi, budget):
    stack = [(list(lo), list(hi))]; used = 0
    while stack:
        a, b = stack.pop(); used += 1
        if used > budget:
            return True, 'budget'
        if (skippable_mix(a, b) if RS else skippable(a, b)):
            continue
        k = int(np.argmax(np.array(b) - np.array(a))); mid = (a[k] + b[k]) / 2
        b1 = list(b); b1[k] = mid; a2 = list(a); a2[k] = mid
        stack += [(a, b1), (a2, b)]
    return False, 'skipped'


def main():
    a = sys.argv[1:]
    opt = lambda k, d: type(d)(a[a.index(k) + 1]) if k in a else d
    nu, npts, budget = opt('--nu', 96), opt('--npts', 256), opt('--budget', 64); rng = np.random.default_rng(opt('--seed', 5))
    only = opt('--only', 0)
    global USE_MV
    USE_MV = '--no-mv' not in a
    outname = 'theta_fpsi_rig.jsonl' if USE_MV else 'theta_fpsi_rig_nomv.jsonl'
    R = [json.loads(l) for l in open(os.path.join(HERE, 'theta_fpsi_ball1.25.jsonl'))]
    Cc = {}
    for cf in ('orbit_pilot/centres_orbit.jsonl', 'orbit_valid/centres_valid.jsonl'):
        Cc.update(PC.load(cf))
    cs = PC.load('t1_sweep/centres_run2.jsonl')
    T = {json.loads(l)['id']: json.loads(l) for l in open(os.path.join(HERE, 'theta_local_exact_s1.jsonl')) if json.loads(l)['kind'] == 'relabelled'}
    out = []; fo = open(os.path.join(HERE, outname), 'w')
    for r in R[:only] if only else R:
        if not r['theta_fpsi']:
            continue
        o = r['id'] // 100; x = PC.XS + cs[o]['r'] * np.array(cs[o]['d'])
        if x[2] < 0.5:
            x = PC.orbit_np(x[None])[3, 0]
        O, dist, psi = TF.psi_orbit(x[None]); z = O[r['psi_best'], 0]
        c = Cc[r['id']]; y = PC.XS + c['r'] * np.array(c['d']); t = T[r['id']]
        rho = t['rho'] if r['same_as_measured'] else t['rho'] * np.linalg.norm(z - PC.C) / np.linalg.norm(y - PC.C)
        t0 = time.time(); U = z + 3 * rho * rng.uniform(-1, 1, (nu, 6)); inW = TF.inside_W(U); mf = mr = 0; why = {}
        for k in range(nu):
            if inW[k]:
                mf += 1; mr += 1; continue
            lo = U[k] - rho; hi = U[k] + rho; V = lo + 2 * rho * rng.uniform(0, 1, (npts, 6))
            if TF.inside_W(V).any():
                mf += 1; mr += 1; continue
            nd, w = needed(lo.tolist(), hi.tolist(), budget); mr += int(nd); why[w] = why.get(w, 0) + 1
        n = max(int(inW.sum()), 1)
        row = dict(id=r['id'], band=r['band'], w=r['w'], rho=float(rho), n_in=int(inW.sum()), theta_float=mf / n, theta_rig=mr / n,
                   theta_fpsi_prev=r['theta_fpsi'], why=why, sec=round(time.time() - t0, 1))
        out.append(row); fo.write(json.dumps(row) + '\n'); fo.flush(); print(json.dumps(row), flush=True)
    for band in ('inner', 'outer'):
        S = [o for o in out if o['band'] == band and o['n_in'] > 0]
        if S:
            W = sum(o['w'] for o in S)
            print('%s: %d centres | cost-weighted theta: float %.2f | rigorous (budget %d) %.2f' % (
                band, len(S), sum(o['w'] * o['theta_float'] for o in S) / W, budget, sum(o['w'] * o['theta_rig'] for o in S) / W), flush=True)


if __name__ == '__main__':
    main()
