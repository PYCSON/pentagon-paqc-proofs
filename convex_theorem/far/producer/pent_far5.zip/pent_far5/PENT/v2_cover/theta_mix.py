"""Cover overhead of the MIXED domain: Dirichlet (identity labelling) for d < RS, cheapest-representative F_psi for
d >= RS (Claude, 2026-11-07; the skip tests are rigorous, the overhead is an ESTIMATE).
  W_inner = D_half cap {1/20 <= |x - c| < RS},   W_outer = F_psi(ball 5/4) cap {z_2 >= 1/2} cap {RS <= d(z) < 3/5}.
Lemma: every P with d in [1/20, RS) has its Dirichlet representative (mirrored to x_2 >= 1/2) in W_inner, every P with
d in [RS, 3/5) its psi-best representative in W_outer (ARCH_V2 Lemma 3 with the shell split at RS).  The seam at
d = RS is the only new boundary.  Same local model as theta_fpsi_rig.py: inner centres = the D_half representatives of
the run3 identity centres with r < RS (theta_local_exact_s1.jsonl 'identity_rep' rows, their rho and cost weight),
outer centres = the psi-best representatives of the measured relabelled centres (theta_fpsi_ball1.25.jsonl).
Output: theta_mix.jsonl and cost-weighted means; compare with the pure F_psi run (theta_fpsi_rig_b512.jsonl) and the
identity run (theta_local_exact_s1 theta_rig) on the same centres.
Usage: python3 theta_mix.py [--RS 0.2] [--nu 96] [--npts 256] [--budget 512] [--seed 5]"""
import sys, os, json, math, time
import numpy as np
from flint import arb
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import plan_cells as PC
import theta_fpsi as TF
import theta_fpsi_rig as TR

TF.BALL = 1.25


def inside_mix(Z, RS):
    O = PC.orbit_np(Z); dist = np.linalg.norm(O - PC.C, axis=2); d0 = dist[0]; d = dist.min(0)
    inner = (Z[:, 2] >= 0.5) & TF.convex(Z) & (d0 >= 0.05) & (d0 < RS) & (d0 <= dist[PC.MIRROR_FREE].min(0))
    psi = TF.area(O) ** 4 / dist ** 6; psi = np.where(dist < TF.BALL, psi, np.inf)
    best = np.ones(len(Z), bool)
    for h in PC.MIRROR_FREE:
        best &= psi[0] <= psi[h]
    outer = best & np.isfinite(psi[0]) & TF.convex(Z) & (Z[:, 2] >= 0.5) & (d >= RS) & (d < 0.6)
    return inner | outer


def main():
    a = sys.argv[1:]
    opt = lambda k, d: type(d)(a[a.index(k) + 1]) if k in a else d
    RS = opt('--RS', 0.2); nu, npts, budget = opt('--nu', 96), opt('--npts', 256), opt('--budget', 512); rng = np.random.default_rng(opt('--seed', 5))
    TR.RS = RS
    cs = PC.load('t1_sweep/centres_run2.jsonl')
    Cc = {}
    for cf in ('orbit_pilot/centres_orbit.jsonl', 'orbit_valid/centres_valid.jsonl'):
        Cc.update(PC.load(cf))
    T = [json.loads(l) for l in open(os.path.join(HERE, 'theta_local_exact_s1.jsonl'))]
    Trel = {t['id']: t for t in T if t['kind'] == 'relabelled'}
    B = [json.loads(l) for l in open(os.path.join(HERE, 'theta_fpsi_ball1.25.jsonl'))]
    centres = []
    for t in T:                                           # inner: identity representatives in D_half, r < RS
        if t['kind'] == 'identity_rep' and t['n_in'] > 0 and t['r'] < RS:
            x = PC.XS + cs[t['id']]['r'] * np.array(cs[t['id']]['d'])
            if x[2] < 0.5:
                x = PC.orbit_np(x[None])[3, 0]
            centres.append(dict(id=t['id'], band='inner', w=t['w'], z=x, rho=t['rho'], ref=t['theta_rig']))
    for r in B:                                           # outer: psi-best representatives
        if r['band'] != 'outer' or not r['theta_fpsi']:
            continue
        o = r['id'] // 100; x = PC.XS + cs[o]['r'] * np.array(cs[o]['d'])
        if x[2] < 0.5:
            x = PC.orbit_np(x[None])[3, 0]
        O, dist, psi = TF.psi_orbit(x[None]); z = O[r['psi_best'], 0]
        c = Cc[r['id']]; y = PC.XS + c['r'] * np.array(c['d']); t = Trel[r['id']]
        rho = t['rho'] if r['same_as_measured'] else t['rho'] * np.linalg.norm(z - PC.C) / np.linalg.norm(y - PC.C)
        centres.append(dict(id=r['id'], band='outer', w=r['w'], z=z, rho=float(rho), ref=None))
    out = []; fo = open(os.path.join(HERE, 'theta_mix.jsonl'), 'w')
    for c in centres:
        t0 = time.time(); z, rho = c['z'], c['rho']; U = z + 3 * rho * rng.uniform(-1, 1, (nu, 6)); inW = inside_mix(U, RS); mf = mr = 0; why = {}
        for k in range(nu):
            if inW[k]:
                mf += 1; mr += 1; continue
            lo = U[k] - rho; hi = U[k] + rho; V = lo + 2 * rho * rng.uniform(0, 1, (npts, 6))
            if inside_mix(V, RS).any():
                mf += 1; mr += 1; continue
            nd, w = TR.needed(lo.tolist(), hi.tolist(), budget); mr += int(nd); why[w] = why.get(w, 0) + 1
        n = max(int(inW.sum()), 1)
        row = dict(id=c['id'], band=c['band'], w=c['w'], rho=rho, n_in=int(inW.sum()), theta_float=mf / n, theta_rig=mr / n, ref_rig=c['ref'], why=why, sec=round(time.time() - t0, 1))
        out.append(row); fo.write(json.dumps(row) + '\n'); fo.flush(); print(json.dumps(row), flush=True)
    for band in ('inner', 'outer'):
        S = [o for o in out if o['band'] == band and o['n_in'] > 0]; W = sum(o['w'] for o in S)
        msg = '%s (RS=%g): %d centres | cost-weighted theta of the mixed domain: float %.2f | rigorous (budget %d) %.2f' % (
            band, RS, len(S), sum(o['w'] * o['theta_float'] for o in S) / W, budget, sum(o['w'] * o['theta_rig'] for o in S) / W)
        if band == 'inner':
            msg += ' | identity-only rigorous on the same centres %.2f' % (sum(o['w'] * o['ref_rig'] for o in S) / W)
        print(msg, flush=True)


if __name__ == '__main__':
    main()
