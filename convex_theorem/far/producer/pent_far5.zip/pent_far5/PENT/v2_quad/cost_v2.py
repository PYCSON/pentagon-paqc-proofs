"""Near-region L4 cost with measured S/T exclusions (Claude, 2026-11-02; model, not a proof).

Same estimator as release/cost/run3_cost.py (Dirichlet domain D, all sampled centres of a band, outside D -> 0), but at
the centres listed in a measurement file the PAQC cost density is replaced by min(PAQC, measured exclusion density).
An exclusion measurement = a region_exclude run on centre +- H that ended with every leaf S or T; its density is
  corner_cpu_seconds / (2H)^6     (the table built for that run, shared by all its boxes; geometry time is negligible),
optionally scaled by an amortisation factor alpha <= 1 for regions larger than the measured one (table ~ H^4,
volume ~ H^6, so a region c times larger in half-width costs ~ c^-2 per volume; alpha = 1 is the unamortised value).
Units (correction of 2026-11-04, see ../local/orbit_valid/PROGRESS.md): measured seconds depend on the machine's load
(run3's seconds per B&B box ranged 64-270 ms with the load), so by default both sides are priced in work counts at the
quiet rates: PAQC T = 29.25 + KAPPA_BOX * boxes (KAPPA_BOX = 0.067 s/box); exclusion = KAPPA_CORNER * new quadrilateral
corner certificates (KAPPA_CORNER = 5.3 s/corner: sandbox runs r301_H0221_sroute 1015.9 s / 192, r437_H0263 1370.2 s /
253).  A measurement may give "corners" (count; preferred) or only "corner_cpu_sec" (used as is).  '--seconds' restores
the old measured-seconds pricing on the PAQC side.
Usage: python3 cost_v2.py MEAS.json [--alpha 1,0.25,0.0625] [--seconds]
MEAS.json: [{"id": 301, "H": 0.0221, "corners": 192, "corner_cpu_sec": 1016, "complete": true}, ...]"""
import sys, os, json, math
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'local', 't1_sweep'))
import run3_cost as RC

BANDS = [(0.05, 0.2), (0.2, 0.6)]
KAPPA_BOX = 0.067
KAPPA_CORNER = 5.3
SECONDS = '--seconds' in sys.argv


def main():
    meas = {m['id']: m for m in json.load(open(sys.argv[1])) if m.get('complete')}
    alphas = [float(v) for v in sys.argv[sys.argv.index('--alpha') + 1].split(',')] if '--alpha' in sys.argv else [1.0, 0.25, 0.0625]
    recs = {json.loads(l)['id']: json.loads(l) for l in open(os.path.join(HERE, '..', 'local', 't1_sweep', 'results_run3', 'results.jsonl'))}
    cent = {json.loads(l)['id']: json.loads(l) for l in open(os.path.join(HERE, '..', 'local', 't1_sweep', 'centres_run2.jsonl'))}
    K = math.pi ** 3 / 64
    rows = []
    for i, x in recs.items():
        p = RC.XS + x['r'] * np.array(cent[i]['d'])
        inD, _ = RC.in_D(p)
        dens = None
        for t in x['tests']:
            if t.get('ok'):
                bb = (t.get('bb_sec') or 0) if SECONDS else KAPPA_BOX * (t.get('boxes') or 0)
                d = (29.25 + bb) / (t['rho'] / x['r']) ** 6
                dens = d if dens is None else min(dens, d)
        rows.append(dict(id=i, r=x['r'], inD=bool(inD), dens=dens))
    out = {}
    for a in [None] + alphas:
        tot = 0.0; detail = {}
        for lo, hi in BANDS:
            sel = [w for w in rows if lo <= w['r'] < hi]
            vals = []
            for w in sel:
                if not w['inD']:
                    vals.append(0.0); continue
                d = w['dens']
                if a is not None and w['id'] in meas:
                    m = meas[w['id']]
                    q_meas = m['H'] / w['r']                     # same normalisation as the PAQC density (q = rho / r)
                    cs = KAPPA_CORNER * m['corners'] if ('corners' in m and not SECONDS) else m['corner_cpu_sec']
                    d_ex = a * cs / q_meas ** 6
                    d = min(d, d_ex)
                vals.append(d)
            days = K * math.log(hi / lo) * float(np.mean(vals)) / 86400
            detail['[%.2f,%.2f)' % (lo, hi)] = round(days, 1); tot += days
        out['PAQC only' if a is None else 'alpha=%g' % a] = dict(L4_near_cpu_days=round(tot, 1), bands=detail)
    out['units'] = 'measured seconds' if SECONDS else 'work counts: %g s/box, %g s/quad corner' % (KAPPA_BOX, KAPPA_CORNER)
    print(json.dumps(out, indent=1))


if __name__ == '__main__':
    main()
