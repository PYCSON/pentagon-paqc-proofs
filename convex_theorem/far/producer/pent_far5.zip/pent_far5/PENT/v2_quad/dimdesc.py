"""Dimension-descent exclusion of whole pentagon boxes (Claude, 2026-11-01, v2 prototype, not yet reviewed).

Statement used.  For a convex pentagon P and an edge k with C = e_{k-1} x e_{k+1} > 0, the enclosing quadrilateral
Q = Q_k(P) contains P, so by domain monotonicity and scale invariance
        F(P) = lambda_1(P)|P| >= lambda_1(Q)|P| = F(Q) * |P|/|Q|,       |P|/|Q| = 1 / (1 + AB/(2C|P|)).
On a pentagon box B (6-D chart box) we bound, in ball arithmetic:
  * convexity of every P in B (five turns > 0) and C > 0;
  * r_lo <= |P|/|Q| on B;
  * the 4-D chart box X4(B) containing the normalised quadrilateral of every P in B (normalisation q0 -> 0, q1 -> 1 by
    a complex similarity, which leaves F invariant);
then
  (S)  2 pi^2 r_lo > F*_up                         excludes B with Polya's quadrilateral theorem alone, or
  (T)  L * r_lo > F*_up, L = min over quadrilateral PAQC cells covering X4(B) of their certified lower bounds,
       excludes B with the quadrilateral table (rig_paqc_n min-corner cells, shared corner certificates).
Otherwise B is bisected along its widest coordinate (up to a depth budget).  The quadrilateral table is a dyadic grid
(level j: cells of side S0 / 2^j aligned at multiples of the side, so all endpoints are exact binary64); a cell whose
bound is too weak is replaced by its 16 children, recursively, up to QMAX levels.  All cell and corner results are
cached and shared between pentagon boxes; the cache is the 'table'."""
import os, sys, time, math, itertools, json
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', 'far', 'qtable'))
sys.path.insert(0, os.path.join(HERE, '..', '..', 'MEAS-01', 'claude', 'scripts', 'C456'))
from flint import arb, acb, ctx
import rig_paqc_n as PN
from fem_check import lam1
import pentquad as PQ

FUP = arb(PQ.FSTAR_UP)
TWO_PI2 = 2 * arb.pi() ** 2
C4 = PN.Chart(4)


def ival(lo, hi):
    return arb(float(lo)).union(arb(float(hi)))


class Dual:
    """value + gradient (6 coordinates) in ball arithmetic: forward-mode derivative enclosures for the mean-value form."""
    __slots__ = ('v', 'g')
    def __init__(self, v, g=None):
        self.v = v if isinstance(v, arb) else arb(v); self.g = g if g is not None else [arb(0)] * 6
    def _c(o):
        return o if isinstance(o, Dual) else Dual(o)
    def __add__(a, b):
        b = Dual._c(b); return Dual(a.v + b.v, [x + y for x, y in zip(a.g, b.g)])
    __radd__ = __add__
    def __sub__(a, b):
        b = Dual._c(b); return Dual(a.v - b.v, [x - y for x, y in zip(a.g, b.g)])
    def __rsub__(a, b):
        return Dual._c(b) - a
    def __neg__(a):
        return Dual(-a.v, [-x for x in a.g])
    def __mul__(a, b):
        b = Dual._c(b); return Dual(a.v * b.v, [a.v * y + b.v * x for x, y in zip(a.g, b.g)])
    __rmul__ = __mul__
    def __truediv__(a, b):
        b = Dual._c(b); q = a.v / b.v
        return Dual(q, [(x - q * y) / b.v for x, y in zip(a.g, b.g)])
    def __rtruediv__(a, b):
        return Dual._c(b) / a


def _geom(x, k, rot=0):
    """the geometric quantities as functions of the six chart coordinates x (arb or Dual)."""
    z0 = x[0] * 0
    V = [(z0, z0), (z0 + 1, z0), (x[0], x[1]), (x[2], x[3]), (x[4], x[5])]
    e = [(V[(i + 1) % 5][0] - V[i][0], V[(i + 1) % 5][1] - V[i][1]) for i in range(5)]
    crs = lambda u, v: u[0] * v[1] - u[1] * v[0]
    turns = [crs(e[i], e[(i + 1) % 5]) for i in range(5)]
    P = (V[2][0] * V[3][1] - V[3][0] * V[2][1] + V[3][0] * V[4][1] - V[4][0] * V[3][1] + V[2][1]) / 2  # shoelace, V0=0, V1=(1,0)
    A = turns[(k - 1) % 5]; B = turns[k]; C = crs(e[(k - 1) % 5], e[(k + 1) % 5])
    ratio = 1 / (1 + A * B / (2 * C * P))
    s = B / C
    W = (V[k][0] + s * e[(k - 1) % 5][0], V[k][1] + s * e[(k - 1) % 5][1])
    Q = [V[(k + 2) % 5], V[(k + 3) % 5], V[(k - 1) % 5], W]
    Q = Q[rot:] + Q[:rot]                    # base edge q0 q1 of the quadrilateral chart (F does not depend on it)
    dx, dy = Q[1][0] - Q[0][0], Q[1][1] - Q[0][1]; den = dx * dx + dy * dy
    X4 = []
    for q in (Q[2], Q[3]):                   # (q - q0) / (q1 - q0) as a complex quotient
        ax, ay = q[0] - Q[0][0], q[1] - Q[0][1]
        X4 += [(ax * dx + ay * dy) / den, (ay * dx - ax * dy) / den]
    return turns, P, C, ratio, X4


def box_geometry(lo6, hi6, k, rot=0):
    """ball-arithmetic geometry of pentagon box [lo6, hi6] for deleted edge k (natural extension intersected with the
    mean-value form f(c) + sum_i f_i(B) [-h_i, h_i], the derivative enclosures f_i(B) from forward-mode Duals)."""
    xb = [ival(lo6[i], hi6[i]) for i in range(6)]
    turns, P, C, ratio, X4 = _geom(xb, k, rot)
    if not all(t > 0 for t in turns):
        return dict(ok=False, why='convexity')
    if not (C > 0) or not (P > 0):
        return dict(ok=False, why='C or area')
    cen = [arb(float((np.float64(lo6[i]) + np.float64(hi6[i])) / 2)) for i in range(6)]
    rad = [arb(float(hi6[i])) - cen[i] for i in range(6)]
    rad = [arb(max(abs((ival(lo6[i], lo6[i]) - cen[i])).upper(), abs(arb(float(hi6[i])) - cen[i]).upper())) for i in range(6)]
    _, _, _, r_c, X4_c = _geom(cen, k, rot)
    xd = [Dual(xb[i], [arb(1) if j == i else arb(0) for j in range(6)]) for i in range(6)]
    _, _, _, r_d, X4_d = _geom(xd, k, rot)
    def mv(fc, fd, fnat):
        spread = sum((abs(gi) * ri for gi, ri in zip(fd.g, rad)), arb(0))
        lo = max(float((fc - spread).lower()), float(fnat.lower())); hi = min(float((fc + spread).upper()), float(fnat.upper()))
        return lo, hi
    rlo, _ = mv(r_c, r_d, ratio)
    lo4 = []; hi4 = []
    for j in range(4):
        a_, b_ = mv(X4_c[j], X4_d[j], X4[j]); lo4.append(a_); hi4.append(b_)
    return dict(ok=True, r_lo=rlo, r_arb=arb(rlo), r_c=float(r_c.mid()), lo4=lo4, hi4=hi4, rot=rot)


class QuadTable:
    """dyadic grid of certified quadrilateral cells with shared corners; LB(cell) = min-corner PAQC bound."""
    def __init__(self, S0=1 / 32, QMAX=3, K=8, nseg=300):
        self.S0 = S0; self.QMAX = QMAX; self.K = K; self.nseg = nseg
        self.cells = {}; self.corners = {}; self.stats = dict(cells=0, corners=0, cell_sec=0.0)

    def side(self, lev):
        return self.S0 / 2 ** lev

    def cell_lb(self, lev, idx):
        key = (lev,) + tuple(idx)
        if key in self.cells:
            return self.cells[key]
        s = self.side(lev)
        lo = np.array([i * s for i in idx], float); hi = lo + s
        mid = (lo + hi) / 2
        Q = np.array([[0, 0], [1, 0], [mid[0], mid[1]], [mid[2], mid[3]]], float)
        try:
            guess = lam1(Q, 24) * abs(PQ.area(Q))
        except Exception:
            self.cells[key] = None; return None
        t0 = time.time(); nc0 = len(self.corners)
        r = C4.certify_box_cached(lo, hi, guess, self.corners, K=self.K, nseg=self.nseg)
        self.stats['cells'] += 1; self.stats['cell_sec'] += time.time() - t0
        self.stats['corners'] += len(self.corners) - nc0
        v = r['LB'] if r.get('ok') else None
        self.cells[key] = v
        return v

    def lower_bound(self, lo4, hi4, need, lev=0, idxs=None):
        """certify F(Q) >= need on the box [lo4, hi4] (returns True / False)."""
        s = self.side(lev)
        if idxs is None:
            rng = [range(math.floor(lo4[i] / s), math.floor(hi4[i] / s) + 1) for i in range(4)]
            idxs = itertools.product(*rng)
        for idx in idxs:
            v = self.cell_lb(lev, idx)
            if v is not None and v > need:
                continue
            if lev >= self.QMAX:
                return False
            # refine this cell into its 16 children, keeping only those that meet [lo4, hi4]
            s2 = self.side(lev + 1); kids = []
            for b in itertools.product((0, 1), repeat=4):
                ci = tuple(2 * idx[i] + b[i] for i in range(4))
                clo = [ci[i] * s2 for i in range(4)]
                if all(clo[i] <= hi4[i] and clo[i] + s2 >= lo4[i] for i in range(4)):
                    kids.append(ci)
            if not self.lower_bound(lo4, hi4, need, lev + 1, kids):
                return False
        return True


def exclude(lo6, hi6, ks, table, depth=0, maxdepth=12, log=None, stats=None):
    """try to exclude the pentagon box; returns list of leaves (lo, hi, status, k)."""
    if stats is None:
        stats = {}
    best = None
    for k in ks:
        g = box_geometry(lo6, hi6, k)
        if not g['ok']:
            continue
        if TWO_PI2 * g['r_arb'] > FUP:
            stats['S'] = stats.get('S', 0) + 1
            return [(lo6, hi6, 'S', k)]
        if best is None or g['r_lo'] > best[1]['r_lo']:
            best = (k, g)
    if best is not None:
        k, g = best
        need = float((FUP / g['r_arb']).upper())
        widths = [g['hi4'][i] - g['lo4'][i] for i in range(4)]
        if max(widths) < 4 * table.S0 and table.lower_bound(g['lo4'], g['hi4'], need):
            stats['T'] = stats.get('T', 0) + 1
            return [(lo6, hi6, 'T', k)]
    if depth >= maxdepth:
        stats['U'] = stats.get('U', 0) + 1
        return [(lo6, hi6, 'U', None)]
    i = int(np.argmax(np.asarray(hi6) - np.asarray(lo6)))
    m = (lo6[i] + hi6[i]) / 2
    a_hi = list(hi6); a_hi[i] = m; b_lo = list(lo6); b_lo[i] = m
    return (exclude(lo6, a_hi, ks, table, depth + 1, maxdepth, log, stats) +
            exclude(b_lo, hi6, ks, table, depth + 1, maxdepth, log, stats))
