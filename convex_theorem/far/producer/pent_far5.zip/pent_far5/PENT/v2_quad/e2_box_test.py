"""E2 (Claude 2026-11-01): try to exclude a whole pentagon box  centre(id) +- h  by dimension descent (S_k / quadrilateral
table, dimdesc.exclude), recording leaves, table cells, corner certificates and CPU time.
Usage: python3 e2_box_test.py ID K H MAXDEPTH QMAX OUT.json"""
import sys, os, json, time
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import dimdesc as DD, pentquad as PQ
cid, k, h, maxdepth, qmax, out = int(sys.argv[1]), int(sys.argv[2]), float(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5]), sys.argv[6]
cs = {json.loads(l)['id']: json.loads(l) for l in open(os.path.join(DD.HERE, '..', 'local', 't1_sweep', 'centres_run2.jsonl'))}
x = PQ.XS + cs[cid]['r'] * np.array(cs[cid]['d'])
lo = [float(v) for v in x - h]; hi = [float(v) for v in x + h]
T = DD.QuadTable(S0=1 / 32, QMAX=qmax)
t0 = time.time(); st = {}
leaves = DD.exclude(lo, hi, [k], T, maxdepth=maxdepth, stats=st)
vol = lambda L: float(np.prod(np.array(L[1]) - np.array(L[0])))
tot = vol((lo, hi))
res = dict(id=cid, k=k, h=h, maxdepth=maxdepth, qmax=qmax, leaves=len(leaves), status_counts=st,
           excluded_volume_fraction=sum(vol(L) for L in leaves if L[2] in 'ST') / tot,
           table=T.stats, table_cells_lb=[[list(key), v] for key, v in T.cells.items()],
           sec=round(time.time() - t0, 1), complete=all(L[2] in 'ST' for L in leaves))
json.dump(res, open(out, 'w'), indent=1)
print({k_: res[k_] for k_ in ('id', 'h', 'leaves', 'status_counts', 'excluded_volume_fraction', 'table', 'sec', 'complete')}, flush=True)
