"""Pentagon -> enclosing quadrilateral (delete edge k), Claude 2026-11-01.  Shared helpers for the v2 exclusion work.

Chart: V0 = (0,0), V1 = (1,0), (V2, V3, V4) = x in R^6, CCW.  Deleting edge k (V_k -> V_{k+1}) and extending its two
neighbours e_{k-1} = V_k - V_{k-1}, e_{k+1} = V_{k+2} - V_{k+1} until they meet at W gives the quadrilateral
Q_k = (V_{k+2}, V_{k+3}, V_{k-1}, W) that contains P (when P is convex and C = e_{k-1} x e_{k+1} > 0), with
W = V_k + (B/C) e_{k-1},  A = e_{k-1} x e_k,  B = e_k x e_{k+1},  |Q| = |P| + A B / (2 C).
Domain monotonicity and Polya's quadrilateral theorem give F(P) >= lambda_1(Q) |P| >= F(Q) |P| / |Q| >= 2 pi^2 |P|/|Q|."""
import numpy as np

XS = np.array([1.3090169943749472, 0.9510565162951535, 0.49999999999999994, 1.5388417685876266,
               -0.30901699437494745, 0.9510565162951536])
FSTAR_UP = 18.919134195733918


def verts(x):
    return np.array([[0.0, 0.0], [1.0, 0.0], [x[0], x[1]], [x[2], x[3]], [x[4], x[5]]])


def cr(u, v):
    return u[0] * v[1] - u[1] * v[0]


def area(V):
    n = len(V)
    return 0.5 * sum(cr(V[i], V[(i + 1) % n]) for i in range(n))


def quad(V, k):
    """float enclosing quadrilateral (CCW) for deleting edge k, or None if it is unbounded / P not convex."""
    e = [V[(i + 1) % 5] - V[i] for i in range(5)]
    if min(cr(e[i], e[(i + 1) % 5]) for i in range(5)) <= 0:
        return None
    A = cr(e[(k - 1) % 5], e[k]); B = cr(e[k], e[(k + 1) % 5]); C = cr(e[(k - 1) % 5], e[(k + 1) % 5])
    if C <= 0:
        return None
    W = V[k] + (B / C) * e[(k - 1) % 5]
    return np.array([V[(k + 2) % 5], V[(k + 3) % 5], V[(k - 1) % 5], W]), A * B / (2 * C)


def quad_chart(Q):
    """normalise Q = (q0, q1, q2, q3) by the similarity sending q0 -> 0, q1 -> 1: returns x4 = (q2, q3) in R^4."""
    z = Q[:, 0] + 1j * Q[:, 1]
    w = (z - z[0]) / (z[1] - z[0])
    return np.array([w[2].real, w[2].imag, w[3].real, w[3].imag])
