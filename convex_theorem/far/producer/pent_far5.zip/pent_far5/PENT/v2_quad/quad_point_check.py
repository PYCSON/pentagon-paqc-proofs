"""E1 (Claude 2026-11-01): rigorous point check of the quadrilateral bound at sampled pentagon centres.

For each centre x and each admissible k: Q = enclosing quadrilateral (pentquad.quad), slightly enlarged (scaled by
1 + 1e-9 about its vertex centroid, so that the float Q certainly contains the exact P; domain monotonicity), a rigorous
lower bound lam_lo(Q) from rig_box.certify_polygon (MPS + FHM + Hong-Krahn-Szego, mu < 1), and the rigorous pointwise
bound F(P) >= lam_lo(Q) * |P|.  This is a statement about the single pentagon x (to binary64 input), not a box.
Usage: [QK=8] [QNSEG=300] [QKS=k1,k2] python3 quad_point_check.py OUT.jsonl ID [ID ...]   (centres from t1_sweep/centres_run2.jsonl)"""
import sys, os, json, time
import numpy as np
from multiprocessing import Pool
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', 'far', 'qtable'))
sys.path.insert(0, os.path.join(HERE, '..', '..', 'MEAS-01', 'claude', 'scripts', 'C456'))
import pentquad as PQ
from fem_check import lam1
import rig_box
from flint import arb

CENTRES = os.path.join(HERE, '..', 'local', 't1_sweep', 'centres_run2.jsonl')


def one(args):
    cid, x, k = args
    V = PQ.verts(x); q = PQ.quad(V, k)
    if q is None:
        return dict(id=cid, k=k, ok=False, why='unbounded or nonconvex')
    Q, ear = q
    c = Q.mean(axis=0); Qe = c + (Q - c) * (1 + 1e-9)
    t0 = time.time()
    lf = lam1(Qe, 32)                                  # P1 FEM upper bound, used only as the starting guess
    K = int(os.environ.get('QK', '8')); nseg = int(os.environ.get('QNSEG', '300'))
    r = rig_box.certify_polygon(Qe, K, lf, nseg=nseg, width=0.03)
    P_area = arb(PQ.area(V))                           # float area of P; the bound uses lam_lo * |P|
    lo = r['lam_lo'] * P_area
    return dict(id=cid, k=k, K=K, nseg=nseg, ok=bool(r['ok_index']), mu=float(r['mu'].upper()), FQ=float(r['lam'] * PQ.area(Qe)),
                score_lo=float(lo.lower()), margin=float(lo.lower()) - PQ.FSTAR_UP, fem_guess_FQ=lf * PQ.area(Qe),
                sec=round(time.time() - t0, 1))


def main():
    out = sys.argv[1]; ids = [int(v) for v in sys.argv[2:]]
    cs = {json.loads(l)['id']: json.loads(l) for l in open(CENTRES)}
    tasks = []
    for i in ids:
        x = PQ.XS + cs[i]['r'] * np.array(cs[i]['d'])
        for k in ([int(v) for v in os.environ['QKS'].split(',')] if os.environ.get('QKS') else range(5)):
            if PQ.quad(PQ.verts(x), k) is not None:
                tasks.append((i, x.tolist(), k))
    with Pool(2) as pool, open(out, 'a') as f:
        for res in pool.imap_unordered(one, tasks):
            f.write(json.dumps(res) + '\n'); f.flush()
            print(res, flush=True)


if __name__ == '__main__':
    main()
