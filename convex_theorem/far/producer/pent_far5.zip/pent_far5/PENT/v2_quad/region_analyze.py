"""Cost of the quadrilateral route (S/T exclusion, region_exclude.py) measured on the user's machine, against PAQC on the
same set of pentagons (Claude, 2026-11-05; a cost comparison, not a proof).

Input: the extracted v2_region_results.tgz (OUT/<job>/summary.json, params.json, leaves.jsonl).  Per job (centre id, half
width H, region = centre +- H in the identity chart, volume (2H)^6):
  quad CPU   = serial geometry + corner certificates.  region_exclude.py does the box geometry (ball arithmetic: convexity,
               quadrilateral enclosures, S test) in the main process, one box at a time, and only the corner certificates in
               the worker pool; so geometry = wall_sec - corner_cpu_sec / workers (corner_cpu_sec = corner-phase wall x
               workers), and quad CPU = geometry + corner_cpu_sec.  (The old cost_v2.py model counted corners only.)
  excluded   = volume fraction of S and T leaves (summary.json); S share from leaves.jsonl.
  PAQC (identity) on the same region = min over passing run3 sizes of (29.25 + 0.067 boxes) / (2 rho)^6, times (2H)^6.
  PAQC (relabelled) = identity / gain, gain from the pilot + validation measurements (../local/orbit_valid/valid_analyze.py,
               ZeroDivisionError re-tests merged; pair = mean of the two mirror members, and pair = cheaper member);
               centres without a measurement keep gain 1.
  ratio      = quad CPU per excluded volume / PAQC CPU per volume (> 1: the quadrilateral route is dearer).
Usage: python3 region_analyze.py OUTDIR [--json out.json]"""
import sys, os, json, glob, math
HERE = os.path.dirname(os.path.abspath(__file__))
L = os.path.join(HERE, '..', 'local')
OUT = sys.argv[1]
JSON_OUT = sys.argv[sys.argv.index('--json') + 1] if '--json' in sys.argv else None


def gains(pairmin):
    sys.argv = ['valid_analyze.py', '--zd', os.path.join(L, 'zd_rerun', 'zd_results.jsonl')] + (['--pairmin'] if pairmin else [])
    import importlib.util
    spec = importlib.util.spec_from_file_location('VA%d' % pairmin, os.path.join(L, 'orbit_valid', 'valid_analyze.py'))
    VA = importlib.util.module_from_spec(spec); spec.loader.exec_module(VA)
    r3 = VA.merge_zd({json.loads(l)['id']: json.loads(l) for l in open(os.path.join(VA.T1, 'results_run3', 'results.jsonl'))}, 'run3')
    gp, _, _ = VA.gains(os.path.join(VA.OP, 'results_all98.jsonl'), os.path.join(VA.OP, 'centres_orbit.jsonl'), r3, 'pilot')
    gv, nv, cv = VA.gains(os.path.join(L, 'orbit_valid', 'out_sandbox', 'results.jsonl'), os.path.join(L, 'orbit_valid', 'centres_valid.jsonl'), r3, 'valid')
    g = dict(gv); g.update(gp)
    return g, r3, VA.best_density


def svol(path):
    s = t = u = 0.0
    with open(path) as f:
        for line in f:
            d = json.loads(line); v = math.prod(h - l for l, h in zip(d['lo'], d['hi']))
            if d['status'] == 'S':
                s += v
            elif d['status'] == 'T':
                t += v
            else:
                u += v
    return s, t, u


def main():
    gmean, r3, bd = gains(False)
    gmin, _, _ = gains(True)
    rows = []
    for sp in sorted(glob.glob(os.path.join(OUT, '*', 'summary.json'))):
        d = os.path.dirname(sp); name = os.path.basename(d)
        s = json.load(open(sp)); p = json.load(open(os.path.join(d, 'params.json')))
        i, H, w = p['id'], p['H'], p['workers']
        geo = s['wall_sec'] - s['corner_cpu_sec'] / w; quad = geo + s['corner_cpu_sec']
        V = (2 * H) ** 6; ex = s['excluded_fraction']
        sv, tv, uv = svol(os.path.join(d, 'leaves.jsonl'))
        paqc_id = bd(r3[i]) * V
        row = dict(job=name, id=i, r=round(r3[i]['r'], 3), H=H, done=s['done'], excluded=round(ex, 4),
                   S_share_of_excluded=round(sv / (sv + tv), 3) if sv + tv else None,
                   leaves=sum(s['counts'].values()), corners=s['corners_new'],
                   geometry_cpu_h=round(geo / 3600, 2), corner_cpu_h=round(s['corner_cpu_sec'] / 3600, 2), quad_cpu_h=round(quad / 3600, 2),
                   sec_per_corner=round(s['corner_cpu_sec'] / max(s['corners_new'], 1), 2),
                   ms_per_leaf_geometry=round(1000 * geo / max(sum(s['counts'].values()), 1), 1),
                   paqc_identity_cpu_h=round(paqc_id / 3600, 3),
                   gain_mean=round(gmean.get(i, 1.0), 2), gain_min=round(gmin.get(i, 1.0), 2),
                   measured_gain=i in gmean)
        row['ratio_vs_identity'] = round(quad / max(ex, 1e-12) / paqc_id, 1)
        row['ratio_vs_relabelled_mean'] = round(row['ratio_vs_identity'] * row['gain_mean'], 1)
        row['ratio_vs_relabelled_min'] = round(row['ratio_vs_identity'] * row['gain_min'], 1)
        rows.append(row)
        print(json.dumps(row), flush=True)
    if JSON_OUT:
        json.dump(rows, open(JSON_OUT, 'w'), indent=1)


if __name__ == '__main__':
    main()
