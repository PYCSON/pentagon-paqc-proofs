"""Parallel, resumable dimension-descent exclusion of a pentagon region (Claude, 2026-11-01, v2 prototype, not reviewed).

A region is a 6-D chart box (centre +- H).  It is processed in waves of pentagon boxes:
  1. ball-arithmetic geometry (dimdesc.box_geometry: convexity, C > 0, r_lo = lower bound of |P|/|Q|, 4-D enclosure X4
     of the normalised enclosing quadrilateral) for every admissible deleted edge k;
  2. S test: 2 pi^2 r_lo > F*_up (Polya's quadrilateral theorem, no eigenvalues)  -> status S;
  3. T test: L * r_lo > F*_up with L = min of the certified quadrilateral-cell bounds over the dyadic table cells of
     level `qlev` meeting X4 (cells of side S0 / 2^qlev, exact binary64 endpoints)  -> status T;
  4. otherwise the box is bisected along its widest coordinate (or, when the table loss dominates, retried with finer
     table cells), up to MAXDEPTH;  boxes that remain are reported UNRESOLVED (to be covered by PAQC).
All missing corner certificates of a wave are computed in parallel (rig_box.certify_polygon via rig_paqc_n.Chart(4)),
and every corner and cell result is appended to the table files, so a restarted run reuses them ('the table').
Outputs (in OUT/): corners.jsonl, cells.jsonl (the table), leaves.jsonl (every final box with its status, k, r_lo and the
bound used), progress.json, summary.json.
Usage: python3 region_exclude.py OUT  --id ID --H H  [--centre x1,...,x6] [--workers 4] [--maxdepth 14] [--S0 0.03125]
                                  [--qmax 0] [--maxtablewidth 0.25] [--sroute 0.003] [--hours 0] [--K 8] [--nseg 300]"""
import os, sys, json, time, math, itertools, argparse
import numpy as np
from multiprocessing import Pool
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import dimdesc as DD, pentquad as PQ
from flint import arb
from fem_check import lam1


def corner_job(args):
    key, x, K, nseg = args
    Q = np.array([[0, 0], [1, 0], [x[0], x[1]], [x[2], x[3]]], float)
    try:
        guess = lam1(Q, 24) * abs(PQ.area(Q))
        F, r = DD.C4.corner_F(np.array(x, float), guess, K=K, nseg=nseg)
        return key, (None if F is None else float(F)), float(r['mu'].upper())
    except Exception as exc:
        return key, None, repr(exc)[:80]


class Table:
    def __init__(self, out, S0):
        self.S0 = S0; self.fc = os.path.join(out, 'corners.jsonl'); self.fl = os.path.join(out, 'cells.jsonl')
        self.corners = {}; self.cells = {}
        if os.path.exists(self.fc):
            for line in open(self.fc):
                d = json.loads(line); self.corners[tuple(d['key'])] = d['F']
        # cell bounds are NOT reloaded (their keys depend on S0); they are recomputed from the saved corners (cheap)
        self.new_corners = 0; self.new_cells = 0; self.corner_sec = 0.0

    def side(self, lev):
        return self.S0 / 2 ** lev

    def cell_box(self, key):
        lev, idx = key[0], key[1:]; s = self.side(lev)
        lo = np.array([i * s for i in idx], float); return lo, lo + s

    def cells_for(self, lo4, hi4, lev):
        s = self.side(lev)
        rng = [range(math.floor(lo4[i] / s), math.floor(hi4[i] / s) + 1) for i in range(4)]
        return [(lev,) + idx for idx in itertools.product(*rng)]

    def missing_corners(self, keys):
        need = {}
        for key in keys:
            if key in self.cells:
                continue
            lo, hi = self.cell_box(key)
            for x in DD.C4.cell_corners(lo, hi):
                ck = tuple(repr(float(v)) for v in x)
                if ck not in self.corners:
                    need[ck] = [float(v) for v in x]
        return need

    def add_corners(self, results):
        with open(self.fc, 'a', buffering=1) as f:
            for key, F, info in results:
                self.corners[key] = F; self.new_corners += 1
                f.write(json.dumps(dict(key=list(key), F=F, mu=info)) + '\n')

    def cell_lb(self, key):
        if key in self.cells:
            return self.cells[key]
        lo, hi = self.cell_box(key)
        Fl = []
        for x in DD.C4.cell_corners(lo, hi):
            F = self.corners.get(tuple(repr(float(v)) for v in x))
            if F is None:
                Fl = None; break
            Fl.append(F)
        LB = None
        if Fl is not None:
            g = DD.C4.geometry_bound_box(lo, hi)
            if g['ok']:
                LB = float((g['factor'] * DD.PN.amin([arb(v) for v in Fl])).lower())
        self.cells[key] = LB; self.new_cells += 1
        with open(self.fl, 'a') as f:
            f.write(json.dumps(dict(key=list(key), side=self.side(key[0]), LB=LB)) + '\n')
        return LB


def geometry_all(lo, hi):
    """per admissible k, the base-edge rotation of the quadrilateral chart with the smallest 4-D enclosure (volume)."""
    gs = {}
    for k in range(5):
        best = None
        for rot in range(4):
            g = DD.box_geometry(lo, hi, k, rot)
            if not g['ok']:
                break
            v = float(np.prod(np.array(g['hi4']) - np.array(g['lo4'])))
            if best is None or v < best[0]:
                best = (v, g)
        if best is not None:
            gs[k] = best[1]
    return gs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('out'); ap.add_argument('--id', type=int); ap.add_argument('--H', type=float, required=True)
    ap.add_argument('--centre'); ap.add_argument('--workers', type=int, default=4); ap.add_argument('--maxdepth', type=int, default=14)
    ap.add_argument('--S0', type=float, default=1 / 32); ap.add_argument('--qmax', type=int, default=0)
    ap.add_argument('--maxtablewidth', type=float, default=0.25); ap.add_argument('--sroute', type=float, default=0.003); ap.add_argument('--hours', type=float, default=0)
    ap.add_argument('--K', type=int, default=8); ap.add_argument('--nseg', type=int, default=300)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    if a.centre:
        x = np.array([float(v) for v in a.centre.split(',')])
    else:
        cf = os.path.join(HERE, 'centres_run2.jsonl')
        if not os.path.exists(cf):
            cf = os.path.join(HERE, '..', 'local', 't1_sweep', 'centres_run2.jsonl')
        cs = {json.loads(l)['id']: json.loads(l) for l in open(cf)}
        x = PQ.XS + cs[a.id]['r'] * np.array(cs[a.id]['d'])
    root = ([float(v - a.H) for v in x], [float(v + a.H) for v in x])
    json.dump(dict(vars(a), centre_x=[float(v) for v in x], started=time.strftime('%F %T')), open(os.path.join(a.out, 'params.json'), 'w'), indent=1)
    T = Table(a.out, a.S0)
    leaves_f = open(os.path.join(a.out, 'leaves.jsonl'), 'w')     # leaves are recomputed on restart (cheap); table reused
    t0 = time.time(); wave = [(root[0], root[1], 0, 0)]; counts = dict(S=0, T=0, U=0, X=0); vol = dict(S=0.0, T=0.0, U=0.0, X=0.0)
    vroot = float(np.prod(np.array(root[1]) - np.array(root[0])))
    pool = Pool(a.workers); nwave = 0
    while wave:
        nwave += 1; nxt = []; pend = []
        for lo, hi, depth, qlev in wave:
            gs = geometry_all(lo, hi)
            v = float(np.prod(np.array(hi) - np.array(lo)))
            if not gs:
                st = 'X' if depth >= a.maxdepth else None                     # convexity/C not provable on the box
                if st:
                    counts['X'] += 1; vol['X'] += v; leaves_f.write(json.dumps(dict(lo=lo, hi=hi, status='X')) + '\n')
                else:
                    nxt += split(lo, hi, depth, qlev)
                continue
            kS = [k for k, g in gs.items() if DD.TWO_PI2 * g['r_arb'] > DD.FUP]
            if kS:
                counts['S'] += 1; vol['S'] += v
                leaves_f.write(json.dumps(dict(lo=lo, hi=hi, status='S', k=kS[0], r_lo=gs[kS[0]]['r_lo'])) + '\n'); continue
            k, g = max(gs.items(), key=lambda kv: kv[1]['r_lo'])
            widths = [g['hi4'][i] - g['lo4'][i] for i in range(4)]
            # S route: where the Polya bound alone has a comfortable margin at the box centre, splitting is far cheaper
            # than certifying table corners (boxes cost milliseconds, corners seconds)
            s_route = max(2 * math.pi ** 2 * gg['r_c'] for gg in gs.values()) > PQ.FSTAR_UP * (1 + a.sroute) and depth < a.maxdepth - 2
            if max(widths) > a.maxtablewidth or s_route:
                nxt += split(lo, hi, depth, qlev); continue
            keys = T.cells_for(g['lo4'], g['hi4'], qlev)
            pend.append((lo, hi, depth, qlev, k, g, keys, v))
        need = {}
        for item in pend:
            need.update(T.missing_corners(item[6]))
        if need:
            tc = time.time()
            for one in pool.imap_unordered(corner_job, [(k_, v_, a.K, a.nseg) for k_, v_ in need.items()], chunksize=1):
                T.add_corners([one])                                  # saved one by one: a killed run loses nothing
            T.corner_sec += time.time() - tc
        for lo, hi, depth, qlev, k, g, keys, v in pend:
            lbs = [T.cell_lb(key) for key in keys]
            req = float((DD.FUP / g['r_arb']).upper())
            if all(L is not None for L in lbs) and min(lbs) > req:
                counts['T'] += 1; vol['T'] += v
                leaves_f.write(json.dumps(dict(lo=lo, hi=hi, status='T', k=k, rot=g['rot'], r_lo=g['r_lo'], L=min(lbs), qlev=qlev, ncells=len(keys))) + '\n')
            elif depth >= a.maxdepth:
                counts['U'] += 1; vol['U'] += v
                leaves_f.write(json.dumps(dict(lo=lo, hi=hi, status='U', k=k, r_lo=g['r_lo'],
                                               L=min([L for L in lbs if L is not None], default=None), qlev=qlev)) + '\n')
            else:
                # refine the table if its loss dominates, otherwise bisect the pentagon box
                Lmin = min([L for L in lbs if L is not None], default=0.0)
                table_short = Lmin < req and qlev < a.qmax and len(keys) <= 16 and Lmin > 0.985 * req   # small boxes only
                if table_short:
                    nxt.append((lo, hi, depth, qlev + 1))
                else:
                    nxt += split(lo, hi, depth, qlev)
        leaves_f.flush()
        prog = dict(wave=nwave, next_wave=len(nxt), counts=counts, excluded_fraction=(vol['S'] + vol['T']) / vroot,
                    unresolved_fraction=(vol['U'] + vol['X']) / vroot, corners_total=len(T.corners), corners_new=T.new_corners,
                    cells_total=len(T.cells), corner_cpu_sec=round(T.corner_sec * a.workers, 1), wall_sec=round(time.time() - t0, 1))
        json.dump(prog, open(os.path.join(a.out, 'progress.json'), 'w'))
        print(json.dumps(prog), flush=True)
        if a.hours and time.time() - t0 > 3600 * a.hours:
            print('time budget reached; stopping (rerun to continue)', flush=True); break
        wave = nxt
    pool.close()
    json.dump(dict(prog, done=not wave, finished=time.strftime('%F %T')), open(os.path.join(a.out, 'summary.json'), 'w'), indent=1)


def split(lo, hi, depth, qlev):
    w = np.array(hi) - np.array(lo); i = int(np.argmax(w)); m = (lo[i] + hi[i]) / 2
    a_hi = list(hi); a_hi[i] = m; b_lo = list(lo); b_lo[i] = m
    return [(lo, a_hi, depth + 1, qlev), (b_lo, hi, depth + 1, qlev)]


if __name__ == '__main__':
    main()
