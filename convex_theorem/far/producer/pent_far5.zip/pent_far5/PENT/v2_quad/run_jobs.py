"""Local long run (v2, Claude 2026-11-02): run region_exclude.py over a list of regions, one after another, resumable.
Each job writes OUT/<name>/ (table files are reused on restart; a job whose summary.json says done is skipped).
Guards: stops safely when available memory < 1.5 GB or free disk < 2 GB (writes STOPPED_guard.txt).
Usage: python3 run_jobs.py jobs.json OUT WORKERS"""
import sys, os, json, subprocess, shutil, time
HERE = os.path.dirname(os.path.abspath(__file__))


def mem_gb():
    for line in open('/proc/meminfo'):
        if line.startswith('MemAvailable:'):
            return int(line.split()[1]) / 1e6
    return 99.0


def main():
    jobs = json.load(open(sys.argv[1])); out = sys.argv[2]; workers = sys.argv[3]
    os.makedirs(out, exist_ok=True)
    for j in jobs:
        d = os.path.join(out, j['name'])
        sp = os.path.join(d, 'summary.json')
        if os.path.exists(sp) and json.load(open(sp)).get('done'):
            print('skip (done)', j['name'], flush=True); continue
        if mem_gb() < 1.5 or shutil.disk_usage(out).free / 1e9 < 2:
            open(os.path.join(out, 'STOPPED_guard.txt'), 'w').write(time.strftime('%F %T') + ' memory/disk guard\n')
            print('guard stop', flush=True); return
        cmd = [sys.executable, os.path.join(HERE, 'region_exclude.py'), d, '--id', str(j['id']), '--H', str(j['H']),
               '--workers', workers, '--maxdepth', str(j.get('maxdepth', 30)), '--S0', str(j.get('S0', 0.0625)),
               '--qmax', str(j.get('qmax', 1)), '--hours', str(j.get('hours', 2)), '--K', str(j.get('K', 6)),
               '--nseg', str(j.get('nseg', 150))]
        print(time.strftime('%F %T'), 'start', j['name'], flush=True)
        subprocess.run(cmd, stdout=open(os.path.join(out, j['name'] + '.log'), 'a'), stderr=subprocess.STDOUT)
        print(time.strftime('%F %T'), 'end', j['name'], flush=True)
    open(os.path.join(out, 'DONE.txt'), 'w').write(time.strftime('%F %T') + '\n')


if __name__ == '__main__':
    main()
