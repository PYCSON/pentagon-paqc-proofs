"""Corner certificate for v2 (Claude, 2026-11-07): the v1.0 method (MEAS-01 rig_box.certify_polygon: MPS + FHM + HKS)
with two production changes, both about cost or robustness, neither about rigour.

1. Adaptive eigenvalue bracket.  v1.0's corner_F searched lambda in guess * [1 - 0.05, 1 + 0.05] with
   guess = 18.94 / area, which is fine near the regular pentagon (v1.0 cells) but fails for shapes with F > 19.887:
   the solver returns the bracket end, the MPS function is no eigenfunction and mu is large (measured: d = 0.8,
   mu = 0.09 with width 0.05 versus 2.5e-3 with width 0.3).  Here: width 0.05 first; if the solution sits at the bracket
   end or mu > 0.02 (far above the nseg-limited level), solve again with width 0.3, then 0.6.  The certificate records the width used.
2. Two boundary resolutions.  The rigorous boundary sup (sup_boundary) is 93-98% of a corner's time; mu falls like
   nseg^-3: nseg = 300 gives mu ~ 2-6e-4 (F loss 0.02-0.06%, 4.7 s) against nseg = 1000 (mu ~ 1e-5, 15.5 s).  The
   caller asks for 'fast' (300) or 'fine' (1000); near_certify uses fast first and fine only for cells that fail.
Certificate fields (replayable without search): vertices (exact binary64 repr), K, nseg, width, lam_tilde,
coefficients, sup_bdry_upper, l2sq_lower, mu, area, lam_lo, hks_index_ok, F_lo (rounded down), solver tag;
2026-11-08 (GPT PENT-14b CHANGES): lam_lo_f64, area_lo_f64, mu_up_f64 (binary64 outward bounds, exact rationals) and
F_lo_safe = f_down(lam_lo_f64 * area_lo_f64): a checker verifies F_lo_safe <= lam_lo_f64 * area_lo_f64 in exact arithmetic
(the ball strings are decimal displays that only ENCLOSE the balls, so products of their printed endpoints are not
comparable with F_lo at the last digit); rig_paqc.cert_F_lo returns F_lo_safe when present, so production and checker
use the same number.
The cache key must include (K, nseg, SOLVER); corners with different keys are different certificates."""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'scripts'))
import numpy as np
import rig_paqc as R
from flint import arb
import rig_box as RB
from mps import poly_area

SOLVER = 'corner_v2/1'
NSEG = {'fast': 300, 'fine': 1000}
# 2026-11-10 EXPERIMENT (sup_fast.py, NEAR_SPEC section 13): SUP = 'fast' computes the boundary sup with 4 instead of 11
# Bessel calls per (corner, mode, segment), 2.5x faster corners; certificates then carry solver 'corner_v2/2'.
# Default stays 'rig_box' (the v1.0 code path) until the pre-run audit and GPT's review decide.
SUP = 'rig_box'


# 2026-11-12 EXPERIMENT (sup_taylor.py, NEAR_SPEC section 15): SUP = 'taylor': order-TAYLOR_P Taylor bound per segment;
# mu ~ 1e-5 (the true residual level) instead of ~1e-3, and the sup takes 0.5 s instead of 4.5 s.  The tiers then mean
# NSEG_TAYLOR segments per edge; the certificate records nseg and sup_order; solver tag 'corner_v2/3'.
TAYLOR_P = 6
NSEG_TAYLOR = {'fast': 40, 'fine': 80}


# 2026-11-16 EXPERIMENT (lgfan.py, far/LG_LEMMA.md computation B; awaiting review): SUP = 'fan': the corner value is the
# fan certificate (Lemma LG, piecewise polynomials, integer arithmetic) instead of an eigenvalue certificate.
# Tiers: (degree N, extra flux degree); P+ on the grid 2^-FAN_GRID.  Deficit on the regular pentagon 4e-7 (N = 12, 13 ms),
# 5e-8 (N = 16, 50 ms); the eigenvalue certificate has 1.6e-6 in 0.8 s (taylor) to 15 s (rig_box, fine).
# Certificates carry kind 'fan' and solver 'fan/1'; the key slot 'nseg' holds N.
FAN = {'fast': (8, 1), 'fine': (14, 2)}
FAN_GRID = 40


def solver():
    """the solver tag of certificates made now (cache keys carry it, so the sup paths never mix)"""
    return {'fast': 'corner_v2/2', 'taylor': 'corner_v2/3', 'fan': 'fan/1'}.get(SUP, SOLVER)


def nseg_of(tier):
    if SUP == 'fan':
        return FAN[tier][0]
    return NSEG_TAYLOR[tier] if SUP == 'taylor' and tier in NSEG_TAYLOR else NSEG[tier]


def fan_corner(x, tier):
    """fan certificate of the chart pentagon (0, (1,0), x[0:2], x[2:4], x[4:6]) (exact binary64 vertices); None if there
    is none (not strictly convex and counter-clockwise, or the hypothesis D < 0 of Lemma LG fails)"""
    import lgfan
    N, extra = FAN[tier]
    V = [(0.0, 0.0), (1.0, 0.0), (float(x[0]), float(x[1])), (float(x[2]), float(x[3])), (float(x[4]), float(x[5]))]
    rec = lgfan.F_lower(V, N, extra, grid=FAN_GRID)
    if rec is None:
        return None
    return dict(vertices_x=[repr(float(v)) for v in x], kind='fan', solver=solver(), tier=tier, lg=rec, F_lo=repr(rec['F_lo']))


def _certify_polygon_fastsup(V, K, guess, nseg, width):
    """rig_box.certify_polygon with sup_fast.sup_boundary_fast in place of rig_box.sup_boundary; every other step is
    the rig_box one (MPS solve, ArbU, l2_lower, area, FHM mu, HKS index), line by line."""
    from mps import PolyMPS
    m = PolyMPS(V, K=K)
    lam = m.solve(guess, width=width, ngrid=11)
    U = RB.ArbU(m)
    if SUP == 'taylor':
        import sup_taylor as ST
        sup = ST.sup_boundary_taylor(U, nseg, TAYLOR_P)
    else:
        import sup_fast as SF
        sup = SF.sup_boundary_fast(U, nseg)
    l2 = RB.l2_lower(U, None)
    xs = [RB.A(v[0]) for v in V]; ys = [RB.A(v[1]) for v in V]; nv = len(V)
    area = abs(sum(xs[i] * ys[(i + 1) % nv] - xs[(i + 1) % nv] * ys[i] for i in range(nv))) / 2
    mu = area.sqrt() * sup / l2.sqrt()
    lamt = arb(float(lam))
    ok_index = bool(mu < 1) and bool((lamt / (1 - mu) * area) < RB.HKS)
    return dict(lam=lam, mu=mu, ok_index=bool(ok_index), lam_lo=lamt / (1 + mu), lam_hi=lamt / (1 - mu), area=area,
                coefficients=[repr(float(v)) for v in U.c], sup_bdry=sup, l2sq_lower=l2)


def certify_corner(x, K=8, tier='fast', widths=(0.05, 0.3, 0.6)):
    """widths: the bracket sequence; the far region (F ~ 22, 16% above the regular pentagon) passes (0.3, 0.6) to skip the
    always-failing 0.05 solve (2026-11-09: halves the corner time there)."""
    if SUP == 'fan':
        return fan_corner(x, tier)
    V = np.array([[0, 0], [1, 0], [x[0], x[1]], [x[2], x[3]], [x[4], x[5]]], float)
    nseg = nseg_of(tier); guess = 18.94 / poly_area(V); r = None
    for width in widths:
        r = (_certify_polygon_fastsup(V, K, guess, nseg, width) if SUP in ('fast', 'taylor') else
             RB.certify_polygon(V, K, guess, nseg=nseg, width=width))
        lam = float(r['lam']); at_edge = min(abs(lam - guess * (1 - width)), abs(lam - guess * (1 + width))) < 1e-9 * guess
        if r['ok_index'] and not at_edge and float(r['mu'].upper()) <= 0.02:
            break
    if not r['ok_index']:
        return None
    F = r['lam_lo'] * r['area']; lo_ = R.f_down(F)
    rec = dict(vertices_x=[repr(float(v)) for v in x], K=K, nseg=nseg, width=width, solver=solver(), lam_tilde=repr(float(r['lam'])),
               mu=str(r['mu']), lam_lo=str(r['lam_lo']), lam_hi=str(r['lam_hi']), area=str(r['area']), hks_index_ok=bool(r['ok_index']),
               F_lo=repr(lo_), coefficients=r.get('coefficients'), sup_bdry_upper=repr(R.f_up(r['sup_bdry'])),
               l2sq_lower=repr(R.f_down(r['l2sq_lower'])))
    if SUP == 'taylor':
        rec['sup_order'] = TAYLOR_P
    rec.update(R.safe_fields(arb(rec['lam_lo']), arb(rec['area']), arb(rec['mu'])))   # from the stored strings, so a checker recomputes the same
    return rec
