"""Cut-chart cover of the far region (Claude, 2026-11-12; FAR_SPEC section 9.7).  DRAFT for review.
Input: a quadrilateral table (t4table.Table: for each level-0 cell c a rigorous LB_c <= F on the convex quadrilaterals
of c).  For every table cell c and cut corner j in (3, 0) the set c x (0,1]^2 of cut-chart points (q, t, u) is covered
by closed boxes, each with one of the labels
   T  t_hi u_hi sup tau_j < 1 - F*_up / LB_c          proven by fact F1 (FAR_SPEC 9.7)
   X  cutchart.not_kept                                not the smallest-ear representation anywhere on the box
   H  far_exclude.classify(x-box, rep=False) = EXCLUDED (cheap exclusion) or INVALID (no convex pentagon in the box)
   N  far_pilot.near(x-box)                            every pentagon of the box has a labelling with d < 3/5 (near region)
   P  none of these at the minimal size                to be certified by n = 5 PAQC / T1 on the x-box
The boxes of one (c, j) are the leaves of a bisection tree of c x [0,1]^2 (widest coordinate first, relative to the
minimal widths), so they partition it exactly.  T leaves are not stored one by one: the whole part
{t u < theta_c} is proven, theta_c = (1 - F*_up/LB_c) / sup_c tau_j, and the tree only covers the bounding square of
the rest, [max(theta_c, 0), 1]^2 clipped to [0,1]^2.
x-box of a box (the pentagons in the frame V0 = (0,0), V1 = (1,0)): cutchart.x_box (exact hull for j = 3; for j = 0 the
frame is rescaled by 1/(1-t), every variable occurring once in each coordinate formula).
Output OUT/cover.jsonl: one record per (cell, j): theta, leaf counts and volumes by label, and the P boxes
[lo6, hi6, x_lo, x_hi]; OUT/cover_info.json.  Resumable; parallel over cells.
Usage: python3 cut_cover.py TABLE_DIR OUT [--wq 0.03125] [--wt 0.0625] [--jobs 2] [--limit N]"""
import os, sys, json, time, argparse
from multiprocessing import Pool
HERE = os.path.dirname(os.path.abspath(__file__))
for p in ('.', '../far', '../far/pilot', '../scripts'):
    sys.path.insert(0, os.path.join(HERE, p))
import numpy as np
from flint import arb
import rig_paqc as R
import cutchart as CC
import t4table as T4
import jsonl_safe as JS

ARGS = None


def x_box0(lo, hi):
    """exact x-box for j = 0: x = 1 + (v - 1)/(1 - t) for the abscissae, y/(1 - t) for the ordinates (each variable once)"""
    z = CC.zbox(lo, hi); s = 1 / (1 - z[4])
    if not s.is_finite():
        return None
    x = [1 + (z[0] - 1) * s, z[1] * s, 1 + (z[2] - 1) * s, z[3] * s, 1 + (z[5] * z[2] - 1) * s, z[5] * z[3] * s]
    return [float(v.lower()) for v in x], [float(v.upper()) for v in x]


def x_box(lo, hi, j):
    """j = 3: exact hull in the natural frame (base = base of Q).  j = 0: frame with base q1 -> q2 or q2 -> q3 (the longer
    one at the piece centre); returns (lo, hi) of the pentagon-chart box"""
    if j == 3:
        return CC.x_box(lo, hi, 3)
    zc = [(a + b) / 2 for a, b in zip(lo, hi)]
    l1 = (zc[0] - 1) ** 2 + zc[1] ** 2; l2 = (zc[2] - zc[0]) ** 2 + (zc[3] - zc[1]) ** 2
    return CC.frame_box(lo, hi, 0, 1 if l1 >= l2 else 2)


def cover_cell(args):
    key, LB, S0, wq, wt = args
    import far_exclude as FE, far_pilot as FP
    t0 = time.time(); lo4, hi4 = T4.cell_box(tuple(key), S0); out = []
    one_minus = 1 - R.FSTAR_UP / arb(LB) if LB != float('inf') else None
    for j in (3, 0):
        rec = dict(key=list(key), j=j, n={}, vol={}, P=[])
        ts = CC.tau_sup(lo4 + [0, 0], hi4 + [1, 1], j)
        if ts is None or one_minus is None:
            theta = 0.0
        else:
            theta = max(0.0, min(1.0, R.f_down(one_minus / arb(ts)))) if ts > 0 else 1.0
        rec['theta'] = theta
        if theta < 1:
            stack = [(lo4 + [0.0, 0.0], hi4 + [1.0, 1.0])]          # dyadic boxes only (cutcell needs exact corners); T closes the part below the hyperbola
            wmin = [wq] * 4 + [wt] * 2
            while stack:
                lo, hi = stack.pop(); typ = None; xb = None
                th = theta
                if hi[0] - lo[0] < (hi4[0] - lo4[0]) * 0.99 and one_minus is not None:      # a sub-box in q: its own sup tau
                    ts2 = CC.tau_sup(lo, hi, j)
                    if ts2 is not None and ts2 > 0:
                        th = max(theta, R.f_down(one_minus / arb(ts2)))
                if hi[4] * hi[5] < th:
                    typ = 'T'
                elif CC.not_kept(lo, hi, j) is not None:
                    typ = 'X'
                else:
                    xb = x_box(lo, hi, j)
                    if xb is not None:
                        lab, why = FE.classify([(xb[0][i], xb[1][i]) for i in range(6)], rep=False)
                        if lab in ('EXCLUDED', 'INVALID'):
                            typ = 'H'
                        elif max(xb[1][i] - xb[0][i] for i in range(6)) < 1.2 and FP.near(xb[0], xb[1]) is not None:
                            typ = 'N'
                w = [(hi[i] - lo[i]) / wmin[i] for i in range(6)]
                if typ is None and max(w) <= 1.0001:
                    typ = 'P'; rec['P'].append([lo, hi, xb[0] if xb else None, xb[1] if xb else None])
                if typ is None:
                    i = int(np.argmax(w)); m = (lo[i] + hi[i]) / 2
                    h1 = list(hi); h1[i] = m; l2 = list(lo); l2[i] = m; stack += [(lo, h1), (l2, hi)]
                else:
                    rec['n'][typ] = rec['n'].get(typ, 0) + 1
                    rec['vol'][typ] = rec['vol'].get(typ, 0) + float(np.prod([hi[i] - lo[i] for i in range(6)]))
        rec['sec'] = round(time.time() - t0, 2); out.append(rec)
    return out


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('table'); ap.add_argument('out'); ap.add_argument('--wq', type=float, default=1 / 32)
    ap.add_argument('--wt', type=float, default=1 / 16); ap.add_argument('--jobs', type=int, default=2); ap.add_argument('--limit', type=int, default=0)
    ap.add_argument('--sample', type=int, default=0, help='cover a random sample of this many table cells (cost estimate)')
    a = ap.parse_args(); os.makedirs(a.out, exist_ok=True); t0 = time.time()
    T = T4.Table(a.table, json.load(open(os.path.join(a.table, 'table_info.json')))['S0'] if os.path.exists(os.path.join(a.table, 'table_info.json')) else 1 / 16)
    fo = os.path.join(a.out, 'cover.jsonl'); done = {(tuple(d['key']), d['j']) for d in JS.read_jsonl(fo)}
    cells = [(k, c['LB']) for k, c in sorted(T.cells.items()) if c.get('LB') is not None and c['how'] != 'noncvx' and (k, 3) not in done]
    if a.sample:
        import random
        random.seed(1); cells = random.sample(cells, min(a.sample, len(cells)))
    if a.limit:
        cells = cells[:a.limit]
    print('table cells', len(T.cells), 'to cover', len(cells), flush=True)
    tot = {}; nP = 0
    with Pool(a.jobs) as pool, open(fo, 'a') as f:
        for n, recs in enumerate(pool.imap_unordered(cover_cell, [(list(k), LB, T.S0, a.wq, a.wt) for k, LB in cells], chunksize=4)):
            for rec in recs:
                f.write(json.dumps(rec) + '\n'); nP += len(rec['P'])
                for k, v in rec['n'].items():
                    tot[k] = tot.get(k, 0) + v
            if n % 200 == 0:
                f.flush(); print('cells %d/%d  leaves %s  P boxes %d  %.0fs' % (n + 1, len(cells), tot, nP, time.time() - t0), flush=True)
    JS.atomic_json(os.path.join(a.out, 'cover_info.json'), dict(table=a.table, wq=a.wq, wt=a.wt, cells=len(cells), leaves=tot, P=nP, sec=round(time.time() - t0, 1)))
    print('done', tot, 'P boxes', nP, '%.0fs' % (time.time() - t0), flush=True)


if __name__ == '__main__':
    main()
