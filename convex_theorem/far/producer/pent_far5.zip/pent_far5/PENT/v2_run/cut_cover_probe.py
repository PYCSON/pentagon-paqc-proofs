"""Cut-chart cover probe (Claude, 2026-11-12; FAR_SPEC section 9.7).  For sampled cells c of the quadrilateral table
(side S, FLOAT stand-in for the certified bound: LB = (1 - EPS) * min F at the 16 cell corners and the centre) and the
cut corners j = 3, 0, cover the unproven part {(t, u) in (0,1]^2 : t u >= theta}, theta = (1 - F*/LB) / sup tau_j,
by rectangles, each closed by a RIGOROUS test:
   T  t1 u1 < theta                      (table-proven, fact F1)
   X  cutchart.not_kept                  (another edge has a strictly smaller ear on the whole piece, fact F3)
   H  far_exclude.classify(x-box, rep=False) in (EXCLUDED, INVALID)      (cheap exclusion / no convex pentagon)
   N  far_pilot.near(x-box)              (some labelling is inside the near ball d < 3/5)
or, when its sides are <= RMIN, left as a P piece (to be certified by n = 5 PAQC on the x-box).
Output: per (cell, j) the counts, the (t, u)-area of each type, and for P pieces the x-box and a float diagnosis of the
centre (is the cut representation the smallest-ear one, d_sym, min turn).
Usage: python3 cut_cover_probe.py OUT [--S 0.0625] [--ncells 60] [--eps 0.05] [--rmin 0.125] [--jobs 2] [--seed 1]"""
import os, sys, json, time, argparse
from multiprocessing import Pool
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, '..', 'far')); sys.path.insert(0, os.path.join(HERE, '..', 'far', 'pilot'))
import numpy as np
import cutchart as CC
import far_design_probe as FD
FSTAR = 18.919134195733918
ARGS = None


def quad(q):
    return np.array([[0, 0], [1, 0], q[0:2], q[2:4]], float)


def cell_job(args):
    idx, S, eps, rmin = args
    import far_exclude as FE, far_pilot as FP, far_strata as FS
    t0 = time.time(); lo4 = [i * S for i in idx]; hi4 = [(i + 1) * S for i in idx]
    Fs = []
    for b in range(16):
        q = [hi4[i] if (b >> i) & 1 else lo4[i] for i in range(4)]; Q = quad(q)
        if FD.convex(Q):
            Fs.append(FD.F_float(Q))
    Fs.append(FD.F_float(quad([(a + b) / 2 for a, b in zip(lo4, hi4)])))
    Fs = [f for f in Fs if f]
    LB = max((1 - eps) * min(Fs), 2 * np.pi ** 2) if Fs else 2 * np.pi ** 2     # universal floor: Polya (convex quadrilaterals)
    out = dict(idx=list(idx), LB=LB, Fmin=min(Fs) if Fs else None, corners=len(Fs), j={})
    for j in (3, 0):
        ts = CC.tau_sup(lo4 + [0, 0], hi4 + [1, 1], j)
        if ts is None or ts <= 0:
            out['j'][j] = dict(theta=None, why='tau'); continue
        theta = (1 - FSTAR / LB) / ts
        st = dict(theta=theta, n={}, area={}, P=[])
        if theta < 1:
            stack = [(lo4 + [theta, theta], hi4 + [1.0, 1.0])]
            while stack:
                lo, hi = stack.pop(); typ = None
                th = theta
                if hi[0] - lo[0] < S * 0.99:                      # a sub-box of the table cell: its own sup tau
                    ts2 = CC.tau_sup(lo, hi, j)
                    if ts2:
                        th = max(theta, (1 - FSTAR / LB) / ts2)
                if hi[4] * hi[5] < th:
                    typ = 'T'
                elif CC.not_kept(lo, hi, j) is not None:
                    typ = 'X'
                else:
                    xb = CC.x_box(lo, hi, j)
                    if xb is not None:
                        lab, why = FE.classify([(xb[0][i], xb[1][i]) for i in range(6)], rep=False)
                        if lab in ('EXCLUDED', 'INVALID'):
                            typ = 'H'
                        elif FP.near(xb[0], xb[1]) is not None:
                            typ = 'N'
                    w = [hi[i] - lo[i] for i in range(6)]
                    if typ is None and max(w) <= rmin * 1.0001:
                        typ = 'P'
                        zc = [(a + b) / 2 for a, b in zip(lo, hi)]; V = np.array([[float(v[0]), float(v[1])] for v in CC.verts(zc, j)])
                        E = CC.ears(V); ear = [a * b / (2 * c) if c > 1e-12 else np.inf for c, a, b in E]
                        e = [V[(i + 1) % 5] - V[i] for i in range(5)]; mt = min(CC.crs(e[i], e[(i + 1) % 5]) for i in range(5))
                        xc = [(a + b) / 2 for a, b in zip(*xb)] if xb is not None else None
                        st['P'].append(dict(lo=lo, hi=hi, xbox=xb, kept=bool(int(np.argmin(ear)) == CC.CUT_EDGE[j]),
                                            gap=float(ear[CC.CUT_EDGE[j]] - min(ear)), minturn=float(mt),
                                            d=float(FS.dist_c(np.array([xc]))[0]) if xc is not None else None))
                vol = float(np.prod([hi[i] - lo[i] for i in range(6)]))
                if typ is None:
                    i = int(np.argmax([hi[i] - lo[i] for i in range(6)])); m = (lo[i] + hi[i]) / 2
                    h1 = list(hi); h1[i] = m; l2 = list(lo); l2[i] = m; stack += [(lo, h1), (l2, hi)]
                else:
                    st['n'][typ] = st['n'].get(typ, 0) + 1; st['area'][typ] = st['area'].get(typ, 0) + vol
        out['j'][j] = st
    out['sec'] = round(time.time() - t0, 1)
    return out


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('out'); ap.add_argument('--S', type=float, default=1 / 16)
    ap.add_argument('--ncells', type=int, default=60); ap.add_argument('--eps', type=float, default=0.05)
    ap.add_argument('--rmin', type=float, default=0.125); ap.add_argument('--jobs', type=int, default=2); ap.add_argument('--seed', type=int, default=1)
    a = ap.parse_args(); os.makedirs(a.out, exist_ok=True); rng = np.random.default_rng(a.seed); cells = []
    while len(cells) < a.ncells:                      # volume-uniform cells of the region 'convex, base = longest edge'
        q = np.array([rng.uniform(0, 2), rng.uniform(0, 1), rng.uniform(-1, 1), rng.uniform(0, 1)]); Q = quad(q)
        if FD.convex(Q) and all(np.linalg.norm(Q[(i + 1) % 4] - Q[i]) <= 1 for i in range(1, 4)):
            idx = tuple(int(np.floor(v / a.S)) for v in q)
            if idx not in cells:
                cells.append(idx)
    with Pool(a.jobs) as pool, open(os.path.join(a.out, 'cover.jsonl'), 'w') as f:
        for r in pool.imap_unordered(cell_job, [(c, a.S, a.eps, a.rmin) for c in cells]):
            f.write(json.dumps(r) + '\n'); f.flush()
            print(r['idx'], 'LB %.2f' % r['LB'], {j: (round(s['theta'], 3) if s.get('theta') else None, s.get('n')) for j, s in r['j'].items()}, r['sec'], flush=True)


if __name__ == '__main__':
    main()
