"""Far region in the cut chart: adaptive cover + n = 5 PAQC / T1 (Claude, 2026-11-12; FAR_SPEC sections 9.7-9.8).  DRAFT.
For every cell c of the quadrilateral table (t4table) and cut corner j in (3, 0), the set c x [0,1]^2 of cut-chart points
(q, t, u) is covered by the leaves of ONE bisection tree of dyadic boxes.  Leaf labels:
   T  t_hi u_hi sup tau_j < 1 - F*_up / LB_c         fact F1: F(P) >= F(Q) (1 - t u tau)
   X  cutchart.not_kept                               another representation (smaller ear) covers these pentagons
   H  far_exclude.classify(x-box) EXCLUDED / INVALID  cheap exclusions
   S  strip bound: pi^2 inf|P| / sup width^2 > F*_up  elongated pentagons (strip_label)
   N  near_cut                                        d < 3/5: near region (corner form in the cut chart)
   C  certified by n = 5 PAQC in the cut chart: 64 corner certificates (cutcell.certify_corner) + T1 (t1_tv)
   V  no convex quadrilateral in the q-box (t4table.noncvx)
   U  unresolved at the minimal size (reported; must be empty in a complete run)
The T test of a box uses the best available lower bound of F on the convex quadrilaterals of ITS q-box: the table
bound of the cell or the closed-form bounds u3 / hp evaluated on the q-box (near a flat vertex of Q the triangle
bound u3 tends to 22.79, so T and X overlap there and the convexity boundary D = 0 needs no fine boxes).
Per round: (1) cheap phase, parallel over trees: close what T / X / H / N close; an open box is either split (too large
for an attempt, or its centre lies in a cheap region) or queued for an attempt; (2) all missing corner certificates of
the queued boxes, parallel, shared store (key = cut-chart grid point); (3) T1 per queued box; a failed box is bisected
along the coordinate with the largest relative variation of the sector maps and goes back to (1).
An attempt is made when the box passes the convexity gate, the sharp constant at its centre e0 (geometry only) is
<= --ecap, and the box is not larger than --maxq / --maxt.
Output: OUT/leaves.jsonl (every C leaf with its T1 certificate summary; closed cheap leaves are counted, not listed --
a checker recomputes the tree), OUT/corners.jsonl, OUT/rounds.jsonl, OUT/summary.json.
Usage: python3 cut_run.py TABLE_DIR OUT [--sample N] [--seed 1] [--jobs 2] [--ecap 0.1] [--max-boxes 3000] [--save-leaves]"""
import os, sys, json, time, argparse, random
from multiprocessing import Pool
HERE = os.path.dirname(os.path.abspath(__file__))
for p in ('.', '../far', '../far/pilot', '../scripts', '../v2_cover'):
    sys.path.insert(0, os.path.join(HERE, p))
import numpy as np
from flint import arb
import rig_paqc as R
import cutchart as CC
import t4table as T4
import jsonl_safe as JS
import qchart as QC

TRACE = None           # debugging: a list here collects (reason, lo, hi, e0, float margin at the centre) of every split of an open box
CHART = 'std'          # chart of the boxes (cutchart.to_std); set per process from cfg['chart']

MINW = [1 / 256] * 4 + [1 / 128] * 2           # minimal box widths (q, then t and u)
SMALLW = [1 / 64] * 4 + [1 / 32] * 2           # at or below this size an attempt is made even if the centre is in a cheap region
CFG = dict(efrac=0.7, efree=0.05, eigm=0.11, fthin=35.0, cheapfrac=1.25, ecap=0.1, maxq=1 / 16, maxt=1 / 4, max_boxes=3000, datt=0.4, chart='std', H2=1 / 8, H3=1 / 8)   # datt: no attempt on a large box whose centre has d < datt (split until N closes it)


def x_box(lo, hi, j):
    import cut_cover as CV
    return CV.x_box(lo, hi, j)


_VC = [None, None]


def _corner_verts(lo, hi, j):
    """the 64 corner pentagons of the box as exact binary64 vertex lists (cutcell.exact_verts); the last box is cached"""
    import cutcell as CE
    k = (tuple(lo), tuple(hi), j, CHART)
    if _VC[0] != k:
        _VC[0] = k; _VC[1] = [CE.exact_verts(z, j, CHART) for z in CE.corner_zs(lo, hi)]
    return _VC[1]


FAN_N = int(os.environ.get('PENT_FAN_N', '5'))
NO_H = os.environ.get('PENT_NO_H', '0') == '1'             # far5: the label H (old pentagon-chart tests, far_exclude) is not used at all
STRIP_PRE = float(os.environ.get('PENT_STRIP_PRE', '1.0'))


def fan_point(V):
    """lower bound of F of one pentagon from the fan certificate (lgfan.py); None if there is none.  Used for decisions only."""
    if not FAN_N:
        return None
    try:
        import lgfan
        r = lgfan.F_lower([(float(a), float(b)) for a, b in V], FAN_N)
        return None if r is None else r['F_lo']
    except Exception:
        return None


def cheap_point(V):
    """float: the pointwise values of the cheap bounds S(a), S(b), R for the pentagon V (5 x 2 array), divided by F*.
    Heuristic only: a box whose centre has a large value is left to the cheap bounds (bisected until one closes it)
    instead of being queued for PAQC."""
    def cr(u, v):
        return u[0] * v[1] - u[1] * v[0]
    V = np.array(V, float); e = np.roll(V, -1, 0) - V; A = 0.5 * abs(sum(cr(V[i], V[(i + 1) % 5]) for i in range(5)))
    L = np.hypot(e[:, 0], e[:, 1])
    if A <= 0 or L.min() <= 1e-12:
        return 0.0
    Sa = max(np.pi ** 2 * A / np.ptp(V @ (np.array([-e[i][1], e[i][0]]) / L[i])) ** 2 for i in range(5))
    Sb = max(np.pi ** 2 * L[a] ** 2 / (2 * max(max(cr(e[a], V[k] - V[a]) for k in range(5)), 1e-300)) for a in range(5))
    Rb = 0.0
    for m in range(5):
        ears = 0.0
        for k in (m, (m + 2) % 5):
            C = cr(e[k - 1], e[(k + 1) % 5]); ears += cr(e[k - 1], e[k]) * cr(e[k], e[(k + 1) % 5]) / (2 * C) if C > 1e-12 else np.inf
        Rb = max(Rb, float(QC.TRI_MIN.mid()) / (1 + ears / A))
    import fibre as FB
    Ob = FB.best_direction([(float(a), float(b)) for a, b in V])[0] * A * 0.99          # fibre bound (float estimate)
    return max(Sa, Sb, Rb, Ob) / float(R.FSTAR_UP)


def displacement(lo, hi, j):
    """float: for each coordinate the largest vertex displacement across the box (corner pairs that differ in that
    coordinate only).  Split heuristic for boxes that must be closed by the cheap bounds S / R (their looseness on a box
    comes from the vertex movement), not by PAQC."""
    Vc = np.array(_corner_verts(lo, hi, j), float); out = []
    for i in range(6):
        bit = 1 << (5 - i); idx = [c for c in range(64) if not c & bit]
        out.append(float(np.hypot(*(Vc[idx] - Vc[[c | bit for c in idx]]).reshape(-1, 2).T).max()))
    return out


def _centre_d2(lo, hi, j):
    """float: squared chart distances of the 10 labellings of the centre pentagon to the regular pentagon"""
    import plan_cells as PC
    zc = [(lo[i] + hi[i]) / 2 for i in range(6)]; V = [complex(a, b) for a, b in CC.verts(CC.to_std(zc, CHART), j)]; out = []
    for idx, rev in PC.IDX:
        w = [V[i] for i in idx]; den = w[1] - w[0]
        if den == 0:
            out.append(float('inf')); continue
        s = 0.0
        for p in (2, 3, 4):
            u = (w[p] - w[0]) / den
            if rev:
                u = u.conjugate()
            s += abs(u - complex(PC.C[2 * (p - 2)], PC.C[2 * (p - 2) + 1])) ** 2
        out.append(s)
    return V, out


def near_cut(lo, hi, j):
    """Rigorous near test in the cut chart (2026-11-12).  Returns a labelling h such that every pentagon P(z), z in
    the box, has |phi_h(x(P)) - c|^2 < 9/25 (so d(P) < 3/5: near region), or None.
    The chart image of labelling h = (idx, rev) is u_p = (W_p - W_0) / (W_1 - W_0), W = V[idx], conjugated if rev
    (plan_cells.orbit_np); it is similarity invariant, so it can be computed from the cut-chart vertices directly.
    N_p(z) = W_p - W_0 and D(z) = W_1 - W_0 are multi-affine (complex) in z.  For a constant r0,
        u_p(z) - r0 = (N_p(z) - r0 D(z)) / D(z);
    N_p - r0 D is multi-affine, so on the box it lies in the convex hull of its 64 corner values and its modulus is
    <= the largest corner modulus; D(z) lies in the hull of its corner values, so |D(z)| >= min_c Re(D_c conj(e)) for any
    unit vector e.  Hence |u_p(z) - r0| <= rho_p := max_c |N_p,c - r0 D_c| / min_c Re(D_c conj(e))  (needs the min > 0),
    and |phi_h(x) - c|^2 <= sum_p (|r0_p - c_p| + rho_p)^2.  Box endpoints dyadic: corner vertices are exact."""
    import cutcell as CE, plan_cells as PC
    V, d2 = _centre_d2(lo, hi, j)
    cand = [h for h in range(10) if d2[h] < 0.36]
    if not cand:
        return None
    Vc = _corner_verts(lo, hi, j) if any(hi[i] > lo[i] for i in range(6)) else [[(v.real, v.imag) for v in V]]
    for h in sorted(cand, key=lambda h: d2[h]):
        idx, rev = PC.IDX[h]; a, b = idx[0], idx[1]
        Dm = V[b] - V[a]; e = Dm / abs(Dm)
        Dc = [(arb(W[b][0]) - arb(W[a][0]), arb(W[b][1]) - arb(W[a][1])) for W in Vc]
        dmin = None
        for dr, di in Dc:
            pr = dr * arb(e.real) + di * arb(e.imag)
            dmin = pr if dmin is None else arb(min(dmin.lower(), pr.lower()))
        dmin = dmin / (arb(e.real) * arb(e.real) + arb(e.imag) * arb(e.imag)).sqrt()          # e is a unit vector only up to rounding
        if not (dmin > 0):
            continue
        tot = arb(0)
        for p in (2, 3, 4):
            m = idx[p]; r0 = (V[m] - V[a]) / Dm; mx = arb(0)
            for W, (dr, di) in zip(Vc, Dc):
                nr = arb(W[m][0]) - arb(W[a][0]) - (arb(r0.real) * dr - arb(r0.imag) * di)
                ni = arb(W[m][1]) - arb(W[a][1]) - (arb(r0.real) * di + arb(r0.imag) * dr)
                mx = arb(max(mx.upper(), (nr * nr + ni * ni).upper()))
            rho = mx.sqrt() / dmin
            cr = float(PC.C[2 * (p - 2)]); ci = float(PC.C[2 * (p - 2) + 1]) * (-1.0 if rev else 1.0)      # |conj(u) - c| = |u - conj(c)|
            dist = ((arb(r0.real) - arb(cr)) ** 2 + (arb(r0.imag) - arb(ci)) ** 2).sqrt() + rho
            tot += dist * dist
        if tot < arb(9) / arb(25):
            return h
    return None


_DIRS = [(arb(np.cos(k * np.pi / 12)), arb(np.sin(k * np.pi / 12))) for k in range(12)]     # any vectors n; |n| is divided out


def strip_label(lo, hi, j):
    """S: elongated pentagons.  A domain inside a strip of width W has lambda_1 >= pi^2 / W^2 (domain monotonicity and
    the one-dimensional Dirichlet inequality on every cross-section), so F(P) >= pi^2 |P| / W(P)^2.
      (a) any direction n: F(P(z)) >= pi^2 min_c |P(z_c)| / W_n(z_c)^2 over the 64 corners c (see the code: the
          vertex projections and the area are multi-affine in z, and |P| - tau (p_i - p_k)^2 is concave in each coordinate);
      (b) an edge (V_a, V_b) of P of length l (2026-11-15): the convex P lies on one side of the line of the edge, within
          distance H = max_k dist(V_k, line), and contains the triangle over the edge with apex at a farthest vertex, so
          |P| >= l H / 2 and F(P) >= pi^2 l / (2 H) = pi^2 l^2 / (2 max_k c_k),  c_k = (V_b - V_a) x (V_k - V_a) >= 0.
          Box: c_k is a cross product of vertex differences, multi-affine in z, so max_k c_k <= max_{c,k} c_k(z_c);
          the components of V_b - V_a are multi-affine, so l^2 >= (min |dx|)^2 + (min |dy|)^2 from their exact ranges.
          No area bound is needed, so (b) also works on boxes that touch collapsing quadrilaterals.
    Returns True if (a) holds for one of 12 directions or (b) holds.  Statements about the convex members of the box."""
    import cutcell as CE
    Vc = [[(arb(a), arb(b)) for a, b in V] for V in _corner_verts(lo, hi, j)]
    for a in range(5):                                             # (b) for every edge (V_a, V_b) of P
        b = (a + 1) % 5
        dx = [V[b][0] - V[a][0] for V in Vc]; dy = [V[b][1] - V[a][1] for V in Vc]
        l2 = arb(0)
        for d in (dx, dy):                                         # exact ranges of the multi-affine components
            dl = min(v.lower() for v in d); du = max(v.upper() for v in d)
            if dl > 0 or du < 0:
                m = arb(min(abs(dl), abs(du))); l2 += m * m
        cmax = max(((V[b][0] - V[a][0]) * (V[k][1] - V[a][1]) - (V[b][1] - V[a][1]) * (V[k][0] - V[a][0])).upper() for V in Vc for k in range(5))
        if cmax > 0 and l2 > 0 and arb.pi() ** 2 * l2 / (2 * arb(cmax)) > R.FSTAR_UP:
            return True
    Amin = None
    for V in Vc:
        A = sum(V[i][0] * V[(i + 1) % 5][1] - V[(i + 1) % 5][0] * V[i][1] for i in range(5)) / 2
        Amin = A if Amin is None else arb(min(Amin.lower(), A.lower()))
    if not (Amin > 0):
        return False
    # directions: the edge normals of the centre pentagon (the minimal width of a convex polygon is attained
    # perpendicular to one of its edges; for elongated shapes a fixed 15-degree fan misses it and loses a factor 2),
    # then 12 fixed ones.  Any direction is valid; the choice is a float heuristic.
    Vm = CC.verts(CC.to_std([(lo[i] + hi[i]) / 2 for i in range(6)], CHART), j)
    dirs = []
    for i in range(5):
        ex = float(Vm[(i + 1) % 5][0]) - float(Vm[i][0]); ey = float(Vm[(i + 1) % 5][1]) - float(Vm[i][1])
        if ex * ex + ey * ey > 1e-12:
            dirs.append((arb(-ey), arb(ex)))
    Ac = []
    for V in Vc:
        Ac.append(sum(V[i][0] * V[(i + 1) % 5][1] - V[(i + 1) % 5][0] * V[i][1] for i in range(5)) / 2)
    for nx, ny in dirs + _DIRS:
        # exact box form (2026-11-15): for vertices i, k the function |P(z)| - tau (p_i(z) - p_k(z))^2, p = <V, n>, is
        # concave in each coordinate separately (|P| and p_i - p_k are multi-affine), so its minimum over the box is
        # attained at a corner.  With tau = min_c |P(z_c)| / W_n(z_c)^2 it is >= 0 at every corner for every pair, hence
        # |P(z)| >= tau W_n(z)^2 on the whole box:   F >= pi^2 min_c |P(z_c)| / W_n(z_c)^2.
        tau = None; n2 = nx * nx + ny * ny
        for V, A in zip(Vc, Ac):
            pr = [V[i][0] * nx + V[i][1] * ny for i in range(5)]
            W = arb(max(p.upper() for p in pr)) - arb(min(p.lower() for p in pr))
            if not (W > 0):
                tau = None; break
            t = A * n2 / (W * W)
            tau = t if tau is None else arb(min(tau.lower(), t.lower()))
        if tau is not None and arb.pi() ** 2 * tau > R.FSTAR_UP:
            return True
    return False


def tri_label(lo, hi, j):
    """R: pentagons close to a triangle (2026-11-15).  e_i = V_{i+1} - V_i.  For an edge m with C_m = e_{m-1} x e_{m+1} > 0
    the lines of the edges m-1 and m+1 meet beyond the edge m and cut off the ear of area A_m B_m / (2 C_m),
    A_m = e_{m-1} x e_m, B_m = e_m x e_{m+1}.  For two non-adjacent edges m, m+2 with C_m, C_{m+2} > 0 the lines of the
    other three edges bound a triangle T containing P (P is the intersection of its five half-planes), with
    |T| = |P| + ear_m + ear_{m+2}.  Then lambda_1(P) >= lambda_1(T) and F(P) >= (4 pi^2 / sqrt 3) |P| / |T|
    (Polya: the equilateral triangle minimises F among triangles).
    Box: A_m, B_m, C_m and |P| are cross products of vertex differences, multi-affine in the chart coordinates, so
    their exact ranges are attained at the 64 corners; the bound is monotone in each.  Convex members only."""
    import cutcell as CE
    Vc = [[(arb(a), arb(b)) for a, b in V] for V in _corner_verts(lo, hi, j)]
    Amin = None; rng = [[float('inf'), -float('inf')] for _ in range(15)]
    for V in Vc:
        e = [(V[(i + 1) % 5][0] - V[i][0], V[(i + 1) % 5][1] - V[i][1]) for i in range(5)]
        A = sum(V[i][0] * V[(i + 1) % 5][1] - V[(i + 1) % 5][0] * V[i][1] for i in range(5)) / 2
        Amin = A if Amin is None else arb(min(Amin.lower(), A.lower()))
        for m in range(5):
            for t, (u, v) in enumerate(((e[m - 1], e[m]), (e[m], e[(m + 1) % 5]), (e[m - 1], e[(m + 1) % 5]))):
                c = u[0] * v[1] - u[1] * v[0]; r = rng[3 * m + t]
                r[0] = min(r[0], float(c.lower())); r[1] = max(r[1], float(c.upper()))
    if not (Amin > 0):
        return False
    ear = []
    for m in range(5):
        Ah, Bh, Cl = max(rng[3 * m][1], 0.0), max(rng[3 * m + 1][1], 0.0), rng[3 * m + 2][0]
        ear.append(arb(Ah) * arb(Bh) / (2 * arb(Cl)) if Cl > 0 else None)
    for m in range(5):
        m2 = (m + 2) % 5
        if ear[m] is not None and ear[m2] is not None and QC.TRI_MIN / (1 + (ear[m] + ear[m2]) / Amin) > R.FSTAR_UP:
            return True
    return False


def quick_F(V):
    """float estimate of F for the attempt decision (heuristic only; about 1e-4 accurate, 26 evaluations of sigma instead
    of the 70 of far_design_probe.F_float): grid on F in [12.5, 37.5], then the intersection of the two branches of the
    V-shaped sigma.  A value near 37.5 means 'at or above the window' (callers compare with fthin = 35)."""
    from mps import PolyMPS, poly_area
    V = np.array(V, float); A = abs(poly_area(V))
    if A < 1e-6:
        return None
    try:
        m = PolyMPS(V, K=6); grid = np.linspace(12.5 / A, 37.5 / A, 21); vals = [m.sigma(g) for g in grid]; i = int(np.argmin(vals))
        ia, ib = max(i - 1, 0), min(i + 1, 20); a, b = grid[ia], grid[ib]; fa, fb = vals[ia], vals[ib]
        for _ in range(5):
            if not (fa + fb > 0):
                break
            c = (a * fb + b * fa) / (fa + fb); c = min(max(c, a + 1e-3 * (b - a)), b - 1e-3 * (b - a)); fc = m.sigma(c)
            if (fa - fc) * (b - c) > (fb - fc) * (c - a):
                a, fa = c, fc
            else:
                b, fb = c, fc
        lam = (a * fb + b * fa) / (fa + fb) if fa + fb > 0 else 0.5 * (a + b)
        return float(lam * A) if np.isfinite(lam) else None
    except Exception:
        return None


def fibre_label(lo, hi, j):
    """O: fibre bound (fibre.py, Lemma OD) on the convex hull H of the 320 vertices of the 64 corner pentagons
    (2026-11-15).  The vertices of P(z) are multi-affine in z, hence convex combinations of the corner values, so
    P(z) lies in H for every z of the box and lambda_1(P(z)) >= lambda_1(H); the area |P(z)| is multi-affine, its
    minimum is attained at a corner.  O holds if (fibre bound of lambda_1(H)) * min_c |P(z_c)| > F*_up.
    The direction is a float choice from the centre pentagon.  Statement about the convex members of the box."""
    import fibre as FB
    Vc = _corner_verts(lo, hi, j); Amin = None
    for V in Vc:
        A = sum(arb(V[i][0]) * arb(V[(i + 1) % 5][1]) - arb(V[(i + 1) % 5][0]) * arb(V[i][1]) for i in range(5)) / 2
        Amin = A if Amin is None else arb(min(Amin.lower(), A.lower()))
    if not (Amin > 0):
        return False
    Vm = [(float(a), float(b)) for a, b in CC.verts(CC.to_std([(lo[i] + hi[i]) / 2 for i in range(6)], CHART), j)]
    est, d = FB.best_direction(Vm)
    Am = 0.5 * abs(sum(Vm[i][0] * Vm[(i + 1) % 5][1] - Vm[(i + 1) % 5][0] * Vm[i][1] for i in range(5)))
    if d is None or est * Am < 1.02 * float(R.FSTAR_UP):           # float: hopeless even at the centre
        return False
    H = FB.hull([p for V in Vc for p in V])
    if len(H) < 3:
        return False
    P = [(arb(a), arb(b)) for a, b in H]
    sp = FB.step_potential(P, d, 128)
    if sp is None:
        return False
    D2 = arb(float(d[0])) ** 2 + arb(float(d[1])) ** 2
    m = FB._up(R.FSTAR_UP * (1 + arb(2) ** -30) / (Amin * D2))      # lambda_1 >= D^2 m  =>  F >= D^2 m Amin > F*_up
    if FB.float_mu(*sp) * 0.9985 < m:
        return False
    return FB.verify(sp[0], sp[1], m)


def cheap_label(lo, hi, j, th, gx=float('inf')):
    """T / X / S / N / H or None for the closed box [lo, hi]; th = theta_T and gx = X threshold of its w-box (qchart)"""
    import far_exclude as FE, far_pilot as FP
    if hi[4] * hi[5] < th:
        return 'T'
    if lo[4] * lo[5] > gx or QC.stub_not_kept(lo, hi, j, CHART) is not None:
        return 'X'
    # 2026-11-16: S and R are box versions of pointwise bounds; they are tried only if the float pointwise bounds at the
    # centre reach STRIP_PRE F* (a heuristic filter: skipping a label is always sound; 0.0 = degenerate centre, no filter)
    cp = cheap_point(CC.verts(CC.to_std([(lo[i] + hi[i]) / 2 for i in range(6)], CHART), j))
    if cp == 0.0 or cp >= STRIP_PRE:
        if strip_label(lo, hi, j):
            return 'S'
        if tri_label(lo, hi, j):
            return 'R'
    if CHART == 'E3' and lo[1] == 0.0 and lo[3] == 0.0 and QC.face_not_kept(lo, hi, j):
        return 'X'                                                  # corner face q2y = 0 = h: homogeneous form of X
    if fibre_label(lo, hi, j):
        return 'O'
    if near_cut(lo, hi, j) is not None:
        return 'N'
    xb = x_box(lo, hi, j) if CHART == 'std' and not NO_H else None
    if xb is not None:
        lab, why = FE.classify([(xb[0][i], xb[1][i]) for i in range(6)], rep=False)
        if lab in ('EXCLUDED', 'INVALID'):
            return 'H'
    return None


def geometry(lo, hi, j):
    """float pre-test of a box: None if some corner pentagon is not strictly convex, else t1_tv.geometry_probe"""
    import cutcell as CE, rig_t1_v2 as T, t1_tv as TV
    try:
        Vs = [[[arb(a), arb(b)] for a, b in V] for V in _corner_verts(lo, hi, j)]
        cd = T.CellData(None, None, [arb(20)] * 64, emode='exact', corner_verts=Vs)
    except (AssertionError, ZeroDivisionError, ValueError):
        return None
    return TV.geometry_probe(cd)


def theta_of(lo, hi, j, one_minus):
    if one_minus is None:
        return 0.0
    ts = CC.tau_sup(lo, hi, j)
    if ts is None:
        return 0.0
    return max(0.0, min(1.0, R.f_down(one_minus / arb(ts)))) if ts > 0 else 1.0


def tree_job(args):
    """cheap phase for the boxes of one (table cell, j).  Returns (key, j, stats, attempts, unresolved)."""
    global CHART
    key, j, LB, boxes, cfg = args; CHART = cfg.get('chart', 'std')
    n = {}; vol = {}; attempts = []; unres = []; stack = list(boxes); qcache = {}
    leaves = [] if cfg.get('leaves') else None             # production: every closed leaf [lo, hi, label]

    def local(lo, hi):
        """data of the w-box (cached): no convex member, all convex, defer label (std chart), theta_T, X threshold.
        LB = max(table bound of the cell (std chart), closed-form bounds of the w-box): all hold for its convex members"""
        k4 = (tuple(lo[:4]), tuple(hi[:4]))
        if k4 not in qcache:
            inv = QC.invariants(list(lo[:4]), list(hi[:4]), CHART); nc = QC.noncvx(inv); lb = QC.quad_lb(inv)[0]; df = None
            if not nc and LB and LB != float('inf'):
                lb = max(lb, LB)                                   # bound of the root cell (table): valid on every sub-box
            if not nc and cfg.get('qfibre', True):
                lb = max(lb, QC.quad_fibre(list(lo[:4]), list(hi[:4]), CHART, inv))       # fibre bound of the quadrilaterals
            if CHART == 'std' and not nc:
                lb = max([lb] + list(T4.fallback_bounds(list(lo[:4]), list(hi[:4])).values()))
                df = QC.defer(inv, list(lo[:4]), list(hi[:4]), cfg['H2'], cfg['H3'])
            qcache[k4] = (nc, QC.all_convex(inv), df, QC.theta_T(inv, j, lb), QC.x_threshold(inv, j), inv)
        return qcache[k4]
    nodes_done = 0
    while stack:
        if cfg.get('deadline') and time.time() > cfg['deadline']:  # production time budget: the rest stays open (far_block)
            cfg['left'].extend(stack); break
        lo, hi = stack.pop(); nodes_done += 1
        if nodes_done > cfg.get('node_cap', 10 ** 9):              # survey safety: report the rest of this tree as CAP
            for lo, hi in [(lo, hi)] + stack:
                n['CAP'] = n.get('CAP', 0) + 1; vol['CAP'] = vol.get('CAP', 0) + float(np.prod([hi[i] - lo[i] for i in range(6)]))
            break
        nc, allc, df, th, gx, inv = local(lo, hi)
        full = lo[4] == 0.0 and lo[5] == 0.0 and hi[4] == 1.0 and hi[5] == 1.0
        if nc:
            lab = 'V'
        elif df is not None:
            lab = df                                               # this q-box is covered in the edge chart E2 / E3
        elif full and th > gx:
            lab = 'TX'                                             # column test: T below theta_T, not kept above
        else:
            lab = cheap_label(lo, hi, j, th, gx)
        if lab is None and full and not allc:
            # the w-box contains non-convex quadrilaterals: no PAQC possible; refine w (not t, u) until TX / V / E closes it
            relq = [(hi[i] - lo[i]) / MINW[i] for i in range(4)]
            if max(relq) > 1.0001:
                hfirst = CHART != 'std' and relq[3] > 1.0001 and inv['K' if CHART == 'E2' else 'D'][0] <= 0
                i = 3 if hfirst else int(np.argmax(relq)); m = (lo[i] + hi[i]) / 2
                h1 = list(hi); h1[i] = m; l2 = list(lo); l2[i] = m; stack += [(lo, h1), (l2, hi)]
                continue
        w = [hi[i] - lo[i] for i in range(6)]
        if lab is None:
            rel = [w[i] / MINW[i] for i in range(6)]
            small = all(w[i] <= SMALLW[i] * 1.0001 for i in range(6))
            fits = all(w[i] <= cfg['maxq'] * 1.0001 for i in range(4)) and all(w[i] <= cfg['maxt'] * 1.0001 for i in (4, 5))
            g = geometry(lo, hi, j) if fits else None
            ok = False; mc = None
            why = 'nofit' if not fits else ('gate' if g is None else ('notok' if not g['ok'] else 'e0'))
            if g is not None and g['ok'] and g['e0'] <= cfg['efree']:
                ok = True                                          # small sharp constant: attempt at once
            elif g is not None and g['ok'] and g['e0'] <= 0.4:
                # attempt only if the margin at the centre is larger than the sharp constant e0 (float heuristic).
                # Margin = what the corner values will give: the cheap closed-form bounds (cutcell.cheap_lower, no
                # eigenvalue needed, any F), or the eigenvalue certificate (only for F below the index limit 36.3).
                zc = [(lo[i] + hi[i]) / 2 for i in range(6)]; Vc0 = CC.verts(CC.to_std(zc, CHART), j)
                mc = cheap_point(Vc0) - 1
                # 2026-11-16: the fan certificate (lgfan.py, 2 ms, within 1e-3 of F) gives the margin at the centre almost
                # exactly; the closed forms and the float eigenvalue below remain for pentagons without one (F > 34)
                Ff = fan_point(Vc0)
                if Ff is not None:
                    mc = max(mc, Ff / float(R.FSTAR_UP) - 1)
                # the float eigenvalue (0.3 s) only where eigenvalue certificates would be computed at all: closed-form
                # margin at the centre below eigm (far_block computes them for corners below CHEAP_OK = 1.08 F*)
                # ... and only if the box could pass with the true value: the closed-form bound is at least 0.8 F on
                # every pentagon seen so far, so the true margin is at most mmax (2026-11-16: the float eigenvalue was
                # 60 % of the cheap phase in low-margin roots, mostly on boxes far too large to pass)
                mmax = (1 + mc) / 0.8 - 1
                if Ff is None and (mc <= 0 or g['e0'] > cfg['efrac'] * mc / (1 + mc)) and mc < cfg.get('eigm', 0.11) and mmax > 0 and g['e0'] <= cfg['efrac'] * mmax / (1 + mmax):
                    import far_design_probe as FD
                    Fc = quick_F(np.array(Vc0, float))
                    if Fc is not None and Fc < cfg['fthin']:
                        mc = max(mc, Fc / float(R.FSTAR_UP) - 1)
                ok = mc > 0 and g['e0'] <= cfg['efrac'] * mc / (1 + mc)       # (1 - e0)(1 + m) > 1 is what T1 needs (far_block RHO)
            if ok and not small:                                   # centre in the NEAR region (margin -> 0 there): split first.
                if min(_centre_d2(lo, hi, j)[1]) < cfg['datt'] ** 2:            # T / X / H regions are NOT avoided: their pentagons are
                    ok = False; why = 'centreN'                    # ordinary pentagons with F > F*, PAQC certifies them too,
                                                                   # and chasing those boundaries costs far more boxes
            if ok:
                attempts.append([lo, hi, g['w'], g['e0']]); continue
            if TRACE is not None:
                TRACE.append((why, lo, hi, None if g is None else g['e0'], mc))
            if max(rel) <= 1.0001:
                lab = 'U'; unres.append([lo, hi])
            else:
                sc = [(g['w'][i] if g is not None and g['ok'] and np.isfinite(g['w'][i]) else rel[i] * 1e-6) * (rel[i] > 1.0001) for i in range(6)]
                if g is None or not g['ok']:
                    sc = [rel[i] * (rel[i] > 1.0001) for i in range(6)]
                    # 2026-11-15: all quadrilaterals of the w-box are convex, so a failed gate comes from a degenerate
                    # corner pentagon on a face t, u = 0 or 1: split only that coordinate (splitting w as well multiplied
                    # the number of attempt boxes by up to 16)
                    edge = [i for i in (4, 5) if (lo[i] == 0.0 or hi[i] == 1.0) and rel[i] > 1.0001]
                    if allc and fits and edge:
                        sc = [w[i] if i in edge else 0.0 for i in range(6)]
                i = int(np.argmax(sc)); m = (lo[i] + hi[i]) / 2
                h1 = list(hi); h1[i] = m; l2 = list(lo); l2[i] = m; stack += [(lo, h1), (l2, hi)]
                continue
        n[lab] = n.get(lab, 0) + 1; vol[lab] = vol.get(lab, 0) + float(np.prod(w))
        if leaves is not None:
            leaves.append([lo, hi, lab])
    if leaves is not None:
        return key, j, n, vol, attempts, unres, leaves
    return key, j, n, vol, attempts, unres


def split_box(lo, hi, w):
    """bisection of a box whose PAQC attempt failed: along the coordinate with the largest relative variation of the
    sector maps (w from t1_tv.geometry_probe), among the coordinates above the minimal width.  None at the minimal size."""
    rel = [(hi[i] - lo[i]) / MINW[i] for i in range(6)]
    if max(rel) <= 1.0001:
        return None
    sc = [(w[i] if np.isfinite(w[i]) else 0.0) * (rel[i] > 1.0001) for i in range(6)]
    if max(sc) <= 0:
        sc = [rel[i] * (rel[i] > 1.0001) for i in range(6)]
    i = int(np.argmax(sc)); m = (lo[i] + hi[i]) / 2
    h1 = list(hi); h1[i] = m; l2 = list(lo); l2[i] = m
    return [(list(lo), h1), (l2, list(hi))]


def corner_job(args):
    import cutcell as CE
    k, z, j, chart = args
    c = CE.certify_corner(z, j, chart)
    return k, (None if c is None else c)


def t1_job(args):
    import cutcell as CE, rig_t1_v2 as T, t1_tv as TV
    global CHART
    key, j, lo, hi, Fl, max_boxes, save, CHART = args
    t0 = time.time()
    try:
        Vs = [[[arb(a), arb(b)] for a, b in CE.exact_verts(z, j, CHART)] for z in CE.corner_zs(lo, hi)]
        cd = T.CellData(None, None, [arb(f) for f in Fl], emode='exact', corner_verts=Vs)
        t = TV.certify_T1(cd, R.FSTAR_UP, max_boxes=max_boxes, min_rad=1e-3, fail_point=True)
    except (AssertionError, ZeroDivisionError, ValueError) as ex:
        return key, j, lo, hi, dict(status='exception', why=repr(ex)[:100], boxes=0, sec=round(time.time() - t0, 2))
    out = dict(status=t['status'], boxes=t['boxes'], sec=round(time.time() - t0, 2), Fmin=min(Fl))
    if t['status'] == 'certified':
        out['min_lower'] = t['min_lower']; out['nleaves'] = len(t['leaves'])
        if save:
            out['leaves'] = t['leaves']
    return key, j, lo, hi, out


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('table'); ap.add_argument('out'); ap.add_argument('--sample', type=int, default=0)
    ap.add_argument('--seed', type=int, default=1); ap.add_argument('--jobs', type=int, default=2); ap.add_argument('--ecap', type=float, default=CFG['ecap'])
    ap.add_argument('--max-boxes', type=int, default=CFG['max_boxes']); ap.add_argument('--save-leaves', action='store_true')
    ap.add_argument('--datt', type=float, default=CFG['datt']); ap.add_argument('--how', default='', help='only table cells whose bound is of this kind (survey)')
    ap.add_argument('--node-cap', type=int, default=10 ** 9, help='survey: stop a tree after this many nodes (rest reported as CAP)')
    ap.add_argument('--cheap-only', action='store_true', help='survey: stop after the first cheap phase')
    ap.add_argument('--qtable', default='', help='directory of qtable.py for this chart (root bounds of F on quadrilaterals)')
    ap.add_argument('--chart', default='std', choices=('std', 'E2', 'E3')); ap.add_argument('--H2', type=float, default=CFG['H2']); ap.add_argument('--H3', type=float, default=CFG['H3'])
    ap.add_argument('--maxq', type=float, default=CFG['maxq']); ap.add_argument('--maxt', type=float, default=CFG['maxt']); ap.add_argument('--max-rounds', type=int, default=40)
    a = ap.parse_args(); os.makedirs(a.out, exist_ok=True); t0 = time.time()
    import cutcell as CE
    cfg = dict(CFG); cfg.update(ecap=a.ecap, maxq=a.maxq, maxt=a.maxt, max_boxes=a.max_boxes, datt=a.datt, chart=a.chart, H2=a.H2, H3=a.H3, node_cap=a.node_cap)
    global CHART
    CHART = a.chart

    def pre(j):
        return (j,) if a.chart == 'std' else (a.chart, j)
    if a.chart == 'std':
        info = json.load(open(os.path.join(a.table, 'table_info.json'))); S0 = info['S0']; T = T4.Table(a.table, S0)
        cells = [(k, c['LB']) for k, c in sorted(T.cells.items()) if c.get('LB') is not None and c['how'] != 'noncvx' and (not a.how or c['how'] == a.how)]
        boxes = {tuple(k): T4.cell_box(tuple(k), S0) for k, LB in cells}
    else:
        # edge chart: root boxes of side 1/16 in (q3x, q3y, a, h) [E2] or (q2x, q2y, b, h) [E3], h in [0, H]
        S0 = 1 / 16; H = a.H2 if a.chart == 'E2' else a.H3; cells = []; boxes = {}
        for k, lo4, hi4 in QC.edge_roots(a.chart, H, S0):
            cells.append((k, 0.0)); boxes[k] = (lo4, hi4)
    if a.sample:
        random.Random(a.seed).shuffle(cells); cells = cells[:a.sample]
    print('chart %s: root boxes with convex members: %d, used here: %d' % (a.chart, len(boxes), len(cells)), flush=True)
    LBs = {tuple(k): LB for k, LB in cells}
    if a.qtable:                                           # quadrilateral table of this chart (qtable.py): better bounds for T
        nq = 0
        for d in JS.read_jsonl(os.path.join(a.qtable, 'cells.jsonl')):
            k = tuple(d['key'])
            if k in LBs and d.get('LB') is not None:
                LBs[k] = max(LBs[k], d['LB']); nq += 1
        print('quadrilateral table %s: bounds for %d of the %d roots' % (a.qtable, nq, len(LBs)), flush=True)
    nodes = {}                                             # (key, j) -> list of boxes to process
    for k, LB in cells:
        lo4, hi4 = boxes[tuple(k)]
        for j in (3, 0):
            nodes[(tuple(k), j)] = [(list(lo4) + [0.0, 0.0], list(hi4) + [1.0, 1.0])]
    store = {}                                             # corner key -> F_lo_safe (float) or None
    cf = os.path.join(a.out, 'corners.jsonl')
    for c in JS.read_jsonl(cf):
        store[tuple(c['key'])] = c.get('F')
    tot = dict(n={}, vol={}, attempts=0, certified=0, failed=0, corners=0, corner_sec=0.0, t1_boxes=0, t1_sec=0.0, unresolved=0, cheap_sec=0.0)
    cvol = 0.0; fl = open(os.path.join(a.out, 'leaves.jsonl'), 'a'); fc = open(cf, 'a'); fr = open(os.path.join(a.out, 'rounds.jsonl'), 'a')
    with Pool(a.jobs) as pool:
        for rnd in range(a.max_rounds):
            if not nodes:
                break
            t1 = time.time(); att = []
            for key, j, n, vol, attempts, unres in pool.imap_unordered(tree_job, [(k, j, LBs[k], b, cfg) for (k, j), b in nodes.items()], chunksize=1):
                for lab in n:
                    tot['n'][lab] = tot['n'].get(lab, 0) + n[lab]; tot['vol'][lab] = tot['vol'].get(lab, 0) + vol[lab]
                tot['unresolved'] += len(unres)
                att += [(key, j, lo, hi, w, e0) for lo, hi, w, e0 in attempts]
            t2 = time.time(); tot['cheap_sec'] += t2 - t1
            if a.cheap_only:
                tot['attempts'] = len(att); tot['attempt_vol'] = sum(float(np.prod([hi[i] - lo[i] for i in range(6)])) for _, _, lo, hi, _, _ in att)
                sz = {}
                for _, _, lo, hi, _, _ in att:
                    kk = '%g,%g,%g' % (max(hi[i] - lo[i] for i in range(4)), hi[4] - lo[4], hi[5] - lo[5]); sz[kk] = sz.get(kk, 0) + 1
                tot['attempt_sizes'] = sz; tot['roots'] = len(cells); tot['roots_all'] = len(boxes); tot['cfg'] = cfg
                JS.atomic_json(os.path.join(a.out, 'cheap_summary.json'), tot); print('cheap only:', json.dumps(tot), flush=True); return
            print('  round %d: cheap phase %.0fs, %d attempts, leaves %s' % (rnd, t2 - t1, len(att), tot['n']), flush=True)
            need = {}
            for key, j, lo, hi, w, e0 in att:
                for z in CE.corner_zs(lo, hi):
                    k = pre(j) + CE.zkey(z)
                    if k not in store and k not in need:
                        need[k] = (k, z, j, a.chart)
            for k, c in pool.imap_unordered(corner_job, list(need.values()), chunksize=2):
                F = None if c is None else float(R.cert_F_lo(c))
                store[k] = F; fc.write(json.dumps(dict(key=list(k), F=F, mu=None if c is None else c['mu'], sec=None if c is None else c['sec'])) + '\n')
                tot['corners'] += 1
                if tot['corners'] % 50 == 0:
                    fc.flush()
            fc.flush(); t3 = time.time(); tot['corner_sec'] += t3 - t2
            print('  round %d: %d new corners %.0fs' % (rnd, len(need), t3 - t2), flush=True)
            jobs = []; nodes = {}; nfail = 0; ncert = 0

            def split(key, j, lo, hi, w):
                rel = [(hi[i] - lo[i]) / MINW[i] for i in range(6)]
                if max(rel) <= 1.0001:
                    tot['unresolved'] += 1; tot['n']['U'] = tot['n'].get('U', 0) + 1
                    tot['vol']['U'] = tot['vol'].get('U', 0) + float(np.prod([hi[i] - lo[i] for i in range(6)])); return
                sc = [(w[i] if np.isfinite(w[i]) else 0.0) * (rel[i] > 1.0001) for i in range(6)]
                if max(sc) <= 0:
                    sc = [rel[i] * (rel[i] > 1.0001) for i in range(6)]
                i = int(np.argmax(sc)); m = (lo[i] + hi[i]) / 2
                h1 = list(hi); h1[i] = m; l2 = list(lo); l2[i] = m
                nodes.setdefault((key, j), []).extend([(lo, h1), (l2, hi)])
            wmap = {}
            for key, j, lo, hi, w, e0 in att:
                Fl = [store[pre(j) + CE.zkey(z)] for z in CE.corner_zs(lo, hi)]
                if any(f is None for f in Fl):
                    nfail += 1; split(key, j, lo, hi, w); continue
                wmap[(key, j, tuple(lo), tuple(hi))] = w
                jobs.append((key, j, lo, hi, Fl, a.max_boxes, a.save_leaves, a.chart))
            for key, j, lo, hi, out in pool.imap_unordered(t1_job, jobs, chunksize=2):
                tot['t1_boxes'] += out['boxes']; tot['t1_sec'] += out['sec']
                if out['status'] == 'certified':
                    ncert += 1; v = float(np.prod([hi[i] - lo[i] for i in range(6)])); cvol += v
                    tot['n']['C'] = tot['n'].get('C', 0) + 1; tot['vol']['C'] = tot['vol'].get('C', 0) + v
                    fl.write(json.dumps(dict(key=list(key), j=j, lo=lo, hi=hi, **out)) + '\n')
                else:
                    nfail += 1; split(key, j, lo, hi, wmap[(key, j, tuple(lo), tuple(hi))])
            fl.flush(); t4 = time.time()
            tot['attempts'] += len(att); tot['certified'] += ncert; tot['failed'] += nfail
            rec = dict(round=rnd, attempts=len(att), new_corners=len(need), certified=ncert, failed=nfail, open_boxes=sum(len(b) for b in nodes.values()),
                       cheap_sec=round(t2 - t1, 1), corner_sec=round(t3 - t2, 1), t1_sec=round(t4 - t3, 1), elapsed=round(t4 - t0, 1), leaves=dict(tot['n']))
            fr.write(json.dumps(rec) + '\n'); fr.flush(); print(json.dumps(rec), flush=True)
    tot['sec'] = round(time.time() - t0, 1); tot['cells'] = len(cells); tot['open_boxes'] = sum(len(b) for b in nodes.values()); tot['cfg'] = cfg
    JS.atomic_json(os.path.join(a.out, 'summary.json'), tot)
    print('done', json.dumps(tot), flush=True)


if __name__ == '__main__':
    main()
