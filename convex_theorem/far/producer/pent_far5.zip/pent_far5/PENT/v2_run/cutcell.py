"""n = 5 PAQC / T1 on a box of the CUT CHART (Claude, 2026-11-12; FAR_SPEC section 9.7).  DRAFT for review.
A piece = box [lo, hi] of (q2x, q2y, q3x, q3y, t, u) with cut corner j (cutchart.verts).  The vertex map is
multi-affine and ruled, so the T1 statement of rig_t1_v2 holds on the box with the 64 corner pentagons P(z_c), z_c the
box corners (rig_t1_v2.CellData(corner_verts=...)).  No frame change, no bounding box in another chart.
Exact corners: the box endpoints are dyadic rationals with denominator <= 2^20, so every vertex coordinate
(q3 + t (q2 - q3), (1 - u) q3, u q3, t) is computed without rounding in binary64 (checked with Fractions); the corner
certificate is a certificate of exactly the corner pentagon.
Corner certificate: PolyMPS + Fox-Henrici-Moler + Hong-Krahn-Szego index (rig_box), boundary sup by sup_taylor;
fields as corner_v2 with `vertices` (the five vertices) instead of vertices_x; solver tag 'cutcorner/1'.
Corner key: (j, k_0..k_5) with z_c = k / 2^KBITS (the cut-chart grid), plus the solver settings."""
import os, sys, json, time
from fractions import Fraction
HERE = os.path.dirname(os.path.abspath(__file__))
for p in ('.', '../scripts', '../far'):
    sys.path.insert(0, os.path.join(HERE, p))
import numpy as np
from flint import arb
import rig_paqc as R
import rig_t1_v2 as T
import t1_np as TN
import corner_v2 as CV
import cutchart as CC

KBITS = 20
SOLVER = 'cutcorner/1'
SET = dict(K=8, nseg=40, P=6)
FMAX = 36.0              # float F at or above this: no corner certificate is attempted (see certify_corner)
FMAX_GUESS = 34.5        # a neighbour's F above this is not used as the search-window centre
ENGINE = 'tv'            # T1 box test: 'tv' (t1_tv.py) or 'np' (t1_np.py, Efron-Stein / Taylor)


def zkey(z):
    k = [Fraction(float(v)) * 2 ** KBITS for v in z]
    assert all(v.denominator == 1 for v in k), 'piece corner not on the 2^-%d grid' % KBITS
    return tuple(int(v) for v in k)


def exact_verts(z, j, chart='std'):
    """the five vertices of P(z) as binary64 numbers, with a Fraction check that no rounding occurred.
    chart: 'std' or an edge chart of cutchart.to_std (there the coordinates are products of up to four grid numbers, so
    the grid must be coarse enough; the assertion decides)"""
    V = [(float(a), float(b)) for a, b in CC.verts(CC.to_std([float(v) for v in z], chart), j)]
    zf = [Fraction(float(v)) for v in z]; Vf = CC.verts(CC.to_std(zf, chart), j)
    assert all(Fraction(V[i][0]) == Vf[i][0] and Fraction(V[i][1]) == Vf[i][1] for i in range(5)), 'vertex not exact in binary64'
    return V


def corner_zs(lo, hi):
    return [[hi[i] if s[i] > 0 else lo[i] for i in range(6)] for s in R.CORN]


def cheap_lower(V, fdir=None, fibre=True):
    """rigorous lower bound of F(P) for ONE convex pentagon with exact binary64 vertices V (5 pairs), from the
    closed-form bounds (no eigenvalue computation; FAR_SPEC 9.11-9.12):
       S(a)  pi^2 |P| / W_n^2 for the normals n of the five edges (P lies in a strip of width W_n),
       S(b)  pi^2 l^2 / (2 max_k c_k) for the five edges (|P| >= l H / 2, P within distance H of the edge line),
       R     (4 pi^2 / sqrt 3) |P| / (|P| + ear_m + ear_{m+2}) for non-adjacent edges with C_m, C_{m+2} > 0,
       M     pi^2 L^2 / (16 |P|)   (Makai: lambda_1 >= pi^2 L^2 / (16 A^2) for convex domains, L the perimeter),
       O     the fibre bound fibre.F_lower (one-dimensional reduction; within 4-8 % of F for elongated pentagons).
    Returns (float lower bound, name of the best bound); (0.0, None) if P is not strictly convex and positively oriented.
    Used as the corner value of a PAQC cell where the eigenvalue certificate is unavailable (F above the index limit
    2 pi j_{0,1}^2) or unnecessary (the cheap bound is already well above F*)."""
    P = [(arb(float(a)), arb(float(b))) for a, b in V]
    e = [(P[(i + 1) % 5][0] - P[i][0], P[(i + 1) % 5][1] - P[i][1]) for i in range(5)]

    def cr(u, v):
        return u[0] * v[1] - u[1] * v[0]
    if not all(cr(e[i], e[(i + 1) % 5]) > 0 for i in range(5)):
        return 0.0, None
    A = sum(cr(P[i], P[(i + 1) % 5]) for i in range(5)) / 2; pi2 = arb.pi() ** 2; best = (0.0, None)

    def take(v, name):
        nonlocal best
        if v.is_finite() and R.f_down(v) > best[0]:
            best = (R.f_down(v), name)
    L = arb(0)
    for a in range(5):
        l2 = e[a][0] * e[a][0] + e[a][1] * e[a][1]; L += l2.sqrt()
        cs = [cr(e[a], (P[k][0] - P[a][0], P[k][1] - P[a][1])) for k in range(5)]         # = l * signed distance of V_k from the edge line
        cmax = arb(max(c.upper() for c in cs))
        take(pi2 * l2 / (2 * cmax), 'Sb%d' % a)                                           # S(b)
        take(pi2 * A * l2 / (cmax * cmax), 'Sa%d' % a)                                    # S(a): W_n = cmax / l for the normal of edge a
    ear = []
    for m in range(5):
        C = cr(e[m - 1], e[(m + 1) % 5])
        ear.append(cr(e[m - 1], e[m]) * cr(e[m], e[(m + 1) % 5]) / (2 * C) if C > 0 else None)
    tri = 4 * pi2 / arb(3).sqrt()
    for m in range(5):
        if ear[m] is not None and ear[(m + 2) % 5] is not None:
            take(tri * A / (A + ear[m] + ear[(m + 2) % 5]), 'R%d' % m)
    take(pi2 * L * L / (16 * A), 'M')
    if not fibre:
        return best
    import fibre as FB                                                                    # O: fibre bound (fibre.py, Lemma OD)
    v, d = FB.F_lower([(float(a), float(b)) for a, b in V], d=fdir)    # fdir: a direction chosen by the caller (e.g. once per box)
    if v > best[0]:
        best = (v, 'O')
    return best


def certify_corner(z, j, chart='std', guess=None):
    """rigorous F_lo of the corner pentagon P(z) (cut corner j); returns the certificate dict or None.
    guess: a float F of a nearby pentagon (2026-11-15).  It only replaces the float pre-solve as the centre of the search
    window (width 6%); the certificate is the same kind (index check included), and if the window fails the float
    pre-solve is used as before."""
    import far_design_probe as FD
    from mps import poly_area
    V = np.array(exact_verts(z, j, chart), float); t0 = time.time()
    # A numerical failure of the float solver (e.g. numpy 'SVD did not converge', seen once in 5,800 corners on
    # 2026-11-16) means 'no certificate for this corner', not a crash of the block.
    try:
        if guess is not None and guess < FMAX_GUESS:
            c = _certify_with(V, z, j, chart, float(guess), (0.06,), t0)
            if c is not None:
                c['guess'] = 'neighbour'; return c
    except (np.linalg.LinAlgError, FloatingPointError, ZeroDivisionError, ValueError):
        pass
    try:
        Ff = FD.F_float(V)
    except (np.linalg.LinAlgError, FloatingPointError, ZeroDivisionError, ValueError):
        Ff = None
    if Ff is None or Ff >= FMAX:
        return None                    # the index check needs lambda A < 2 pi j_{0,1}^2 = 36.34: no certificate for such pentagons
    for K in (SET['K'], SET['K'] + 2):   # a failed certificate is retried once with two more basis functions per corner:
        try:                             # a corner without a certificate in the low-margin region ends as an unresolved box
            c = _certify_with(V, z, j, chart, Ff, (0.03, 0.1), t0, K)
            if c is not None:
                return c
        except (np.linalg.LinAlgError, FloatingPointError, ZeroDivisionError, ValueError):
            pass
    return None


FAN_N = int(os.environ.get('PENT_FAN_N', '5'))        # degree of the fan certificate (lgfan.py) of every corner; 0 switches it off
LG_D = int(os.environ.get('PENT_LG_D', '0'))          # older tiers, off by default since the fan certificate (2026-11-16):
LG_D2 = int(os.environ.get('PENT_LG_D2', '0'))        # degrees of the one-piece polynomial certificate (lgcert.py) and of its refinement


def corner_lower(V):
    """lower bound of F for ONE corner pentagon with exact binary64 vertices (2026-11-16): the closed forms S, R, M of
    cheap_lower, the fan certificate (lgfan.py, Lemma LG; about 2 ms, within 1e-3 of F for F < 24), and the fibre bound
    only where there is no fan certificate (elongated pentagons, F near or above 2 pi j_{0,1}^2).
    Returns (closed-form value, its name, fan record or None, fibre direction used or None)."""
    ch, name = cheap_lower(V, fibre=False)
    if not (ch > 0):
        return 0.0, None, None, None
    rec = None
    if FAN_N:
        import lgfan
        try:
            rec = lgfan.F_lower(V, FAN_N)
        except Exception:
            rec = None
    if rec is not None:
        return ch, name, rec, None
    import fibre as FB
    fd = FB.best_direction([(float(a), float(b)) for a, b in V])[1]
    ch, name = cheap_lower(V, fd)
    return ch, name, None, fd


LGBOX_N = int(os.environ.get('PENT_LGBOX_N', '6'))      # degree of the trial family of the box certificate


LG_TRACE = os.environ.get('PENT_LG_TRACE', '')
LGBOX_ORDER = int(os.environ.get('PENT_LGBOX_ORDER', '1'))   # 1: coefficient lists affine in the box parameters; 0: constant (experiment)


LG_SCREEN = float(os.environ.get('PENT_LG_SCREEN', '0.5'))    # production pre-filter of lg_box (0: off)


def lg_box(lo, hi, j, chart='std', N=None, screen=False):
    """LG box certificate (lgbox.py / lgpoly.py, far/LG_LEMMA.md computation C) for the box [lo, hi] of the chart with cut
    corner j: (True, info) if F(P(z)) > F*_up is PROVED for every z of the box (one trial family computed at the centre;
    exact polynomial positivity; the vertex map of the chart is polynomial in z).  No corner values, no T1."""
    import lgbox as LB, lgpoly as LP
    mid = [(a + b) / 2 for a, b in zip(lo, hi)]; rad = [(b - a) / 2 for a, b in zip(lo, hi)]
    try:
        fam = LB.Family(lambda z: [(float(a), float(b)) for a, b in CC.verts(CC.to_std(list(z), chart), j)], mid, N or LGBOX_N, order=LGBOX_ORDER)
        if not fam.ok:
            return False, {}
        if screen and LG_SCREEN > 0:
            # HEURISTIC pre-filter (floating point; production only, never in a verifier): the transplanted family at the 64
            # corners.  A certificate needs positive fan determinants and a positive margin at every corner; on 231
            # attempts of an E2 block every certified box kept at least half of the centre margin at its worst corner and
            # 43 of the 50 failed ones did not.  A rejected box is bisected by the caller, as after a failed certificate.
            import itertools
            vf = lambda z: [(float(a), float(b)) for a, b in CC.verts(CC.to_std(list(z), chart), j)]; nd = len(mid)
            pts = [mid] + [[lo[i] if sg[i] == 0 else hi[i] for i in range(nd)] for sg in itertools.product((0, 1), repeat=nd)]
            dm, Dc, mg = LB.float_margins(fam, (np.array([vf(z) for z in pts]), np.array(pts) - np.array(fam.zc)), float(R.FSTAR_UP))
            m = np.clip(np.nan_to_num(np.where((Dc > 0) & (dm > 0), mg, -1.0), nan=-1.0, posinf=5.0, neginf=-1.0), -1.0, 5.0); mc = m[1:]
            if not (m[0] > 0 and mc.min() >= LG_SCREEN * m[0]):
                return False, dict(why='screen', N=fam.N)           # no 'w': the caller splits along its own direction (geometry probe)
        ok, info = LP.check_box(fam, lambda x, const: CC.verts(CC.to_std(x, chart), j), mid, rad, float(R.FSTAR_UP))
    except Exception as ex:
        return False, dict(error=repr(ex)[:100])
    info = dict(info, N=fam.N)
    if 'lin' in info:
        info['w'] = [info['lin'][i] + info['hi'][i] for i in range(len(mid))]
    if LG_TRACE:                                                    # diagnostics only (2026-11-17): one line per attempt
        with open(LG_TRACE, 'a') as f:
            f.write(json.dumps(dict(lo=list(lo), hi=list(hi), j=j, chart=chart, ok=bool(ok), stage=info.get('stage'), why=info.get('why'), sub=info.get('sub'),
                                    c0=info.get('c0'), qp=info.get('qp'), tail=info.get('tail'))) + '\n')
    return ok, info


def lg_corner(z, j, chart='std', d=None):
    """polynomial certificate (lgcert.F_lower, Lemma LG) of the corner pentagon: a dict with F_lo, or None"""
    import lgcert as LG
    try:
        return LG.F_lower(exact_verts(z, j, chart), d or LG_D)
    except Exception:
        return None


FAST_SOLVE = os.environ.get('PENT_FAST_SOLVE', '1') == '1'


def fast_solve(self, lam_guess, width=0.05, tol=1e-15, ngrid=41):
    """Float eigenvalue search of PolyMPS with fewer evaluations (2026-11-16): the same grid and the same final V-fit
    refinement as mps.PolyMPS.solve, but the golden-section stage (about 34 evaluations of sigma) is replaced by the
    intersection of the two branches of the V-shaped function sigma(lam) ~ s |lam - lam*| (about 5 evaluations).
    Only the floating-point approximation changes; the certificate (boundary sup, index check) is computed afterwards
    for whatever lam is returned."""
    lo, hi = lam_guess * (1 - width), lam_guess * (1 + width)
    grid = np.linspace(lo, hi, ngrid); vals = [self.sigma(g) for g in grid]; i = int(np.argmin(vals))
    ia, ib = max(i - 1, 0), min(i + 1, len(grid) - 1); a, b = grid[ia], grid[ib]; fa, fb = vals[ia], vals[ib]
    for _ in range(8):
        if not (fa + fb > 0) or (b - a) <= 1e-9 * lam_guess:
            break
        c = (a * fb + b * fa) / (fa + fb)                           # the two branches meet here if the slopes are equal
        c = min(max(c, a + 1e-3 * (b - a)), b - 1e-3 * (b - a)); fc = self.sigma(c)
        if (fa - fc) * (b - c) > (fb - fc) * (c - a):               # c lies on the left branch (steeper chord from a)
            a, fa = c, fc
        else:
            b, fb = c, fc
    x0 = 0.5 * (a + b) if not (fa + fb > 0) else (a * fb + b * fa) / (fa + fb); h = max(1e-9 * lam_guess, min(b - a, 1e-6 * lam_guess))
    for _ in range(3):
        xl, xr = x0 - h, x0 + h; fl, fr = self.sigma(xl), self.sigma(xr)
        x0 = x0 + h * (fl - fr) / (fl + fr) if (fl + fr) > 0 else x0
        h = h * 1e-2
        if h < tol * lam_guess:
            break
    self.lam = x0; self.sig = self.sigma(x0); self._coeffs()
    return self.lam


def _certify_with(V, z, j, chart, Ff, widths, t0, K=None):
    from mps import poly_area, PolyMPS
    K = K or SET['K']
    A = abs(poly_area(V)); old = CV.SUP; CV.SUP = 'taylor'; old_solve = PolyMPS.solve
    if FAST_SOLVE:
        PolyMPS.solve = fast_solve
    try:
        r = None
        for width in widths:
            r = CV._certify_polygon_fastsup(V, K, Ff / A, SET['nseg'], width)
            lam = float(r['lam']); g = Ff / A
            at_edge = min(abs(lam - g * (1 - width)), abs(lam - g * (1 + width))) < 1e-9 * g
            if r['ok_index'] and not at_edge and float(r['mu'].upper()) <= 0.02:
                break
        if r is None or not r['ok_index'] or at_edge:
            return None
    finally:
        CV.SUP = old; PolyMPS.solve = old_solve
    rec = dict(j=j, chart=chart, z=[repr(float(v)) for v in z], vertices=[[repr(a), repr(b)] for a, b in V.tolist()], K=K, nseg=SET['nseg'], sup_order=SET['P'],
               width=width, solver=SOLVER, lam_tilde=repr(float(r['lam'])), mu=str(r['mu']), lam_lo=str(r['lam_lo']), lam_hi=str(r['lam_hi']),
               area=str(r['area']), hks_index_ok=True, coefficients=r.get('coefficients'), sup_bdry_upper=repr(R.f_up(r['sup_bdry'])),
               l2sq_lower=repr(R.f_down(r['l2sq_lower'])), sec=round(time.time() - t0, 2))
    rec['F_lo'] = repr(R.f_down(r['lam_lo'] * r['area']))
    rec.update(R.safe_fields(arb(rec['lam_lo']), arb(rec['area']), arb(rec['mu'])))
    return rec


def certify_piece(j, lo, hi, cache, max_boxes=6000, log=None, chart='std'):
    """T1 on the piece.  cache: dict corner key -> certificate (or None); new corners are added.
    Returns dict(status = certified / budget / fail / gate / fail_corner, ...).
    chart: the box is a box of this chart (cutchart.to_std); keys of non-standard charts carry the chart name."""
    t0 = time.time(); zs = corner_zs(lo, hi); pre = (j,) if chart == 'std' else (chart, j)
    keys = [pre + zkey(z) for z in zs]; new = 0
    Vs = [[[arb(a), arb(b)] for a, b in exact_verts(z, j, chart)] for z in zs]
    # gate first (cheap): all corner pentagons strictly convex
    for V in Vs:
        for i in range(5):
            a, b = V[i], V[(i + 1) % 5]
            for m in range(5):
                if m in (i, (i + 1) % 5):
                    continue
                if not ((b[0] - a[0]) * (V[m][1] - a[1]) - (b[1] - a[1]) * (V[m][0] - a[0]) > 0):
                    return dict(status='gate', sec=round(time.time() - t0, 2))
    for k, z in zip(keys, zs):
        if k not in cache:
            cache[k] = certify_corner(z, j, chart); new += 1
            if log is not None:
                log(k, cache[k])
    certs = [cache[k] for k in keys]
    if any(c is None for c in certs):
        return dict(status='fail_corner', new_corners=new, sec=round(time.time() - t0, 2))
    Fl = [arb(R.cert_F_lo(c)) for c in certs]
    try:
        cd = T.CellData(None, None, Fl, emode='exact' if ENGINE == 'tv' else 'es', corner_verts=Vs)
    except AssertionError as ex:
        return dict(status='gate', why=repr(ex)[:80], new_corners=new, sec=round(time.time() - t0, 2))
    if ENGINE == 'tv':
        import t1_tv as TV
        t = TV.certify_T1(cd, R.FSTAR_UP, max_boxes=max_boxes, min_rad=1e-3)
    else:
        t = TN.certify_T1(cd, R.FSTAR_UP, max_boxes=max_boxes, min_rad=1e-3)
    return dict(status=t['status'], boxes=t['boxes'], Fmin=float(min(R.cert_F_lo(c) for c in certs)), new_corners=new, t1_sec=t['sec'],
                sec=round(time.time() - t0, 2), T1=t)
