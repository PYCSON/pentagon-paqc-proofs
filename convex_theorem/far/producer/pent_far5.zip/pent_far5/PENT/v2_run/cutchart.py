"""The cut chart for pentagons (Claude, 2026-11-12, DRAFT; FAR_SPEC section 9.7).
Every convex pentagon P has an edge k with C_k > 0 (the two neighbouring edge lines meet beyond edge k: the exterior
angles sum to 2 pi, so some adjacent pair sums to < pi); then P = Q minus a corner triangle, where Q = Q_k(P) is the
convex quadrilateral of the other four edge lines and the corner is W = the meeting point.  Normalise Q by a similarity
to Q(q) = (q0 = 0, q1 = (1,0), q2, q3), q = (q2x, q2y, q3x, q3y), base = the longest edge of Q, and let j be the index
of W.  With t, u in (0,1) the fractions of the two edges at W that are cut away,
   j = 3:  P = [q0, q1, q2, q3 + t (q2 - q3), q3 + u (q0 - q3)]            (cut edge = edge 3)
   j = 0:  P = [(t, 0), q1, q2, q3, u q3]                                    (cut edge = edge 4)
   (j = 2, 1 are the mirror images of j = 3, 0 under (x, y) -> (1 - x, y), q2 <-> q3)
and  |P|/|Q| = 1 - t u tau_j(q),  tau_j = |triangle(q_{j-1}, q_j, q_{j+1})| / |Q|.
Facts used:
 (F1) F(P) >= F(Q) (1 - t u tau_j(q))      (P inside Q: lambda_1(P) >= lambda_1(Q); F is scale invariant).
      So with a table bound LB <= F on the convex quadrilaterals of a 4-D cell c, every (q, t, u) with q in c and
      t u sup_c tau_j < 1 - F*_up / LB is proven -- exactly, with no 6-D enclosure.
 (F2) every vertex of P is multi-affine in (q, t, u) and each of the six variables moves all vertices along one common
      direction; hence the bounding box of the vertices over a box of (q, t, u) is attained at its 64 corners.
 (F3) ear_k' = A_k' B_k' / (2 C_k') (C_k' > 0) is the area added when edge k' is deleted; the representation with the
      smallest ear (largest |P|/|Q|) is the 'kept' one.  A piece on which another edge k' has C_k' > 0 and
      ear_k' < ear_cut everywhere is skipped: each of its pentagons is covered at its own smallest-ear representation.
All functions accept arb balls or dimdesc.Dual objects (value + gradient in the six chart variables)."""
import os, sys
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'v2_quad'))
from flint import arb
import dimdesc as DD

CUT_EDGE = {3: 3, 0: 4}


def crs(u, v):
    return u[0] * v[1] - u[1] * v[0]


def verts(z, j):
    """z = (q2x, q2y, q3x, q3y, t, u) (floats, arbs or Duals) -> the five vertices"""
    q2 = (z[0], z[1]); q3 = (z[2], z[3]); t, u = z[4], z[5]; o = z[0] * 0
    if j == 3:
        return [(o, o), (o + 1, o), q2, (q3[0] + t * (q2[0] - q3[0]), q3[1] + t * (q2[1] - q3[1])), (q3[0] - u * q3[0], q3[1] - u * q3[1])]
    if j == 0:
        return [(o + t, o), (o + 1, o), q2, q3, (u * q3[0], u * q3[1])]
    raise ValueError(j)


def to_std(z, chart='std'):
    """chart coordinates -> standard cut-chart coordinates (q2x, q2y, q3x, q3y, t, u)   (FAR_SPEC 9.8 (b), 2026-11-12).
    'E2': z = (q3x, q3y, a, h, t, u),  q2 = q1 + a (q3 - q1) + h (0, 1)   (flat vertex at q2 <=> h = 0;  K = h (1 - q3x))
    'E3': z = (q2x, q2y, b, h, t, u),  q3 = b q2 + h (0, 1)               (flat vertex at q3 <=> h = 0;  D = h q2x)
    Both are multi-affine in z, and every coordinate moves all vertices of Q along one common direction (ruled): e.g. in
    E2, q3x moves q3 along (1, 0) and q2 along (a, 0).  Works for floats, Fractions and arb."""
    if chart == 'std':
        return list(z)
    if chart == 'E2':
        q3x, q3y, a, h, t, u = z
        return [1 + a * (q3x - 1), a * q3y + h, q3x, q3y, t, u]
    if chart == 'E3':
        q2x, q2y, b, h, t, u = z
        return [q2x, q2y, b * q2x, b * q2y + h, t, u]
    raise ValueError(chart)


def quad_area(z):
    return (z[1] + z[0] * z[3] - z[2] * z[1]) / 2          # shoelace of (0, (1,0), q2, q3)


def tau(z, j):
    """|corner triangle at q_j| / |Q|"""
    if j == 3:      # triangle (q2, q3, q0)
        tri = (z[0] * z[3] - z[2] * z[1]) / 2               # cross(q2, q3)/2
    else:           # triangle (q3, q0, q1)
        tri = z[3] / 2
    return tri / quad_area(z)


def ears(V):
    """for each edge k: (C_k, ear_k = A_k B_k / (2 C_k)) with A_k = e_{k-1} x e_k, B_k = e_k x e_{k+1}, C_k = e_{k-1} x e_{k+1}"""
    e = [(V[(i + 1) % 5][0] - V[i][0], V[(i + 1) % 5][1] - V[i][1]) for i in range(5)]
    out = []
    for k in range(5):
        A = crs(e[(k - 1) % 5], e[k]); B = crs(e[k], e[(k + 1) % 5]); C = crs(e[(k - 1) % 5], e[(k + 1) % 5])
        out.append((C, A, B))
    return out


def zbox(lo, hi):
    return [DD.ival(lo[i], hi[i]) for i in range(6)]


def x_box(lo, hi, j):
    """bounding box in the pentagon chart x = (V2, V3, V4) (base V0 = 0, V1 = (1,0)) of the image of the piece.
    j = 3: the vertices are already in that frame and the box is the hull of the 64 corner images (F2), computed in
    ball arithmetic.  j = 0: the frame is rescaled by 1/(1 - t) about (t, 0) -> natural interval extension (an outer box)."""
    if j == 3:
        los = [None] * 6; his = [None] * 6
        for b in range(64):
            z = [arb(float(hi[i] if (b >> i) & 1 else lo[i])) for i in range(6)]
            V = verts(z, 3); x = [V[2][0], V[2][1], V[3][0], V[3][1], V[4][0], V[4][1]]
            for i in range(6):
                a = float(x[i].lower()); c = float(x[i].upper())
                los[i] = a if los[i] is None else min(los[i], a); his[i] = c if his[i] is None else max(his[i], c)
        return los, his
    z = zbox(lo, hi); V = verts(z, 0); s = 1 / (1 - z[4])
    x = []
    for v in (V[2], V[3], V[4]):
        x += [(v[0] - z[4]) * s, v[1] * s]
    if not all(v.is_finite() for v in x):
        return None
    return [float(v.lower()) for v in x], [float(v.upper()) for v in x]


def tau_sup(lo, hi, j):
    """rigorous upper bound of tau_j over the q-cell (first four coordinates), or None (area not positive on the cell)"""
    z = zbox(lo, hi); A = quad_area(z)
    if not (A > 0):
        return None
    v = tau(z, j)
    return float(v.upper()) if v.is_finite() else None


def _corner_range(f, lo, hi):
    """exact range of a MULTI-AFFINE polynomial over the box: min and max over the 64 corners (ball arithmetic)"""
    mn = None; mx = None
    for b in range(64):
        v = f([arb(float(hi[i] if (b >> i) & 1 else lo[i])) for i in range(6)])
        a_, c_ = v.lower(), v.upper()
        mn = a_ if mn is None or a_ < mn else mn; mx = c_ if mx is None or c_ > mx else mx
    return mn, mx


# closed forms (sympy-derived, checked against ears() in tests/cutchart_selftest.py); z = (q2x, q2y, q3x, q3y, t, u)
def _D(z): return z[0] * z[3] - z[1] * z[2]                    # 2 |triangle(q0, q2, q3)| = q2 x q3
def _M(z): return _D(z) - z[3]                                 # (q2 - q1) x q3
def _K(z): return _D(z) - z[3] + z[1]                          # (q2 - q1) x (q3 - q2)


STUB = {
    # j: [(k', C_k'(z) (must be > 0), g(z) with: ear_k' < ear_cut  <=>  g < 0)]   -- all multi-affine in the six variables
    3: [(4, lambda z: z[5] * z[3] + z[4] * (z[1] - z[3]), lambda z: z[3] * (1 - 2 * z[5]) - z[4] * z[5] * (z[1] - z[3])),
        (2, lambda z: z[4] * _K(z) - z[5] * _M(z), lambda z: _K(z) * (1 - 2 * z[4]) + z[4] * z[5] * _M(z))],
    0: [(0, lambda z: z[5] * _M(z) + z[1] * z[4], lambda z: -(z[4] * z[5] * _M(z) + z[1] * (2 * z[4] - 1))),
        (3, lambda z: z[5] * _D(z) + z[4] * (z[1] - z[3]), lambda z: -(_D(z) * (2 * z[5] - 1) + z[4] * z[5] * (z[1] - z[3])))],
}


def not_kept(lo, hi, j):
    """rigorous and essentially exact: on the whole piece some other edge k' has C_k' > 0 and ear_k' < ear_cut.
    Stub edges (the two shortened edges at the cut): the comparison reduces to the sign of a multi-affine polynomial,
    whose range over the box is attained at the corners.  The two untouched edges (their ears do not depend on t, u):
    interval arithmetic on the closed forms
        j = 3:  k' = 0: M > 0 and q2y q3y < t u D M;        k' = 1: q3y > q2y and q2y K < t u (q3y - q2y) D
        j = 0:  k' = 1: q3y > q2y and q2y K < t u q3y (q3y - q2y);   k' = 2: M < 0 and D K < t u q3y (-M)
    Returns k' or None."""
    for k, C, g in STUB[j]:
        if _corner_range(C, lo, hi)[0] > 0 and _corner_range(g, lo, hi)[1] < 0:
            return k
    z = zbox(lo, hi); D = _D(z); M = _M(z); K = _K(z); tu = z[4] * z[5]
    if j == 3:
        if M > 0 and (z[1] * z[3] - tu * D * M) < 0:
            return 0
        if (z[3] - z[1]) > 0 and (z[1] * K - tu * (z[3] - z[1]) * D) < 0:
            return 1
    else:
        if (z[3] - z[1]) > 0 and (z[1] * K - tu * z[3] * (z[3] - z[1])) < 0:
            return 1
        if M < 0 and (D * K + tu * z[3] * M) < 0:
            return 2
    return None


def frame_box(lo, hi, j, start):
    """bounding box, in the pentagon chart, of the piece seen in the frame whose base is the edge V_start -> V_start+1 of
    the vertex list verts(z, j): x = ((V_{start+2} - V_start)/(V_{start+1} - V_start), ...) as complex quotients (a
    similarity, so F is unchanged and the labelled pentagon is the cyclic relabelling by `start`).
    Enclosure: natural interval extension intersected with the mean-value form in the six chart variables
    (dimdesc.Dual), valid when the base edge has positive length on the whole piece; None otherwise.
    Use: j = 0 pieces with start = 1 (base q1 -> q2) or 2 (base q2 -> q3): the base does not depend on t, u, so the box
    is tight in t and u (the natural frame of j = 0 rescales by 1/(1 - t) and is not)."""
    zb = zbox(lo, hi)
    cen = [arb(float((np.float64(lo[i]) + np.float64(hi[i])) / 2)) for i in range(6)]
    rad = [arb(max(abs(arb(float(lo[i])) - cen[i]).upper(), abs(arb(float(hi[i])) - cen[i]).upper())) for i in range(6)]
    zd = [DD.Dual(zb[i], [arb(1) if m == i else arb(0) for m in range(6)]) for i in range(6)]

    def coords(z):
        V = verts(z, j); V = [V[(start + m) % 5] for m in range(5)]
        dx = V[1][0] - V[0][0]; dy = V[1][1] - V[0][1]; den = dx * dx + dy * dy; out = []
        for m in (2, 3, 4):
            ax = V[m][0] - V[0][0]; ay = V[m][1] - V[0][1]
            out += [(ax * dx + ay * dy) / den, (ay * dx - ax * dy) / den]
        return out, den
    xn, den = coords(zb)
    if not (den > 0):
        return None
    xc, _ = coords(cen); xd, _ = coords(zd); los = []; his = []
    for i in range(6):
        a = xn[i].lower(); b = xn[i].upper()
        if xc[i].is_finite() and all(g.is_finite() for g in xd[i].g):
            spread = sum((abs(g) * r for g, r in zip(xd[i].g, rad)), arb(0))
            a2 = (xc[i] - spread).lower(); b2 = (xc[i] + spread).upper()
            a = a2 if a2 > a else a; b = b2 if b2 < b else b
        if not (arb(a).is_finite() and arb(b).is_finite()):
            return None
        los.append(float(arb(a).lower() if False else a)); his.append(float(b))
    # float() of an arb rounds to nearest: widen by one float outward
    return [float(np.nextafter(v, -np.inf)) for v in los], [float(np.nextafter(v, np.inf)) for v in his]
