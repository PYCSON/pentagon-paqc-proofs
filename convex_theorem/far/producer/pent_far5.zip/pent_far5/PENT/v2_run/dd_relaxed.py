"""Dimension descent pentagon box -> quadrilateral chart box WITHOUT whole-box convexity (Claude, 2026-11-12, DRAFT for
review; FAR_SPEC section 9.7).
Statement.  Let B be a box in the pentagon chart, k an edge, and write (pentquad.py) A = e_{k-1} x e_k, B_ = e_k x e_{k+1},
C = e_{k-1} x e_{k+1}, |P| the shoelace area.  If C > 0 and |P| > 0 on all of B, then for every x in B whose pentagon
P_x is CONVEX (all five turns >= 0; in particular A, B_ >= 0):
   (i)   Q_k(P_x) = (V_{k+2}, V_{k+3}, V_{k-1}, W), W = V_k + (B_/C) e_{k-1}, is a convex quadrilateral containing P_x,
   (ii)  |P_x|/|Q_k(P_x)| = 1/(1 + A B_/(2 C |P|)) >= r_lo,
   (iii) the chart coordinates of Q_k(P_x) (base = edge `rot`, sent to 0 -> 1) lie in the box [lo4, hi4],
so  F(P_x) >= F(Q) r_lo >= r_lo * min{ LB(cell) : table cells meeting [lo4, hi4] },  LB(cell) a lower bound of F on the
CONVEX quadrilaterals of the cell.  Nothing is claimed for non-convex x (they are not pentagons of the theorem).
Enclosures: natural interval extension with the turn intervals A, B_ intersected with [0, +inf) (legitimate because
only convex x matter), intersected with the mean-value form of the UNCLAMPED functions (valid on all of B when they
are C^1 there: C > 0, |P| > 0, 1 + A B_/(2 C |P|) > 0 and |q1 - q0|^2 > 0 on B, all checked)."""
import os, sys
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'v2_quad'))
from flint import arb
import dimdesc as DD


def _clamp0(a):
    """a intersect [0, +inf) as an arb (None if empty)"""
    if a.upper() < 0:
        return None
    lo = a.lower()
    return a if lo >= 0 else arb(0).union(arb(a.upper()))


def _fin(a):
    return a.is_finite()


def _geom_nat(xb, k, rot):
    """clamped natural extension: (ratio, X4) or (None, why)"""
    z0 = xb[0] * 0
    V = [(z0, z0), (z0 + 1, z0), (xb[0], xb[1]), (xb[2], xb[3]), (xb[4], xb[5])]
    e = [(V[(i + 1) % 5][0] - V[i][0], V[(i + 1) % 5][1] - V[i][1]) for i in range(5)]
    crs = lambda u, v: u[0] * v[1] - u[1] * v[0]
    turns = [crs(e[i], e[(i + 1) % 5]) for i in range(5)]
    if any(t.upper() <= 0 for t in turns):
        return None, 'no convex member'
    P = (V[2][0] * V[3][1] - V[3][0] * V[2][1] + V[3][0] * V[4][1] - V[4][0] * V[3][1] + V[2][1]) / 2
    C = crs(e[(k - 1) % 5], e[(k + 1) % 5])
    if not (C > 0) or not (P > 0):
        return None, 'C or area'
    A = _clamp0(turns[(k - 1) % 5]); B = _clamp0(turns[k])
    ratio = 1 / (1 + A * B / (2 * C * P))
    s = B / C
    W = (V[k][0] + s * e[(k - 1) % 5][0], V[k][1] + s * e[(k - 1) % 5][1])
    Q = [V[(k + 2) % 5], V[(k + 3) % 5], V[(k - 1) % 5], W]; Q = Q[rot:] + Q[:rot]
    dx, dy = Q[1][0] - Q[0][0], Q[1][1] - Q[0][1]; den = dx * dx + dy * dy
    if not (den > 0):
        return None, 'base'
    X4 = []
    for q in (Q[2], Q[3]):
        ax, ay = q[0] - Q[0][0], q[1] - Q[0][1]
        X4 += [(ax * dx + ay * dy) / den, (ay * dx - ax * dy) / den]
    return (ratio, X4), None


def box_geometry(lo6, hi6, k, rot=0, use_mv=True):
    xb = [DD.ival(lo6[i], hi6[i]) for i in range(6)]
    nat, why = _geom_nat(xb, k, rot)
    if nat is None:
        return dict(ok=False, why=why)
    ratio, X4 = nat
    rlo = float(ratio.lower()); lo4 = [float(v.lower()) for v in X4]; hi4 = [float(v.upper()) for v in X4]
    if use_mv:
        try:
            cen = [arb(float((np.float64(lo6[i]) + np.float64(hi6[i])) / 2)) for i in range(6)]
            rad = [arb(max(abs(arb(float(lo6[i])) - cen[i]).upper(), abs(arb(float(hi6[i])) - cen[i]).upper())) for i in range(6)]
            _, _, _, r_c, X4_c = DD._geom(cen, k, rot)
            xd = [DD.Dual(xb[i], [arb(1) if j == i else arb(0) for j in range(6)]) for i in range(6)]
            _, _, _, r_d, X4_d = DD._geom(xd, k, rot)

            def mv(fc, fd):
                if not _fin(fc) or not _fin(fd.v) or not all(_fin(g) for g in fd.g):
                    return None            # the unclamped function is not certified C^1 on the box
                spread = sum((abs(gi) * ri for gi, ri in zip(fd.g, rad)), arb(0))
                return float((fc - spread).lower()), float((fc + spread).upper())
            m = mv(r_c, r_d)
            if m is not None:
                rlo = max(rlo, m[0])
            for j in range(4):
                m = mv(X4_c[j], X4_d[j])
                if m is not None:
                    lo4[j] = max(lo4[j], m[0]); hi4[j] = min(hi4[j], m[1])
        except ZeroDivisionError:
            pass
    return dict(ok=True, r_lo=rlo, lo4=lo4, hi4=hi4, rot=rot)


def float_quads(x):
    """float: for each k with C > 0 the quadrilateral Q_k (vertices in the order of the docstring), ratio; no convexity test"""
    V = np.array([[0, 0], [1, 0], x[0:2], x[2:4], x[4:6]], float)
    e = [V[(i + 1) % 5] - V[i] for i in range(5)]; cr = lambda u, v: u[0] * v[1] - u[1] * v[0]
    P = 0.5 * sum(cr(V[i], V[(i + 1) % 5]) for i in range(5)); out = {}
    for k in range(5):
        A = cr(e[(k - 1) % 5], e[k]); B = cr(e[k], e[(k + 1) % 5]); C = cr(e[(k - 1) % 5], e[(k + 1) % 5])
        if C <= 1e-9 or P <= 0:
            continue
        W = V[k] + (B / C) * e[(k - 1) % 5]
        Q = np.array([V[(k + 2) % 5], V[(k + 3) % 5], V[(k - 1) % 5], W])
        out[k] = (Q, 1 / (1 + A * B / (2 * C * P)))
    return out, P


def best_rot(Q):
    """rotation whose base edge is the longest edge of Q"""
    L = [np.linalg.norm(Q[(i + 1) % 4] - Q[i]) for i in range(4)]
    return int(np.argmax(L))


def chart4(Q, rot):
    Q = np.vstack([Q[rot:], Q[:rot]]); z = Q[:, 0] + 1j * Q[:, 1]; w = (z - z[0]) / (z[1] - z[0])
    return np.array([w[2].real, w[2].imag, w[3].real, w[3].imag])
