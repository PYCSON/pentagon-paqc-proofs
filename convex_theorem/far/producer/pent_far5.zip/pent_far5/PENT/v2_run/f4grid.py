"""Float map of F(Q) = lambda_1 |Q| on the normalised quadrilateral chart (Claude, 2026-11-12; FLOAT, planning only).
Q = (0, 1, q2, q3), x4 = (q2x, q2y, q3x, q3y); nodes at spacing H = 1/16 on [0,2] x [0,1] x [-1,1] x [0,1]
(index (a, b, c, d) -> x4 = (a H, b H, -1 + c H, d H)); a node is computed when the quadrilateral is strictly convex
(min turn > 1e-3) and its edges 1..3 are <= EDGE_MAX (the chart region 'longest edge = base' plus a collar).
interp(x4): multilinear interpolation of F over the 16 surrounding nodes, None if a node is missing.
Use: guesses and planning (which table cells are needed, with which accuracy).  NOT a bound.
Usage: python3 f4grid.py OUT.npy [--jobs 2]"""
import os, sys, argparse, itertools
from multiprocessing import Pool
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import numpy as np
H = 1 / 16; SHAPE = (33, 17, 33, 17); EDGE_MAX = 1.2
GRID = None


def x4_of(idx):
    a, b, c, d = idx
    return np.array([a * H, b * H, -1 + c * H, d * H])


def quad(x4):
    return np.array([[0, 0], [1, 0], x4[0:2], x4[2:4]], float)


def cross(u, v):
    return u[0] * v[1] - u[1] * v[0]


def min_turn(V):
    n = len(V)
    return min(cross(V[(i + 1) % n] - V[i], V[(i + 2) % n] - V[(i + 1) % n]) for i in range(n))


def wanted(idx):
    V = quad(x4_of(idx))
    return min_turn(V) > 1e-3 and all(np.linalg.norm(V[(i + 1) % 4] - V[i]) <= EDGE_MAX for i in range(1, 4))


def job(idx):
    import far_design_probe as FD
    return idx, FD.F_float(quad(x4_of(idx)))


def load(path):
    global GRID
    GRID = np.load(path); return GRID


def interp(x4):
    t = [x4[0] / H, x4[1] / H, (x4[2] + 1) / H, x4[3] / H]
    i0 = [int(np.floor(v)) for v in t]
    if any(i0[k] < 0 or i0[k] + 1 >= SHAPE[k] for k in range(4)):
        return None
    f = [t[k] - i0[k] for k in range(4)]
    blk = GRID[i0[0]:i0[0] + 2, i0[1]:i0[1] + 2, i0[2]:i0[2] + 2, i0[3]:i0[3] + 2]
    if np.isnan(blk).any():
        return None
    for k in range(4):
        blk = blk[0] * (1 - f[k]) + blk[1] * f[k]
    return float(blk)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('out'); ap.add_argument('--jobs', type=int, default=2)
    a = ap.parse_args()
    G = np.load(a.out) if os.path.exists(a.out) else np.full(SHAPE, np.nan)
    todo = [idx for idx in itertools.product(*[range(n) for n in SHAPE]) if np.isnan(G[idx]) and wanted(idx)]
    print('nodes to compute', len(todo), flush=True)
    with Pool(a.jobs) as pool:
        for n, (idx, F) in enumerate(pool.imap_unordered(job, todo, chunksize=16)):
            G[idx] = F if F is not None else -1.0          # -1: solver failed (treated as missing by the planner)
            if n % 2000 == 0:
                np.save(a.out, G); print(n, flush=True)
    G[G < 0] = np.nan; np.save(a.out, G); print('done', int((~np.isnan(G)).sum()), 'nodes')


if __name__ == '__main__':
    main()
