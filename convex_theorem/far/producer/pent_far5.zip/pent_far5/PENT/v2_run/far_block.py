"""Far region, production pipeline for ONE block of root boxes of one chart (Claude, 2026-11-15; FAR_SPEC 9.10).  DRAFT.
Usage: python3 far_block.py RUN CHART BLOCK        (RUN/config.json, RUN/CHART/roots.json made by far_runner.py init)
Single process, resumable.  Per round: (1) cheap phase of every open box (cut_run.tree_job; all closed leaves are
written to leaves.jsonl); (2) per queued box: the closed-form values of its corners (cutcell.cheap_lower, incl. the fibre bound), a first T1 try
with these (t1_tv), and only if that fails the eigenvalue certificates (cutcell.certify_corner) of the corners whose
closed-form value is below CHEAP_OK F*, then T1 again.  Corner records are appended to corners.jsonl (several records
per corner are possible; the value of a corner is the largest proved one); corners of the neighbouring blocks are read
at the start and reused.  Certified -> cert.jsonl (with the corner values used), failed -> bisected and back to (1); a
failed box at the minimal size is written to leaves.jsonl with the label U.  After every round state.json is replaced atomically (open boxes,
counters, byte offsets of leaves.jsonl and cert.jsonl); a restart truncates the two files to these offsets and repeats
the interrupted round (the corner certificates of that round are kept).  At the end: done.json with counts and SHA256.
Time budget: with PENT_BLOCK_SEC=N in the environment the block stops cleanly after about N seconds of this start
(open boxes are kept in state.json, exit code 3, no done.json); a later start continues.
Files of RUN/CHART/blocks/BLOCK/:  leaves.jsonl  [key, j, lo, hi, label];   cert.jsonl  {key, j, lo, hi, T1 summary and
leaves};   corners.jsonl  {key, cert};   state.json;   done.json;   block.log."""
import os, sys, json, time, hashlib
HERE = os.path.dirname(os.path.abspath(__file__))
for p in ('.', '../far', '../far/pilot', '../scripts', '../v2_cover'):
    sys.path.insert(0, os.path.join(HERE, p))
import numpy as np
import rig_paqc as R
import cut_run as CR
import cutcell as CE
import jsonl_safe as JS


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


CHEAP_OK = float(os.environ.get("PENT_CHEAP_OK", "1.08"))          # a corner whose closed-form bound is >= CHEAP_OK * F* never gets an eigenvalue certificate
# (1.20 -> 1.08 on 2026-11-15: with a closed-form margin of 8 % or more a failed box is bisected instead; one std root
#  went from 199 s / 228 eigenvalue corners / 33 attempts to 23 s / 0 / 44)
LGBOX = os.environ.get('PENT_LGBOX', '0') == '1'            # certify the queued boxes with the LG box certificate instead of corner values + T1
USE_EIG = os.environ.get('PENT_EIG', '0') == '1'            # eigenvalue (MPS) certificates of weak corners: off since the fan certificate (2026-11-16)
RHO = float(os.environ.get("PENT_RHO", "0.65"))           # T1 is tried if e0 <= RHO m / (1 + m), m = min corner margin; else the box is bisected
RHO_EIG = float(os.environ.get("PENT_RHO_EIG", "0.9"))    # the same for boxes with eigenvalue corners (there a corner costs far more than T1 leaves)
LG2_GAIN = 0.985        # the same for a refined polynomial certificate
LG_GAIN = 0.97          # an eigenvalue certificate lifts the value of a polynomial certificate by at most 1 / LG_GAIN
GAIN_MAX = 0.85         # permissive: an eigenvalue certificate lifts a closed-form corner value by at most 1 / GAIN_MAX
PRED_SLACK = 0.97       # the other weak corners are predicted with (closed / certified at the worst corner) * PRED_SLACK
EIG_GAIN = 0.92          # an eigenvalue certificate is expected to lift a closed-form corner value by at most 1 / EIG_GAIN


def corner_value(d):
    """the lower bound of F stored for a corner record: the larger of the eigenvalue certificate (re-checked by
    rig_paqc.cert_F_lo) and the closed-form bound cutcell.cheap_lower; None if neither exists"""
    v = [float(R.cert_F_lo(d['cert']))] if d.get('cert') is not None else []
    if d.get('cheap') and d['cheap'][0] > 0:
        v.append(d['cheap'][0])
    if d.get('lg') is not None:
        v.append(float(d['lg']['F_lo']))                           # polynomial certificate (lgcert.py, Lemma LG)
    return max(v) if v else None


def main():
    run, chart, block = sys.argv[1], sys.argv[2], sys.argv[3]
    cfg = json.load(open(os.path.join(run, 'config.json')))['cut']; cfg = dict(cfg, chart=chart, leaves=True); CR.CHART = chart
    info = json.load(open(os.path.join(run, chart, 'roots.json')))
    roots = info['blocks'][block]                                   # list of [key, lo4, hi4, LB]
    bdir = os.path.join(run, chart, 'blocks', block); os.makedirs(bdir, exist_ok=True)
    if os.path.exists(os.path.join(bdir, 'done.json')):
        print('block', block, 'already done'); return
    fl = os.path.join(bdir, 'leaves.jsonl'); fcert = os.path.join(bdir, 'cert.jsonl'); fcor = os.path.join(bdir, 'corners.jsonl'); fst = os.path.join(bdir, 'state.json')
    log = open(os.path.join(bdir, 'block.log'), 'a'); t0 = time.time()

    def say(*a):
        msg = ' '.join(str(x) for x in a); log.write(time.strftime('%Y-%m-%d %H:%M:%S ') + msg + '\n'); log.flush(); print(msg, flush=True)
    pre = (lambda j: (j,)) if chart == 'std' else (lambda j: (chart, j))
    LBs = {tuple(k): LB for k, lo4, hi4, LB in roots}
    # corner store: this block's file (tail repaired) and the neighbouring blocks' files (read only)
    store = {}
    JS.repair_tail(fcor)
    lgdone = set(); lgref = set()      # corners whose polynomial certificate was attempted / refined
    closed = {}; tried = set()         # closed-form value per corner; corners whose eigenvalue certificate was attempted
    for nb in [block] + info['neighbours'].get(block, []):
        f = os.path.join(run, chart, 'blocks', nb, 'corners.jsonl')
        for d in JS.iter_jsonl_ro(f):      # streaming and read-only: a neighbour may be running, never touch its file (own tail repaired above)
            k = tuple(d['key']); v = corner_value(d)
            closed[k] = max(closed.get(k, 0.0), d['cheap'][0], float(d['lg']['F_lo']) if d.get('lg') is not None else 0.0)
            if d.get('eig') is not None:
                tried.add(k)
            if 'lg' in d:
                lgdone.add(k)
                if d['lg'] is not None and d['lg'].get('d', 0) >= CE.LG_D2:
                    lgref.add(k)
            if k not in store or (v is not None and (store[k] is None or v > store[k])):
                store[k] = v                                        # several records per corner: the largest proved value
    if os.path.exists(fst):
        st = json.load(open(fst))
        for f, off in ((fl, st['leaves_off']), (fcert, st['cert_off'])):
            with open(f, 'ab') as g:
                g.truncate(off)
        nodes = {(tuple(k), j): [(lo, hi) for lo, hi in b] for k, j, b in st['nodes']}; tot = st['tot']; rnd = st['round']
        say('resume at round', rnd, 'open boxes', sum(len(b) for b in nodes.values()))
    else:
        for f in (fl, fcert):
            open(f, 'w').close()
        nodes = {(tuple(k), j): [(list(lo4) + [0.0, 0.0], list(hi4) + [1.0, 1.0])] for k, lo4, hi4, LB in roots for j in (3, 0)}
        tot = dict(n={}, attempts=0, certified=0, failed=0, corners=0, corner_fail=0, t1_boxes=0, cheap_sec=0.0, corner_sec=0.0, t1_sec=0.0); rnd = 0
        say('start block', block, 'chart', chart, 'roots', len(roots), 'known corners', len(store))
    gl = open(fl, 'a'); gc = open(fcert, 'a'); gk = open(fcor, 'a')
    budget = float(os.environ.get('PENT_BLOCK_SEC', '0'))          # time budget of this start (0: none); see the end of the loop
    while nodes:
        if budget and time.time() - t0 > budget:
            break
        t1 = time.time(); att = []; carry = {}
        for (key, j), boxes in sorted(nodes.items()):
            if budget and time.time() - t0 > budget:               # out of time: untouched boxes stay open
                carry[(key, j)] = list(boxes); continue
            left = []; cfgj = dict(cfg, deadline=t0 + budget, left=left) if budget else cfg
            _, _, n, vol, attempts, unres, leaves = CR.tree_job((key, j, LBs[key], boxes, cfgj))
            if left:
                carry[(key, j)] = [(list(lo), list(hi)) for lo, hi in left]
            for lo, hi, lab in leaves:
                gl.write(json.dumps([list(key), j, lo, hi, lab]) + '\n'); tot['n'][lab] = tot['n'].get(lab, 0) + 1
            att += [(key, j, lo, hi, w, e0) for lo, hi, w, e0 in attempts]
        t2 = time.time(); tot['cheap_sec'] += t2 - t1; nnew = 0; ncl = 0; nlg = 0; nlg2 = 0
        fstar = float(R.FSTAR_UP); tcor = 0.0; tt1 = 0.0
        nodes = carry; ncert = 0; nfail = 0

        def put(rec):
            gk.write(json.dumps(rec) + '\n')

        def run_t1(key, j, lo, hi, Fl, mb):
            out = CR.t1_job((key, j, lo, hi, Fl, mb, True, chart))[4]; tot['t1_boxes'] += out['boxes']
            return out
        for ia, (key, j, lo, hi, w, e0) in enumerate(att):
            if budget and time.time() - t0 > budget:               # out of time: the remaining boxes stay open, untouched
                for key2, j2, lo2, hi2, w2, e2 in att[ia:]:
                    nodes.setdefault((key2, j2), []).append((lo2, hi2))
                att = att[:ia]; break
            if LGBOX:
                # box certificate (cutcell.lg_box; 2026-11-16 evening, experimental): no corner values, no T1
                ta = time.time(); ok, info = CE.lg_box(lo, hi, j, chart, screen=True); tcor += time.time() - ta; nlg += 1
                if ok:
                    ncert += 1; tot['n']['C'] = tot['n'].get('C', 0) + 1
                    gc.write(json.dumps(dict(key=list(key), j=j, lo=lo, hi=hi, status='certified', how='LG', N=info['N'], sub=info.get('sub'))) + '\n')
                else:
                    nfail += 1; ch = CR.split_box(lo, hi, info.get('w') or w)
                    if ch is None:
                        gl.write(json.dumps([list(key), j, lo, hi, 'U']) + '\n'); tot['n']['U'] = tot['n'].get('U', 0) + 1
                    else:
                        nodes.setdefault((key, j), []).extend(ch)
                continue
            ta = time.time(); zs = CE.corner_zs(lo, hi); ks = [pre(j) + CE.zkey(z) for z in zs]
            # (1) value of every new corner (exact vertices): closed forms, the fan certificate (lgfan.py), and the fibre
            # bound where there is no fan certificate (cutcell.corner_lower).  No eigenvalue computation.
            for z, k in zip(zs, ks):
                if k not in store:
                    ch, name, rec, fd = CE.corner_lower(CE.exact_verts(z, j, chart)); ncl += 1
                    v = max(ch, rec['F_lo'] if rec is not None else 0.0); closed[k] = v; store[k] = v if v > 0 else None
                    r = dict(key=list(k), cheap=[ch, name] + ([[float(fd[0]), float(fd[1])]] if fd else []), cert=None)   # the fibre direction used is stored: the verifier recomputes with it
                    if CE.FAN_N:
                        r['lg'] = rec; lgdone.add(k); nlg += rec is not None
                    put(r)
            tb = time.time(); tcor += tb - ta
            # (2) T1 with the values at hand, if it is likely to pass cheaply.  Float heuristic (2026-11-15): with
            #     m = min corner value / F* - 1   and   e0 = the sharp constant of the whole box (geometry probe)
            # the root box of T1 passes iff (1 - e0)(1 + m) > 1, i.e. e0 < m / (1 + m).  On 44 attempts of an E3 block all
            # with (1 - e0)(1 + m) < 0.97 failed or ran out of boxes and all >= 0.985 passed, with 1300-2900 T1 leaves;
            # at e0 <= RHO m / (1 + m) a box needs about 20 leaves, and bisecting first is cheaper than a long T1.
            weak = [i for i, k in enumerate(ks) if k not in tried and closed.get(k, 0.0) < CHEAP_OK * fstar]
            Fl = [store.get(k) for k in ks]; out = None; have = all(f is not None for f in Fl)
            eigzone = any(k in tried or k in lgdone or closed.get(k, 0.0) < CHEAP_OK * fstar for k in ks)   # box with certified corners

            def likely(vals):
                m = min(vals) / fstar - 1
                return m > 0 and e0 <= (RHO_EIG if (USE_EIG and eigzone) else RHO) * m / (1 + m)
            if have and likely(Fl):
                out = run_t1(key, j, lo, hi, Fl, cfg['max_boxes']); tot['first_try'] = tot.get('first_try', 0) + 1
                tot['first_ok'] = tot.get('first_ok', 0) + (out['status'] == 'certified')
            tc = time.time(); tt1 += tc - tb
            # (3) eigenvalue certificates of the corners whose closed-form value is below CHEAP_OK F*, if they can make the
            # box likely (the closed-form value is at least 0.92 of the true one where it matters); otherwise bisect
            if out is None and weak:
                # (3a) polynomial certificates (lgcert.py, Lemma LG; about 30 ms each, 0.975-0.999 of F) for the weak
                # corners, if the box could pass at all (permissive test: every weak corner lifted by 1 / GAIN_MAX)
                wset = set(weak); todo = [i for i in weak if ks[i] not in lgdone]
                if CE.LG_D and todo and (not have or likely([Fl[i] / GAIN_MAX if i in wset else Fl[i] for i in range(len(ks))])):
                    for i in sorted(todo, key=lambda i: closed.get(ks[i], 0.0)):
                        k = ks[i]; r = CE.lg_corner(zs[i], j, chart); lgdone.add(k); nlg += 1
                        put(dict(key=list(k), cheap=[closed.get(k, 0.0), None], cert=None, lg=r))
                        if r is not None:
                            closed[k] = max(closed.get(k, 0.0), r['F_lo'])
                            if store.get(k) is None or r['F_lo'] > store[k]:
                                store[k] = r['F_lo']
                    Fl = [store.get(k) for k in ks]; have = all(f is not None for f in Fl)
                    # refinement: if the box is close (it would pass with the certified corners lifted by 1 / LG_GAIN), the
                    # lowest corners (within 3 % of the minimum) get a certificate of higher degree (90 ms each)
                    if have and not likely(Fl) and CE.LG_D2 > CE.LG_D and likely([Fl[i] / LG_GAIN if ks[i] in lgdone else Fl[i] for i in range(len(ks))]):
                        fmin = min(Fl)
                        for i in range(len(ks)):
                            k = ks[i]
                            if k in lgdone and k not in lgref and k not in tried and Fl[i] <= 1.03 * fmin:
                                r = CE.lg_corner(zs[i], j, chart, CE.LG_D2); lgref.add(k); nlg2 += 1
                                put(dict(key=list(k), cheap=[closed.get(k, 0.0), None], cert=None, lg=r))
                                if r is not None and r['F_lo'] > store[k]:
                                    store[k] = r['F_lo']; closed[k] = max(closed.get(k, 0.0), r['F_lo'])
                        Fl = [store.get(k) for k in ks]
                    tx = time.time(); tcor += tx - tc; tc = tx
                    if have and likely(Fl):
                        out = run_t1(key, j, lo, hi, Fl, cfg['max_boxes']); tx = time.time(); tt1 += tx - tc; tc = tx
            if out is None and weak and USE_EIG:
                # (3b) eigenvalue certificates (MPS, 0.6 s each, 0.99997 of F) for the corners that are still weak, if that
                # can make the box likely: permissive test with the factor LG_GAIN for corners that have a polynomial
                # certificate and GAIN_MAX for the others; then the weakest corner first, and the others are predicted
                # with the ratio found there (2026-11-16: a fixed ratio 0.92 stalled in the low-margin valley).
                weak = [i for i, k in enumerate(ks) if k not in tried and closed.get(k, 0.0) < CHEAP_OK * fstar]; wset = set(weak)
                gain = lambda q: (LG2_GAIN if ks[q] in lgref else (LG_GAIN if ks[q] in lgdone and store.get(ks[q]) is not None else GAIN_MAX))
                if weak and (not have or likely([Fl[i] / gain(i) if i in wset else Fl[i] for i in range(len(ks))])):
                    known = [store[k] for k in ks if k in tried and store.get(k) is not None]
                    g = known[0] if known else None                 # search-window centre from a corner of the same box
                    order = sorted(weak, key=lambda i: closed.get(ks[i], 0.0)); go = True
                    for n_, i in enumerate(order):
                        k = ks[i]; c = CE.certify_corner(zs[i], j, chart, guess=g if (g is not None and g < CE.FMAX_GUESS) else None); nnew += 1
                        tried.add(k); tot['corner_fail'] += c is None
                        rec = dict(key=list(k), cheap=[closed.get(k, 0.0), None], cert=c, eig='ok' if c is not None else 'failed'); put(rec)
                        v = corner_value(rec)
                        if v is not None and (store.get(k) is None or v > store[k]):
                            store[k] = v
                        if c is not None:
                            g = store[k]
                        if nnew % 20 == 0:
                            gk.flush(); os.fsync(gk.fileno())
                        if n_ == 0 and c is not None and have and closed.get(k, 0.0) > 0:
                            ratio = min(1.0, closed[k] / store[k]) * PRED_SLACK
                            pred = [store[ks[q]] if (q not in wset or ks[q] in tried) else Fl[q] / ratio for q in range(len(ks))]
                            if not likely(pred):
                                go = False; tot['eig_stop'] = tot.get('eig_stop', 0) + 1; break
                    td = time.time(); tcor += td - tc
                    Fl = [store.get(k) for k in ks]
                    have = all(f is not None for f in Fl)
                    if go and have and likely(Fl):
                        out = run_t1(key, j, lo, hi, Fl, cfg['max_boxes'])
                    tt1 += time.time() - td
            if out is None:
                tot['skipped'] = tot.get('skipped', 0) + 1
            if out is not None and out['status'] == 'certified':
                # Fl: the corner values used (each is <= a proved lower bound stored in corners.jsonl; the checker replays with these)
                ncert += 1; gc.write(json.dumps(dict(key=list(key), j=j, lo=lo, hi=hi, Fl=Fl, **out)) + '\n'); tot['n']['C'] = tot['n'].get('C', 0) + 1
            else:
                # failed or skipped: bisect by the sector-map variation w (by the vertex displacement if a corner has no value at all)
                nfail += 1; ch = CR.split_box(lo, hi, w if have else CR.displacement(lo, hi, j))
                if out is not None or not have:
                    tot['fail_t1' if out is not None else 'fail_no_corner'] = tot.get('fail_t1' if out is not None else 'fail_no_corner', 0) + 1
                if ch is None:
                    gl.write(json.dumps([list(key), j, lo, hi, 'U']) + '\n'); tot['n']['U'] = tot['n'].get('U', 0) + 1
                else:
                    nodes.setdefault((key, j), []).extend(ch)
        gk.flush(); os.fsync(gk.fileno()); tot['corners'] += nnew; tot['cheap_corners'] = tot.get('cheap_corners', 0) + ncl; tot['lg_corners'] = tot.get('lg_corners', 0) + nlg; tot['lg_refined'] = tot.get('lg_refined', 0) + nlg2
        tot['corner_sec'] += tcor; t3 = t2 + tcor; t4 = t3 + tt1
        t4 = time.time(); tot['t1_sec'] += t4 - t3; tot['attempts'] += len(att); tot['certified'] += ncert; tot['failed'] += nfail; rnd += 1
        for g in (gl, gc):
            g.flush(); os.fsync(g.fileno())
        JS.atomic_json(fst, dict(round=rnd, tot=tot, leaves_off=gl.tell(), cert_off=gc.tell(), nodes=[[list(k), j, b] for (k, j), b in nodes.items()]))
        say('round %d: attempts %d, eigen corners %d, polynomial certificates %d, closed-form corners %d, certified %d, failed %d, open %d | cheap %.0fs corners %.0fs T1 %.0fs' % (
            rnd - 1, len(att), nnew, nlg, ncl, ncert, nfail, sum(len(b) for b in nodes.values()), t2 - t1, t3 - t2, t4 - t3))
    for g in (gl, gc, gk):
        g.close()
    if nodes:                                                      # paused by the time budget: state.json is current, no done.json
        say('paused after %.0fs: open boxes %d' % (time.time() - t0, sum(len(b) for b in nodes.values())), json.dumps(tot)); sys.exit(3)
    JS.atomic_json(os.path.join(bdir, 'done.json'), dict(block=block, chart=chart, roots=len(roots), rounds=rnd, tot=tot, sec_this_start=round(time.time() - t0, 1),
                                                          sha256={os.path.basename(f): sha(f) for f in (fl, fcert, fcor)}))
    say('done', json.dumps(tot))


if __name__ == '__main__':
    main()
