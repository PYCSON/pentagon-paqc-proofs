"""Far-region work count (Claude, 2026-11-10): how many grid.FAR cubes at level LT survive the cheap rigorous whole-cell
tests of far_block.py (OUTSIDE root box -> far_exclude.classify INVALID / CONST -> far_pilot.near NEAR), descending
from the root cube with 64-child splits exactly as far_block --paqc does above paqc_max_side.  The survivors at LT are
the far region's PAQC work list (a superset: a survivor may still turn out INVALID in its children, e.g. edge > 1).
Far cost = (number of survivors) x (per-cube cost from the pent_far3 pilot).  Analysis tool: no certificates.
Output: OUT/count.json (per level: nodes, leaves by type, survivors) and OUT/cand_L<LT>.jsonl (one [L, j] per line).
Usage: python3 far_count.py OUT [--LT 5] [--hours 2]
       python3 far_count.py OUT --sample-from cand_L4.jsonl --n 3000   (2026-11-10: expand a random sample of one level's
       survivors to their 64 children; the next level's survivor count is estimated as mean x total, with a 95% interval;
       the full L5 pass is ~5.5e6 nodes / ~1.5 h and was lost once to a sandbox restart)"""
import os, sys, json, time, argparse
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, '..', 'far', 'pilot'))
import grid as G
import far_block as FB
import far_exclude as FE
import far_pilot as FP


def classify(Lc, j):
    lo, hi = G.FAR.cell_box(Lc, j)
    if FB.outside_root(lo, hi):
        return 'OUTSIDE'
    lab, why = FE.classify([(lo[i], hi[i]) for i in range(6)])
    if lab == 'INVALID':
        return 'INVALID'
    if lab == 'EXCLUDED':
        return 'CONST'
    return 'NEAR' if FP.near(lo, hi) is not None else None


def sample(a):
    import random, math
    par = [json.loads(l) for l in open(a.sample_from)]; random.seed(a.seed); pick = random.sample(par, min(a.n, len(par)))
    t0 = time.time(); per = []; leaves = {}; kids = []
    for Lc, j in pick:
        k = 0
        for L2, j2 in G.FAR.children_cube(Lc, tuple(j)):
            t = classify(L2, j2)
            if t:
                leaves[t] = leaves.get(t, 0) + 1
            else:
                k += 1; kids.append([L2, list(j2)])
        per.append(k)
    m = sum(per) / len(per); sd = (sum((x - m) ** 2 for x in per) / (len(per) - 1)) ** 0.5
    tot = len(par); est = m * tot; half = 1.96 * sd / math.sqrt(len(per)) * tot * math.sqrt(1 - len(per) / tot)
    out = dict(parents_total=tot, parents_sampled=len(pick), seed=a.seed, children_tested=64 * len(pick), leaves=leaves,
               survivors_per_parent_mean=round(m, 3), survivors_per_parent_sd=round(sd, 3),
               hist=dict(sorted({str(v): per.count(v) for v in set(per)}.items(), key=lambda kv: int(kv[0]))),
               next_level_survivors_est=round(est), ci95=[round(est - half), round(est + half)], sec=round(time.time() - t0, 1))
    json.dump(out, open(os.path.join(a.out, 'sample_%s.json' % os.path.basename(a.sample_from).split('.')[0]), 'w'), indent=1)
    with open(os.path.join(a.out, 'sample_children.jsonl'), 'w') as f:
        for c in kids:
            f.write(json.dumps(c) + '\n')
    print(json.dumps(out, indent=1))


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('out'); ap.add_argument('--LT', type=int, default=5); ap.add_argument('--hours', type=float, default=2)
    ap.add_argument('--sample-from', default=''); ap.add_argument('--n', type=int, default=3000); ap.add_argument('--seed', type=int, default=1)
    a = ap.parse_args(); os.makedirs(a.out, exist_ok=True); t0 = time.time()
    if a.sample_from:
        return sample(a)
    wave = [(0, (0,) * 6)]; levels = []
    for L in range(a.LT + 1):
        st = dict(level=L, side=G.FAR.side(L), nodes=len(wave), leaves={}, survivors=0, why={})
        nxt = []; surv = []
        for idx, (Lc, j) in enumerate(wave):
            if time.time() - t0 > 3600 * a.hours:
                st['truncated_at'] = idx; break
            lo, hi = G.FAR.cell_box(Lc, j)
            if FB.outside_root(lo, hi):
                typ, why = 'OUTSIDE', None
            else:
                lab, why = FE.classify([(lo[i], hi[i]) for i in range(6)])
                typ = 'INVALID' if lab == 'INVALID' else 'CONST' if lab == 'EXCLUDED' else None
                if typ is None:
                    h = FP.near(lo, hi)
                    typ, why = ('NEAR', 'h%d' % h) if h is not None else (None, None)
            if typ:
                st['leaves'][typ] = st['leaves'].get(typ, 0) + 1
                if why:
                    w = str(why).split(':')[0][:40]; st['why'][w] = st['why'].get(w, 0) + 1
                continue
            st['survivors'] += 1; surv.append([Lc, list(j)])
            if L < a.LT:
                nxt += list(G.FAR.children_cube(Lc, j))
        st['sec'] = round(time.time() - t0, 1); levels.append(st)
        print(json.dumps({k: v for k, v in st.items() if k != 'why'}), flush=True)
        json.dump(dict(LT=a.LT, levels=levels), open(os.path.join(a.out, 'count.json'), 'w'), indent=1)
        if 'truncated_at' in st:
            break
        if 'truncated_at' not in st:
            with open(os.path.join(a.out, 'cand_L%d.jsonl' % L), 'w') as f:
                for c in surv:
                    f.write(json.dumps(c) + '\n')
        wave = nxt


if __name__ == '__main__':
    main()
