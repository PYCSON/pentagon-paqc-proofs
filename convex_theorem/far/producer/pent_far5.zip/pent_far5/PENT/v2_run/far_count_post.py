"""Post-processing of far_count.py (Claude, 2026-11-10): for the level-LT survivors, the cheap rigorous part of the
PAQC step without any corner certificate: rig_paqc.geometry_bound (whole cell strictly convex pentagons, factor), and
the number of DISTINCT n=5 corners the survivors with geometry ok would need (corners are shared between neighbouring
cubes of the grid).  Far corner cost = distinct corners x seconds per corner; cubes with geometry not ok are split
(their cost is extra and is estimated from the pent_far3 pilot).
Output: OUT/post.json.  Usage: python3 far_count_post.py OUT [--LT 5] [--sample 0]   (sample N: random N survivors)"""
import os, sys, json, time, random, argparse
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, '..', 'scripts'))
import numpy as np
import grid as G
import rig_paqc as R


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('out'); ap.add_argument('--LT', type=int, default=5); ap.add_argument('--sample', type=int, default=0)
    a = ap.parse_args(); t0 = time.time()
    cand = [json.loads(l) for l in open(os.path.join(a.out, 'cand_L%d.jsonl' % a.LT))]
    if a.sample:
        random.seed(1); cand = random.sample(cand, min(a.sample, len(cand)))
    ok = 0; why = {}; corners = set(); fac = []
    for L, j in cand:
        lo, hi = G.FAR.cell_box(L, j); p, rho = G.FAR.cell_p_rho(lo, hi)
        g = R.geometry_bound(p, rho)
        if not g['ok']:
            w = str(g.get('why'))[:40]; why[w] = why.get(w, 0) + 1; continue
        ok += 1; fac.append(float(g['factor'].lower()) if hasattr(g['factor'], 'lower') else float(g['factor']))
        lo2, hi2 = R.cell_endpoints(p, rho)
        for x in R.cell_corners(lo2, hi2):
            corners.add(G.FAR.corner_key([float(v) for v in x]))
    out = dict(LT=a.LT, survivors=len(cand), sampled=bool(a.sample), geometry_ok=ok, geometry_fail=why,
               distinct_corners=len(corners), corners_per_ok_cube=round(len(corners) / max(ok, 1), 3),
               factor_quantiles=[round(float(q), 5) for q in np.quantile(fac, [0, 0.1, 0.5, 0.9, 1])] if fac else None,
               sec=round(time.time() - t0, 1))
    json.dump(out, open(os.path.join(a.out, 'post.json'), 'w'), indent=1); print(json.dumps(out, indent=1))


if __name__ == '__main__':
    main()
