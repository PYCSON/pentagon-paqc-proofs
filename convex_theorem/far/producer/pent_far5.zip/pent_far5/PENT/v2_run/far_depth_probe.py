"""How fast do the far region's hard cubes resolve with depth? (Claude, 2026-11-10; analysis tool, no certificates.)
A level-L survivor of the cheap tests (far_count.py) whose rig_paqc.geometry_bound fails (the cube is not entirely
strictly convex pentagons, typically it straddles the convexity boundary) cannot be certified whole and is split into
64 children.  Each child is classified: cheap leaf (OUTSIDE / INVALID / CONST / NEAR, far_count.classify), PAQC
candidate (geometry_bound ok: needs its n=5 corners + the min-corner form), or unresolved again (geometry fails).
Branching-process estimate: per level, take a random sample of at most --n unresolved parents, expand them, and scale
the per-parent means by the estimated number of unresolved parents at that level.
Output: OUT/depth.json.  Usage: python3 far_depth_probe.py OUT START.jsonl --total N0 [--levels 4] [--n 400] [--seed 1]
  START.jsonl: [L, j] cells of one level (e.g. the far_count sample children, i.e. level-5 survivors);
  --total: estimated number of such cells in the whole far region (e.g. 1.78e6 level-5 survivors)."""
import os, sys, json, time, random, math, argparse
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, '..', 'scripts'))
import grid as G
import far_count as FC
import rig_paqc as R


def geo_ok(L, j):
    lo, hi = G.FAR.cell_box(L, j); p, rho = G.FAR.cell_p_rho(lo, hi)
    g = R.geometry_bound(p, rho)
    return bool(g['ok']), g


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('out'); ap.add_argument('start'); ap.add_argument('--total', type=float, required=True)
    ap.add_argument('--levels', type=int, default=4); ap.add_argument('--n', type=int, default=400); ap.add_argument('--seed', type=int, default=1)
    ap.add_argument('--hours', type=float, default=0.15)
    a = ap.parse_args(); os.makedirs(a.out, exist_ok=True); random.seed(a.seed); t0 = time.time()
    cells = [tuple(json.loads(l)) for l in open(a.start)]
    # level of the start cells: classify them first (they are survivors, so only the geometry test is new)
    sample = random.sample(cells, min(a.n, len(cells))); ok = 0; bad = []
    for L, j in sample:
        g, _ = geo_ok(L, tuple(j))
        ok += g
        if not g:
            bad.append((L, tuple(j)))
    L0 = sample[0][0]; f_ok = ok / len(sample)
    levels = [dict(level=L0, cells_est=a.total, paqc_candidates_est=a.total * f_ok, unresolved_est=a.total * (1 - f_ok),
                   sampled=len(sample), geometry_ok_frac=round(f_ok, 4), sec=round(time.time() - t0, 1))]
    print(json.dumps(levels[-1]), flush=True)
    unresolved = bad; U = a.total * (1 - f_ok)
    for step in range(a.levels):
        if not unresolved or time.time() - t0 > 3600 * a.hours:
            break
        par = random.sample(unresolved, min(a.n, len(unresolved)))
        counts = dict(cheap=0, paqc=0, unresolved=0); leafs = {}; nxt = []
        for L, j in par:
            for L2, j2 in G.FAR.children_cube(L, j):
                t = FC.classify(L2, j2)
                if t:
                    counts['cheap'] += 1; leafs[t] = leafs.get(t, 0) + 1; continue
                g, _ = geo_ok(L2, j2)
                if g:
                    counts['paqc'] += 1
                else:
                    counts['unresolved'] += 1; nxt.append((L2, j2))
        npar = len(par); per = {k: v / npar for k, v in counts.items()}
        lev = dict(level=par[0][0] + 1, parents_sampled=npar, per_parent=per, cheap_leaves=leafs,
                   paqc_candidates_est=U * per['paqc'], unresolved_est=U * per['unresolved'], cheap_est=U * per['cheap'],
                   sec=round(time.time() - t0, 1))
        levels.append(lev); print(json.dumps(lev), flush=True)
        with open(os.path.join(a.out, 'unresolved_L%d.jsonl' % lev['level']), 'w') as f:
            for c in nxt:
                f.write(json.dumps([c[0], list(c[1])]) + '\n')
        U = U * per['unresolved']; unresolved = nxt
        json.dump(dict(start=a.start, total=a.total, levels=levels), open(os.path.join(a.out, 'depth.json'), 'w'), indent=1)
    json.dump(dict(start=a.start, total=a.total, levels=levels), open(os.path.join(a.out, 'depth.json'), 'w'), indent=1)


if __name__ == '__main__':
    main()
