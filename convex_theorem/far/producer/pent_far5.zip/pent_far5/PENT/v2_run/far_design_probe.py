"""Far-region design probe (Claude, 2026-11-11): FLOAT ESTIMATES, NOT RIGOROUS -- to choose a far design before building
it.  Question: if near-degenerate pentagons are excluded through their containing quadrilateral with the quadrilateral's
TRUE F (a quadrilateral table, 4-dim, shared by the whole far region) instead of the constant 2 pi^2, how many 6-dim
PAQC cubes are left?
Per cube X (level L, side s), after the cheap rigorous tests (far_count.classify with HP2 on):
  Q4T  : some j with det4_j > 0 and   min over sample points x of  F(Q4_j(x)) * A(P_x)/A(Q4_j(x))  > F* (1 + MARGIN_T)
         (Q4_j(P) = the quadrilateral of the four half-planes other than edge j's: P inside it, so
          lambda(P) >= lambda(Q) and F(P) >= F(Q) A(P)/A(Q); F(Q) by a float MPS solve -- in production a table lookup)
  PAQC : rig_paqc.geometry_bound with the star2 gate ok (rigorous part) and  factor * min over sample corners F(P_c)
         > F* (1 + MARGIN_P)   (production: all corners certified)
  else : split into the 64 children (as far_block).
Sample points: centre + NS random corners of the cube (a heuristic stand-in for the rigorous enclosures).
Branching-process estimate per level as far_depth_probe.py.  Output OUT/design.json (+ per-level lines on stdout).
Usage: FAR_HP2=1 PAQC_GATE=star2 python3 far_design_probe.py OUT START.jsonl.gz --total N0 [--n 20] [--levels 4] [--jobs 2]"""
import os, sys, json, gzip, time, random, argparse
from multiprocessing import Pool
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, '..', 'scripts'))
sys.path.insert(0, os.path.join(HERE, '..', '..', 'MEAS-01', 'claude', 'scripts', 'C456'))
import numpy as np
import grid as G
import far_count as FC
import rig_paqc as R
from mps import PolyMPS, poly_area

FSTAR = 18.9191; MARGIN_T = 0.005; MARGIN_P = 0.003; NS = int(os.environ.get('PROBE_NS', '4'))


def F_float(V):
    V = np.array(V, float); A = abs(poly_area(V))
    if A < 1e-6:
        return None
    for guess, w in ((25.0, 0.5), (55.0, 0.5), (120.0, 0.6)):
        try:
            lam = PolyMPS(V, K=6).solve(guess / A, width=w, ngrid=21)
            if lam is not None and np.isfinite(lam):
                return float(lam * A)
        except Exception:
            pass
    return None


def verts(x):
    return np.array([[0, 0], [1, 0], x[0:2], x[2:4], x[4:6]], float)


def cross(a, b):
    return a[0] * b[1] - a[1] * b[0]


def q4(V, j):
    """the quadrilateral of P's half-planes without edge j (vertices V_j, V_j+1 replaced by w), or None"""
    a, b = V[(j - 1) % 5], V[j]; c, d = V[(j + 1) % 5], V[(j + 2) % 5]
    u, v = b - a, d - c; den = cross(u, v)
    if abs(den) < 1e-12:
        return None
    t = cross(c - a, v) / den; w = a + t * u
    if t < 1:                          # lines must meet beyond edge j
        return None
    Q = [V[(j + 2) % 5], V[(j + 3) % 5], V[(j + 4) % 5], w]
    return np.array(Q)


def convex(V):
    n = len(V)
    return all(cross(V[(i + 1) % n] - V[i], V[(i + 2) % n] - V[(i + 1) % n]) > 0 for i in range(n))


def test_cube(args):
    L, j, seed = args
    rng = np.random.default_rng(seed)
    t = FC.classify(L, j)
    if t:
        return 'cheap', t
    lo, hi = G.FAR.cell_box(L, j); lo = np.array(lo); hi = np.array(hi)
    pts = [(lo + hi) / 2] + [np.where(rng.integers(0, 2, 6) == 1, hi, lo) for _ in range(NS)]
    Vs = [verts(x) for x in pts]; cvx = [convex(V) for V in Vs]
    # Q4T: only the convex sample points matter (non-convex shapes are not representatives)
    best = None; cv = [V for V, c in zip(Vs, cvx) if c]
    # order the j by the worst area ratio over the convex sample points; F solves only for the two best j
    rank = []
    for jj in range(5):
        Qs = [q4(V, jj) for V in cv]
        if not cv or any(Q is None or not convex(Q) for Q in Qs):
            continue
        rs = [poly_area(V) / poly_area(Q) for V, Q in zip(cv, Qs)]
        if min(rs) * 40 >= FSTAR:
            rank.append((min(rs), jj, Qs, rs))
    for _, jj, Qs, rs in sorted(rank, reverse=True)[:2]:
        mn = 1e9; ok = True
        for Q, r in zip(Qs, rs):
            FQ = F_float(Q)
            if FQ is None:
                ok = False; break
            mn = min(mn, FQ * r)
        if ok and mn > FSTAR * (1 + MARGIN_T):
            best = ('Q4T', jj, mn); break
    if best:
        return 'Q4T', best[1]
    p, rho = G.FAR.cell_p_rho(list(lo), list(hi))
    g = R.geometry_bound(p, rho)
    if g['ok']:
        fac = float(g['factor'].lower())
        Fs = [F_float(V) for V in Vs]
        if all(f is not None for f in Fs) and fac * min(Fs) > FSTAR * (1 + MARGIN_P):
            return 'PAQC', round(fac, 4)
        return 'split', 'paqc_margin'
    return 'split', str(g.get('why'))[:24]


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('out'); ap.add_argument('start'); ap.add_argument('--total', type=float, required=True)
    ap.add_argument('--n', type=int, default=20); ap.add_argument('--levels', type=int, default=4); ap.add_argument('--jobs', type=int, default=2)
    ap.add_argument('--seed', type=int, default=1)
    a = ap.parse_args(); os.makedirs(a.out, exist_ok=True); random.seed(a.seed); t0 = time.time()
    op = gzip.open if a.start.endswith('.gz') else open
    cells = [tuple(json.loads(l)) for l in op(a.start, 'rt')]
    par = random.sample(cells, min(a.n * 8, len(cells)))      # level 0 of the probe: the start cells themselves
    levels = []; U = a.total; todo = [(L, tuple(j)) for L, j in par]; first = True
    with Pool(a.jobs) as pool:
        for step in range(a.levels + 1):
            if not todo:
                break
            if first:
                kids = todo; npar = len(todo)
            else:
                parents = random.sample(todo, min(a.n, len(todo))); npar = len(parents)
                kids = [k for L, j in parents for k in G.FAR.children_cube(L, j)]
            res = pool.map(test_cube, [(L, j, i + 1000 * step) for i, (L, j) in enumerate(kids)])
            cnt = {}; why = {}; nxt = []
            with open(os.path.join(a.out, 'leaves_step%d.jsonl' % step), 'w') as f:
                for (L, j), (typ, w) in zip(kids, res):
                    f.write(json.dumps([L, list(j), typ, w]) + '\n')
            for (L, j), (typ, w) in zip(kids, res):
                cnt[typ] = cnt.get(typ, 0) + 1
                if typ == 'split':
                    why[w] = why.get(w, 0) + 1; nxt.append((L, j))
            per = {k: v / npar for k, v in cnt.items()}
            scale = U if not first else U / npar
            lev = dict(level=kids[0][0] if isinstance(kids[0][0], int) else kids[0][0][0], parents_sampled=npar, per_parent=per,
                       est={k: scale * v for k, v in cnt.items()} if first else {k: U * per[k] for k in per},
                       split_why=why, sec=round(time.time() - t0, 1))
            levels.append(lev); print(json.dumps(lev), flush=True)
            U = lev['est'].get('split', 0); todo = nxt; first = False
            json.dump(dict(start=a.start, total=a.total, margins=[MARGIN_T, MARGIN_P], NS=NS, levels=levels), open(os.path.join(a.out, 'design.json'), 'w'), indent=1)


if __name__ == '__main__':
    main()
