"""Far-region stratified pilot, wave 1, v0.2 (Claude, 2026-11-09/10; design: GPT PENT-16 section 3, seed 20261109).
v0.2: direct n=5 PAQC (far_block --paqc) on L4 cubes, all 24 first-wave macros + the calibration cube; shared n=5
corner cache OUT/corners.jsonl (symlinked into each cube directory).  Below: the v0.1 text (table mode, L5 cubes).
Eight L5 cubes of the far grid, two per K-density tier (Kq1..Kq4) from GPT's first-wave macro list
(far/pilot/far_strata.json: macro i = far_strata.dyadic_boxes(10)[i], a sub-box of the longest-edge root box).  In each
macro the L5 cube (side 3/32) containing a far-K float sample point (far_strata classification, 20,000 points,
numpy seed = seed + macro_id) is taken -- an engineering pilot, not GPT's uniform-in-macro estimator rule (uniform
cubes in low-K macros are almost all INVALID; first try on macro 362 gave a 100% INVALID cube).  Each cube is run with
far_block.py --refine 0 into OUT/m<id>/, all cubes sharing one table OUT/table (exact corner keys, so sharing is safe;
the table's new-corner count per cube is the 'discovery curve' of GPT 3.3).  Per cube: wall seconds, the child's CPU
seconds (resource.getrusage of the far_block process tree), leaves and volumes (stats.json), new table corners.
Resumable: a cube with OUT/m<id>/done.json is skipped.  Output OUT/pilot2_summary.json.
Usage: python3 far_pilot2.py OUT [--workers 8] [--hours 6] [--only id,id]"""
import os, sys, json, time, random, argparse, subprocess, resource
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, '..', 'far', 'pilot')); sys.path.insert(0, os.path.join(HERE, '..', 'far'))
import grid as G

CALIB = ('far1', 'calib', '4,10,1,11,4,6,4')   # the L4 parent of the 11-09 band cube (sandbox, --paqc: 48 PAQC + 16 INVALID L5, ~2 CPU h)
# GPT PENT-16 first wave (logs/far_plan.json, seed 20261109): all 24 macros, 4 per K tier + 4 N + 4 E
WAVE1 = [(362, 'Kq1'), (534, 'Kq1'), (582, 'Kq1'), (959, 'Kq1'), (46, 'Kq2'), (319, 'Kq2'), (409, 'Kq2'), (854, 'Kq2'),
         (141, 'Kq3'), (320, 'Kq3'), (342, 'Kq3'), (567, 'Kq3'), (265, 'Kq4'), (283, 'Kq4'), (672, 'Kq4'), (673, 'Kq4'),
         (122, 'N'), (188, 'N'), (307, 'N'), (392, 'N'), (230, 'E'), (450, 'E'), (540, 'E'), (963, 'E')]
SEED = 20261109
L5 = 4          # cube level of the pilot (v0.2, 2026-11-10: L4 cubes, side 3/16, 64 L5 cubes each)


def macro_box(i):
    import far_strata as FS
    return FS.dyadic_boxes(10)[i]


def k_points(mid, M=20000):
    """float far-K sample points of the macro (far_strata classification: valid, d >= 3/5, not const-excluded)"""
    import numpy as np, far_strata as FS, far_exclude as FE
    box = macro_box(mid); rng = np.random.default_rng(SEED + mid)
    lo = np.array([x[0] for x in box]); hi = np.array([x[1] for x in box]); X = lo + (hi - lo) * rng.random((M, 6))
    v = FS.valid_mask(X); Xv = X[v]
    if not len(Xv):
        return []
    far = FS.dist_c(Xv) >= 0.6; Xf = Xv[far]
    return [x for x in Xf if not FE.float_excluded(x)]


def pick_cube(mid):
    """the L5 cube containing a far-K float sample point drawn uniformly from the macro's K points (an engineering
    pilot choice, NOT the uniform-in-macro rule of an unbiased estimator: uniform cubes in low-K macros are almost all
    INVALID and teach nothing about cost); falls back to the cube at the macro centre when the macro has no K point.
    Returns (j, rule, number of K points)."""
    import random as _r
    s = G.FAR.side(L5); base = G.FAR.base
    K = k_points(mid)
    if K:
        x = _r.Random(SEED + mid).choice(K); rule = 'K-point'
    else:
        box = macro_box(mid); x = [(a + b) / 2 for a, b in box]; rule = 'centre'
    return tuple(int((x[k] - base[k]) // s) for k in range(6)), rule, len(K)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('out'); ap.add_argument('--workers', type=int, default=8)
    ap.add_argument('--hours', type=float, default=6.0); ap.add_argument('--only', default='')
    ap.add_argument('--mode', default='paqc', choices=('paqc', 'table'), help='paqc (v0.3 far_block --paqc, default) or the quadrilateral table')
    a = ap.parse_args(); out = os.path.abspath(a.out); os.makedirs(out, exist_ok=True)
    todo = [CALIB[:2]] + WAVE1
    if a.only:
        todo = [w for w in todo if str(w[0]) in a.only.split(',')]
    summ = []
    for mid, tier in todo:
        d = os.path.join(out, 'm%s' % mid); os.makedirs(d, exist_ok=True); df = os.path.join(d, 'done.json')
        if os.path.exists(df):
            summ.append(json.load(open(df))); continue
        if mid == CALIB[0]:
            cell, rule, nK = CALIB[2], 'calibration (far1 cube)', -1
        else:
            j, rule, nK = pick_cube(mid); cell = '%d,%s' % (L5, ','.join(map(str, j)))
        tf = os.path.join(out, 'corners.jsonl') if a.mode == 'paqc' else os.path.join(out, 'table', 'corners.jsonl'); n0 = sum(1 for _ in open(tf)) if os.path.exists(tf) else 0
        print('macro %d (%s): cube %s (%s, %d K sample points)' % (mid, tier, cell, rule, nK), flush=True)
        r0 = resource.getrusage(resource.RUSAGE_CHILDREN); t0 = time.time()
        with open(os.path.join(d, 'run.log'), 'w') as log:
            cmd = [sys.executable, os.path.join(HERE, 'far_block.py'), d, '--cell', cell, '--workers', str(a.workers), '--hours', str(a.hours)]
            if a.mode == 'paqc':
                cmd += ['--paqc', '--paqc-max-side', '0.2', '--tmin-side', '0.024']
                # share the n=5 corner cache across cubes (exact keys on grid.FAR)
                sc = os.path.join(out, 'corners.jsonl')
                if os.path.exists(sc) and not os.path.exists(os.path.join(d, 'corners.jsonl')):
                    os.symlink(sc, os.path.join(d, 'corners.jsonl'))
                elif not os.path.exists(sc):
                    open(sc, 'a').close(); os.symlink(sc, os.path.join(d, 'corners.jsonl'))
            else:
                cmd += ['--band-hw', '0.012', '--refine', '0', '--table', os.path.join(out, 'table')]
            rc = subprocess.run(cmd,
                                stdout=log, stderr=subprocess.STDOUT).returncode
        r1 = resource.getrusage(resource.RUSAGE_CHILDREN)
        n1 = sum(1 for _ in open(tf)) if os.path.exists(tf) else 0
        st = json.load(open(os.path.join(d, 'stats.json'))) if os.path.exists(os.path.join(d, 'stats.json')) else {}
        rec = dict(macro=mid, tier=tier, cell=cell, pick=rule, K_points=nK, rc=rc, wall_sec=round(time.time() - t0, 1),
                   cpu_sec=round((r1.ru_utime - r0.ru_utime) + (r1.ru_stime - r0.ru_stime), 1),
                   new_table_corners=n1 - n0, table_corners_total=n1, stats=st)
        json.dump(rec, open(df, 'w'), indent=1); summ.append(rec)
        print('  done: wall %.0f s, cpu %.0f s, new corners %d, vol_frac %s' % (rec['wall_sec'], rec['cpu_sec'], rec['new_table_corners'], st.get('vol_frac')), flush=True)
        json.dump(summ, open(os.path.join(out, 'pilot2_summary.json'), 'w'), indent=1)
    json.dump(summ, open(os.path.join(out, 'pilot2_summary.json'), 'w'), indent=1)
    print('ALL DONE' if len(summ) == len(todo) else 'partial')


if __name__ == '__main__':
    main()
