"""Far region run directory (Claude, 2026-11-15; FAR_SPEC 9.10).  DRAFT: init and status only; blocks are run by
far_block.py (one process per block).
  python3 far_runner.py init RUN --chart std|E2|E3 [--qtable DIR] [--std-keys T4_DIR] [--blocks NAME,NAME,...]
        writes RUN/config.json (once) and RUN/CHART/roots.json: {blocks: {name: [[key, lo4, hi4, LB], ...]}, neighbours}
        block name = the first two root indices 'i_j'; neighbours = the existing blocks with both indices within 1.
        LB = bound of F on the convex quadrilaterals of the root from the quadrilateral table (0 if none: the cheap
        phase then uses the closed-form bounds only).
  python3 far_runner.py run RUN [--jobs N] [--block-sec S]     every block that is not done, N at a time; restartable.
        --block-sec: time budget per block and start; a block over budget is paused (state kept) and continued by a later run
  python3 far_runner.py status RUN
A complete run needs: every chart initialised with ALL its roots, every block done, no leaf with label U."""
import os, sys, json, argparse
HERE = os.path.dirname(os.path.abspath(__file__))
for p in ('.', '../far', '../far/pilot', '../scripts', '../v2_cover'):
    sys.path.insert(0, os.path.join(HERE, p))
import cut_run as CR
import qchart as QC
import t4table as T4
import jsonl_safe as JS


def block_of(chart, key):
    return '%d_%d' % ((key[1], key[2]) if chart == 'std' else (key[0], key[1]))


def init(a):
    os.makedirs(os.path.join(a.run, a.chart), exist_ok=True); fc = os.path.join(a.run, 'config.json')
    if not os.path.exists(fc):
        JS.atomic_json(fc, dict(cut=dict(CR.CFG), minw=CR.MINW, smallw=CR.SMALLW, S0=1 / 16, note='far region, cut chart; FAR_SPEC 9.7-9.10'))
    cfg = json.load(open(fc))['cut']; S0 = 1 / 16
    if a.chart == 'std':
        roots = QC.std_roots(a.std_keys, S0)                       # every cell classified 'build' (t4table classes.json)
    else:
        roots = [(k, lo4, hi4, 0.0) for k, lo4, hi4 in QC.edge_roots(a.chart, cfg['H2'] if a.chart == 'E2' else cfg['H3'], S0)]
    qt = {}
    if a.qtable:
        for d in JS.read_jsonl(os.path.join(a.qtable, 'cells.jsonl')):
            if d.get('LB') is not None:
                qt[tuple(d['key'])] = d['LB']
    blocks = {}
    for k, lo4, hi4, LB in roots:
        blocks.setdefault(block_of(a.chart, k), []).append([list(k), lo4, hi4, max(LB, qt.get(tuple(k), 0.0))])
    if a.blocks:
        keep = set(a.blocks.split(',')); blocks = {b: v for b, v in blocks.items() if b in keep}
    if a.keys:                                                # testing only: these roots ('i,j,k,l;i,j,k,l')
        ks = set(tuple(int(v) for v in t.split(',')) for t in a.keys.split(';'))
        blocks = {b: [r for r in v if tuple(r[0]) in ks] for b, v in blocks.items()}; blocks = {b: v for b, v in blocks.items() if v}
    if a.max_roots:                                           # testing only: a run made this way is not complete
        blocks = {b: v[:a.max_roots] for b, v in blocks.items()}
    nb = {}
    for b in blocks:
        i, j = [int(v) for v in b.split('_')]
        nb[b] = ['%d_%d' % (i + di, j + dj) for di in (-1, 0, 1) for dj in (-1, 0, 1) if (di or dj) and '%d_%d' % (i + di, j + dj) in blocks]
    JS.atomic_json(os.path.join(a.run, a.chart, 'roots.json'), dict(chart=a.chart, blocks=blocks, neighbours=nb, complete=not a.blocks and not a.max_roots and not a.keys, qtable=a.qtable))
    print('chart %s: %d blocks, %d roots, %d with a table bound' % (a.chart, len(blocks), sum(len(v) for v in blocks.values()), sum(1 for v in blocks.values() for r in v if r[3] > 0)))


def status(a):
    for chart in ('std', 'E2', 'E3'):
        f = os.path.join(a.run, chart, 'roots.json')
        if not os.path.exists(f):
            continue
        info = json.load(open(f)); done = 0; tot = {}; cor = 0; att = 0; paused = 0; sec = 0.0
        for b in info['blocks']:
            d = os.path.join(a.run, chart, 'blocks', b, 'done.json'); st = os.path.join(a.run, chart, 'blocks', b, 'state.json'); t = None
            if os.path.exists(d):
                done += 1; t = json.load(open(d))['tot']
            elif os.path.exists(st):
                paused += 1; t = json.load(open(st))['tot']       # started, not finished (running or paused)
            if t is not None:
                cor += t['corners']; att += t['attempts']; sec += t['cheap_sec'] + t['corner_sec'] + t['t1_sec']
                for k, v in t['n'].items():
                    tot[k] = tot.get(k, 0) + v
        print('%s: blocks done %d/%d, unfinished %d, CPU %.1f h, attempts %d, eigen corners %d, leaves %s' % (chart, done, len(info['blocks']), paused, sec / 3600, att, cor, tot))


MIN_FREE_GB = 5


def _one(args):
    run, chart, b = args
    import subprocess
    import shutil
    if shutil.disk_usage(run).free < MIN_FREE_GB * 2 ** 30:       # disk guard: do not start a block on a nearly full disk
        return chart, b, 5
    bdir = os.path.join(run, chart, 'blocks', b); os.makedirs(bdir, exist_ok=True)
    with open(os.path.join(bdir, 'stdout.log'), 'a') as f:
        rc = subprocess.run([sys.executable, os.path.join(HERE, 'far_block.py'), run, chart, b], stdout=f, stderr=subprocess.STDOUT).returncode
    return chart, b, rc


def run_all(a):
    """run every block that is not done, a.jobs at a time (one far_block.py process per block).  Safe to start again
    after a stop: finished blocks are skipped, an interrupted block resumes from its state.json.  A second runner on the
    same RUN is refused (lock file with the pid)."""
    from multiprocessing import Pool
    lock = os.path.join(a.run, 'runner.pid')
    if os.path.exists(lock):
        # The lock is stale unless that pid is alive AND is a far_runner process (after a reboot the old pid may belong
        # to an unrelated process).  A really active runner ends this call with exit code 2, never with 0.
        try:
            pid = int(open(lock).read().strip()); os.kill(pid, 0)
            with open('/proc/%d/cmdline' % pid, 'rb') as f:
                active = b'far_runner.py' in f.read()
        except (ValueError, ProcessLookupError, PermissionError, OSError):
            active = False
        if active:
            print('another runner is active (pid %d): not starting' % pid, flush=True); sys.exit(2)
    with open(lock, 'w') as f:
        f.write(str(os.getpid()))
    try:
        todo = []
        if a.block_sec:
            os.environ['PENT_BLOCK_SEC'] = str(a.block_sec)       # inherited by the block processes
        for chart in a.charts.split(','):
            f = os.path.join(a.run, chart, 'roots.json')
            if os.path.exists(f):
                for b in sorted(json.load(open(f))['blocks']):
                    if not os.path.exists(os.path.join(a.run, chart, 'blocks', b, 'done.json')):
                        todo.append((a.run, chart, b))
        # Order: four colours (i0 mod 2, i1 mod 2) of the block indices, one colour after the other.  Blocks of one
        # colour share no corner; a block reads the corner files of its neighbours when it starts, so the later
        # colours reuse the eigenvalue certificates of the earlier ones (up to a factor 4 in the heavy regions).
        def colour(t):
            i0, i1 = (int(v) for v in t[2].split('_'))
            return (('E2', 'E3', 'std').index(t[1]), i0 % 2, i1 % 2)
        todo.sort(key=lambda t: (colour(t), t[2]))
        print('blocks to run: %d, jobs %d' % (len(todo), a.jobs), flush=True)
        left = 0; err = 0
        with Pool(a.jobs) as pool:
            for chart, b, rc in pool.imap_unordered(_one, todo, chunksize=1):
                left += rc == 3; err += rc not in (0, 3)
                print('%s block %s %s: %s' % (__import__('time').strftime('%Y-%m-%d %H:%M:%S'), chart, b, 'ok' if rc == 0 else ('paused (time budget)' if rc == 3 else ('NOT STARTED: less than %d GB free on the disk' % MIN_FREE_GB if rc == 5 else 'ERROR rc %d' % rc))), flush=True)
    finally:
        if os.path.exists(lock):
            os.remove(lock)
    print('this pass: paused %d, errors %d' % (left, err), flush=True)
    sys.exit(1 if err else (3 if left else 0))                   # 3: some blocks are paused, run again to continue them


if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('cmd', choices=('init', 'status', 'run')); ap.add_argument('run'); ap.add_argument('--jobs', type=int, default=2); ap.add_argument('--block-sec', type=float, default=0.0); ap.add_argument('--charts', default='E2,E3,std')
    ap.add_argument('--chart', default='std'); ap.add_argument('--qtable', default=''); ap.add_argument('--std-keys', default=''); ap.add_argument('--blocks', default=''); ap.add_argument('--max-roots', type=int, default=0); ap.add_argument('--keys', default='')
    a = ap.parse_args(); {'init': init, 'status': status, 'run': run_all}[a.cmd](a)
