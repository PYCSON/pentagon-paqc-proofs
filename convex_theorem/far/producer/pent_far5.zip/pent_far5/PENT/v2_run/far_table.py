"""Quadrilateral table with a min-tree for the far region (Claude, 2026-11-07; FAR_SPEC.md section 4).
Fine cells: dyadic 4-D cells of side S0 = 1/32 in the normalised quadrilateral chart (q0 = 0, q1 = 1, X4 = (q2, q3)),
key (0, i0, i1, i2, i3); bound = factor * min over the 16 corner certificates (rig_paqc_n C4, the n = 4 PAQC min-corner
form with its convexity gate, epsilon < 1 and geometry factor > 0), or None when a corner or the gate fails.
Coarse cells: level 1 (side 1/16, 16 fine children) and level 2 (side 1/8, 256 fine descendants); their bound is the
min of ALL children's bounds and exists only when every child is certified (None otherwise).  Corner certificates are
keyed by the exact corner coordinates and the solver settings (K, nseg); corners of different settings never mix.
Query(lo4, hi4, depth): the fine cells meeting the box; a fine cell without a bound (gate straddles the convexity
boundary, or a corner failed) is refined up to `depth` halvings (levels -1, -2: sides 1/64, 1/128); a cell certified
to contain no convex quadrilateral counts as +inf (noncvx_cert, 2026-11-08, FAR_SPEC section 9 fix 1).  Returns (min
bound over the cover or None, list of cells (any level) still needing corners).  Everything is
persisted (corners.jsonl, cells.jsonl) and reloaded; cell bounds are recomputed from corners if S0 or settings change."""
import os, sys, json, math, itertools
import numpy as np
from flint import arb, ctx
HERE = os.path.dirname(os.path.abspath(__file__))
for p in ('../v2_quad', '../far/qtable', '../scripts'):
    sys.path.insert(0, os.path.join(HERE, p))
import dimdesc as DD
import pentquad as PQ
from fem_check import lam1


def corner_job(args):
    key, x, K, nseg, prec = args
    ctx.prec = prec
    Q = np.array([[0, 0], [1, 0], [x[0], x[1]], [x[2], x[3]]], float)
    try:
        guess = lam1(Q, 24) * abs(PQ.area(Q))
        F, r = DD.C4.corner_F(np.array(x, float), guess, K=K, nseg=nseg)
        return key, (None if F is None else float(F)), float(r['mu'].upper())
    except Exception as exc:
        return key, None, repr(exc)[:80]


class MinTree:
    def __init__(self, out, S0=1 / 32, K=8, nseg=300):
        os.makedirs(out, exist_ok=True)
        self.S0, self.K, self.nseg = S0, K, nseg; self.tag = (K, nseg, ctx.prec)   # arb precision is part of the key (2026-11-08)
        self.fc = os.path.join(out, 'corners.jsonl'); self.fl = os.path.join(out, 'cells.jsonl')
        self.corners = {}; self.cells = {}; self.corner_sec = 0.0; self.new_corners = 0
        if os.path.exists(self.fc):
            for line in open(self.fc):
                d = json.loads(line)
                if tuple(d['tag']) == self.tag:
                    self.corners[tuple(d['key'])] = d['F']
        if os.path.exists(self.fl):
            for line in open(self.fl):
                d = json.loads(line)
                if d['S0'] == S0 and tuple(d['tag']) == self.tag:
                    self.cells[tuple(d['key'])] = d['LB']          # json: Infinity round-trips

    # geometry of keys
    def side(self, lev):
        return self.S0 * 2 ** lev

    def box(self, key):
        lev, idx = key[0], key[1:]; s = self.side(lev); lo = [i * s for i in idx]; return lo, [v + s for v in lo]

    def children(self, key):
        lev, idx = key[0], key[1:]
        return [(lev - 1,) + tuple(2 * idx[i] + d[i] for i in range(4)) for d in itertools.product((0, 1), repeat=4)]

    def fine_cells_for(self, lo4, hi4):
        s = self.S0; rng = [range(math.floor(lo4[i] / s), math.floor(hi4[i] / s) + 1) for i in range(4)]
        return [(0,) + idx for idx in itertools.product(*rng)]

    # corners
    def corner_key(self, x):
        return tuple(repr(float(v)) for v in x)

    def missing_corners(self, fine_keys):
        need = {}
        for key in fine_keys:
            if key in self.cells:
                continue
            lo, hi = self.box(key)
            for x in DD.C4.cell_corners(lo, hi):
                ck = self.corner_key(x)
                if ck not in self.corners:
                    need[ck] = [float(v) for v in x]
        return need

    def add_corners(self, results):
        with open(self.fc, 'a', buffering=1) as f:
            for key, F, info in results:
                self.corners[key] = F; self.new_corners += 1
                f.write(json.dumps(dict(key=list(key), tag=list(self.tag), F=F, mu=info)) + '\n')

    # bounds
    INF = float('inf')

    def noncvx_cert(self, lo, hi):
        """True when the 4-D box contains NO convex quadrilateral: for some directed edge (i, i+1) and vertex j the signed
        area d_ij = cross(V_{i+1} - V_i, V_j - V_i) has a rigorous upper bound <= 0 at every corner of the box.  Each d_ij is
        multiaffine in the chart coordinates (V_0, V_1 fixed; each free vertex enters affinely), so its sup over the box is
        attained at a corner.  The far-region query encloses circumscribed quadrilaterals Q (edge k of a convex pentagon deleted,
        the two neighbouring edge lines extended to W; dimdesc.box_geometry requires turns > 0 and C > 0, so Q is convex
        and positively oriented, and the chart map q -> (q - q0)/(q1 - q0) is a similarity), so such a cell meets no image
        and contributes nothing to a query minimum (LB = +inf).  Same sign convention as C4.convexity_gate (d > 0 for all pairs = convex)."""
        n = 4; corners = DD.C4.cell_corners(lo, hi); Vs = [DD.C4.verts(x) for x in corners]
        for i in range(n):
            for j in range(n):
                if j in (i, (i + 1) % n):
                    continue
                top = -self.INF
                for V in Vs:
                    a, b, c = V[i], V[(i + 1) % n], V[j]
                    d = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
                    top = max(top, float(d.upper()))
                if top <= 0:
                    return True
        return False

    def fine_lb(self, key):
        """bound of a table cell at any level <= 0 (level 0 = S0, negative = refinements): factor * min corner F, +inf for
        a cell certified to contain no convex quadrilateral (noncvx_cert), None when the geometry gate or a corner fails
        (cached: 'why' in cells.jsonl), None uncached when a corner has not been computed yet."""
        if key in self.cells:
            return self.cells[key]
        lo, hi = self.box(key); Fl = []; why = None
        if self.noncvx_cert(lo, hi):
            LB = self.INF; why = 'noncvx'
        else:
            for x in DD.C4.cell_corners(lo, hi):
                ck = self.corner_key(x)
                if ck not in self.corners:
                    return None                   # corner not computed yet: no record
                F = self.corners[ck]
                if F is None:
                    why = 'corner_fail'; break
                Fl.append(F)
            LB = None
            if why is None:
                g = DD.C4.geometry_bound_box(lo, hi)
                if g['ok']:
                    LB = float((g['factor'] * DD.PN.amin([arb(v) for v in Fl])).lower())
                else:
                    why = g['why']
        self.cells[key] = LB
        with open(self.fl, 'a') as f:
            f.write(json.dumps(dict(key=list(key), S0=self.S0, tag=list(self.tag), LB=LB, why=why)) + '\n')
        return LB

    def lb_refined(self, key, depth):
        """(bound, missing): the cell's own bound when it has one; otherwise, down to `depth` halvings, the min over its
        16 children (recursively).  missing = sub-cells (any level) whose corners must be computed first."""
        v = self.fine_lb(key)
        if v is not None:
            return v, []
        if key not in self.cells:
            return None, [key]
        if depth <= 0:
            return None, []
        vals = []; missing = []
        for c in self.children(key):
            vc, m = self.lb_refined(c, depth - 1); missing += m; vals.append(vc)
        if missing:
            return None, missing
        return (None if any(x is None for x in vals) else min(vals)), []

    def lb(self, key):
        """bound of a cell at any level: min over all children (fine: own); None unless all are certified."""
        if key[0] == 0:
            return self.fine_lb(key)
        vals = [self.lb(c) for c in self.children(key)]
        return None if any(v is None for v in vals) else min(vals)

    def query(self, lo4, hi4, depth=0):
        """(min bound over the fine cells meeting the box or None, keys (any level) whose corners are missing).
        A fine cell without a bound is refined up to `depth` halvings (lb_refined); cells certified free of convex
        quadrilaterals count as +inf.  The caller computes the missing corners and queries again (at most depth + 1 rounds)."""
        fine = self.fine_cells_for(lo4, hi4); missing = []; vals = []
        for key in fine:
            v, m = self.lb_refined(key, depth); missing += m; vals.append(v)
        if missing:
            return None, missing
        v = None if any(x is None for x in vals) else min(vals)
        return (None if v == self.INF else v), []
