"""Far-region tier probe (Claude, 2026-11-12; FLOAT, analysis only).  Uniform sample of the valid far set
V = {convex representatives, d >= 3/5} (far_strata.valid_mask / dist_c); for each point: F(P), the five containing
quadrilaterals Q4_j with area ratio r_j and F(Q4_j), the pointwise tests S (2 pi^2 r), HP, T (F(Q) r).
Output OUT/tier.jsonl (one record per point) -- which tool can prove what, and with which margin.
Usage: python3 far_tier_probe.py OUT [--n 300000] [--seed 1] [--jobs 2]"""
import os, sys, json, argparse, math
from multiprocessing import Pool
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, '..', 'far')); sys.path.insert(0, os.path.join(HERE, '..', 'far', 'pilot'))
import numpy as np
import far_design_probe as FD
FS_ = None


def job(x):
    x = np.array(x); V = FD.verts(x); A = FD.poly_area(V)
    per = sum(np.linalg.norm(V[(i + 1) % 5] - V[i]) for i in range(5))
    rec = dict(x=[float(v) for v in x], A=float(A), HP=float(math.pi ** 2 * per ** 2 / (16 * A)), F=FD.F_float(V), q=[])
    for j in range(5):
        Q = FD.q4(V, j)
        if Q is None or not FD.convex(Q):
            rec['q'].append(None); continue
        r = A / FD.poly_area(Q)
        rec['q'].append([float(r), FD.F_float(Q) if r * 45 > FD.FSTAR else None])
    return rec


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('out'); ap.add_argument('--n', type=int, default=300000)
    ap.add_argument('--seed', type=int, default=1); ap.add_argument('--per', type=int, default=300); ap.add_argument('--jobs', type=int, default=2)
    a = ap.parse_args(); os.makedirs(a.out, exist_ok=True)
    import far_strata as FS, far_exclude as FE
    rng = np.random.default_rng(a.seed); lo = np.array([b[0] for b in FE.ROOT]); hi = np.array([b[1] for b in FE.ROOT])
    X = lo + (hi - lo) * rng.random((a.n, 6)); v = FS.valid_mask(X); Xv = X[v]; d = FS.dist_c(Xv)
    vol = float(np.prod(hi - lo)); pts = []; meta = dict(n=a.n, valid=int(v.sum()), vol_valid=vol * v.sum() / a.n, strata={})
    # strata by d = min over the 10 labellings of |phi_h x - c| (2026-11-12: all valid representatives, not only far)
    for name, dlo, dhi in (('d<0.3', 0, 0.3), ('0.3-0.45', 0.3, 0.45), ('0.45-0.6', 0.45, 0.6), ('0.6-0.75', 0.6, 0.75), ('0.75-0.9', 0.75, 0.9), ('>=0.9', 0.9, 99)):
        m = (d >= dlo) & (d < dhi); idx = np.flatnonzero(m); take = idx[:a.per]
        meta['strata'][name] = dict(count=int(m.sum()), vol=vol * m.sum() / a.n, taken=int(len(take)))
        pts += [(list(Xv[i]), float(d[i]), name) for i in take]
    print(json.dumps(meta), flush=True); json.dump(meta, open(os.path.join(a.out, 'meta.json'), 'w'))
    with Pool(a.jobs) as pool, open(os.path.join(a.out, 'tier.jsonl'), 'w') as f:
        for i, rec in enumerate(pool.imap(job, [p[0] for p in pts], chunksize=4)):
            rec['d'] = pts[i][1]; rec['stratum'] = pts[i][2]
            f.write(json.dumps(rec) + '\n'); f.flush()


if __name__ == '__main__':
    main()
