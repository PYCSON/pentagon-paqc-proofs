"""Structural self-check of a far-region run (Claude, 2026-11-16).  Producer side: it uses the production modules, so
it is NOT the independent checker; it catches driver and bookkeeping errors (holes, overlaps, stale records, corner
values that are not backed by a stored bound) before a run is handed over.

For every finished block of RUN/CHART (done.json present):
  1. SHA256 of leaves.jsonl, cert.jsonl, corners.jsonl against done.json.
  2. Tiling: for every root box and j in (3, 0) the boxes of leaves.jsonl and cert.jsonl
       - lie in  root x [0,1]^2,
       - are pairwise interior-disjoint,
       - have total volume = volume of root x [0,1]^2,
     all in exact rational arithmetic (binary64 box ends are dyadic rationals).  Hence they tile the root column.
  3. Labels: only known labels, no U.
  4. Certified boxes: status 'certified', 64 corner values Fl, and every Fl[i] <= the largest proved value stored for
     that corner in corners.jsonl of the block or of a neighbouring block (closed-form value, or eigenvalue certificate
     re-evaluated by rig_paqc.cert_F_lo).
  5. --replay N: for N random certified boxes T1 is replayed with the stored Fl (must certify), for N random
     closed-form corner records the value is recomputed (must be >= the stored one), and N random polynomial
     certificates (lgcert.py) are re-proved with a recomputed flux (lgcert.recheck).
  6. --relabel N (2026-11-17): for N random leaves of the block the closed-form label is recomputed by the production
     label code (cut_run.tree_job on the single box) and must close the box with the same label.  -1: every leaf.
  7. --table N (2026-11-17): the bound of every root of the block is checked against the quadrilateral table
     (qtable/cells.jsonl): closed-form entries are recomputed, LG entries (how 'lg') are re-proved part by part (N random
     roots per block, -1: all; the parts must cover the cell).  Entries from the tangent bound (how 'tv') cannot be
     re-proved here and are counted as 'table bounds not re-proved'; with --strict-table they are an error.
  8. --complete (2026-11-17): all three charts are present, their roots cover the root ranges (check_roots: every other
     cell is re-classified as containing no admissible quadrilateral) and every block is finished.
Usage: python3 far_verify.py RUN [--charts E2,E3,std] [--blocks a_b,...] [--replay N] [--relabel N] [--table N] [--strict-table] [--complete] [--seed S]
       (N = -1: everything)
Exit code 0 and a last line 'VERIFY OK' if every check passes."""
import os, sys, json, argparse, random, hashlib
from fractions import Fraction
HERE = os.path.dirname(os.path.abspath(__file__))
for p in ('.', '../scripts', '../far', '../far/pilot', '../v2_cover'):
    sys.path.insert(0, os.path.join(HERE, p))
import rig_paqc as R
import cutcell as CE
import cut_run as CR
import jsonl_safe as JS
import far_block as FBK

LABELS = {'T', 'X', 'TX', 'V', 'S', 'R', 'O', 'N', 'H', 'E2', 'E3'}


def sha(f):
    h = hashlib.sha256()
    with open(f, 'rb') as g:
        for b in iter(lambda: g.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def fr(v):
    return Fraction(float(v))


def vol(lo, hi):
    v = Fraction(1)
    for a, b in zip(lo, hi):
        v *= fr(b) - fr(a)
    return v


def disjoint(boxes):
    """True if the boxes (lists of (lo, hi) with Fraction ends) are pairwise interior-disjoint.  Sweep over the first
    coordinate; pairs that overlap there are compared in all coordinates."""
    ev = sorted(range(len(boxes)), key=lambda i: boxes[i][0][0]); act = []
    for i in ev:
        lo, hi = boxes[i]; act = [k for k in act if boxes[k][1][0] > lo[0]]
        for k in act:
            lo2, hi2 = boxes[k]
            if all(lo[d] < hi2[d] and lo2[d] < hi[d] for d in range(len(lo))):
                return False
        act.append(i)
    return True


def check_labels(run, chart, block, roots, n, rng, out, cfg):
    """recompute the labels of n random leaves (all if n < 0)"""
    bad = []; LBs = {tuple(k): LB for k, lo4, hi4, LB in roots}
    leaves = list(JS.read_jsonl(os.path.join(run, chart, 'blocks', block, 'leaves.jsonl')))
    for d in (leaves if n < 0 else rng.sample(leaves, min(n, len(leaves)))):
        key, j, lo, hi, lab = d; out['relabelled'] = out.get('relabelled', 0) + 1
        res = CR.tree_job((tuple(key), j, LBs[tuple(key)], [(list(lo), list(hi))], dict(cfg, chart=chart, leaves=True, node_cap=1)))
        got = res[6]
        if not (len(got) == 1 and got[0][2] == lab and got[0][2] in LABELS):
            bad.append('label %s of the leaf %s j %d %s-%s not reproduced (%s)' % (lab, key, j, lo, hi, [g[2] for g in got][:3]))
    return bad


def check_table(chart, block, roots, cells, n, rng, out, strict):
    """the bounds of the roots against the quadrilateral table"""
    import qtable as QT, itertools
    bad = []; lgroots = []
    for key, lo4, hi4, LB in roots:
        if not LB:
            continue                                               # no table bound claimed for this root
        rec = cells.get(tuple(key)); out['table_roots'] = out.get('table_roots', 0) + 1
        if rec is None or rec.get('LB') is None or rec['LB'] < LB:
            bad.append('root %s: bound %r not backed by the table' % (key, LB)); continue
        if rec['how'] == 'lg':
            lgroots.append((key, lo4, hi4, rec)); continue
        if rec['how'] == 'tv':
            out['table_tv'] = out.get('table_tv', 0) + 1
            if strict:
                bad.append('root %s: tangent-bound table entry (not re-proved)' % (key,))
            continue
        c, how, nc = QT.closed_lb(lo4, hi4, rec.get('chart', chart))
        if not nc and c < rec['LB']:
            bad.append('root %s: closed-form table bound %r not reproduced (%r)' % (key, rec['LB'], c))
    for key, lo4, hi4, rec in (lgroots if n < 0 else rng.sample(lgroots, min(n, len(lgroots)))):
        ch = rec.get('chart', chart); parts = rec['lg']['parts']; N = rec['lg'].get('N'); out['table_lg'] = out.get('table_lg', 0) + 1
        boxes = {(tuple(p[0]), tuple(p[1])): p for p in parts}
        if (tuple(lo4), tuple(hi4)) not in boxes:                 # the 16 sub-cells: a missing one must have no convex member
            mid = [(a + b) / 2 for a, b in zip(lo4, hi4)]
            for sg in itertools.product((0, 1), repeat=4):
                l2 = tuple(mid[i] if sg[i] else lo4[i] for i in range(4)); h2 = tuple(hi4[i] if sg[i] else mid[i] for i in range(4))
                if (l2, h2) not in boxes and not QT.closed_lb(list(l2), list(h2), ch)[2]:
                    bad.append('root %s: sub-cell %s without a bound' % (key, l2))
        if min(p[2] for p in parts) < rec['LB']:
            bad.append('root %s: table bound above the bounds of its parts' % (key,))
        for l2, h2, Lp, how in parts:
            if how == 'lg':
                if not QT.lg_check(l2, h2, ch, Lp, N):
                    bad.append('root %s: LG bound %r of the part %s not re-proved' % (key, Lp, l2))
            elif QT.closed_lb(l2, h2, ch)[0] < Lp:
                bad.append('root %s: closed-form bound of the part %s not reproduced' % (key, l2))
    return bad


def check_roots(chart, info, cfg, out):
    """--complete (2026-11-17): the roots of the chart cover its domain.  Every cell of side 1/16 of the chart's root
    range is a root, or contains no convex quadrilateral (recomputed), or -- standard chart only -- has an edge longer
    than the base on the whole cell (recomputed; the cut chart needs only quadrilaterals whose base is a longest edge).
    Root ranges: std t4table.BOUNDS (q2 within distance 1 of q1, q3 within distance 1 of q0, both above the base);
    E2 / E3: qchart.E2_RANGE / E3_RANGE with h in [0, H] (qchart.defer hands over only q-boxes with q3y >= 1/4 and
    K < H2 (1 - q3x), resp. q2x >= 1/4 and D < H3 q2x; then |a| <= (1 + H2) / (1/4) = 4.5 and |b| <= 1 / (1/4) = 4).
    Also: the box of every root is its cell, the run was initialised without restrictions, no root twice."""
    import itertools
    import qchart as QC, t4table as T4
    bad = []; S0 = 1 / 16; have = {}
    if not info.get('complete'):
        bad.append('roots.json was made for a part of the chart (--blocks / --keys / --max-roots)')
    for b, v in info['blocks'].items():
        for r in v:
            k = tuple(r[0])
            if k in have:
                bad.append('root %s twice' % (k,))
            have[k] = (r[1], r[2])
    n = 0
    if chart == 'std':
        rg = [range(int(round(lo / S0)), int(round(hi / S0))) for lo, hi in T4.BOUNDS]
        assert all(r.start * S0 == lo and r.stop * S0 == hi for r, (lo, hi) in zip(rg, T4.BOUNDS))
        for idx in itertools.product(*rg):
            key = (0,) + idx; lo, hi = T4.cell_box(key, S0); n += 1
            if key in have:
                if [list(lo), list(hi)] != [list(have[key][0]), list(have[key][1])]:
                    bad.append('root %s: box differs from its cell' % (key,))
            elif not (T4.noncvx(lo, hi) or T4.outside(lo, hi)):
                bad.append('cell %s is not a root and is neither non-convex nor outside' % (key,))
    else:
        xr, yr, ar = QC.E2_RANGE if chart == 'E2' else QC.E3_RANGE; H = cfg['H2'] if chart == 'E2' else cfg['H3']
        assert (xr.start, xr.stop, yr.start, yr.stop, ar.start, ar.stop) == ((-16, 16, 4, 16, -72, 72) if chart == 'E2' else (4, 32, 0, 16, -64, 64)) and H == 1 / 8
        for key in itertools.product(xr, yr, ar, range(int(round(H / S0)))):
            lo = [i * S0 for i in key]; hi = [v + S0 for v in lo]; n += 1
            if key in have:
                if [lo, hi] != [list(have[key][0]), list(have[key][1])]:
                    bad.append('root %s: box differs from its cell' % (key,))
            elif not QC.noncvx(QC.invariants(lo, hi, chart)):
                bad.append('cell %s is not a root and may contain a convex quadrilateral' % (key,))
    if len(have) > n:
        bad.append('roots outside the root range')
    out['range_cells'] = n; out['roots'] = len(have)
    return bad


def check_block(run, chart, block, roots, neigh, replay, rng, out):
    bdir = os.path.join(run, chart, 'blocks', block); bad = []
    dj = json.load(open(os.path.join(bdir, 'done.json')))
    for name in ('leaves.jsonl', 'cert.jsonl', 'corners.jsonl'):
        want = dj.get('sha256', {}).get(name)
        if want is not None and want != sha(os.path.join(bdir, name)):
            bad.append('sha256 mismatch ' + name)
    cols = {}
    for key, lo4, hi4, LB in roots:
        for j in (3, 0):
            cols[(tuple(key), j)] = ([fr(v) for v in lo4] + [Fraction(0)] * 2, [fr(v) for v in hi4] + [Fraction(1)] * 2, [])
    nl = 0
    for d in JS.read_jsonl(os.path.join(bdir, 'leaves.jsonl')):
        key, j, lo, hi, lab = d; nl += 1; out['labels'][lab] = out['labels'].get(lab, 0) + 1
        if lab not in LABELS:
            bad.append('label %s at %s' % (lab, key))
        c = cols.get((tuple(key), j))
        if c is None:
            bad.append('leaf of an unknown root %s' % (key,)); continue
        c[2].append(([fr(v) for v in lo], [fr(v) for v in hi]))
    certs = list(JS.read_jsonl(os.path.join(bdir, 'cert.jsonl')))
    store = {}
    pre = (lambda j: (j,)) if chart == 'std' else (lambda j: (chart, j))
    for nb in [block] + neigh:
        f = os.path.join(run, chart, 'blocks', nb, 'corners.jsonl')
        if os.path.exists(f):
            for d in JS.iter_jsonl_ro(f):
                k = tuple(d['key']); v = FBK.corner_value(d)
                if v is not None and (k not in store or v > store[k]):
                    store[k] = v
    for d in certs:
        key, j, lo, hi = tuple(d['key']), d['j'], d['lo'], d['hi']; out['labels']['C'] = out['labels'].get('C', 0) + 1
        c = cols.get((key, j))
        if c is None:
            bad.append('cert of an unknown root %s' % (key,)); continue
        c[2].append(([fr(v) for v in lo], [fr(v) for v in hi]))
        if d.get('how') == 'LG' and d.get('status') == 'certified':
            out['lg_boxes'] = out.get('lg_boxes', 0) + 1; continue          # box certificate: re-proved under --replay
        if d.get('status') != 'certified' or len(d.get('Fl', [])) != 64:
            bad.append('cert record without status / Fl at %s' % (key,)); continue
        for z, f in zip(CE.corner_zs(lo, hi), d['Fl']):
            v = store.get(pre(j) + CE.zkey(z))
            if v is None or f > v:
                bad.append('corner value %r not backed (stored %r) at %s j %d' % (f, v, key, j)); break
        out['t1_leaves'] += d.get('nleaves', 0)
    for (key, j), (rlo, rhi, boxes) in cols.items():
        tot = Fraction(0)
        for lo, hi in boxes:
            if not all(rlo[i] <= lo[i] < hi[i] <= rhi[i] for i in range(6)):
                bad.append('box outside its root %s j %d' % (key, j)); break
            w = Fraction(1)
            for a, b in zip(lo, hi):
                w *= b - a
            tot += w
        w = Fraction(1)
        for a, b in zip(rlo, rhi):
            w *= b - a
        if tot != w:
            bad.append('volume %s of root %s j %d is not covered exactly (covered / root = %.6f)' % (key, key, j, float(tot / w)))
        elif not disjoint(boxes):
            bad.append('overlapping boxes in root %s j %d' % (key, j))
    out['boxes'] += nl + len(certs); out['columns'] += len(cols)
    if replay:
        for d in rng.sample(certs, len(certs) if replay < 0 else min(replay, len(certs))):
            if d.get('how') == 'LG':
                import lgpoly as LP
                LP.MAX_SUB = 256; LP.SUB_RATIO = float('inf'); out['replayed'] += 1
                if not (CE.lg_box(d['lo'], d['hi'], d['j'], chart, d.get('N'))[0] or CE.lg_box(d['lo'], d['hi'], d['j'], chart, (d.get('N') or 6) + 2)[0]):
                    bad.append('box certificate not re-proved at %s j %d' % (d['key'], d['j']))
                continue
            r = CR.t1_job((tuple(d['key']), d['j'], d['lo'], d['hi'], d['Fl'], 20000, False, chart))[4]; out['replayed'] += 1
            if r['status'] != 'certified':
                bad.append('T1 replay failed at %s j %d: %s' % (d['key'], d['j'], r['status']))
        allc = list(JS.iter_jsonl_ro(os.path.join(bdir, 'corners.jsonl')))
        lgs = [d for d in allc if d.get('lg') is not None]
        import lgcert as LG, lgfan as LF
        for d in rng.sample(lgs, len(lgs) if replay < 0 else min(replay, len(lgs))):          # polynomial certificates: re-proved with a recomputed flux
            k = d['key']; j = k[0] if chart == 'std' else k[1]; z = [float(Fraction(v, 2 ** CE.KBITS)) for v in (k[1:] if chart == 'std' else k[2:])]
            out['lg_rechecked'] = out.get('lg_rechecked', 0) + 1
            if not (LF.recheck if d['lg'].get('kind') == 'fan' else LG.recheck)(CE.exact_verts(z, j, chart), d['lg']):
                bad.append('polynomial certificate not reproduced at corner %s' % (k,))
        cor = [d for d in allc if d.get('eig') is None and d['cheap'][0] > 0 and d['cheap'][1] is not None]
        for d in rng.sample(cor, len(cor) if replay < 0 else min(replay, len(cor))):
            k = d['key']; j = k[0] if chart == 'std' else k[1]; z = [Fraction(v, 2 ** CE.KBITS) for v in (k[1:] if chart == 'std' else k[2:])]
            V = CE.exact_verts([float(x) for x in z], j, chart); fd = tuple(d['cheap'][2]) if len(d['cheap']) > 2 and d['cheap'][2] else None
            v = CE.cheap_lower(V, fd)[0]; out['recomputed'] += 1          # with the stored fibre direction, if there is one
            if v < d['cheap'][0] and fd is None:                          # older records: any direction gives a valid bound
                import fibre as FB
                v = max([v] + [CE.cheap_lower(V, dd)[0] for dd in FB.directions([(float(a), float(b)) for a, b in V])])
            if v < d['cheap'][0]:
                bad.append('closed-form corner value not reproduced: %r < %r' % (v, d['cheap'][0]))
    return bad


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('run'); ap.add_argument('--charts', default='E2,E3,std'); ap.add_argument('--blocks', default='')
    ap.add_argument('--replay', type=int, default=0); ap.add_argument('--seed', type=int, default=1)
    ap.add_argument('--relabel', type=int, default=0); ap.add_argument('--table', type=int, default=0); ap.add_argument('--strict-table', action='store_true')
    ap.add_argument('--complete', action='store_true', help='also: all three charts present, the roots cover the root range of every chart, every block finished')
    a = ap.parse_args(); rng = random.Random(a.seed); nbad = 0; keep = set(a.blocks.split(',')) if a.blocks else None
    for chart in a.charts.split(','):
        f = os.path.join(a.run, chart, 'roots.json')
        if not os.path.exists(f):
            if a.complete:
                print('  %s: no roots.json' % chart); nbad += 1
            continue
        info = json.load(open(f)); CR.CHART = chart
        cfg = json.load(open(os.path.join(a.run, 'config.json')))['cut']; cells = {}
        if a.table and info.get('qtable'):
            fq_ = os.path.join(info['qtable'], 'cells.jsonl')
            if not os.path.exists(fq_):
                fq_ = os.path.join(a.run, 'qtable', 'cells.jsonl')  # the run directory was moved
            cells = {tuple(d['key']): d for d in JS.read_jsonl(fq_)}
        out = dict(labels={}, boxes=0, columns=0, t1_leaves=0, replayed=0, recomputed=0); nb = 0; skipped = 0
        for b in sorted(info['blocks']):
            if keep is not None and b not in keep:
                continue
            if not os.path.exists(os.path.join(a.run, chart, 'blocks', b, 'done.json')):
                skipped += 1; continue
            bad = check_block(a.run, chart, b, info['blocks'][b], info.get('neighbours', {}).get(b, []), a.replay, rng, out); nb += 1
            if a.relabel:
                bad += check_labels(a.run, chart, b, info['blocks'][b], a.relabel, rng, out, cfg)
            if a.table:
                bad += check_table(chart, b, info['blocks'][b], cells, a.table, rng, out, a.strict_table)
            for m in bad[:5]:
                print('  %s %s: %s' % (chart, b, m))
            nbad += len(bad)
        if CR.NO_H and out['labels'].get('H'):
            print('  %s: %d leaves with the label H, which this run does not use (PENT_NO_H=1)' % (chart, out['labels']['H'])); nbad += 1
        if a.complete:
            bad = check_roots(chart, info, cfg, out) + (['%d blocks unfinished' % skipped] if skipped else []) + (['only some blocks checked (--blocks)'] if keep is not None else [])
            for m in bad[:5]:
                print('  %s: %s' % (chart, m))
            nbad += len(bad)
        print('%s: blocks checked %d (unfinished %d), columns %d, boxes %d, T1 leaves %d, labels %s%s' % (
            chart, nb, skipped, out['columns'], out['boxes'], out['t1_leaves'], dict(sorted(out['labels'].items())),
            ('' if not a.replay else ', certificates replayed %d (box certificates among the certified: %d), corner values recomputed %d, polynomial certificates re-proved %d' % (out['replayed'], out.get('lg_boxes', 0), out['recomputed'], out.get('lg_rechecked', 0)))
            + ('' if not a.relabel else ', labels recomputed %d' % out.get('relabelled', 0))
            + ('' if not a.complete else ', root range: %d cells, %d roots, the others re-classified' % (out.get('range_cells', 0), out.get('roots', 0)))
            + ('' if not a.table else ', table: roots with a bound %d, LG entries re-proved %d, tangent-bound entries not re-proved %d' % (out.get('table_roots', 0), out.get('table_lg', 0), out.get('table_tv', 0)))), flush=True)
    print('VERIFY OK' if nbad == 0 else 'VERIFY FAILED: %d problems' % nbad); sys.exit(1 if nbad else 0)


if __name__ == '__main__':
    main()
