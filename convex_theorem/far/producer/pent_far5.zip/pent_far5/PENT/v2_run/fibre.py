"""Fibre bound for the first Dirichlet eigenvalue of convex polygons (Claude, 2026-11-15; FAR_SPEC 9.13).  DRAFT.

Lemma OD (one-dimensional reduction).  Let P be a bounded convex domain, (x, y) orthonormal coordinates,
P = {a < x < b, g1(x) < y < g2(x)}, w = g2 - g1 the length of the section at x.  For u in C_c^oo(P), extended by zero,
    int |grad u|^2  =  int int u_x^2 dx dy + int int u_y^2 dy dx
                    >= int int u_x^2 dx dy + int (pi^2 / w(x)^2) int u^2 dy dx        (Dirichlet inequality on each section)
                    =  int [ int_a^b (u_x^2 + V(x) u^2) dx ] dy,     V = pi^2 / w^2,
and for every y the function x -> u(x, y) belongs to H^1_0(a, b).  Hence
    lambda_1(P) >= mu(V) := inf { int_a^b (f'^2 + V f^2) : f in H^1_0(a, b), int f^2 = 1 }.
mu is monotone: a smaller potential and a larger interval give a smaller mu.

Lemma PS (positive solution).  Let Vt be a step function on a partition a = x_0 < ... < x_N = b, m a real number, and
phi in C^1[a, b], C^2 on every closed piece, with  -phi'' + Vt phi = m phi  on every piece and phi > 0 on (a, b).
Then mu(Vt) >= m.   Proof: for f in C_c^oo(a, b) put f = phi v; phi phi' is absolutely continuous and
int f'^2 = int phi^2 v'^2 - int phi phi'' v^2, so int (f'^2 + Vt f^2) = int phi^2 v'^2 + m int f^2 >= m int f^2.

Implementation.  Direction d = (dx, dy) (exact binary64, not normalised), x' = <p, d>, y' = d x p (a positively
oriented orthogonal frame scaled by D = |d|).  In the primed coordinates the statement reads
    lambda_1(P) >= D^2 mu'(pi^2 / w'^2),      w' = D w.
The polygon is given by vertex BALLS (arb), counter-clockwise; the statement is proved for every convex,
counter-clockwise polygon whose vertices lie in the balls (possibly with coincident vertices or flat angles).
An edge i -> i+1 with x'_{i+1} - x'_i < 0 (certainly) is an upper edge: the polygon lies below its line U_i; with > 0 it
is a lower edge: the polygon lies above its line L_j; an edge of uncertain direction is dropped (fewer constraints, a
larger w bound).  For every pair, U_i - L_j is affine in x', so on a segment [s, t]
    w'(x') <= min_{i,j} max( (U_i - L_j)(s), (U_i - L_j)(t) ) =: W,       Vt := lower bound of pi^2 / W^2  (0 if no pair),
capped at (CAP / segment length)^2.  phi is obtained by shooting from phi(a) = 0, phi'(a) = 1 with the exact transfer
formulas (cosh / sinh for Vt > m, cos / sin for Vt < m, affine for Vt = m) in ball arithmetic.  Positivity on a piece:
a hyperbolic or affine solution has at most one zero, so positive values at both nodes suffice; a trigonometric piece
is in addition required to be shorter than half a period (k l < pi).  The first piece starts from phi = 0 and is
positive on (a, x_1] under the same conditions.  All checks are 'certainly true' ball comparisons.
Returned bounds are binary64 numbers rounded down."""
import math
import numpy as np
from flint import arb, ctx
from scipy.linalg import eigh_tridiagonal

CAP = 200.0
PREC = 96
LADDER = (0.9985, 0.994, 0.98, 0.95)


def _lower(v):
    """a binary64 number <= every point of the ball v"""
    return float(v.lower()) if hasattr(v, 'lower') else float(v)


def _down(v):
    f = float(v.lower()); return math.nextafter(f, -math.inf)


def _up(v):
    f = float(v.upper()); return math.nextafter(f, math.inf)


def frame(P, d):
    """primed coordinates of the vertex balls: X = <p, d>, Y = d x p"""
    dx, dy = arb(float(d[0])), arb(float(d[1]))
    return [p[0] * dx + p[1] * dy for p in P], [dx * p[1] - dy * p[0] for p in P]


def step_potential(P, d, N):
    """nodes (floats, increasing) and the step values Vt (floats, lower bounds) for all polygons in the vertex balls P"""
    X, Y = frame(P, d); n = len(P)
    a = min(_down(x) for x in X); b = max(_up(x) for x in X)
    if not (b > a):
        return None
    nodes = [a + (b - a) * k / N for k in range(N)] + [b]
    assert all(nodes[k + 1] > nodes[k] for k in range(N))
    up = []; lo = []; pi2 = arb.pi() ** 2; V = []
    # Any subset of the pairs gives a valid W.  Float heuristic: on each segment only the edges whose x'-range meets it
    # (for an exact polygon these are the edges that carry the boundary there), all edges if there is none.
    def act(E, k):
        s, t = nodes[k], nodes[k + 1]
        r = [e for e in E if e[3] <= t and e[4] >= s]
        return r if r else E
    xs = [arb(x) for x in nodes]
    for i in range(n):
        k = (i + 1) % n; ex = X[k] - X[i]
        if ex < 0 or ex > 0:
            a0 = min(float(X[i].mid()), float(X[k].mid())); a1 = max(float(X[i].mid()), float(X[k].mid()))
            (up if ex < 0 else lo).append((X[i], Y[i], (Y[k] - Y[i]) / ex, a0, a1, {}))

    def val(e, k):                                                  # the line of the edge at node k (cached)
        if k not in e[5]:
            e[5][k] = e[1] + e[2] * (xs[k] - e[0])
        return e[5][k]
    if not up or not lo:
        return nodes, [0.0] * N
    for k in range(N):
        W = None
        for U in act(up, k):
            for L in act(lo, k):
                m = max(_up(val(U, k) - val(L, k)), _up(val(U, k + 1) - val(L, k + 1)))
                W = m if W is None else min(W, m)
        cap = (CAP / (nodes[k + 1] - nodes[k])) ** 2
        if W <= 0:
            V.append(cap)                                           # no polygon meets this slab
        else:
            V.append(min(cap, _down(pi2 / (arb(W) * arb(W)))))
    return nodes, V


def verify(nodes, V, m):
    """True if a positive solution of -phi'' + Vt phi = m phi exists on (a, b) (Lemma PS), proved in ball arithmetic"""
    old = ctx.prec; ctx.prec = PREC
    try:
        phi = arb(0); psi = arb(1); pi = arb.pi(); m = arb(float(m))
        for k in range(len(V)):
            l = arb(nodes[k + 1]) - arb(nodes[k]); q = arb(V[k]) - m
            if q > 0:
                kap = q.sqrt(); c = (kap * l).cosh(); s = (kap * l).sinh()
                phi, psi = phi * c + psi * s / kap, phi * kap * s + psi * c
            elif q < 0:
                kk = (-q).sqrt()
                if not (kk * l < pi):
                    return False
                c = (kk * l).cos(); s = (kk * l).sin()
                phi, psi = phi * c + psi * s / kk, -phi * kk * s + psi * c
            elif q == 0:
                phi, psi = phi + psi * l, psi
            else:
                return False
            if not (phi > 0):
                return False
            e = math.frexp(float(phi.mid()) + abs(float(psi.mid())))[1]          # exact rescaling by a power of two
            sc = arb(2) ** (-e); phi *= sc; psi *= sc
        return True
    finally:
        ctx.prec = old


def float_mu(nodes, V):
    """float estimate of mu for the step potential (finite differences, 4 points per piece); not rigorous"""
    x = np.asarray(nodes); N = len(V); r = 4
    h = np.repeat(np.diff(x) / r, r); pot = np.repeat(np.asarray(V), r)
    # non-uniform grid is avoided: the nodes are uniform up to rounding
    hh = float(h.mean()); M = len(pot)
    vm = 0.5 * (pot[:-1] + pot[1:])                                 # potential at the M - 1 interior grid points
    ev = eigh_tridiagonal(2 / hh ** 2 + vm, -np.ones(M - 2) / hh ** 2, select='i', select_range=(0, 0))[0][0]
    return float(ev)


def lam_lower(P, d, N=256, target=None):
    """rigorous lower bound of lambda_1 for every convex ccw polygon with vertices in the balls P, direction d.
    target: a float; if given only 'lambda_1 >= target' is tried (one verification) and target or 0.0 is returned.
    Otherwise the float estimate times the factors of LADDER is tried.  Returns a float (0.0: nothing proved)."""
    sp = step_potential(P, d, N)
    if sp is None:
        return 0.0
    nodes, V = sp; D2 = float(d[0]) ** 2 + float(d[1]) ** 2; D2a = arb(float(d[0])) ** 2 + arb(float(d[1])) ** 2
    if target is not None:
        m = _up(arb(float(target)) / D2a)
        return float(target) if verify(nodes, V, m) else 0.0
    est = float_mu(nodes, V)
    for f in LADDER:
        m = est * f
        if verify(nodes, V, m):
            return _down(D2a * arb(m))
    return 0.0


def directions(Vf):
    """candidate directions for a float polygon: its edges and diagonals"""
    n = len(Vf); out = []
    for i in range(n):
        for j in range(i + 1, n):
            ex = Vf[j][0] - Vf[i][0]; ey = Vf[j][1] - Vf[i][1]
            if ex * ex + ey * ey > 1e-12:
                out.append((ex, ey))
    return out


def _float_estimate(V, d, N):
    """float estimate of D^2 mu for the polygon V (n x 2 array) in the direction d: numpy only, not rigorous"""
    D = math.hypot(d[0], d[1]); x = (V @ np.array([d[0], d[1]])) / D; y = (V @ np.array([-d[1], d[0]])) / D
    a, b = x.min(), x.max()
    if not (b > a):
        return 0.0
    t = np.linspace(a, b, N + 1); x1 = np.roll(x, -1); y1 = np.roll(y, -1); dx = x1 - x
    ok = np.abs(dx) > 1e-14 * (b - a)
    with np.errstate(divide='ignore', invalid='ignore'):
        yy = y[:, None] + (y1 - y)[:, None] * (t[None, :] - x[:, None]) / np.where(ok, dx, 1.0)[:, None]
    ins = ok[:, None] & (t[None, :] >= np.minimum(x, x1)[:, None] - 1e-12) & (t[None, :] <= np.maximum(x, x1)[:, None] + 1e-12)
    up = np.where(ins, yy, -np.inf).max(0); lo = np.where(ins, yy, np.inf).min(0); w = np.maximum(up - lo, 0.0)
    W = np.maximum(w[:-1], w[1:]); h = (b - a) / N
    with np.errstate(divide='ignore'):
        pot = np.minimum(np.pi ** 2 / (W * W), (CAP / h) ** 2)
    vm = 0.5 * (pot[:-1] + pot[1:])
    return float(eigh_tridiagonal(2 / h ** 2 + vm, -np.ones(N - 2) / h ** 2, select='i', select_range=(0, 0))[0][0])


def best_direction(Vf, N=64):
    """float heuristic: the direction (edge or diagonal) with the largest estimate; returns (estimate of lambda, d)"""
    V = np.array(Vf, float); best = (0.0, None)
    for d in directions(Vf):
        v = _float_estimate(V, d, N)
        if v > best[0]:
            best = (v, d)
    return best


def F_lower(Vf, N=256, d=None):
    """rigorous lower bound of F = lambda_1 |P| for ONE convex ccw polygon with exact binary64 vertices Vf.
    d: a direction to use (any non-zero vector gives a valid bound); by default the best edge or diagonal direction.
    Returns (float, direction) or (0.0, None)."""
    P = [(arb(float(a)), arb(float(b))) for a, b in Vf]; n = len(P)
    A = sum(P[i][0] * P[(i + 1) % n][1] - P[(i + 1) % n][0] * P[i][1] for i in range(n)) / 2
    if not (A > 0):
        return 0.0, None
    if d is None:
        est, d = best_direction(Vf)
    if d is None:
        return 0.0, None
    lam = lam_lower(P, d, N)
    return (_down(arb(lam) * A) if lam > 0 else 0.0), d


def hull(points):
    """the convex hull of exact binary64 points, counter-clockwise, without collinear points (Andrew's monotone chain
    with exact rational cross products).  Returns a list of (x, y) floats taken from the input."""
    pts = sorted(set((float(a), float(b)) for a, b in points))
    if len(pts) < 3:
        return pts
    den = max(max(a.as_integer_ratio()[1], b.as_integer_ratio()[1]) for a, b in pts)            # a power of two
    F = [(int(a * den), int(b * den)) for a, b in pts]                                          # exact integers
    assert all(x / den == a and y / den == b for (x, y), (a, b) in zip(F, pts))

    def half(idx):
        h = []
        for i in idx:
            while len(h) >= 2:
                o, a, b = F[h[-2]], F[h[-1]], F[i]
                if (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]) <= 0:
                    h.pop()
                else:
                    break
            h.append(i)
        return h
    lo = half(range(len(pts))); up = half(range(len(pts) - 1, -1, -1))
    return [pts[i] for i in lo[:-1] + up[:-1]]


def family_lower(corner_polys, Amin, d, N=128, target=None):
    """Polygons P(z) whose vertices are convex combinations of the corresponding vertices of the given corner polygons
    (e.g. vertices multi-affine in z on a box) lie in the convex hull H of all corner vertices, so
    lambda_1(P(z)) >= lambda_1(H) >= fibre bound of H.  Returns a float lower bound of  lambda_1(P(z)) * Amin
    (Amin: an arb / float lower bound of the areas |P(z)|, supplied by the caller), or 0.0."""
    H = hull([p for V in corner_polys for p in V])
    if len(H) < 3:
        return 0.0
    P = [(arb(a), arb(b)) for a, b in H]; A = arb(Amin) if not isinstance(Amin, arb) else Amin
    if target is not None:
        t = _up(arb(float(target)) / A)
        return float(target) if lam_lower(P, d, N, target=t) > 0 else 0.0
    lam = lam_lower(P, d, N)
    return _down(arb(lam) * A) if lam > 0 else 0.0
