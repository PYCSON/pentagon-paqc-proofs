"""Exact dyadic grids for the v2 production runs (Claude, 2026-11-07; boxes 2026-11-08).
A grid is (base, root_side).  A cell is (L, j) with L the level vector (L_0..L_5) and j the index vector: side s_i =
root_side / 2^L_i, lo_i = base_i + j_i s_i, hi_i = lo_i + s_i.  An integer L means the cube with all L_i = L (the
2026-11-07 format; every function accepts both).  base_i and root_side are short dyadic numbers, so every endpoint,
centre and half-width is an exact binary64 and rig_paqc.cell_endpoints(p, rad) round-trips bit-exactly (rad a
6-vector): neighbouring cells share faces and corners (corner key = the integer vector k with corner = base + k s_LMAX).
Boxes (ARCH_V2 section 12): a cell is refined by halving its SPLIT_AXES = 3 longest axes (ties: lowest index), so the
volume ladder has factor 8 instead of 64 and aspect ratios stay <= 2.  children(L, j) yields those 8 children.
  NEAR: base = (c - 5/4) rounded down to 2^-20 (base_2 = -3/4, mirror plane on the grid), root_side 5/2.
  FAR : base = (0, 0, -1, 0, -1, 0) (the longest-edge root box of far_exclude.ROOT), root_side 3 (the box has widths
        2, 1, 3, 2, 2, 1; the cube pads it, the padding is INVALID by the root-box constraints)."""
import math, itertools, sys, os
from fractions import Fraction
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'v2_cover'))
import plan_cells as PC

LMAX = 24
SPLIT_AXES = 3


def levels(L):
    """level vector of a cell: an int means a cube"""
    return tuple([int(L)] * 6) if isinstance(L, int) else tuple(int(v) for v in L)


def level_name(L):
    Lv = levels(L)
    return str(Lv[0]) if len(set(Lv)) == 1 else '-'.join(str(v) for v in Lv)


def split_axes(L, n=SPLIT_AXES):
    """the n coarsest axes of the cell (largest sides; ties -> lowest index)"""
    Lv = levels(L)
    return sorted(sorted(range(6), key=lambda i: (Lv[i], i))[:n])


class Grid:
    def __init__(self, base, root_side, name):
        self.base = [float(b) for b in base]; self.root_side = float(root_side); self.name = name
        assert all(Fraction(b).denominator <= 2 ** 24 for b in self.base) and Fraction(self.root_side).denominator <= 2 ** 24

    def side(self, L):
        """side length(s): a float for an int level, a list for a level vector"""
        if isinstance(L, int):
            return self.root_side / 2 ** L
        return [self.root_side / 2 ** v for v in levels(L)]

    def sides(self, L):
        return [self.root_side / 2 ** v for v in levels(L)]

    def cell_box(self, L, j):
        s = self.sides(L)
        return [self.base[i] + j[i] * s[i] for i in range(6)], [self.base[i] + (j[i] + 1) * s[i] for i in range(6)]

    def cell_p_rho(self, lo, hi):
        """centre and half-width: a float for a cube, a 6-list for a box"""
        rad = [(b - a) / 2 for a, b in zip(lo, hi)]
        return [(a + b) / 2 for a, b in zip(lo, hi)], (rad[0] if len(set(rad)) == 1 else rad)

    def cell_rad(self, lo, hi):
        return [(b - a) / 2 for a, b in zip(lo, hi)]

    def children(self, L, j, axes=None):
        """halve the given axes (default: the SPLIT_AXES coarsest); yields (level vector, index vector)"""
        Lv = levels(L); axes = split_axes(Lv, SPLIT_AXES) if axes is None else list(axes)
        for d in itertools.product((0, 1), repeat=len(axes)):
            L2 = list(Lv); j2 = list(j)
            for a, bit in zip(axes, d):
                L2[a] += 1; j2[a] = 2 * j[a] + bit
            yield tuple(L2), tuple(j2)

    def children_cube(self, L, j):
        """the 64 children of the 2026-11-07 cube refinement (all axes halved); an int level stays an int (far_block)"""
        for L2, j2 in self.children(L, j, axes=range(6)):
            yield (L2[0] if isinstance(L, int) else L2), j2

    def corner_key(self, x):
        s = self.root_side / 2 ** LMAX; k = [(x[i] - self.base[i]) / s for i in range(6)]
        assert all(v == int(v) for v in k), 'corner not on the grid'
        return tuple(int(v) for v in k)

    def int_box(self, L, j):
        """the cell as integer coordinates at level LMAX (exact; for partition checks)"""
        Lv = levels(L)
        return [j[i] << (LMAX - Lv[i]) for i in range(6)], [(j[i] + 1) << (LMAX - Lv[i]) for i in range(6)]

    def selftest(self, n=2000):
        import numpy as np
        sys.path.insert(0, os.path.join(HERE, '..', 'scripts'))
        import rig_paqc as R
        rng = np.random.default_rng(0)
        for t in range(n):
            if t % 2:
                L = int(rng.integers(0, LMAX + 1)); Lv = levels(L)
            else:
                Lv = tuple(int(v) for v in rng.integers(0, LMAX + 1, 6)); L = Lv
            j = tuple(int(rng.integers(0, 2 ** Lv[i])) for i in range(6)); lo, hi = self.cell_box(L, j)
            for i in range(6):
                s = Fraction(self.root_side) / 2 ** Lv[i]
                assert Fraction(lo[i]) == Fraction(self.base[i]) + j[i] * s and Fraction(hi[i]) == Fraction(self.base[i]) + (j[i] + 1) * s
            p, rho = self.cell_p_rho(lo, hi); lo2, hi2 = R.cell_endpoints(p, rho if isinstance(rho, float) else np.array(rho))
            assert all(float(lo2[i]) == lo[i] and float(hi2[i]) == hi[i] for i in range(6))
            for x in R.cell_corners(lo2, hi2):
                self.corner_key([float(v) for v in x])
            if max(Lv) >= LMAX:
                continue
            ch = list(self.children(L, j))
            assert len(ch) == 2 ** SPLIT_AXES
            ilo, ihi = self.int_box(L, j); vol = 0
            for L2, j2 in ch:
                a, b = self.int_box(L2, j2)
                assert all(ilo[i] <= a[i] < b[i] <= ihi[i] for i in range(6)); vol += math.prod(b[i] - a[i] for i in range(6))
            assert vol == math.prod(ihi[i] - ilo[i] for i in range(6))
        return True


_GRID = Fraction(1, 2 ** 20)
_C = [float(v) for v in PC.C]


def near_grid(R):
    """the near grid for candidate-ball radius R (a short dyadic: 1.25, 1.5, 2, 2.5): root cube base = c - R rounded
    down to 2^-20, side 2R; the mirror plane z_2 = 1/2 is a grid plane because c_2 = 1/2 and R is dyadic"""
    R = Fraction(R); assert R.denominator <= 4
    g = Grid([float(math.floor(Fraction(_C[i]) / _GRID - R / _GRID) * _GRID) for i in range(6)], float(2 * R), 'near')
    assert Fraction(g.base[2]) == Fraction(1, 2) - R
    return g


NEAR = near_grid(Fraction(5, 4))
assert NEAR.base[2] == -0.75
FAR = Grid([0.0, 0.0, -1.0, 0.0, -1.0, 0.0], 3.0, 'far')
GRIDS = dict(near=NEAR, far=FAR)

if __name__ == '__main__':
    for g in (NEAR, FAR):
        print(g.name, 'selftest', g.selftest())
