"""Crash-safe file helpers for the long runs (Claude, 2026-11-10, after the 11-09 silent WSL stop).
A process killed while appending to a .jsonl file can leave a TORN last line (no trailing newline).  Appending after it
would glue the next record onto the fragment and corrupt a line in the middle of the file, so every append-only file
is repaired before it is reopened: the fragment after the last newline is cut and saved to <file>.torn (it is a record
that was never completed; the work that produced it is simply redone).  JSON state files are replaced atomically."""
import os, json, time


def repair_tail(path):
    """cut a torn last line; returns the number of bytes removed (0 = file was clean or absent)"""
    if not os.path.exists(path) or os.path.getsize(path) == 0:
        return 0
    with open(path, 'rb+') as f:
        f.seek(0, 2); size = f.tell(); back = min(size, 1 << 20)
        while True:
            f.seek(size - back); buf = f.read(back); k = buf.rfind(b'\n')
            if k >= 0 or back == size:
                break
            back = min(size, back * 2)
        if k == len(buf) - 1:
            return 0
        keep = (size - back) + k + 1 if k >= 0 else 0
        f.seek(keep); frag = f.read()
        with open(path + '.torn', 'ab') as t:
            t.write(b'%s %d bytes cut at offset %d\n' % (time.strftime('%Y-%m-%d %H:%M:%S').encode(), len(frag), keep)); t.write(frag + b'\n')
        f.truncate(keep); f.flush(); os.fsync(f.fileno())
        return len(frag)


def read_jsonl(path):
    """all complete records of a .jsonl file (repairs a torn tail first); a corrupt line in the MIDDLE is an error"""
    if not os.path.exists(path):
        return []
    repair_tail(path); out = []
    for i, l in enumerate(open(path)):
        try:
            out.append(json.loads(l))
        except json.JSONDecodeError:
            raise SystemExit('%s line %d is corrupt (not a torn tail) -- stop, keep everything as it is' % (path, i + 1))
    return out


def iter_jsonl_ro(path):
    """the complete records of a .jsonl file, one at a time, without modifying the file and without holding them all
    in memory (a corner file of a heavy block is about 100 MB).  The file may be appended to by ANOTHER process: a last
    line without a newline (a record still being written) ends the iteration, a line that does not parse is skipped.
    (2026-11-16: read_jsonl repairs the tail, i.e. truncates the file; doing that to a neighbouring block's file while
    that block is running cuts a record in half and the rest of it is appended after the cut.)"""
    if not os.path.exists(path):
        return
    with open(path, 'rb') as f:
        for l in f:
            if not l.endswith(b'\n'):
                break
            try:
                yield json.loads(l)
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue


def read_jsonl_ro(path):
    return list(iter_jsonl_ro(path))


def atomic_json(path, obj, **kw):
    tmp = path + '.tmp'
    with open(tmp, 'w') as f:
        json.dump(obj, f, **kw); f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)


def fsync(f):
    f.flush(); os.fsync(f.fileno())


def selftest(d):
    p = os.path.join(d, 'x.jsonl')
    open(p, 'w').write('{"a": 1}\n{"a": 2}\n{"a": 3')
    assert repair_tail(p) == len('{"a": 3') and open(p).read() == '{"a": 1}\n{"a": 2}\n'
    assert repair_tail(p) == 0 and [r['a'] for r in read_jsonl(p)] == [1, 2]
    open(p, 'w').write('{"a"'); assert repair_tail(p) == 4 and open(p).read() == ''
    open(p, 'w').write('{"a": 1}\n{"a": \n{"a": 3}\n')
    try:
        read_jsonl(p); raise AssertionError('middle corruption not caught')
    except SystemExit:
        pass
    q = os.path.join(d, 's.json'); atomic_json(q, dict(k=1)); assert json.load(open(q)) == dict(k=1) and not os.path.exists(q + '.tmp')
    return True


if __name__ == '__main__':
    import tempfile, sys
    with tempfile.TemporaryDirectory() as d:
        print('jsonl_safe selftest', selftest(d))
