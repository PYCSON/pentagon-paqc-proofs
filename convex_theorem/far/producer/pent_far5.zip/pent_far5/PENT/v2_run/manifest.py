"""Run manifest + structural self-check for a v2 near/far run directory (Claude, 2026-11-08; GPT PENT-V2-2 section 0,
Stage A).  Writes into RUN/: config.lock.json (solver settings, code SHA256s, library versions), constants.json (every
constant the proof compares against, as exact strings), manifest.jsonl (one line per file: bytes, SHA256, lines),
status.json (counts + the structural checks).  The checks need no spectral code:
  - every certs/*.json corner_refs key exists in corners.jsonl with a non-null certificate, and the record's p/rho
    reproduce the cell's exact grid box (bit-exact binary64);
  - a certified T1 record's leaves partition [-1,1]^6 exactly (Fraction arithmetic: disjoint interiors, total volume
    2^6) and every leaf lower bound exceeds F*_up (as decimal strings compared through Fraction);
  - every skipped.jsonl record's leaf paths partition its cell exactly (same arithmetic) and each leaf has a reason;
  - cells.jsonl / skipped.jsonl / cells_next.jsonl: no cell both skipped and certified; done.jsonl is an index only.
Content ids: sha256 of the canonical JSON (sorted keys, compact separators, ensure_ascii=False) of each record.
Usage: python3 manifest.py RUN [--grid near|far] [--strict]"""
import os, sys, json, hashlib, argparse, platform, itertools, math
from fractions import Fraction
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, '..', 'scripts')); sys.path.insert(0, os.path.join(HERE, '..', 'v2_cover'))

CODE = ['grid.py', 'near_planner.py', 'near_certify.py', 'corner_v2.py', 'rig_t1_v2.py', 'run_block.py', 'far_block.py',
        'far_table.py', 'manifest.py', '../scripts/rig_paqc.py', '../scripts/rig_box.py', '../scripts/mps.py',
        '../scripts/rig_t1.py', '../v2_cover/theta_fpsi_rig.py', '../v2_cover/plan_cells.py', '../G1/fstar_exact.json']


def jsonl_lines(path):
    """lines of PATH or of PATH.gz (skip records are gzipped once a block is planned, plan_all.py); None if neither exists"""
    import gzip
    if os.path.exists(path):
        return open(path)
    if os.path.exists(path + '.gz'):
        return gzip.open(path + '.gz', 'rt')
    return None


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def canon(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)


def content_id(obj):
    return hashlib.sha256(canon(obj).encode('utf-8')).hexdigest()


def frac(x):
    """exact value of a binary64 (or of a decimal string) as a Fraction."""
    return Fraction(x) if isinstance(x, str) else Fraction(float(x))


def constants():
    import rig_paqc as R, theta_fpsi_rig as TR, plan_cells as PC, grid as G, corner_v2 as CV
    from flint import ctx
    c = [float(v) for v in PC.C]
    return dict(
        schema='PENT-V2-2/claude-manifest-0.1',
        Fstar_up_binary64=repr(float(R.FSTAR_UP.upper())), Fstar_up_exact=str(frac(float(R.FSTAR_UP.upper()))),
        Fstar_source='G1/fstar_exact.json (F_up ball, outward-rounded; see rig_paqc.py)',
        c_binary64=[repr(v) for v in c], c_exact=[str(frac(v)) for v in c],
        c_note='plan_cells.C: regular-pentagon chart point, phi_3(C) = C exactly in binary64',
        near_d2_min='1/400', near_d2_far='9/25', ball_d2=str(TR.BALL2.str(40, radius=False)) if hasattr(TR.BALL2, 'str') else str(TR.BALL2), mirror_plane='z_2 = 1/2',
        near_grid=dict(base_binary64=[repr(v) for v in G.NEAR.base], base_exact=[str(frac(v)) for v in G.NEAR.base],
                       root_side=str(frac(G.NEAR.root_side)), LMAX=G.LMAX, side_L='root_side / 2^L', ball_radius=str(frac(G.NEAR.root_side / 2))),
        far_grid=dict(base_binary64=[repr(v) for v in G.FAR.base], base_exact=[str(frac(v)) for v in G.FAR.base],
                      root_side=str(frac(G.FAR.root_side)), LMAX=G.LMAX),
        corner_solver=dict(SOLVER=CV.SOLVER, NSEG=CV.NSEG, K_default=8, sup_methods={'rig_box': 'corner_v2/1', 'fast': 'corner_v2/2', 'taylor': 'corner_v2/3'},
                           TAYLOR_P=CV.TAYLOR_P, NSEG_TAYLOR=CV.NSEG_TAYLOR), arb_prec_bits=ctx.prec,
        T1_root='[-1,1]^6 in u, x = p + rho * u', T1_leaf='[cen[6], rad[6], tau, lower]  (lower is a binary64 rounded down)')


def config_lock(run):
    import numpy, flint
    cfg = {}
    cf = os.path.join(run, 'config.json')
    if os.path.exists(cf):
        cfg = json.load(open(cf))
    code = {}
    for rel in CODE:
        p = os.path.normpath(os.path.join(HERE, rel))
        if os.path.exists(p):
            code[os.path.relpath(p, os.path.join(HERE, '..'))] = sha(p)
    return dict(schema='PENT-V2-2/claude-manifest-0.1', run_config=cfg, code_sha256=code,
                python=platform.python_version(), numpy=numpy.__version__, python_flint=flint.__version__,
                platform=platform.platform())


def leaf_box(path, lo, hi):
    """sub-box of [lo, hi] (Fractions) along a near_planner.skip_tree path 'a0a1...' (axis digit, half digit)."""
    lo = list(lo); hi = list(hi)
    for a, b in zip(path[0::2], path[1::2]):
        k = int(a); mid = (lo[k] + hi[k]) / 2
        if b == '0':
            hi[k] = mid
        else:
            lo[k] = mid
    return lo, hi


def partition_ok(boxes, root_lo, root_hi):
    """boxes (lists of (lo, hi) Fractions) partition the root: inside, pairwise interior-disjoint, total volume."""
    vol = Fraction(0); n = len(boxes)
    for lo, hi in boxes:
        if any(lo[i] < root_lo[i] or hi[i] > root_hi[i] or lo[i] >= hi[i] for i in range(len(lo))):
            return False, 'leaf outside root or empty'
        v = Fraction(1)
        for i in range(len(lo)):
            v *= hi[i] - lo[i]
        vol += v
    rv = Fraction(1)
    for i in range(len(root_lo)):
        rv *= root_hi[i] - root_lo[i]
    if vol != rv:
        return False, 'volume %s != %s' % (vol, rv)
    # disjointness: the partitions here are produced by recursive bisection (skip_tree, T1 B&B, grid.children), so they
    # are guillotine partitions: some axis cut at the midpoint separates the leaves into two groups.  Recursing on that
    # structure checks interior-disjointness in O(n log n) exact arithmetic; a node without such a cut falls back to a
    # pairwise check (small sets) or fails.
    ok, msg = guillotine(boxes, list(root_lo), list(root_hi))
    if not ok:
        return False, msg
    return True, 'exact partition, %d leaves (guillotine)' % n


def guillotine(S, lo, hi, depth=0):
    if len(S) == 1:
        a, b = S[0]
        return (list(a) == lo and list(b) == hi), 'single leaf differs from its node' if not (list(a) == lo and list(b) == hi) else ''
    d = len(lo)
    for ax in range(d):
        if hi[ax] - lo[ax] == 0:
            continue
        mid = (lo[ax] + hi[ax]) / 2
        if all(b[ax] <= mid or a[ax] >= mid for a, b in S):
            left = [x for x in S if x[1][ax] <= mid]; right = [x for x in S if x[0][ax] >= mid]
            if not left or not right or len(left) + len(right) != len(S):
                return False, 'cut on axis %d leaves an empty side (gap)' % ax
            lo2 = list(lo); hi2 = list(hi); hi2[ax] = mid; lo2[ax] = mid
            ok, msg = guillotine(left, lo, hi2, depth + 1)
            if not ok:
                return ok, msg
            return guillotine(right, lo2, hi, depth + 1)
    if len(S) <= 400:
        for i in range(len(S)):
            la, ha = S[i]
            for j in range(i + 1, len(S)):
                lb, hb = S[j]
                if all(min(ha[k], hb[k]) > max(la[k], lb[k]) for k in range(d)):
                    return False, 'leaves overlap (non-guillotine node)'
        return True, ''
    return False, 'no guillotine cut at a node with %d leaves' % len(S)


def check_run(run, grid_name, strict, root_check=True, caches=(), ball=1.25):
    import grid as G, near_certify as NC, near_planner as NP
    from fractions import Fraction as _F
    if grid_name == 'near':
        NP.configure(ball)
    g = G.near_grid(_F(ball)) if grid_name == 'near' else G.GRIDS[grid_name]; const = constants(); fstar = Fraction(const['Fstar_up_exact'])
    rep = dict(files={}, cells=0, skipped=0, certs=0, certified=0, by_how={}, unresolved=0, corners=0, corners_null=0,
               problems=[])
    corners = {}           # key -> slim certificate (lam_tilde, mu, area, lam_lo, F_lo, sha); full certificates stay on disk
    # 2026-11-10: from the read-only caches (the run-wide corners.jsonl, 1e6-5e6 corners) only the corners referenced by
    # this directory's certificates are loaded (a full load was 2.4 KB per corner in memory, per round); the
    # directory's own corners.jsonl is loaded and chain-checked completely
    need = set(); cdir = os.path.join(run, 'certs')
    if os.path.isdir(cdir):
        for name in os.listdir(cdir):
            for r in json.load(open(os.path.join(cdir, name))).get('corner_refs', []):
                need.add(tuple(r))
    own = os.path.join(run, 'corners.jsonl')
    for cf in list(caches) + [own]:
        if os.path.exists(cf):
            try:
                NC.load_cache(cf, corners, keep=None if cf == own else need)
            except SystemExit as ex:
                rep['problems'].append(str(ex))
    rep['corners'] = len(corners); rep['corners_null'] = sum(v is None for v in corners.values())
    # exact binary64 chain of each corner (2026-11-08, GPT PENT-14b CHANGES): F_lo_safe <= lam_lo_f64 * area_lo_f64 as
    # rationals (parse the hex forms; the decimal repr strings are NOT exact rationals), mu_up_f64 < 1
    nsafe = 0
    for key, sl in corners.items():
        if sl is None:
            continue
        if sl.get('kind') == 'fan':
            continue                                                # fan certificates: re-proved below from the full records
        if 'F_lo_safe_hex' not in sl:
            rep['problems'].append('corner %s: no F_lo_safe (pre-2026-11-08 certificate)' % (key[:6],)); continue
        fs = Fraction(float.fromhex(sl['F_lo_safe_hex'])); ll = Fraction(float.fromhex(sl['lam_lo_f64_hex'])); al = Fraction(float.fromhex(sl['area_lo_f64_hex']))
        if not (fs <= ll * al) or not (float(sl.get('mu_up_f64', 0)) < 1):
            rep['problems'].append('corner %s: F_lo_safe exceeds lam_lo_f64 * area_lo_f64 or mu >= 1' % (key[:6],))
        nsafe += 1
    rep['corners_safe_checked'] = nsafe
    # fan certificates (2026-11-16, lgfan.py / far/LG_LEMMA.md): every one that is used here is re-proved from its record
    # (exact geometry tests, exact integer arithmetic of Lemma LG with a recomputed flux), and the stored F_lo must be the
    # record's value.  7-50 ms each.
    if any(sl is not None and sl.get('kind') == 'fan' for sl in corners.values()):
        import lgfan
        nfan = 0
        for cf in list(caches) + [own]:
            if not os.path.exists(cf):
                continue
            for l in open(cf):
                try:
                    d = json.loads(l)
                except ValueError:
                    continue
                c = d.get('cert'); key = tuple(d['key'])
                if c is None or c.get('kind') != 'fan' or key not in corners:
                    continue
                x = [float(v) for v in c['vertices_x']]; V = [(0.0, 0.0), (1.0, 0.0), (x[0], x[1]), (x[2], x[3]), (x[4], x[5])]
                kx = tuple(g.corner_key(x))
                if kx != tuple(key[:6]):
                    rep['problems'].append('corner %s: vertices_x do not belong to the key' % (key[:6],)); continue
                if float(c['F_lo']) != float(c['lg']['F_lo']) or not lgfan.recheck(V, c['lg']):
                    rep['problems'].append('corner %s: fan certificate not reproduced' % (key[:6],)); continue
                nfan += 1
        rep['corners_fan_reproved'] = nfan
        if nfan != sum(sl is not None and sl.get('kind') == 'fan' for sl in corners.values()):
            rep['problems'].append('fan certificates: %d used, %d re-proved' % (sum(sl is not None and sl.get('kind') == 'fan' for sl in corners.values()), nfan))
    skipped_cells = set(); cert_cells = set()
    sf = os.path.join(run, 'skipped.jsonl'); sfl = jsonl_lines(sf)
    if sfl is not None:
        for line in sfl:
            d = json.loads(line); rep['skipped'] += 1; key = (G.levels(d['L']), tuple(d['j'])); skipped_cells.add(key)
            lo, hi = g.cell_box(d['L'], d['j']); lo = [frac(v) for v in lo]; hi = [frac(v) for v in hi]
            boxes = [leaf_box(p, lo, hi) for p, why in d['leaves']]
            if any(not why for _, why in d['leaves']):
                rep['problems'].append('skipped %s: leaf without reason' % (key,))
            ok, msg = partition_ok(boxes, lo, hi)
            if not ok:
                rep['problems'].append('skipped %s: %s' % (key, msg))
    cl = os.path.join(run, 'cells.jsonl')
    if os.path.exists(cl):
        for line in open(cl):
            d = json.loads(line); rep['cells'] += 1; key = (G.levels(d['L']), tuple(d['j'])); cert_cells.add(key)
            lo, hi = g.cell_box(d['L'], d['j'])
            if [float(v) for v in d['lo']] != lo or [float(v) for v in d['hi']] != hi:
                rep['problems'].append('cells %s: lo/hi not the grid box' % (key,))
    both = skipped_cells & cert_cells
    if both:
        rep['problems'].append('%d cells both skipped and certified' % len(both))
    # tree coverage: skipped + certify cells (+ pending, if the planner stopped early) must partition the planner's root,
    # taken as the bounding box of all of them (for a --cell run this is that cell; for a block run the block)
    pend = []
    pf = os.path.join(run, 'pending.jsonl')
    if os.path.exists(pf):
        pend = [(G.levels(d['L']), tuple(d['j'])) for d in map(json.loads, open(pf))]
    leaves = list(skipped_cells | cert_cells) + pend
    if leaves:
        boxes = []
        for L, j in leaves:
            lo, hi = g.cell_box(L, j); boxes.append(([frac(v) for v in lo], [frac(v) for v in hi]))
        rlo = [min(b[0][i] for b in boxes) for i in range(6)]; rhi = [max(b[1][i] for b in boxes) for i in range(6)]
        Lr = min(min(G.levels(L)) for L, _ in leaves)
        ok, msg = partition_ok(boxes, rlo, rhi)
        rep['coverage'] = dict(root_lo=[str(v) for v in rlo], root_hi=[str(v) for v in rhi], min_level=Lr, leaves=len(leaves),
                               pending=len(pend), result=msg)
        if not ok and root_check:
            rep['problems'].append('coverage: ' + msg)
        elif not ok:
            rep['coverage']['note'] = 'not a single-root directory (round >= 1 of a block): coverage is checked at block level'
    cd = os.path.join(run, 'certs')
    if os.path.isdir(cd):
        import rig_paqc as R
        for name in sorted(os.listdir(cd)):
            d = json.load(open(os.path.join(cd, name))); rep['certs'] += 1; key = (G.levels(d['L']), tuple(d['j']))
            lo, hi = g.cell_box(d['L'], d['j']); p, rho = g.cell_p_rho(lo, hi)
            if d.get('p') != p or d.get('rho') != rho:
                rep['problems'].append('cert %s: p/rho differ from the grid cell' % name)
            if d['status'] == 'certified':
                rep['certified'] += 1; rep['by_how'][d['how']] = rep['by_how'].get(d['how'], 0) + 1
            else:
                rep['unresolved'] += 1
            refs = [tuple(r) for r in d.get('corner_refs', [])]
            if d['status'] == 'certified':
                if len(refs) != 64:
                    rep['problems'].append('cert %s: %d corner refs' % (name, len(refs)))
                for r in refs:
                    if r not in corners or corners[r] is None:
                        rep['problems'].append('cert %s: corner %s missing or null' % (name, r[:6]))
                # the 64 refs must be the 64 corners of the cell
                lo2, hi2 = R.cell_endpoints(p, rho if isinstance(rho, float) else __import__('numpy').array(rho))
                want = {g.corner_key([float(v) for v in x]) for x in R.cell_corners(lo2, hi2)}
                if {r[:6] for r in refs} != want:
                    rep['problems'].append('cert %s: corner refs are not the cell corners' % name)
                Fl = [Fraction(repr(float(R.cert_F_lo(corners[r])))) for r in refs if r in corners and corners[r] is not None]
                if d['how'] == 'mincorner' and Fl and not (Fraction(repr(d['mincorner_LB'])) > fstar):
                    rep['problems'].append('cert %s: mincorner_LB <= F*_up' % name)
                if d['how'] == 'T1':
                    t = d.get('T1', {}); leaves = t.get('leaves')
                    if not leaves:
                        rep['problems'].append('cert %s: T1 certified without leaves' % name)
                    else:
                        boxes = [([frac(c) - frac(r) for c, r in zip(l[0], l[1])], [frac(c) + frac(r) for c, r in zip(l[0], l[1])]) for l in leaves]
                        ok, msg = partition_ok(boxes, [Fraction(-1)] * 6, [Fraction(1)] * 6)
                        if not ok:
                            rep['problems'].append('cert %s: T1 leaves: %s' % (name, msg))
                        bad = [l for l in leaves if not (Fraction(repr(float(l[3]))) > fstar)]
                        if bad:
                            rep['problems'].append('cert %s: %d T1 leaves with lower <= F*_up' % (name, len(bad)))
                        if t.get('min_lower') is not None and not (Fraction(repr(float(t['min_lower']))) > fstar):
                            rep['problems'].append('cert %s: T1 min_lower <= F*_up' % name)
    for fn in sorted(os.listdir(run)):
        p = os.path.join(run, fn)
        if os.path.isfile(p) and fn not in ('manifest.jsonl', 'status.json', 'config.lock.json', 'constants.json'):
            rep['files'][fn] = dict(bytes=os.path.getsize(p), sha256=sha(p))
    if os.path.isdir(cd):
        for fn in sorted(os.listdir(cd)):
            p = os.path.join(cd, fn); rep['files']['certs/' + fn] = dict(bytes=os.path.getsize(p), sha256=sha(p))
    rep['structural'] = 'PASS' if not rep['problems'] else 'FAIL'
    return rep, const


def check_block(bdir, grid_name, caches=(), ball=1.25):
    """block level (run_block.py layout: round_0, round_1, ..., unresolved.jsonl): the leaves of the whole block =
    skipped cells of every round + certified cells of every round + unresolved cells (+ pending) must partition the
    block cell exactly (guillotine partition test + exact volume; boxes or cubes).  Also runs check_run on every round directory."""
    import grid as G
    from fractions import Fraction as _F
    g = G.near_grid(_F(ball)) if grid_name == 'near' else G.GRIDS[grid_name]; rounds = sorted(d for d in os.listdir(bdir) if d.startswith('round_') and os.path.isdir(os.path.join(bdir, d)))
    leaves = {}; per_round = {}; problems = []
    for rd in rounds:
        d = os.path.join(bdir, rd); rep, _ = check_run(d, grid_name, False, root_check=False, caches=caches, ball=ball)
        per_round[rd] = dict(structural=rep['structural'], cells=rep['cells'], skipped=rep['skipped'], certified=rep['certified'], unresolved=rep['unresolved'])
        problems += ['%s: %s' % (rd, p) for p in rep['problems']]
        sf = os.path.join(d, 'skipped.jsonl'); sfl = jsonl_lines(sf)
        if sfl is not None:
            for line in sfl:
                x = json.loads(line); leaves[(G.levels(x['L']), tuple(x['j']))] = 'skipped'
        cd = os.path.join(d, 'certs')
        if os.path.isdir(cd):
            for name in os.listdir(cd):
                x = json.load(open(os.path.join(cd, name)))
                if x['status'] == 'certified':
                    leaves[(G.levels(x['L']), tuple(x['j']))] = 'certified'
        pf = os.path.join(d, 'pending.jsonl')
        if os.path.exists(pf):
            for line in open(pf):
                x = json.loads(line); leaves[(G.levels(x['L']), tuple(x['j']))] = 'pending'
    uf = os.path.join(bdir, 'unresolved.jsonl')
    if os.path.exists(uf):
        for line in open(uf):
            x = json.loads(line); leaves[(G.levels(x['L']), tuple(x['j']))] = 'unresolved'
    kinds = {}
    for v in leaves.values():
        kinds[v] = kinds.get(v, 0) + 1
    cov = dict(leaves=len(leaves), kinds=kinds)
    if leaves:
        keys = list(leaves); boxes = []
        for L, j in keys:
            lo, hi = g.cell_box(L, j); boxes.append(([frac(v) for v in lo], [frac(v) for v in hi]))
        rlo = [min(b[0][i] for b in boxes) for i in range(6)]; rhi = [max(b[1][i] for b in boxes) for i in range(6)]
        vol = sum(math.prod(hi[i] - lo[i] for i in range(6)) for lo, hi in boxes); rvol = math.prod(rhi[i] - rlo[i] for i in range(6))
        side = rhi[0] - rlo[0]; cube = all(rhi[i] - rlo[i] == side for i in range(6))
        pok, pmsg = partition_ok(boxes, rlo, rhi)
        ok = pok and cube; nest = 0 if pok else 1
        cov.update(root_lo=[str(v) for v in rlo], root_side=str(side), volume_ok=(vol == rvol), root_is_cube=cube,
                   result=('exact partition of the root cell' if ok else 'NOT a partition: ' + pmsg))
        if not ok:
            problems.append('block coverage: %s (volume_ok %s, cube %s)' % (pmsg, vol == rvol, cube))
        if kinds.get('pending') or kinds.get('unresolved'):
            problems.append('block has %d pending / %d unresolved cells (coverage holds only with them counted as leaves)'
                            % (kinds.get('pending', 0), kinds.get('unresolved', 0)))
    rep = dict(rounds=per_round, coverage=cov, problems=problems, structural='PASS' if not problems else 'FAIL')
    json.dump(rep, open(os.path.join(bdir, 'block_status.json'), 'w'), indent=1)
    return rep


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('run'); ap.add_argument('--grid', default='near', choices=('near', 'far'))
    ap.add_argument('--strict', action='store_true', help='exit 1 on any structural problem')
    ap.add_argument('--block', action='store_true', help='RUN is a run_block.py block directory (round_* subdirectories)')
    ap.add_argument('--no-root', action='store_true', help='do not require the leaves to partition a single root cell')
    ap.add_argument('--corner-cache', action='append', default=[], help='run-wide corners.jsonl file(s) that certificates may reference')
    ap.add_argument('--ball', type=float, default=None, help='candidate-ball radius of the near grid (default: config.json of the run, else 1.25)')
    a = ap.parse_args(); run = a.run
    caches = list(a.corner_cache)
    ball = a.ball
    if ball is None:
        for cand in (os.path.join(run, 'config.json'), os.path.join(os.path.dirname(os.path.abspath(run.rstrip('/'))), 'config.json'),
                     os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(run.rstrip('/')))), 'config.json')):
            if os.path.exists(cand):
                ball = json.load(open(cand)).get('ball', 1.25); break
        ball = 1.25 if ball is None else ball
    if a.block:
        gc = os.path.join(os.path.dirname(os.path.abspath(run.rstrip('/'))), 'corners.jsonl')
        if os.path.exists(gc) and gc not in caches:
            caches.append(gc)
    if a.block:
        rep = check_block(run, a.grid, caches, ball)
        print(json.dumps({k: v for k, v in rep.items() if k != 'problems'}))
        for p in rep['problems'][:20]:
            print('PROBLEM', p)
        if a.strict and rep['problems']:
            sys.exit(1)
        return
    rep, const = check_run(run, a.grid, a.strict, root_check=not a.no_root, caches=caches, ball=ball)
    json.dump(config_lock(run), open(os.path.join(run, 'config.lock.json'), 'w'), indent=1)
    json.dump(const, open(os.path.join(run, 'constants.json'), 'w'), indent=1)
    with open(os.path.join(run, 'manifest.jsonl'), 'w') as f:
        for fn, info in rep['files'].items():
            f.write(json.dumps(dict(file=fn, **info)) + '\n')
    status = {k: v for k, v in rep.items() if k != 'files'}
    json.dump(status, open(os.path.join(run, 'status.json'), 'w'), indent=1)
    print(json.dumps({k: v for k, v in status.items() if k != 'problems'}))
    for p in rep['problems'][:20]:
        print('PROBLEM', p)
    if a.strict and rep['problems']:
        sys.exit(1)


if __name__ == '__main__':
    main()
