"""Add the exact binary64 safe fields (lam_lo_f64, area_lo_f64, mu_up_f64, F_lo_safe; rig_paqc.safe_fields) to the
certificates of an existing corners.jsonl (Claude, 2026-11-08; GPT PENT-14b CHANGES: the ball strings only enclose
the balls, so a checker could not verify the printed F_lo against them at the last digit).  The bounds are derived
from the stored ball strings, which enclose the true balls, so they are safe; F_lo_safe <= F_lo by at most a few ulp.
Writes IN PLACE (a .bak copy is kept) -- the certificate content hash changes, so every copy of the same cache must be
migrated together (near_certify stops on a key with two different certificates).
Usage: python3 migrate_safe.py corners.jsonl [...]"""
import sys, os, json, shutil
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, '..', 'scripts'))
import rig_paqc as R
from flint import arb
for path in sys.argv[1:]:
    shutil.copy(path, path + '.bak'); out = []; n = 0; changed = 0
    for l in open(path):
        d = json.loads(l); c = d['cert']; n += 1
        if c is not None and 'F_lo_safe' not in c:
            c.update(R.safe_fields(arb(c['lam_lo']), arb(c['area']), arb(c['mu']))); changed += 1
            assert float(c['F_lo_safe']) <= float(c['F_lo'])
            R.cert_F_lo(c)                      # consistency asserts
        out.append(json.dumps(d))
    open(path, 'w').write('\n'.join(out) + '\n'); print(path, n, 'records,', changed, 'migrated')
