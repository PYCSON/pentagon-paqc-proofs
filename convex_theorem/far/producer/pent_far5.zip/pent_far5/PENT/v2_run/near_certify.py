"""Near-region certify stage, v0.4 (Claude, 2026-11-08; v0.3 same day, v0.2 2026-11-07): certifies the cells of near_planner.py.
For each cell (L, j): corner certificates (corner_v2.certify_corner) shared through the corner key, the min-corner
bound, then the T1 branch-and-bound (rig_t1_v2.py = frozen scripts/rig_t1.py + split2).
v0.2 (after GPT PENT-13b and the corner timing):
  - two corner tiers: 'fast' (nseg 300) for every cell first; a cell that fails with its min-corner bound within
    0.2% of F* is tried once more with 'fine' (nseg 1000) corners; other failures are split directly;
  - corner key = (grid key k, K, nseg, corner_v2.SOLVER): certificates of different settings never mix;
  - a cell whose corners cannot be certified (fail_corner) is split like any other failure (it used to be dropped);
  - certs/<L>_<j>.json carries the corner keys it used (corner_refs) and the tier.
A failed cell is split into its 8 children (grid.children: the 3 coarsest axes halved; v0.4 boxes, ARCH_V2 section 12;
before: 64), written to cells_next.jsonl for the next round (the planner's skip test
is re-applied there).  Resumable: finished cells are skipped; corners cached on disk.
Records: certs/<L>_<j>.json, done.jsonl (summary index, not a proof), corners.jsonl (key -> certificate).
v0.4: cells are boxes (L a level vector, rho a half-width vector; cubes still accepted), --fail-fast N: T1 gives up after N
boxes with no accepted leaf (the two observed failures had 0 accepted after 6,001 and 40,001 boxes; passes accept early).
v0.3: --corner-cache FILE (repeatable) loads read-only run-wide caches; in memory only the slim fields cert_F_lo needs
+ a SHA256 per corner (full certificates stay on disk); new corners are written to OUT/corners.jsonl only.
Usage: python3 near_certify.py OUT [--cells cells.jsonl] [--workers 2] [--K 8] [--max-boxes 6000] [--min-rad 1e-3] [--limit N]"""
import os
for k in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[k] = "1"
import sys, json, time, argparse, itertools, hashlib, struct
import numpy as np
from multiprocessing import Pool
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, '..', 'scripts'))
import near_planner as NP
import grid as G
GRID = G.NEAR
import rig_paqc as R
import rig_t1_v2 as T          # split2 production variant of scripts/rig_t1.py
import corner_v2 as CV
import jsonl_safe as JS       # 2026-11-10: torn-tail repair, fsync, atomic certificate files
from flint import arb

LMAX = 24


def corner_key(x, K, tier):
    """(k_0..k_5, K, nseg, solver) with x = base + k * s_LMAX exactly on the run's grid (x is a cell corner)."""
    return GRID.corner_key(x) + (K, CV.nseg_of(tier), CV.solver())


SLIM_KEYS = ('kind', 'lam_tilde', 'mu', 'area', 'lam_lo', 'F_lo', 'lam_lo_f64', 'area_lo_f64', 'mu_up_f64', 'F_lo_safe', 'lam_lo_f64_hex', 'area_lo_f64_hex', 'F_lo_safe_hex')


def slim(cert):
    """what the certify stage keeps in memory per corner: the fields rig_paqc.cert_F_lo recomputes the bound from, plus
    the SHA256 of the canonical full certificate (conflict detection).  The full certificate lives only on disk
    (v0.3, 2026-11-08: a run-wide cache of 1e6-5e6 corners must not be held as full dicts, ~3-5 KB each)."""
    if cert is None:
        return None
    h = hashlib.sha256(json.dumps(cert, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()
    return dict({k: cert[k] for k in SLIM_KEYS if k in cert}, sha=h)


def compact(cert):
    """24 bytes per corner (2026-11-10; the slim dict measured 2.4 KB in memory, 12 GB at 5e6 corners): F_lo_safe as
    binary64, computed ONCE here by rig_paqc.cert_F_lo (which re-checks FHM, HKS and the exact binary64 chain from the
    stored strings and asserts consistency), followed by the first 16 bytes of the certificate's SHA256 (conflict
    detection).  None for a failed corner.
    A certificate that fails cert_F_lo's checks is kept as BAD (8 bytes 0xff + SHA): it is never used as a bound
    (F_of raises, the certify stage treats the cell as fail_corner and splits it), as before 11-10 where the same
    AssertionError surfaced in t1_job as status 'exception'."""
    if cert is None:
        return None
    sl = slim(cert)
    try:
        f = struct.pack('<d', R.cert_F_lo(sl))
    except (AssertionError, ValueError):
        f = BAD
    return f + bytes.fromhex(sl['sha'])[:16]


BAD = b'\xff' * 8


def usable(v):
    return v is not None and not (isinstance(v, (bytes, bytearray)) and bytes(v[:8]) == BAD)


def F_of(v):
    """the corner's rigorous lower bound of lambda_1 * area: from a compact value, or recomputed from a slim/full dict"""
    if isinstance(v, (bytes, bytearray)):
        assert bytes(v[:8]) != BAD, 'corner certificate failed its consistency checks'
        return struct.unpack('<d', bytes(v[:8]))[0]
    return R.cert_F_lo(v)


def sha_of(v):
    if v is None:
        return None
    if isinstance(v, (bytes, bytearray)):
        return bytes(v[8:24])
    return bytes.fromhex(v['sha'])[:16]


class CornerStore:
    """key (k_0..k_5, K, nseg, solver) -> compact value (or None), with the six grid indices packed into one int per
    (K, nseg, solver) tag: about 200 B per corner instead of 2.4 KB (1 GB at 5e6 corners)."""
    BITS = 26

    def __init__(self):
        self.d = {}

    def _split(self, key):
        k = key[:6]; tag = tuple(key[6:]); ik = 0
        for i, v in enumerate(k):
            v = int(v); assert 0 <= v < 1 << self.BITS, 'corner index out of range'
            ik |= v << (self.BITS * i)
        return tag, ik

    def __contains__(self, key):
        tag, ik = self._split(key); return ik in self.d.get(tag, ())

    def __getitem__(self, key):
        tag, ik = self._split(key); return self.d[tag][ik]

    def __setitem__(self, key, v):
        assert v is None or (isinstance(v, bytes) and len(v) == 24)
        tag, ik = self._split(key); self.d.setdefault(tag, {})[ik] = v

    def __len__(self):
        return sum(len(x) for x in self.d.values())

    def values(self):
        for x in self.d.values():
            yield from x.values()


def load_cache(path, corners, ro=False, keep=None):
    """load a corners.jsonl into `corners`: a CornerStore gets compact values, a plain dict gets slim dicts (manifest);
    keep = set of keys: load only those (manifest, 2026-11-10).  Same key with a different certificate = stop."""
    n = 0; store = isinstance(corners, CornerStore)
    for l in open(path):
        d = json.loads(l); key = tuple(d['key'])
        if keep is not None and key not in keep:
            continue
        v = compact(d['cert']) if store else slim(d['cert']); n += 1
        if key in corners and sha_of(corners[key]) != sha_of(v):
            raise SystemExit('corner cache conflict for key %s (%s): same key, different certificate -- stop' % (key, path))
        corners[key] = v
    return n


def corner_job(args):
    key, x, K, tier = args
    return key, CV.certify_corner(list(x), K, tier)


def rad_of(rho):
    """half-width argument for rig_paqc: a float (cube) or a numpy vector (box)"""
    return rho if isinstance(rho, (int, float)) else np.array(rho, dtype=float)


T1_ENGINE = 'arb'        # 'arb' (rig_t1_v2, production), 'np' (t1_np, experiment) or 'tv' (t1_tv, experiment); set by --t1-engine before the pool starts


def t1_job(args):
    rec, certs, max_boxes, min_rad, tier, refs, fail_fast = args
    t0 = time.time(); p, rho = rec['p'], rec['rho']; rad = rad_of(rho)
    try:
        Fl = [arb(F_of(c)) for c in certs]          # compact values: F_lo_safe, chain-checked when loaded
        g = R.geometry_bound(p, rad); res = dict(L=rec['L'], j=rec['j'], p=p, rho=rho, tier=tier, corner_refs=[list(r) for r in refs])
        if g['ok']:
            res['mincorner_LB'] = float((g['factor'] * R.amin(Fl)).lower())
            if g['factor'] * R.amin(Fl) > R.FSTAR_UP:
                res.update(status='certified', how='mincorner', sec=round(time.time() - t0, 1)); return res
        cd = T.CellData(p, rad, Fl, emode='exact' if T1_ENGINE == 'tv' else 'es')
        if T1_ENGINE == 'tv':          # 2026-11-12 EXPERIMENT: tangent majorant + Bernstein products (t1_tv.py, NEAR_SPEC section 17)
            import t1_tv as TV
            t = TV.certify_T1(cd, R.FSTAR_UP, max_boxes=max_boxes, min_rad=min_rad)
        elif T1_ENGINE == 'np':          # 2026-11-12 EXPERIMENT: binary64 interval arithmetic, batches (t1_np.py, NEAR_SPEC section 16)
            import t1_np as TN
            t = TN.certify_T1(cd, R.FSTAR_UP, max_boxes=max_boxes, min_rad=min_rad)
        else:
            t = T.certify_T1(cd, R.FSTAR_UP, max_boxes=max_boxes, min_rad=min_rad, log_every=10 ** 9, fail_fast=fail_fast)
        res.update(status=t['status'], how='T1', boxes=t['boxes'], bb_sec=t['sec'], sec=round(time.time() - t0, 1))
        res['T1'] = t
    except (AssertionError, ZeroDivisionError, ValueError, np.linalg.LinAlgError) as ex:
        res = dict(L=rec['L'], j=rec['j'], p=p, rho=rho, tier=tier, status='exception', why=repr(ex)[:160], sec=round(time.time() - t0, 1))
    return res


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('out'); ap.add_argument('--cells', default='cells.jsonl')
    ap.add_argument('--workers', type=int, default=2); ap.add_argument('--K', type=int, default=8); ap.add_argument('--nseg', type=int, default=0, help='ignored (v0.1)')
    ap.add_argument('--max-boxes', type=int, default=6000); ap.add_argument('--min-rad', type=float, default=1e-3); ap.add_argument('--limit', type=int, default=0)
    ap.add_argument('--split-axes', type=int, default=3, help='axes halved when a failed cell is split: 3 = 8 children (default), 6 = 64')
    ap.add_argument('--fail-fast', type=int, default=0, help='T1 gives up (status budget, why fail_fast) after this many boxes with no accepted leaf; 0 = off')
    ap.add_argument('--grid', default='near', choices=('near', 'far'))
    ap.add_argument('--sup', default='rig_box', choices=('rig_box', 'fast', 'taylor', 'fan'), help='corner method (corner_v2.SUP): boundary-sup variants of the eigenvalue certificate, or fan = polynomial certificate (lgfan.py); fast/taylor/fan are experiments')
    ap.add_argument('--t1-engine', default='arb', choices=('arb', 'np', 'tv'), help='T1 box test: arb (rig_t1_v2), np (t1_np, experiment) or tv (t1_tv, experiment)')
    ap.add_argument('--ball', type=float, default=1.25, help='candidate-ball radius of the near grid (must equal the planner run)')
    ap.add_argument('--corner-cache', action='append', default=[], help='read-only corners.jsonl file(s) (run-wide cache); new corners go to OUT/corners.jsonl only')
    a = ap.parse_args(); out = a.out; G.SPLIT_AXES = a.split_axes
    global GRID, T1_ENGINE
    T1_ENGINE = a.t1_engine; CV.SUP = a.sup
    if a.grid == 'near':
        NP.configure(a.ball)
    GRID = G.NEAR if a.grid == 'near' else G.GRIDS[a.grid]; os.makedirs(os.path.join(out, 'certs'), exist_ok=True)
    cells = [json.loads(l) for l in open(os.path.join(out, a.cells))]
    # 2026-11-10 crash safety: this process owns done.jsonl, corners.jsonl and cells_next.jsonl of OUT; a stop while
    # appending leaves at most a torn last line, cut here before anything is appended (jsonl_safe.repair_tail)
    donef = os.path.join(out, 'done.jsonl'); cornf = os.path.join(out, 'corners.jsonl'); nextf = os.path.join(out, 'cells_next.jsonl')
    for f in (donef, cornf, nextf):
        if JS.repair_tail(f):
            print('repaired a torn last line of', f, flush=True)
    done = {(G.levels(d['L']), tuple(d['j'])) for d in JS.read_jsonl(donef)}
    corners = CornerStore()
    for path in a.corner_cache + ([cornf] if os.path.exists(cornf) else []):
        if os.path.exists(path):
            load_cache(path, corners)
    todo = [c for c in cells if (G.levels(c['L']), tuple(c['j'])) not in done][:a.limit or None]
    print('cells', len(cells), 'done', len(done), 'todo', len(todo), 'corners cached', len(corners), flush=True)
    pool = Pool(a.workers); t0 = time.time()
    with open(donef, 'a') as fd, open(cornf, 'a') as fc, open(nextf, 'a') as fn:
        def corners_for(batch, tier):
            need = {}
            for c in batch:
                lo, hi = R.cell_endpoints(c['p'], rad_of(c['rho']))
                for x in R.cell_corners(lo, hi):
                    key = corner_key(x, a.K, tier)
                    if key not in corners:
                        need[key] = [float(v) for v in x]
            if need:
                for key, cert in pool.imap_unordered(corner_job, [(k, x, a.K, tier) for k, x in need.items()], chunksize=1):
                    corners[key] = compact(cert); fc.write(json.dumps(dict(key=list(key), cert=cert)) + '\n'); fc.flush()

        def run_tier(batch, tier):
            corners_for(batch, tier); jobs = []; results = []
            for c in batch:
                lo, hi = R.cell_endpoints(c['p'], rad_of(c['rho'])); keys = [corner_key(x, a.K, tier) for x in R.cell_corners(lo, hi)]
                certs = [corners[k] for k in keys]
                if not all(usable(ct) for ct in certs):
                    results.append(dict(L=c['L'], j=c['j'], p=c['p'], rho=c['rho'], tier=tier, status='fail_corner',
                                        corner_refs=[list(k) for k in keys if not usable(corners[k])])); continue
                jobs.append((c, certs, a.max_boxes, a.min_rad, tier, keys, a.fail_fast))
            results += list(pool.imap_unordered(t1_job, jobs, chunksize=1))
            return results

        for start in range(0, len(todo), 4 * a.workers):
            batch = todo[start:start + 4 * a.workers]
            res1 = run_tier(batch, 'fast')
            # retry with fine corners only where corner precision can matter: the min-corner bound is within 0.2% of
            # F* (fast corners lose ~0.05%); a cell that fails by more is too large and is split directly
            near = {(G.levels(r['L']), tuple(r['j'])) for r in res1 if r['status'] != 'certified' and
                    (r.get('mincorner_LB') or 0) >= float(R.FSTAR_UP.lower()) * (1 - 2e-3)}
            retry = [c for c in batch if (G.levels(c['L']), tuple(c['j'])) in near]
            res1 = [r for r in res1 if r['status'] == 'certified' or (G.levels(r['L']), tuple(r['j'])) not in near]
            final = res1 + (run_tier(retry, 'fine') if retry else [])
            # order (2026-11-10): corners -> children of a failed cell -> certificate file (atomic) -> done line, each
            # fsync'ed; a stop anywhere leaves the cell either done with everything on disk, or not done (redone on
            # resume; its children may then appear twice in cells_next.jsonl, run_block de-duplicates them)
            JS.fsync(fc)
            for res in final:
                name = '%s_%s' % (G.level_name(res['L']), '_'.join(map(str, res['j'])))
                if res['status'] != 'certified':
                    for L2, j2 in GRID.children(res['L'], tuple(res['j'])):
                        lo, hi = GRID.cell_box(L2, j2); p, rho = GRID.cell_p_rho(lo, hi)
                        fn.write(json.dumps(dict(L=list(L2), j=list(j2), p=p, rho=rho, lo=lo, hi=hi, parent_status=res['status'])) + '\n')
                    JS.fsync(fn)
                JS.atomic_json(os.path.join(out, 'certs', name + '.json'), res)
                summ = {k: v for k, v in res.items() if k not in ('T1', 'corner_refs')}; fd.write(json.dumps(summ) + '\n')
                print(json.dumps(summ), flush=True)
            JS.fsync(fd)
    pool.close(); print('elapsed', round(time.time() - t0), 's', 'corners', len(corners), flush=True)


if __name__ == '__main__':
    main()
