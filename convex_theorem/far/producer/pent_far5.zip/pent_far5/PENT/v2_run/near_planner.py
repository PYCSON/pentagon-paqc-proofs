"""Near-region production planner, v0.4 (Claude, 2026-11-10: resumable inside a block, plan.ckpt.json every 10 min,
--resume; output byte-identical to v0.3, tests/plan_resume_test.py; v0.3 2026-11-08; v0.2 2026-11-07: pending queue on the cap, skip
certificates as sub-box leaves with reasons; v0.3: BOX cells, ARCH_V2 section 12).  Plans the cells of the F_psi cover
(ARCH_V2.md sections 11, 3.3; FAR_SPEC-style leaf records); certification is a separate stage (near_certify.py).

Grid (grid.py NEAR): root cube R = base + [0, 5/2]^6, base_i = (c_i - 5/4) rounded DOWN to a multiple of 2^-20
(c = plan_cells.C; base_2 = -3/4 exactly, so the mirror plane z_2 = 1/2 is a grid plane at every level).  A cell is
(L, j) with L = (L_0..L_5) the per-axis levels: side_i = 5 2^-(L_i+1), lo_i = base_i + j_i side_i, hi_i = lo_i + side_i,
all EXACT binary64; p = (lo + hi)/2 and rad_i = side_i/2 are exact and rig_paqc.cell_endpoints(p, rad) returns exactly
(lo, hi): neighbouring cells share faces and corners bit-exactly (corner certificates are shared), no gaps.  R contains
the candidate ball of F_psi because its radius is taken as 5/4 - 2^-19 (theta_fpsi_rig.BALL2 is set accordingly here).
Corner key: the integer vector k with corner = base + k s_Lmax.  Records write L as a 6-list (an int = cube is accepted).

Wave algorithm:
  for each cell of the wave:
    SKIP   if theta_fpsi_rig.skippable (rigorous, sub-box budget) proves cell cap W = empty   -> skipped.jsonl
    CERT   if not skippable and rho_eff <= rho_target(cell), rho_eff = (prod side_i)^(1/6) / 2, and at least
           NEEDED_MIN of the cell's volume cannot be skipped (skip_fraction, partial tree to volume/64) -> cells.jsonl
    SPLIT  otherwise: halve the 3 coarsest axes -> 8 children (volume ladder 8, aspect <= 2; v0.2 split all 6 -> 64)
  rho_target(z) = q * |z - c| clipped to [rho_min, rho_max]  (q = median cheapest-size ratio from sample3: 0.147
  identity-like near c, 0.055 relabelled further out; a predictor only: a CERT cell whose T1 fails is split by the
  certify stage).  Why boxes: with cubes the volume ladder is 64 and the near-region cost is about 2.2x the continuum
  estimate; with 8 children about 1x (ladder_cost.py).
Every record carries the exact (L, j) so the checker can rebuild the partition.  Batches: the 64 level-1 cells.
Usage: python3 near_planner.py OUT --block B [--q 0.1] [--rho-min 0.005] [--rho-max 0.08] [--budget 256]
                               [--max-cells 200000] [--cell L,j0,...,j5 | L0-L1-...-L5,j0,...,j5] (count mode)"""
import sys, os, json, math, time, itertools, argparse
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'v2_cover'))
import plan_cells as PC
import theta_fpsi_rig as TR
import grid as G

from fractions import Fraction
from flint import arb
C = [float(v) for v in PC.C]; HALF = 1.25; ROOT_SIDE = 2.5; GRID = Fraction(1, 2 ** 20)
BASE = [float(math.floor(Fraction(C[i]) / GRID - Fraction(5, 4) / GRID) * GRID) for i in range(6)]
assert BASE[2] == -0.75 and all(Fraction(BASE[i]) <= Fraction(C[i]) - Fraction(5, 4) < Fraction(BASE[i]) + GRID for i in range(6))
BALL = 1.25 - 2.0 ** -19
TR.BALL2 = arb(BALL) * arb(BALL)          # exact: BALL is a short dyadic
INF = float('inf')


assert G.NEAR.base == BASE


def configure(R=1.25, box=None):
    """candidate-ball radius R (ARCH_V2 section 12: 5/4 costs ~2x and most planner work; 2 is the candidate) and,
    for experiments, an explicit root box (lo..., hi...) in place of the grid root.  Sets the module globals and
    G.NEAR (all grid calls go through G.NEAR at call time)."""
    global HALF, ROOT_SIDE, BASE, BALL
    HALF = float(R); ROOT_SIDE = 2 * HALF
    BALL = HALF - 2.0 ** -19; TR.BALL2 = arb(BALL) * arb(BALL)
    if box is None:
        G.NEAR = G.near_grid(Fraction(R))
    else:
        lo, hi = box[:6], box[6:]
        assert all(hi[i] - lo[i] == hi[0] - lo[0] for i in range(6)), 'experiment box must be a cube'
        G.NEAR = G.Grid(lo, hi[0] - lo[0], 'near-box')
    BASE = list(G.NEAR.base)


def side(L):
    """cube side (int level) -- kept for the 2026-11-07 tests"""
    return ROOT_SIDE / 2 ** L                     # exact in binary64: 5 * 2^-(L+1)


def cell_box(L, j):
    return G.NEAR.cell_box(L, j)


def cell_p_rho(lo, hi):
    """centre and half-width vector (a float for a cube)"""
    return G.NEAR.cell_p_rho(lo, hi)


def rho_eff(lo, hi):
    """half-width of the cube with the cell's volume"""
    return math.prod(b - a for a, b in zip(lo, hi)) ** (1 / 6) / 2


def selftest(Lmax=24):
    """exactness of the grid: endpoints are the exact dyadic values, neighbours share faces, cell_endpoints round-trips."""
    sys.path.insert(0, os.path.join(HERE, '..', 'scripts'))
    import rig_paqc as R
    rng = np.random.default_rng(0)
    for _ in range(2000):
        L = int(rng.integers(0, Lmax + 1)); j = tuple(int(v) for v in rng.integers(0, 2 ** L, 6)); lo, hi = cell_box(L, j)
        s = Fraction(ROOT_SIDE) / 2 ** L
        for i in range(6):
            assert Fraction(lo[i]) == Fraction(BASE[i]) + j[i] * s and Fraction(hi[i]) == Fraction(BASE[i]) + (j[i] + 1) * s
        p, rho = cell_p_rho(lo, hi); lo2, hi2 = R.cell_endpoints(p, rho)
        assert all(float(lo2[i]) == lo[i] and float(hi2[i]) == hi[i] for i in range(6))
        if j[0] + 1 < 2 ** L:
            lo3, _ = cell_box(L, (j[0] + 1,) + j[1:]); assert lo3[0] == hi[0]
    assert cell_box(3, (0, 0, 4, 0, 0, 0))[0][2] == 0.5
    return True


Q_INNER, Q_OUTER, R_SPLIT = 0.147, 0.055, 0.3
OUTER_LAW_A, OUTER_LAW_B = math.exp(-3.080), 0.736      # rho_best ~ A r^B on the relabelled sample3 centres (2026-11-08)     # sample3 (198 records, 2026-11-07): rho_best / r, identity 0.147,
                                                  # relabelled representatives 0.055 (median); F_psi picks identity-like
                                                  # representatives near c and relabelled ones further out


def rho_target(p, q, rmin, rmax):
    """predicted passing half-width at z = p: q * |z - c| with q = Q_INNER / Q_OUTER by |z - c| (q <= 0 means the
    calibrated rule; a positive q overrides it), clipped to [rmin, rmax].  A prediction only."""
    r = math.sqrt(sum((pi - ci) ** 2 for pi, ci in zip(p, C)))
    if q > 0:
        return min(rmax, max(rmin, q * r))
    if r < R_SPLIT:
        return min(rmax, max(rmin, Q_INNER * r))
    # outer band: the cheapest tested size of the 179 relabelled sample3 centres follows rho ~ 0.0459 r^0.736 (ARCH_V2
    # section 13; rho/r falls from 0.055 at r ~ 0.45 to 0.040 at r ~ 1.8); take the smaller of the two laws
    return min(rmax, max(rmin, min(Q_OUTER * r, OUTER_LAW_A * r ** OUTER_LAW_B)))


def children(L, j):
    """v0.3: the 8 children of halving the 3 coarsest axes (grid.children)"""
    return G.NEAR.children(L, j)


def skip_tree(lo, hi, budget, partial=False):
    """rigorous skip of the box by bisection (widest coordinate, lower half first); returns (leaves, None) where leaves
    is a list of (path, reason) covering the box -- path = string of 'a0'/'a1' steps, a = axis digit -- or
    (None, why_not) when a sub-box could not be skipped or the budget ran out.  The leaves are the skip certificate:
    a checker re-evaluates each reason on its sub-box, without searching.  2026-11-07 (GPT PENT-13b item 5).
    partial=True (v0.3): on failure returns (None, why_not, leaves_so_far, unresolved_paths) so the planner can
    inherit the finished parts (inherit_skips)."""
    stack = [('', list(lo), list(hi))]; leaves = []; used = 0
    while stack:
        path, a_, b_ = stack.pop(); used += 1
        if used > budget:
            return (None, 'budget', leaves, [path] + [q for q, _, _ in stack]) if partial else (None, 'budget')
        why = TR.skippable(a_, b_)
        if why:
            leaves.append((path, why)); continue
        k = int(np.argmax(np.array(b_) - np.array(a_))); mid = (a_[k] + b_[k]) / 2
        b1 = list(b_); b1[k] = mid; a2 = list(a_); a2[k] = mid
        stack += [(path + '%d1' % k, a2, b_), (path + '%d0' % k, a_, b1)]
    return (leaves, None, leaves, []) if partial else (leaves, None)


def inherit_skips(L, j, leaves, unresolved):
    """The skip tree bisects the widest coordinate first (ties: lowest index), which is exactly how grid.children halves
    the coarsest axes, so the tree's depth-3 nodes ARE the 8 children.  A child is already proven skippable when a leaf
    sits at or above it (a leaf path that is a prefix of the child's path: the skip conditions are statements for all
    z in the box, so they hold on sub-boxes) or when its subtree was fully resolved (leaves under it, nothing
    unresolved under it; the DFS finishes a subtree before leaving it).  Returns (skipped_children [(L2, j2, leaves)],
    children_to_process [(L2, j2)]).  Leaf paths of a skipped child are re-rooted at the child."""
    Lv = G.levels(L); axes = G.split_axes(Lv, G.SPLIT_AXES)
    done = []; todo = []
    for L2, j2 in G.NEAR.children(L, j):
        bits = [j2[a] - 2 * j[a] for a in axes]
        prefix = ''.join('%d%d' % (a, b) for a, b in zip(axes, bits))
        above = [(pth, why) for pth, why in leaves if prefix.startswith(pth) and len(pth) < len(prefix)]
        if above:
            done.append((L2, j2, [('', above[0][1])])); continue
        under = [(pth[len(prefix):], why) for pth, why in leaves if pth.startswith(prefix)]
        if under and not any(u.startswith(prefix) or prefix.startswith(u) for u in unresolved):
            done.append((L2, j2, under)); continue
        todo.append((L2, j2))
    return done, todo


NEEDED_MIN = 0.5      # certify a cell whole only when at least this fraction of its volume cannot be skipped (v0.3)
PARTIAL_DEPTH = 12    # partial skip tree: bisect to volume / 2^12 (the cube refinement needed deeper trees to skip its children)


def skip_fraction(lo, hi, budget, depth=PARTIAL_DEPTH):
    """partial skip tree (v0.3, 2026-11-08): bisect the box (widest coordinate) down to `depth` halvings; sub-boxes that
    skippable() proves empty of W are leaves, the rest is 'needed'.  Returns the needed volume fraction (budget
    leftovers count as needed).  Used by the planner to avoid certifying a cell of which only a sliver meets W: the box
    refinement (8 children) is coarser than the old 64-cube one, and a coarse boundary cell wastes certification volume
    (seen on the L4 test cell: 1 of 8 children skippable vs 59 of 64 cubes)."""
    stack = [(0, list(lo), list(hi))]; used = 0; needed = 0.0; total = float(np.prod(np.array(hi) - np.array(lo)))
    while stack:
        d, a_, b_ = stack.pop(); used += 1
        v = float(np.prod(np.array(b_) - np.array(a_)))
        if used > budget or d >= depth:
            if used > budget:
                needed += v + sum(float(np.prod(np.array(y) - np.array(x))) for _, x, y in stack); break
            if not TR.skippable(a_, b_):
                needed += v
            continue
        if TR.skippable(a_, b_):
            continue
        k = int(np.argmax(np.array(b_) - np.array(a_))); mid = (a_[k] + b_[k]) / 2
        b1 = list(b_); b1[k] = mid; a2 = list(a_); a2[k] = mid
        stack += [(d + 1, a2, b_), (d + 1, a_, b1)]
    return needed / total


CKPT = 'plan.ckpt.json'
CKPT_SEC = 600.0       # checkpoint interval (s); 0 = off


def _cell_in(c):
    L, j = c
    return (L if isinstance(L, int) else tuple(L)), tuple(j)


def _cell_out(c):
    L, j = c
    return [L if isinstance(L, int) else list(L), list(j)]


def _fsync(f):
    f.flush(); os.fsync(f.fileno())


def write_ckpt(out, rest, nxt, stats, fc, fs, elapsed):
    """mid-wave checkpoint (2026-11-10, after the 11-09 silent stop of the plan pass: a WSL shutdown cost 8 blocks of
    up to 3.7 h each).  State between two nodes = (rest of the wave, children collected so far, stats, byte sizes of
    cells.jsonl / skipped.jsonl); both files are fsync'ed first and the checkpoint is replaced atomically, so a stop at
    any moment resumes from the last checkpoint with the same output as an uninterrupted run (the planner is
    deterministic; checked by tests/plan_resume_test.py)."""
    _fsync(fc); _fsync(fs)
    d = dict(version=1, rest=[_cell_out(c) for c in rest], nxt=[_cell_out(c) for c in nxt], stats=stats,
             cells_size=fc.tell(), skipped_size=fs.tell(), elapsed=elapsed)
    tmp = os.path.join(out, CKPT + '.tmp')
    with open(tmp, 'w') as f:
        json.dump(d, f); _fsync(f)
    os.replace(tmp, os.path.join(out, CKPT))


def read_ckpt(out):
    """load the checkpoint and cut cells.jsonl / skipped.jsonl back to the sizes it recorded (lines written after it
    are produced again); a file SHORTER than recorded means lost data -> stop."""
    d = json.load(open(os.path.join(out, CKPT)))
    for fn, n in (('cells.jsonl', d['cells_size']), ('skipped.jsonl', d['skipped_size'])):
        f = os.path.join(out, fn); have = os.path.getsize(f) if os.path.exists(f) else 0
        if have < n:
            raise SystemExit('checkpoint says %s has %d bytes, found %d: data lost, restart this block clean' % (fn, n, have))
        with open(f, 'r+b' if os.path.exists(f) else 'wb') as g:
            g.truncate(n)
    return [_cell_in(c) for c in d['rest']], [_cell_in(c) for c in d['nxt']], d['stats'], d['elapsed']


def plan(out, start, a):
    """v0.2: a cap on CERT cells (max_cells) no longer drops work: the unprocessed rest of the wave and the children
    already generated are written to pending.jsonl and stats['complete'] = False (GPT PENT-13b item 1).
    2026-11-10: resumable inside a block (plan.ckpt.json, see write_ckpt); --resume continues from it."""
    os.makedirs(out, exist_ok=True)
    nxt0 = []; elapsed0 = 0.0
    if getattr(a, 'resume', False) and os.path.exists(os.path.join(out, CKPT)):
        wave, nxt0, stats, elapsed0 = read_ckpt(out)
        print('resumed from checkpoint: %d nodes done, %d left in the wave, %d children collected' % (stats['nodes'], len(wave), len(nxt0)), flush=True)
    else:
        for fn in ('cells.jsonl', 'skipped.jsonl', 'pending.jsonl', 'stats.json', CKPT):
            if os.path.exists(os.path.join(out, fn)):
                os.remove(os.path.join(out, fn))
        wave = list(start); stats = dict(nodes=0, skipped=0, cert=0, split=0, budget_needed=0, by_level={}, complete=True)
    fc = open(os.path.join(out, 'cells.jsonl'), 'a'); fs = open(os.path.join(out, 'skipped.jsonl'), 'a')
    t0 = time.time() - elapsed0; ck_sec = getattr(a, 'ckpt_sec', CKPT_SEC); t_ck = time.time()
    first = True
    while wave:
        nxt = nxt0 if first else []; first = False
        for idx, (L, j) in enumerate(wave):
            if ck_sec > 0 and time.time() - t_ck >= ck_sec:
                write_ckpt(out, wave[idx:], nxt, stats, fc, fs, time.time() - t0); t_ck = time.time()
            if stats['cert'] >= a.max_cells:
                with open(os.path.join(out, 'pending.jsonl'), 'a') as fp:
                    for L2, j2 in list(wave[idx:]) + nxt:
                        fp.write(json.dumps(dict(L=list(G.levels(L2)), j=list(j2))) + '\n')
                stats['complete'] = False; nxt = []; break
            stats['nodes'] += 1
            lo, hi = cell_box(L, j); p, rho = cell_p_rho(lo, hi)
            # coarse cells (well above the certification size) get a small skip budget: the cheap whole-box tests
            # (mirror, ball, far/inner d) still fire, the psi test needs fine boxes anyway (v0.3, planner cost ~55 ms/node
            # was dominated by exhausted 256-budget trees at the top levels)
            coarse = rho_eff(lo, hi) > 4 * rho_target(p, a.q, a.rho_min, a.rho_max)
            leaves, why_not, part, unresolved = skip_tree(lo, hi, max(16, a.budget // 16) if coarse else a.budget, partial=True)
            if leaves is not None:
                stats['skipped'] += 1
                fs.write(json.dumps(dict(L=list(G.levels(L)), j=list(j), leaves=leaves)) + '\n'); continue
            if why_not == 'budget':
                stats['budget_needed'] += 1

            def split_here():
                done, todo = inherit_skips(L, j, part, unresolved)
                for L2, j2, lv in done:
                    stats['skipped'] += 1; stats['skip_inherited'] = stats.get('skip_inherited', 0) + 1
                    fs.write(json.dumps(dict(L=list(L2), j=list(j2), leaves=lv)) + '\n')
                stats['split'] += 1; nxt.extend(todo)

            Lv = G.levels(L)
            if rho_eff(lo, hi) <= rho_target(p, a.q, a.rho_min, a.rho_max) or max(Lv) >= a.Lmax:
                # the failed skip tree already proved part of the cell skippable: if that part alone exceeds 1 - needed_min
                # the cell is a sliver without the (0.4 s) partial-tree pass
                covered = sum(2.0 ** (-len(pth) // 2) for pth, _ in part) if part else 0.0
                if a.needed_min > 0 and max(Lv) < a.Lmax and covered > 1.0 - a.needed_min:
                    nf = 1.0 - covered
                else:
                    nf = skip_fraction(lo, hi, 4 * a.budget) if (a.needed_min > 0 and max(Lv) < a.Lmax) else 1.0
                if nf < a.needed_min:
                    stats['split_sliver'] = stats.get('split_sliver', 0) + 1; split_here(); continue
                stats['cert'] += 1; stats['by_level'][G.level_name(Lv)] = stats['by_level'].get(G.level_name(Lv), 0) + 1
                fc.write(json.dumps(dict(L=list(Lv), j=list(j), p=p, rho=rho, lo=lo, hi=hi, needed_frac=round(nf, 3))) + '\n'); continue
            split_here()
        wave = nxt; fc.flush(); fs.flush()
        print('wave done: %s  next %d  %.0fs' % ({k: v for k, v in stats.items() if k != 'by_level'}, len(wave), time.time() - t0), flush=True)
    stats['sec'] = round(time.time() - t0, 1)
    _fsync(fc); _fsync(fs); fc.close(); fs.close()
    json.dump(stats, open(os.path.join(out, 'stats.json'), 'w'), indent=1)
    if os.path.exists(os.path.join(out, CKPT)):
        os.remove(os.path.join(out, CKPT))
    return stats


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('out'); ap.add_argument('--block', type=int, default=-1)
    ap.add_argument('--Lmax', type=int, default=11); ap.add_argument('--q', type=float, default=0.0, help='0 = calibrated rule (Q_INNER / Q_OUTER)')
    ap.add_argument('--rho-min', type=float, default=0.005); ap.add_argument('--rho-max', type=float, default=0.08)
    ap.add_argument('--budget', type=int, default=256); ap.add_argument('--max-cells', type=int, default=200000)
    ap.add_argument('--cell', default='', help='start from one cell L,j0,j1,...,j5 (count mode test)')
    ap.add_argument('--needed-min', type=float, default=NEEDED_MIN, help='certify a cell whole only if this fraction of it cannot be skipped (0 = off)')
    ap.add_argument('--split-axes', type=int, default=3, help='axes halved per split: 3 = boxes, 8 children (default); 6 = cubes, 64 children')
    ap.add_argument('--ball', type=float, default=1.25, help='candidate-ball radius (short dyadic; 1.25 = v0.2 design, 2 = ARCH_V2 12 candidate)')
    ap.add_argument('--resume', action='store_true', help='continue from OUT/plan.ckpt.json if present (otherwise start clean)')
    ap.add_argument('--ckpt-sec', type=float, default=CKPT_SEC, help='checkpoint interval in seconds (0 = off)')
    ap.add_argument('--box', default='', help='EXPERIMENT: root box lo0,...,lo5,hi0,...,hi5 (cube) instead of the grid; cells are relative to it')
    a = ap.parse_args(); G.SPLIT_AXES = a.split_axes
    configure(a.ball, [float(v) for v in a.box.split(',')] if a.box else None)
    assert a.box or selftest()
    if a.cell:
        v = a.cell.split(','); L0 = tuple(int(x) for x in v[0].split('-')) if '-' in v[0] else int(v[0])
        start = [(L0, tuple(int(x) for x in v[1:]))]
    elif a.block >= 0:
        d = [(a.block >> i) & 1 for i in range(6)]; start = [(1, tuple(d))]
    else:
        start = [(0, (0,) * 6)]
    st = plan(a.out, start, a); print(json.dumps(st, indent=1))


if __name__ == '__main__':
    main()
