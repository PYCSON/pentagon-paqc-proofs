"""Plan-only pass over the whole near region (Claude, 2026-11-08).  Runs near_planner.py on the 64 level-1 blocks in
parallel (one process per block, N at a time) into RUN/blocks/XX/round_0/ exactly as run_block.py round 0 would, and
marks each finished block with planned.ok so run_block.py skips planning and goes straight to certification.
Why a separate pass: planning needs no corners and no T1 (about 70 ms per node), so the complete cell list of the
cover is available early; from it the certification cost is estimated exactly for the corner part (distinct corner
keys of all CERT cells x seconds per corner) and from sample3 for the T1 part, before any long run starts.
Output: RUN/plan_summary.json (per block: nodes, skipped, cert cells by level, planner seconds; totals: cells, distinct
corners over all blocks, certified volume) and a progress one-liner on stdout.
Usage: python3 plan_all.py RUN [--parallel 8] [--blocks 0-63] [--budget 256]
       python3 plan_all.py RUN --summary            (recompute the summary from finished blocks)"""
import os, sys, json, time, argparse, subprocess
from multiprocessing import Pool
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, '..', 'scripts'))


def plan_block(args):
    run, b, cfg = args
    import run_block as RB
    bdir = os.path.join(run, 'blocks', '%02d' % b); rdir = os.path.join(bdir, 'round_0'); os.makedirs(rdir, exist_ok=True)
    if os.path.exists(os.path.join(rdir, 'planned.ok')):
        return b, 'already'
    # 2026-11-10: an interrupted block RESUMES from the planner's checkpoint (plan.ckpt.json, written every 10 min);
    # without one the planner starts the block clean itself.  States after the planner ended (stats.json written, no
    # checkpoint) go straight to the gzip step.
    sk = os.path.join(rdir, 'skipped.jsonl'); gz = sk + '.gz'; ck = os.path.join(rdir, 'plan.ckpt.json')
    finished = os.path.exists(os.path.join(rdir, 'stats.json')) and not os.path.exists(ck)
    d = [(b >> i) & 1 for i in range(6)]; start = '1,' + ','.join(map(str, d))
    t0 = time.time()
    if finished:
        return _finish_block(rdir, t0, b, 'finished earlier')
    if os.path.exists(gz):
        os.remove(gz)                  # a partial gzip from a stop during compression; skipped.jsonl is still there
    with open(os.path.join(rdir, 'plan.log'), 'a') as log:
        log.write('=== plan_all start %s (resume=%s)\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), os.path.exists(ck))); log.flush()
        rc = subprocess.run([sys.executable, os.path.join(HERE, 'near_planner.py'), rdir, '--resume', '--cell', start,
                             '--q', str(cfg['q']), '--rho-min', str(cfg['rho_min']), '--rho-max', str(cfg['rho_max']),
                             '--budget', str(cfg['budget']), '--Lmax', str(cfg['Lmax']), '--max-cells', '100000000',
                             '--split-axes', str(cfg.get('split_axes', 3)), '--needed-min', str(cfg.get('needed_min', 0.5)),
                             '--ball', str(cfg.get('ball', 1.25))],
                            stdout=log, stderr=subprocess.STDOUT)
    if rc.returncode != 0:
        return b, 'error rc %d' % rc.returncode
    return _finish_block(rdir, t0, b, 'ok')


def _finish_block(rdir, t0, b, msg):
    """gzip the skip records (hundreds of MB per block as text; ~8x smaller; readers accept .jsonl or .jsonl.gz) and
    write planned.ok.  Restartable: the .gz is written under a temporary name, verified, then renamed; skipped.jsonl
    is removed only after that."""
    import gzip, shutil
    st = json.load(open(os.path.join(rdir, 'stats.json')))
    if not st.get('complete', True):
        return b, 'incomplete (pending)'
    sk = os.path.join(rdir, 'skipped.jsonl'); gz = sk + '.gz'
    if os.path.exists(sk):
        tmp = gz + '.tmp'
        with open(sk, 'rb') as fi, gzip.open(tmp, 'wb', compresslevel=6) as fo:
            shutil.copyfileobj(fi, fo)
        n1 = sum(1 for _ in open(sk, 'rb')); n2 = sum(1 for _ in gzip.open(tmp, 'rb'))
        if n1 != n2:
            return b, 'gzip check failed (%d vs %d lines)' % (n1, n2)
        os.replace(tmp, gz); os.remove(sk)
    elif not os.path.exists(gz):
        return b, 'error: no skip records'
    open(os.path.join(rdir, 'planned.ok'), 'w').write('%.1f\n' % (time.time() - t0))
    return b, '%s %.0fs' % (msg, st.get('sec', time.time() - t0))


def summary(run):
    import grid as G, rig_paqc as R, near_certify as NC, run_block as RB, near_planner as NP
    NP.configure(RB.load_config(run).get('ball', 1.25))
    out = dict(blocks={}, totals=dict(cells=0, skipped=0, nodes=0, planner_sec=0.0, cert_volume=0.0, by_level={}))
    corners = set()
    for b in range(64):
        rdir = os.path.join(run, 'blocks', '%02d' % b, 'round_0')
        sf = os.path.join(rdir, 'stats.json')
        if not os.path.exists(os.path.join(rdir, 'planned.ok')) or not os.path.exists(sf):
            continue
        st = json.load(open(sf)); ncell = 0; vol = 0.0
        for l in open(os.path.join(rdir, 'cells.jsonl')):
            c = json.loads(l); ncell += 1
            lo, hi = R.cell_endpoints(c['p'], NC.rad_of(c['rho'])); vol += float(__import__('numpy').prod(hi - lo))
            for x in R.cell_corners(lo, hi):
                corners.add(G.NEAR.corner_key([float(v) for v in x]))
            name = G.level_name(c['L']); out['totals']['by_level'][name] = out['totals']['by_level'].get(name, 0) + 1
        out['blocks'][b] = dict(nodes=st['nodes'], skipped=st['skipped'], cells=ncell, split_sliver=st.get('split_sliver', 0), sec=st['sec'], cert_volume=vol)
        T = out['totals']; T['cells'] += ncell; T['skipped'] += st['skipped']; T['nodes'] += st['nodes']; T['planner_sec'] += st['sec']; T['cert_volume'] += vol
    out['totals']['distinct_corners'] = len(corners); out['totals']['blocks_done'] = len(out['blocks'])
    out['totals']['corner_cpu_days_at_5s'] = round(len(corners) * 5 / 86400, 2)
    # T1 part, rough: sample3 passes near the planner's size need ~1,000-2,000 boxes (70-130 s at 0.067 s/box); with the
    # ~20% first-try failures (full 6,000-box budget, then 8 children) about 150 s per planned cell on average
    out['totals']['t1_cpu_days_rough_150s_per_cell'] = round(out['totals']['cells'] * 150 / 86400, 2)
    out['totals']['note'] = 'corner part exact in count (x 5 s fast tier; fine-tier retries extra); T1 part rough; neither includes the far region'
    json.dump(out, open(os.path.join(run, 'plan_summary.json'), 'w'), indent=1)
    return out


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('run'); ap.add_argument('--parallel', type=int, default=8)
    ap.add_argument('--blocks', default='0-63'); ap.add_argument('--summary', action='store_true')
    a = ap.parse_args(); run = a.run
    if a.summary:
        s = summary(run); print(json.dumps(s['totals'], indent=1)); return
    import run_block as RB
    os.makedirs(run, exist_ok=True)          # 2026-11-09: the run directory may not exist yet (user report)
    cfg = RB.load_config(run)
    lo, hi = [int(v) for v in a.blocks.split('-')] if '-' in a.blocks else (int(a.blocks), int(a.blocks))
    blocks = list(range(lo, hi + 1)); t0 = time.time(); done = 0
    with Pool(a.parallel) as pool:
        for b, msg in pool.imap_unordered(plan_block, [(run, b, cfg) for b in blocks]):
            done += 1
            print('block %02d: %s   [%d/%d, %.0f s]' % (b, msg, done, len(blocks), time.time() - t0), flush=True)
    s = summary(run); print(json.dumps(s['totals'], indent=1))


if __name__ == '__main__':
    main()
