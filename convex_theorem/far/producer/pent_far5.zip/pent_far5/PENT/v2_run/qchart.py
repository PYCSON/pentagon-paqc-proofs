"""Quadrilateral invariants and closed-form tests on boxes of the charts std / E2 / E3 (Claude, 2026-11-12; FAR_SPEC 9.9).
DRAFT for review.  Q = (q0, q1, q2, q3) = (0, (1,0), q2, q3), edge vectors e0 = (1,0), e1 = q2 - q1, e2 = q3 - q2, e3 = -q3.
Invariants (cross products of edge vectors):
   q3y = e3 x e0,  q2y = e0 x e1,  K = e1 x e2,  D = e2 x e3 = q2 x q3,  M = e3 x e1 = D - q3y,  L = e0 x e2 = q3y - q2y,
   A2 = 2 |Q| = q2y + D.         Q convex and positively oriented  <=>  q2y, K, D, q3y > 0.
In each chart (cutchart.to_std) the vertices are multi-affine in the chart coordinates w and every coordinate moves all
vertices along one common direction, so every cross product of vertex differences is MULTI-AFFINE in w (its second
derivative in one coordinate is 2 (d_x u) x (d_x v) = 0).  Hence the exact range of each invariant over a w-box is
attained at the 16 corners.  All statements below are needed for the CONVEX members of the box only, so the ranges of
q2y, K, D, q3y are clipped to [0, inf).
Closed forms (each bound is monotone in the invariants it uses, so it is evaluated at the ends of their ranges):
   u3     F(Q) >= (4 pi^2 / sqrt 3) / (1 + ear_k / |Q|),  ear_k / |Q| = A_k B_k / (C_k A2),  needs C_k > 0 on the box:
          k = 0: (q3y, q2y, M);  k = 1: (q2y, K, L);  k = 2: (K, D, -M);  k = 3: (D, q3y, -L)
          (T_e = Q + ear_k is the triangle bounded by the lines of the edges k-1, k+1 and the opposite edge)
   strip  F(Q) >= pi^2 |Q| / max(q2y, q3y)^2;     floor  2 pi^2 (Polya-Szego for quadrilaterals)
   tau    tau_3 = D / (q2y + D),  tau_0 = q3y / (q2y + D)          (|P| = |Q| (1 - t u tau_j))
   X      't u > g  ==>  another edge k' has a smaller ear' (cutchart.not_kept, untouched edges):
          j = 3:  k' = 0: M > 0, g = q2y q3y / (D M);      k' = 1: L > 0, g = q2y K / (L D)
          j = 0:  k' = 1: L > 0, g = q2y K / (q3y L);      k' = 2: M < 0, g = D K / (q3y (-M))
Column test TX:  theta_T := (1 - F*_up / LB) / sup tau_j  >  sup g   ==>   every (t, u): t u < theta_T (proved by F1) or
t u >= theta_T > g (not kept).  The whole column  w-box x [0,1]^2  is closed."""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
for p in ('.', '../scripts'):
    sys.path.insert(0, os.path.join(HERE, p))
from flint import arb
import rig_paqc as R
import cutchart as CC

TRI_MIN = 4 * arb.pi() ** 2 / arb(3).sqrt()
TWO_PI2 = 2 * arb.pi() ** 2
NAMES = ('q2y', 'q3y', 'K', 'D', 'M', 'L', 'A2')
INF = float('inf')


def invariants(lo4, hi4, chart='std'):
    """exact ranges over the w-box: dict name -> (lower float, upper float), outward"""
    mn = {n: INF for n in NAMES}; mx = {n: -INF for n in NAMES}
    for b in range(16):
        w = [arb(float(hi4[i] if (b >> i) & 1 else lo4[i])) for i in range(4)]
        q2x, q2y, q3x, q3y = CC.to_std(w + [arb(0), arb(0)], chart)[:4]
        D = q2x * q3y - q2y * q3x
        v = dict(q2y=q2y, q3y=q3y, K=D - q3y + q2y, D=D, M=D - q3y, L=q3y - q2y, A2=q2y + D)
        for n in NAMES:
            a = R.f_down(v[n]); c = R.f_up(v[n])
            mn[n] = min(mn[n], a); mx[n] = max(mx[n], c)
    return {n: (mn[n], mx[n]) for n in NAMES}


def noncvx(inv):
    """no convex positively oriented quadrilateral in the box"""
    return any(inv[n][1] <= 0 for n in ('q2y', 'q3y', 'K', 'D'))


def all_convex(inv):
    return all(inv[n][0] > 0 for n in ('q2y', 'q3y', 'K', 'D'))


def _hi(inv, n):
    return arb(max(inv[n][1], 0.0))


def quad_lb(inv):
    """rigorous lower bound of F on the convex quadrilaterals of the box: max(floor, u3, strip); returns (float, how)"""
    best = R.f_down(TWO_PI2); how = 'floor'
    A2lo = inv['A2'][0]
    if A2lo > 0:
        for An, Bn, Cn, sg in (('q3y', 'q2y', 'M', 1), ('q2y', 'K', 'L', 1), ('K', 'D', 'M', -1), ('D', 'q3y', 'L', -1)):
            Clo = inv[Cn][0] if sg > 0 else -inv[Cn][1]
            if Clo > 0:
                ear = _hi(inv, An) * _hi(inv, Bn) / (arb(Clo) * arb(A2lo))
                v = R.f_down(TRI_MIN / (1 + ear))
                if v > best:
                    best = v; how = 'u3'
        w = arb(max(inv['q2y'][1], inv['q3y'][1]))
        if w > 0:
            v = R.f_down(arb.pi() ** 2 * arb(A2lo) / (2 * w * w))
            if v > best:
                best = v; how = 'strip'
    # strip without an area bound (2026-11-15): a convex Q with the edge (0,0)-(1,0) and height w = max(q2y, q3y)
    # contains the triangle over that edge with apex at its highest vertex, so |Q| >= w / 2 and F(Q) >= pi^2 / (2 w)
    wh = max(inv['q2y'][1], inv['q3y'][1])
    if wh > 0:
        v = R.f_down(arb.pi() ** 2 / (2 * arb(wh)))
        if v > best:
            best = v; how = 'strip'
    return best, how


def quad_fibre(lo4, hi4, chart, inv):
    """fibre bound (fibre.py, Lemma OD) for the convex quadrilaterals of the w-box (2026-11-15): the vertices are
    multi-affine in w, so every Q(w) of the box has its vertices in the convex hull H of the 64 corner vertices, a convex
    Q(w) lies in H, and F(Q) >= (fibre bound of lambda_1(H)) * A2_min / 2  (A2 = 2 |Q| is multi-affine, exact range in inv).
    Returns a float lower bound (0.0 if nothing is proved).  The direction is a float choice from the centre."""
    import fibre as FB
    if inv['A2'][0] <= 0:
        return 0.0
    Vs = []
    for b in range(16):
        w = [float(hi4[i] if (b >> i) & 1 else lo4[i]) for i in range(4)]
        q = _exact_std(w, chart)
        if q is None:
            return 0.0
        Vs.append([(0.0, 0.0), (1.0, 0.0), (q[0], q[1]), (q[2], q[3])])
    qc = [float(v) for v in CC.to_std([(lo4[i] + hi4[i]) / 2 for i in range(4)] + [0.0, 0.0], chart)[:4]]
    est, d = FB.best_direction([(0.0, 0.0), (1.0, 0.0), (qc[0], qc[1]), (qc[2], qc[3])])
    if d is None:
        return 0.0
    return FB.family_lower(Vs, arb(inv['A2'][0]) / 2, d, N=128)


def _exact_std(w, chart):
    """standard coordinates of the chart point w as exact binary64 numbers, or None if they are not representable"""
    from fractions import Fraction
    q = [float(v) for v in CC.to_std(list(w) + [0.0, 0.0], chart)[:4]]
    qf = CC.to_std([Fraction(v) for v in w] + [Fraction(0), Fraction(0)], chart)[:4]
    return q if all(Fraction(a) == b for a, b in zip(q, qf)) else None


def tau_sup(inv, j):
    """upper bound of tau_j on the convex members; None if not available"""
    if j == 3:
        Dh = max(inv['D'][1], 0.0); q2lo = max(inv['q2y'][0], 0.0)
        if Dh + q2lo <= 0:
            return 1.0
        return R.f_up(arb(Dh) / (arb(q2lo) + arb(Dh)))            # D / (q2y + D): increasing in D, decreasing in q2y
    if inv['A2'][0] <= 0:
        return 1.0                                                 # tau_j <= 1: the corner triangle lies in the convex Q
    return min(1.0, R.f_up(_hi(inv, 'q3y') / arb(inv['A2'][0])))


def x_threshold(inv, j):
    """upper bound of the smallest g over the box such that t u > g implies 'not kept' (untouched edges); inf if none"""
    best = INF

    def take(num, den_lo):
        nonlocal best
        if all(d > 0 for d in den_lo):
            den = arb(1)
            for d in den_lo:
                den *= arb(d)
            best = min(best, R.f_up(num / den))
    if j == 3:
        take(_hi(inv, 'q2y') * _hi(inv, 'q3y'), (inv['D'][0], inv['M'][0]))
        take(_hi(inv, 'q2y') * _hi(inv, 'K'), (inv['L'][0], inv['D'][0]))
    else:
        take(_hi(inv, 'q2y') * _hi(inv, 'K'), (inv['q3y'][0], inv['L'][0]))
        take(_hi(inv, 'D') * _hi(inv, 'K'), (inv['q3y'][0], -inv['M'][1]))
    return best


def theta_T(inv, j, LB):
    """t u < theta_T is proved by F1 on the box (LB = lower bound of F on its convex quadrilaterals)"""
    ts = tau_sup(inv, j)
    if ts is None or LB == INF:
        return 0.0
    if ts <= 0:
        return 4.0
    # not capped at 1: theta_T > 1 means that even t = u = 1 is proved, so the test t_hi u_hi < theta_T closes the whole
    # column (2026-11-15; the cap left the columns next to D = 0 in chart E3, j = 3, open down to the minimal size)
    return max(0.0, min(4.0, R.f_down((1 - R.FSTAR_UP / arb(LB)) / arb(ts))))


def stub_not_kept(lo, hi, j, chart='std'):
    """the two shortened edges: multi-affine polynomials in the chart coordinates (w-part times (t,u)-part), exact
    ranges at the 64 corners.  Returns k' or None."""
    for k, C, g in CC.STUB[j]:
        if CC._corner_range(lambda z: C(CC.to_std(z, chart)), lo, hi)[0] > 0 and CC._corner_range(lambda z: g(CC.to_std(z, chart)), lo, hi)[1] < 0:
            return k
    return None


def defer(inv_std_box, lo4, hi4, H2, H3):
    """standard chart only: 'E2' if K < H2 (1 - q3x) on the whole q-box, 'E3' if D < H3 q2x (both multi-affine in q).
    Only boxes with q3y >= 1/4 go to E2 and only boxes with q2x >= 1/4 go to E3, so that the edge-chart coordinates of
    the deferred quadrilaterals are bounded: a = (1 - q2x) / (1 - q3x) with |a| |q3 - q1| <= |e1| + h <= 1 + H2 and
    |q3 - q1| >= q3y >= 1/4 give |a| <= 4 (1 + H2);  b = q3x / q2x with |q3x| <= |e3| <= 1 gives |b| <= 4.
    (E2_RANGE / E3_RANGE below are the root ranges of the edge-chart runs.)"""
    e2 = lo4[3] >= 0.25; e3 = lo4[0] >= 0.25
    for b in range(16):
        q = [arb(float(hi4[i] if (b >> i) & 1 else lo4[i])) for i in range(4)]
        D = q[0] * q[3] - q[1] * q[2]; K = D - q[3] + q[1]
        e2 = e2 and bool(K - arb(H2) * (1 - q[2]) < 0)
        e3 = e3 and bool(D - arb(H3) * q[0] < 0)
    return 'E2' if e2 else ('E3' if e3 else None)


# root ranges of the edge-chart runs, in cells of side 1/16: (first coordinate, second, a or b); h in [0, H]
E2_RANGE = (range(-16, 16), range(4, 16), range(-72, 72))        # q3x in [-1, 1], q3y in [1/4, 1], a in [-4.5, 4.5]
E3_RANGE = (range(4, 32), range(0, 16), range(-64, 64))          # q2x in [1/4, 2], q2y in [0, 1], b in [-4, 4]


def edge_roots(chart, H, S0=1 / 16):
    """root boxes of an edge-chart run that contain a convex quadrilateral: list of (key, lo4, hi4), in a fixed order
    (cut_run.py and qtable.py shuffle this list with the same seed to draw the same sample)"""
    xr, yr, ar = E2_RANGE if chart == 'E2' else E3_RANGE; out = []
    for ix in xr:
        for iy in yr:
            for ia in ar:
                for ih in range(int(round(H / S0))):
                    lo4 = [ix * S0, iy * S0, ia * S0, ih * S0]; hi4 = [v + S0 for v in lo4]
                    if not noncvx(invariants(lo4, hi4, chart)):
                        out.append(((ix, iy, ia, ih), lo4, hi4))
    return out


def std_roots(t4dir, S0=1 / 16):
    """root cells of the standard chart: the cells of side S0 classified 'build' by t4table (classes.json: a convex
    quadrilateral with the base as longest edge may lie in the cell).  List of (key, lo4, hi4, LB of the old table or 0)."""
    import json, os
    import t4table as T4
    cl = json.load(open(os.path.join(t4dir, 'classes.json'))); old = {}
    f = os.path.join(t4dir, 'cells.jsonl')
    if os.path.exists(f):
        for line in open(f):
            if line.endswith('\n'):
                d = json.loads(line)
                if d.get('LB') is not None and d.get('how') != 'noncvx':
                    old[tuple(d['key'])] = d['LB']
    out = []
    for ks, c in sorted(cl.items()):
        if c == 'build':
            k = tuple(int(v) for v in ks.split(',')); lo4, hi4 = T4.cell_box(k, S0)
            out.append((k, lo4, hi4, old.get(k, 0.0)))
    return out


def face_not_kept(lo, hi, j, depth=7):
    """Chart E3, boxes that touch the corner face q2y = 0 = h (lo[1] == 0 == lo[3]), 2026-11-16.
    In E3 the invariants are linear and homogeneous in (q2y, h):
        q3y = b q2y + h,  D = q2x h,  K = h (q2x - 1) + q2y (1 - b),  M = h (q2x - 1) - b q2y,  L = h - (1 - b) q2y,
    and a convex member has q2y > 0, h > 0 (D > 0).  With r = h / q2y in (0, inf) the 'not kept' comparisons of
    cutchart.not_kept (untouched edges), divided by q2y^2, read
        j = 0:  k' = 1:  r - (1-b) > 0  and  t u (b + r)(r - (1-b)) > r (q2x-1) + (1-b)
                k' = 2:  r (q2x-1) - b < 0  and  t u (b + r)(b - r (q2x-1)) > q2x r (r (q2x-1) + (1-b))
        j = 3:  k' = 0:  r (q2x-1) - b > 0  and  t u q2x r (r (q2x-1) - b) > b + r
                k' = 1:  r - (1-b) > 0  and  t u q2x r (r - (1-b)) > r (q2x-1) + (1-b)
    They do not depend on the size of the box in q2y and h.  The half line r > 0 is covered by [0, 1] and, with
    s = 1 / r, by s in [0, 1] (the comparisons divided by r^2); each piece is bisected until, in ball arithmetic over
    the ranges of q2x, b, t, u, one comparison certainly holds or K <= 0 certainly (no convex member).
    Returns True if every convex member of the box with q2y > 0, h > 0 is not kept."""
    if not (lo[1] == 0.0 and lo[3] == 0.0):
        return False

    def ball(a, b):
        a, b = max(a, 0.0), max(b, 0.0)                             # r, s, q2x, b are >= 0 here (b < 0 is not handled)
        return arb((a + b) / 2, (b - a) / 2 * (1 + 1e-12))
    if lo[2] < 0:
        return False
    # tu: the LOWER end of t u.  Every comparison has the form t u A > B with A > 0 required first (A is a product of
    # factors that are checked to be positive), so t u A >= tu A on the box.
    x = ball(lo[0], hi[0]); b = ball(lo[2], hi[2]); tu = arb(float(lo[4])) * arb(float(lo[5])); one = arb(1)
    if not (x > 0):
        return False

    def ok_r(r):                                                    # r = h / q2y in the ball r
        K = r * (x - 1) + (one - b); L = r - (one - b); M = r * (x - 1) - b; q3 = b + r; D = x * r
        if K <= 0:
            return True
        if not (q3 > 0):
            return False
        if j == 0:
            return bool((L > 0 and tu * q3 * L - K > 0) or (M < 0 and tu * q3 * (-M) - D * K > 0))
        return bool((M > 0 and tu * D * M - q3 > 0) or (L > 0 and tu * L * D - K > 0))

    def ok_s(s):                                                    # s = q2y / h in the ball s; everything divided by r
        K = (x - 1) + (one - b) * s; L = one - (one - b) * s; M = (x - 1) - b * s; q3 = b * s + 1; D = x
        if K <= 0:
            return True
        if not (q3 > 0):
            return False
        if j == 0:
            return bool((L > 0 and tu * q3 * L - s * K > 0) or (M < 0 and tu * q3 * (-M) - D * K > 0))
        return bool((M > 0 and tu * D * M - s * q3 > 0) or (L > 0 and tu * L * D - s * K > 0))

    def cover(f, a, c, d):
        if f(ball(a, c)):
            return True
        if d == 0:
            return False
        m = (a + c) / 2
        return cover(f, a, m, d - 1) and cover(f, m, c, d - 1)
    return cover(ok_r, 0.0, 1.0, depth) and cover(ok_s, 0.0, 1.0, depth)
