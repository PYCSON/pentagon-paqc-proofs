"""Quadrilateral-level tier probe (Claude, 2026-11-12; FLOAT, analysis only): for random convex quadrilaterals in the
normalised chart (q0 = 0, q1 = 1, longest edge = base), F(Q) and the triangle descent  max_j F(T_j) |Q|/|T_j|
(T_j = the triangle of the three edge lines other than edge j, when it contains Q), with the minimal turn
(cross product of consecutive edges) as the distance to the convexity boundary.  Question: how much does the
triangle descent lose near the boundary of the quadrilateral table, where the n = 4 PAQC gate fails?
Usage: python3 quad_tier_probe.py OUT [--n 600] [--seed 1] [--jobs 2]"""
import os, sys, json, argparse
from multiprocessing import Pool
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import numpy as np
import far_design_probe as FD


def del_edge(V, j):
    n = len(V); a, b, c, d = V[(j - 1) % n], V[j], V[(j + 1) % n], V[(j + 2) % n]
    u, v = b - a, d - c; den = FD.cross(u, v)
    if abs(den) < 1e-12:
        return None
    t = FD.cross(c - a, v) / den
    if t < 1:
        return None
    w = a + t * u
    return np.array([V[(j + 2 + i) % n] for i in range(n - 2)] + [w])


def job(x):
    V = np.array([[0, 0], [1, 0], x[0:2], x[2:4]], float); A = FD.poly_area(V)
    turns = [FD.cross(V[(i + 1) % 4] - V[i], V[(i + 2) % 4] - V[(i + 1) % 4]) for i in range(4)]
    per = sum(np.linalg.norm(V[(i + 1) % 4] - V[i]) for i in range(4))
    rec = dict(x=[float(v) for v in x], A=float(A), minturn=float(min(turns)), HP=float(np.pi ** 2 * per ** 2 / (16 * A)), F=FD.F_float(V), t=[])
    for j in range(4):
        T = del_edge(V, j)
        if T is None or FD.cross(T[1] - T[0], T[2] - T[0]) <= 0:
            rec['t'].append(None); continue
        rho = A / FD.poly_area(T)
        rec['t'].append([float(rho), FD.F_float(T) if rho > 0.5 else None])
    return rec


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('out'); ap.add_argument('--n', type=int, default=600)
    ap.add_argument('--seed', type=int, default=1); ap.add_argument('--jobs', type=int, default=2)
    a = ap.parse_args(); os.makedirs(a.out, exist_ok=True); rng = np.random.default_rng(a.seed); pts = []
    while len(pts) < a.n:
        x = np.array([rng.uniform(0, 2), rng.uniform(0, 1), rng.uniform(-1, 1), rng.uniform(0, 1)])
        V = np.array([[0, 0], [1, 0], x[0:2], x[2:4]])
        if FD.convex(V) and all(np.linalg.norm(V[(i + 1) % 4] - V[i]) <= 1 for i in range(1, 4)):
            pts.append(x)
    with Pool(a.jobs) as pool, open(os.path.join(a.out, 'quad_tier.jsonl'), 'w') as f:
        for rec in pool.imap(job, pts, chunksize=4):
            f.write(json.dumps(rec) + '\n'); f.flush()


if __name__ == '__main__':
    main()
