"""Near-region block driver, v0.3 (Claude, 2026-11-08: box cells (grid.py, 8 children per split), fail_fast in config,
read-only run-wide corner cache, block-level structural check via manifest.py; v0.2 2026-11-07: corner-cache conflict stop, pending stop, final state
"queue_empty" instead of "done"): plan -> certify -> split -> ... for one level-1 block.
Layout (RUN/blocks/<b>/): round_<r>/cells.jsonl, skipped.jsonl, done.jsonl, certs/, cells_next.jsonl; state.json;
RUN/corners.jsonl shared by all blocks (near_certify reads/appends); RUN/config.json frozen parameters (SHA256 in state).
Round 0: near_planner from the level-1 block cell.  Round r >= 1: the failed cells' children of round r-1, filtered by
the planner's skip test, then certified.  Stops when no cell is left or the level exceeds Lmax (cells written to
unresolved.jsonl, NOT a counterexample).  Heartbeat in state.json every batch; resumable at the round level.
Usage: python3 run_block.py RUN --block B [--workers W] [--rounds 8]   (parameters in RUN/config.json)"""
import os, sys, json, time, hashlib, subprocess, argparse
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import near_planner as NP
import grid as G
import theta_fpsi_rig as TR
import jsonl_safe as JS        # 2026-11-10 crash safety

DEFAULT = dict(L0=1, Lmax=11, q=0.0, rho_min=0.005, rho_max=0.08, budget=256, K=8, nseg=1000, max_boxes=6000, min_rad=1e-3, fail_fast=0, split_axes=3, needed_min=0.5,
               ball=2.0, fstar_up='18.919134195733914')      # ball: candidate-ball radius (ARCH_V2 section 13); the grid base follows from it


def sha(path):
    return hashlib.sha256(open(path, 'rb').read()).hexdigest()


def load_config(run):
    cf = os.path.join(run, 'config.json')
    if not os.path.exists(cf):
        d = dict(DEFAULT); d['base'] = list(G.near_grid(__import__('fractions').Fraction(d['ball'])).base); d['root_side'] = 2 * d['ball']
        json.dump(d, open(cf, 'w'), indent=1, sort_keys=True)
    cfg = json.load(open(cf)); cfg['sha256'] = sha(cf); return cfg


def write_state(bdir, **kw):
    sf = os.path.join(bdir, 'state.json'); st = json.load(open(sf)) if os.path.exists(sf) else {}
    st.update(kw); st['heartbeat'] = time.strftime('%Y-%m-%d %H:%M:%S'); JS.atomic_json(sf, st, indent=1)
    return st


def filter_cells(cells, cfg):
    """planner skip test on the children of failed cells; returns (kept, skipped); skipped records carry the skip
    certificate leaves of near_planner.skip_tree.  v0.3: a child of which less than needed_min can not be skipped is
    split further (near_planner.skip_fraction) instead of being certified whole, down to Lmax."""
    kept = []; skipped = []; stack = list(cells); nmin = cfg.get('needed_min', NP.NEEDED_MIN); Lmax = cfg.get('Lmax', 11)
    while stack:
        c = stack.pop()
        leaves, _ = NP.skip_tree(c['lo'], c['hi'], cfg['budget'])
        if leaves is not None:
            skipped.append(dict(c, leaves=leaves)); continue
        if nmin > 0 and max(G.levels(c['L'])) < Lmax and NP.skip_fraction(c['lo'], c['hi'], 4 * cfg['budget']) < nmin:
            for L2, j2 in G.NEAR.children(c['L'], tuple(c['j'])):
                lo, hi = G.NEAR.cell_box(L2, j2); p, rho = G.NEAR.cell_p_rho(lo, hi)
                stack.append(dict(L=list(L2), j=list(j2), p=p, rho=rho, lo=lo, hi=hi, parent_status=c.get('parent_status', 'sliver')))
            continue
        kept.append(c)
    return kept, skipped


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('run'); ap.add_argument('--block', type=int, required=True)
    ap.add_argument('--workers', type=int, default=2); ap.add_argument('--rounds', type=int, default=8)
    ap.add_argument('--cell', default='', help='TEST: start from this cell L,j0..j5 instead of the level-1 block'); a = ap.parse_args()
    cfg = load_config(a.run); G.SPLIT_AXES = cfg.get('split_axes', 3); NP.configure(cfg.get('ball', 1.25))
    bdir = os.path.join(a.run, 'blocks', ('%02d' % a.block) if not a.cell else 'cell_' + a.cell.replace(',', '_')); os.makedirs(bdir, exist_ok=True)
    # one process per block: a second run_block on the same block would race on the round files (seen in a test,
    # 2026-11-07: two instances, the second read cells_next.jsonl before the first had written it)
    lock = os.path.join(bdir, 'lock')
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY); os.write(fd, str(os.getpid()).encode()); os.close(fd)
    except FileExistsError:
        pid = int(open(lock).read() or 0)
        try:
            os.kill(pid, 0); raise SystemExit('block %d is already running (pid %d)' % (a.block, pid))
        except ProcessLookupError:
            open(lock, 'w').write(str(os.getpid()))          # stale lock of a dead process
    import atexit; atexit.register(lambda: os.path.exists(lock) and os.remove(lock))
    st = write_state(bdir, block=a.block, config_sha256=cfg['sha256'], status='running')
    r0 = st.get('round', 0)
    for r in range(r0, a.rounds):
        rdir = os.path.join(bdir, 'round_%d' % r); os.makedirs(rdir, exist_ok=True)
        cells_f = os.path.join(rdir, 'cells.jsonl')
        if not os.path.exists(os.path.join(rdir, 'planned.ok')):
            if r == 0:
                d = [(a.block >> i) & 1 for i in range(6)]; start = a.cell or ('1,' + ','.join(map(str, d)))
                finished = os.path.exists(os.path.join(rdir, 'stats.json')) and not os.path.exists(os.path.join(rdir, 'plan.ckpt.json'))
                # 2026-11-10: the planner resumes from its own checkpoint (plan.ckpt.json); a planner that already ended is not rerun
                finished or subprocess.run([sys.executable, os.path.join(HERE, 'near_planner.py'), rdir, '--resume', '--cell', start,
                                '--q', str(cfg['q']), '--rho-min', str(cfg['rho_min']), '--rho-max', str(cfg['rho_max']),
                                '--budget', str(cfg['budget']), '--Lmax', str(cfg['Lmax']), '--max-cells', '100000000',
                                '--split-axes', str(cfg.get('split_axes', 3)), '--needed-min', str(cfg.get('needed_min', 0.5)),
                                '--ball', str(cfg.get('ball', 1.25))], check=True)
            else:
                prev = os.path.join(bdir, 'round_%d' % (r - 1), 'cells_next.jsonl')
                # de-duplicate: a cell redone after a stop may have written its children twice (near_certify order, 2026-11-10)
                nxt = []; seen_c = set()
                for c in JS.read_jsonl(prev):
                    k = (G.levels(c['L']), tuple(c['j']))
                    if k not in seen_c:
                        seen_c.add(k); nxt.append(c)
                over = [c for c in nxt if max(G.levels(c['L'])) > cfg['Lmax']]; nxt = [c for c in nxt if max(G.levels(c['L'])) <= cfg['Lmax']]
                kept, skipped = filter_cells(nxt, cfg)
                with open(cells_f, 'w') as f:
                    for c in kept:
                        f.write(json.dumps(c) + '\n')
                with open(os.path.join(rdir, 'skipped.jsonl'), 'w') as f:
                    for c in skipped:
                        f.write(json.dumps(dict(L=c['L'], j=c['j'], leaves=c['leaves'])) + '\n')
                with open(os.path.join(bdir, 'unresolved.jsonl'), 'a') as f:
                    for c in over:
                        f.write(json.dumps(c) + '\n')
            open(os.path.join(rdir, 'planned.ok'), 'w').write('ok\n')
        n = sum(1 for _ in open(cells_f)) if os.path.exists(cells_f) else 0
        write_state(bdir, round=r, cells=n)
        if n == 0:
            uf = os.path.join(bdir, 'unresolved.jsonl'); nu = sum(1 for _ in open(uf)) if os.path.exists(uf) else 0
            # 'queue_empty' only: whether the block is COVERED is decided by the independent checker (GPT PENT-13b item 4)
            write_state(bdir, status='queue_empty' if nu == 0 else 'queue_empty_with_unresolved', unresolved=nu, rounds=r)
            # structural self-check + manifest of every round directory (manifest.py; its verdict is the producer's own,
            # the independent checker repeats Stage A).  Failures are recorded, never hidden.
            subprocess.run([sys.executable, os.path.join(HERE, 'manifest.py'), bdir, '--block'], capture_output=True, text=True)
            try:
                bs = json.load(open(os.path.join(bdir, 'block_status.json'))); struct = dict(structural=bs['structural'], coverage=bs['coverage'].get('result'))
            except Exception as ex:
                struct = dict(structural='manifest error: %s' % repr(ex)[:80])
            write_state(bdir, **struct)
            print('block %d: work queue empty after %d rounds, unresolved %d, structural %s' % (a.block, r, nu, struct)); return
        # v0.3 (2026-11-08): the run-wide cache run/corners.jsonl is read-only for the certify stage (--corner-cache, slim
        # in memory); new corners land in rdir/corners.jsonl and are appended to the run-wide cache afterwards.  Same key
        # with a different certificate = stop (GPT PENT-13b item 3); keys carry (K, nseg, solver), see near_certify.corner_key.
        gc = os.path.join(a.run, 'corners.jsonl')
        if JS.repair_tail(gc):                 # one block runs at a time (runner.resume), so this process owns the append end
            print('repaired a torn last line of', gc, flush=True)
        cmd = [sys.executable, os.path.join(HERE, 'near_certify.py'), rdir, '--workers', str(a.workers), '--K', str(cfg['K']),
               '--nseg', str(cfg['nseg']), '--max-boxes', str(cfg['max_boxes']), '--min-rad', str(cfg['min_rad']),
               '--fail-fast', str(cfg.get('fail_fast', 0)), '--split-axes', str(cfg.get('split_axes', 3)), '--ball', str(cfg.get('ball', 1.25)),
               '--sup', cfg.get('sup', 'rig_box'), '--t1-engine', cfg.get('t1_engine', 'arb')]     # 2026-11-12: engines are config keys (NEAR_SPEC 15-16)
        if os.path.exists(gc):
            cmd += ['--corner-cache', gc]
        subprocess.run(cmd, check=True)
        rc = os.path.join(rdir, 'corners.jsonl')
        if os.path.exists(rc):
            import near_certify as NC
            seen = NC.CornerStore()           # compact (2026-11-10): ~200 B per corner instead of 2.4 KB
            if os.path.exists(gc):
                NC.load_cache(gc, seen)
            merged = os.path.join(rdir, 'merged.ok')
            if not os.path.exists(merged):
                with open(gc, 'a') as g:
                    for l in open(rc):
                        d = json.loads(l); k = tuple(d['key']); sl = NC.compact(d['cert'])
                        if k in seen:
                            if NC.sha_of(seen[k]) != NC.sha_of(sl):
                                write_state(bdir, status='STOP_corner_conflict', key=list(k))
                                raise SystemExit('corner cache conflict for key %s -- stop, keep everything as it is' % (k,))
                            continue
                        g.write(l); seen[k] = sl
                    JS.fsync(g)
                open(merged, 'w').write('ok\n')
        pend = os.path.join(rdir, 'pending.jsonl')
        if os.path.exists(pend) and os.path.getsize(pend) > 0:
            write_state(bdir, status='planner_pending')
            raise SystemExit('planner stopped at its cell cap; pending work in %s' % pend)
        write_state(bdir, round=r + 1)
    write_state(bdir, status='rounds_exhausted')


if __name__ == '__main__':
    main()
