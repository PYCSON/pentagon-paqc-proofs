"""Operator interface for the near-region production run, skeleton v0.1 (Claude, 2026-11-07).  Chinese one-line
answers for a non-technical operator (RUNBOOK-CN.md of GPT PENT-12).  Read-only except 'resume' and 'reduce-workers'.
  status           per-block state, cells done / open, corners, last heartbeat, disk free
  health           SHA256 of config.json vs the blocks' recorded sha, disk, memory, heartbeat age; exit 0 ok / 1 warn / 2 stop
  resume [W]       (re)start the pending blocks with W worker processes, one block at a time, detached (setsid nohup)
  reduce-workers N write the new worker count for the next block start (1..16)
  pack             tar.gz of all manifests/certs/logs + SHA256; prints the archive's SHA256
  set-engines SUP T1   (2026-11-12) before certification: SUP = rig_box | fast | taylor, T1 = arb | np (config keys)
  watch [W]        (2026-11-10) foreground watchdog: every 10 min, if no block is running and blocks are pending and
                   health is not 'stop', run resume; logs to RUN/watch.log.  Started by the Windows logon task
                   (local/WATCHDOG_WINDOWS.md), it also keeps WSL alive (a wsl.exe session that never ends).
Usage: python3 runner.py RUN <command> [arg]"""
import os, sys, json, time, hashlib, shutil, subprocess, tarfile, glob
HERE = os.path.dirname(os.path.abspath(__file__))


def sha(path):
    return hashlib.sha256(open(path, 'rb').read()).hexdigest()


def blocks(run):
    out = []
    for d in sorted(glob.glob(os.path.join(run, 'blocks', '[0-9][0-9]'))):
        sf = os.path.join(d, 'state.json'); st = json.load(open(sf)) if os.path.exists(sf) else {}
        done = sum(len(open(f).readlines()) for f in glob.glob(os.path.join(d, 'round_*', 'done.jsonl')))
        cert = sum(l.count('"certified"') for f in glob.glob(os.path.join(d, 'round_*', 'done.jsonl')) for l in open(f))
        out.append(dict(block=int(os.path.basename(d)), status=st.get('status', 'pending'), round=st.get('round', 0), cells_done=done,
                        cells_certified=cert, heartbeat=st.get('heartbeat'), config_sha256=st.get('config_sha256')))
    return out


def status(run):
    B = blocks(run); du = shutil.disk_usage(run)
    nc = sum(1 for _ in open(os.path.join(run, 'corners.jsonl'))) if os.path.exists(os.path.join(run, 'corners.jsonl')) else 0
    done = sum(b['status'] in ('done', 'queue_empty') for b in B); running = sum(b['status'] == 'running' for b in B)
    print('块：完成 %d / 运行中 %d / 未开始 %d（共 64）| 格子：已处理 %d，已认证 %d | 角点证书 %d | 磁盘剩余 %.1f GB | 最近心跳 %s' % (
        done, running, 64 - len(B) + sum(b['status'] == 'pending' for b in B), sum(b['cells_done'] for b in B), sum(b['cells_certified'] for b in B), nc,
        du.free / 1e9, max((b['heartbeat'] or '') for b in B) if B else '无'))


def health(run):
    code = 0; msgs = []
    cf = os.path.join(run, 'config.json'); s = sha(cf) if os.path.exists(cf) else None
    for b in blocks(run):
        if str(b['status']).startswith('STOP'):
            msgs.append('块 %02d 状态 %s（数据冲突，程序自己停的）——不要再启动，把 status 和该块日志最后 50 行发给 GPT' % (b['block'], b['status'])); code = 2
        if b['config_sha256'] and b['config_sha256'] != s:
            msgs.append('块 %02d 的参数 SHA 与 config.json 不一致——立即停机，不要继续' % b['block']); code = 2
    du = shutil.disk_usage(run)
    if du.free < 20e9:
        msgs.append('磁盘剩余 %.1f GB，低于 20 GB——暂停新批次，等用户决定' % (du.free / 1e9)); code = max(code, 2)
    try:
        mem = dict(l.split(':') for l in open('/proc/meminfo')); avail = int(mem['MemAvailable'].split()[0]) / 1e6
        if avail < 1.5:
            msgs.append('可用内存 %.1f GB，低于 1.5 GB——先减少进程数（reduce-workers 6）' % avail); code = max(code, 1)
    except Exception:
        pass
    running = [b for b in blocks(run) if b['status'] == 'running']
    alive = subprocess.run(['pgrep', '-f', 'run_block.py'], capture_output=True).returncode == 0
    for b in running:
        # heartbeat = newest write in the block (corners and done records are appended as they finish; the state file
        # is only rewritten between rounds, which can be many hours apart)
        files = glob.glob(os.path.join(run, 'blocks', '%02d' % b['block'], '**', '*'), recursive=True)
        newest = max((os.path.getmtime(f) for f in files if os.path.isfile(f)), default=0)
        age = time.time() - newest
        if not alive:
            msgs.append('块 %02d 标记为运行中，但没有 run_block 进程——电脑可能重启过，运行 resume' % b['block']); code = max(code, 1)
        elif age > 2 * 3600:
            msgs.append('块 %02d 已 %.1f 小时没有写入新结果——可能卡住，把 status 输出和该块日志最后 50 行发给 GPT' % (b['block'], age / 3600)); code = max(code, 1)
    if not msgs:
        msgs.append('正常')
    print('\n'.join(msgs)); return code


def set_engines(run, sup, t1):
    """2026-11-12: choose the corner boundary-sup method and the T1 arithmetic for the certification stage (config keys
    `sup`, `t1_engine`; NEAR_SPEC sections 15-16).  Only before certification starts: the plan (round_0 cells and skip
    records) does not depend on the engines, the certificates do."""
    assert sup in ('rig_box', 'fast', 'taylor', 'fan') and t1 in ('arb', 'np', 'tv'), 'usage: runner.py RUN set-engines {rig_box|fast|taylor|fan} {arb|np|tv}'
    started = [b['block'] for b in blocks(run) if b['config_sha256']]
    if started:
        print('认证已经开始（块 %s 有状态记录），不能再改引擎。' % started[:5]); sys.exit(2)
    cf = os.path.join(run, 'config.json'); cfg = json.load(open(cf)); cfg['sup'] = sup; cfg['t1_engine'] = t1
    tmp = cf + '.tmp'; json.dump(cfg, open(tmp, 'w'), indent=1, sort_keys=True); os.replace(tmp, cf)
    print('引擎已设为：角点上确界 = %s，T1 算术 = %s' % (sup, t1))


def busy():
    """a resume_all.sh or run_block.py is running: a second resume would run two blocks at once (shared corner cache)"""
    return any(subprocess.run(['pgrep', '-f', pat], capture_output=True).returncode == 0 for pat in ('resume_all.sh', 'run_block.py'))


def resume(run, workers):
    if busy():
        print('已经在运行，不需要再启动（查进度用 status）'); return
    wf = os.path.join(run, 'workers.txt')
    if workers is None:
        workers = int(open(wf).read()) if os.path.exists(wf) else 10
    open(wf, 'w').write(str(workers))
    pending = [b for b in range(64) if not os.path.exists(os.path.join(run, 'blocks', '%02d' % b, 'state.json'))
               or json.load(open(os.path.join(run, 'blocks', '%02d' % b, 'state.json'))).get('status') not in ('done', 'queue_empty', 'queue_empty_with_unresolved')]
    if not pending:
        print('全部 64 块已完成'); return
    script = os.path.join(run, 'resume_all.sh')
    with open(script, 'w') as f:
        f.write('#!/bin/bash\ncd %s\n' % run)
        for b in pending:
            f.write('nice -n 19 %s %s %s --block %d --workers %d >> logs/block_%02d.log 2>&1\n' % (sys.executable, os.path.join(HERE, 'run_block.py'), run, b, workers, b))
    os.makedirs(os.path.join(run, 'logs'), exist_ok=True); os.chmod(script, 0o755)
    subprocess.Popen(['setsid', 'nohup', 'bash', script], stdout=open(os.devnull, 'w'), stderr=subprocess.STDOUT, stdin=open(os.devnull))
    print('已在后台启动：待做 %d 块，%d 个进程。查进度：python3 runner.py %s status' % (len(pending), workers, run))


def watch(run, workers):
    log = os.path.join(run, 'watch.log')

    def say(msg):
        with open(log, 'a') as f:
            f.write('%s %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), msg))
    say('watch start (pid %d)' % os.getpid())
    while True:
        try:
            if not busy():
                import io, contextlib
                buf = io.StringIO()
                with contextlib.redirect_stdout(buf):
                    code = health(run)
                if code == 2:
                    say('health = stop, not resuming: ' + buf.getvalue().strip().replace('\n', ' | '))
                else:
                    with contextlib.redirect_stdout(buf):
                        resume(run, workers)
                    say('resume: ' + buf.getvalue().strip().splitlines()[-1])
                    if '全部 64 块已完成' in buf.getvalue():
                        say('all blocks done, watch keeps WSL alive only')
        except Exception as ex:
            say('watch error %r' % ex)
        time.sleep(600)


def pack(run):
    name = os.path.join(run, 'pent_v2_near_%s.tar.gz' % time.strftime('%Y%m%d_%H%M'))
    with tarfile.open(name, 'w:gz') as t:
        for pat in ('config.json', 'corners.jsonl', 'blocks/*/state.json', 'blocks/*/unresolved.jsonl', 'blocks/*/round_*/done.jsonl',
                    'blocks/*/round_*/skipped.jsonl', 'blocks/*/round_*/skipped.jsonl.gz', 'blocks/*/round_*/cells.jsonl', 'blocks/*/round_*/stats.json',
                    'blocks/*/round_*/status.json', 'blocks/*/block_status.json', 'blocks/*/round_*/corners.jsonl', 'blocks/*/round_*/certs/*.json', 'logs/*.log'):
            for f in glob.glob(os.path.join(run, pat)):
                t.add(f, arcname=os.path.relpath(f, run))
    print(sha(name), name)


def main():
    run, cmd = sys.argv[1], sys.argv[2]; arg = sys.argv[3] if len(sys.argv) > 3 else None
    if cmd == 'status':
        status(run)
    elif cmd == 'health':
        sys.exit(health(run))
    elif cmd == 'resume':
        resume(run, int(arg) if arg else None)
    elif cmd == 'reduce-workers':
        n = max(1, min(16, int(arg))); open(os.path.join(run, 'workers.txt'), 'w').write(str(n)); print('下次启动用 %d 个进程' % n)
    elif cmd == 'set-engines':
        set_engines(run, arg, sys.argv[4] if len(sys.argv) > 4 else None)
    elif cmd == 'watch':
        watch(run, int(arg) if arg else None)
    elif cmd == 'pack':
        pack(run)
    else:
        print(__doc__)


if __name__ == '__main__':
    main()
