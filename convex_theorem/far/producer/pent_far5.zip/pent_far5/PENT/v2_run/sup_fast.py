"""Faster rigorous boundary sup for the corner certificate (Claude, 2026-11-10; EXPERIMENT, not used by production until
the pre-run audit decides).  Same bound as MEAS-01 rig_box.sup_boundary -- per edge segment of length h (parameter t):
    sup_seg |u| <= |u(t_m)| + |u'(t_m)| h/2 + sup_seg |u''| h^2/8
-- with the same ArbU object (vertices, coefficients, branch cuts), but fewer Bessel evaluations:
  * J'_nu and J''_nu from the identities  J'_nu(z) = (nu/z) J_nu(z) - J_{nu+1}(z)  and the Bessel equation
    J''_nu(z) = -J'_nu(z)/z - (1 - nu^2/z^2) J_nu(z)   (z > 0: on edge i only corners j != i, i+1 enter, and r_j > 0
    there), instead of J_{nu-2}, J_{nu-1}, J_{nu+1}, J_{nu+2}: 2 Bessel calls per (corner, mode, point) instead of 5;
  * value and first derivative at the midpoint share one polar transform and one J_nu.
rig_box: 1 + 5 (midpoint) + 5 (segment) = 11 calls per (corner, mode, segment); here 2 + 2 = 4.
Both are rigorous enclosures of the same quantities; the numbers differ only in ball radii (the identity form can be a
little wider on the segment interval, which enters with the factor h^2/8)."""
from flint import arb


def _terms(U, x, y, ex, ey, skip, want_val, want_f1, want_f2):
    val = arb(0); f1 = arb(0); f2 = arb(0); k = U.k
    for j in range(U.n):
        if j in skip:
            continue
        p, c0, s0, al, nus = U.fr[j]
        r, th, wx, wy = U.polar(j, x, y)
        lex = c0 * ex + s0 * ey; ley = -s0 * ex + c0 * ey
        cr, sr = wx / r, wy / r
        a = lex * cr + ley * sr; b = -lex * sr + ley * cr
        z = k * r; iz = 1 / z
        for mm, nu in enumerate(nus):
            cc = U.c[j * U.K + mm]
            J0 = z.bessel_j(nu); S = (nu * th).sin()
            if want_val:
                val += cc * J0 * S
            if not (want_f1 or want_f2):
                continue
            Jp1 = z.bessel_j(nu + 1)
            Jd = nu * iz * J0 - Jp1
            C = (nu * th).cos()
            if want_f1:
                f1 += cc * (a * k * Jd * S + b * nu * J0 * C / r)
            if want_f2:
                Jdd = -Jd * iz - (1 - nu * nu * iz * iz) * J0
                Hrr = k * k * Jdd * S
                Hrt = k * nu * Jd * C / r - nu * J0 * C / (r * r)
                Htt = k * Jd * S / r - nu * nu * J0 * S / (r * r)
                f2 += cc * (a * a * Hrr + 2 * a * b * Hrt + b * b * Htt)
    return val, f1, f2


def sup_boundary_fast(U, nseg):
    A = lambda v: arb(float(v))
    best = arb(0); V = U.V; n = U.n
    for i in range(n):
        q0 = [A(V[i][0]), A(V[i][1])]; q1 = [A(V[(i + 1) % n][0]), A(V[(i + 1) % n][1])]
        ex, ey = q1[0] - q0[0], q1[1] - q0[1]
        skip = (i, (i + 1) % n); h = arb(1) / nseg
        for s in range(nseg):
            tm = (arb(s) + arb("0.5")) * h
            f0, f1, _ = _terms(U, q0[0] + tm * ex, q0[1] + tm * ey, ex, ey, skip, True, True, False)
            tI = tm + arb(0, 0.5 / nseg + 1e-18)
            _, _, f2 = _terms(U, q0[0] + tI * ex, q0[1] + tI * ey, ex, ey, skip, False, False, True)
            bound = abs(f0) + abs(f1) * h / 2 + abs(f2) * h * h / 8
            best = arb(max(best.upper(), bound.upper()))
    return best
