"""Higher-order rigorous boundary sup for the corner certificate (Claude, 2026-11-12; EXPERIMENT, not used by production
until reviewed -- NEAR_SPEC section 15).
Why.  rig_box.sup_boundary / sup_fast bound u on each edge segment of parameter length h by the order-2 form
     |u(t_m)| + |u'(t_m)| h/2 + sup_seg |u''| h^2/8.
The last term is an INTERVAL enclosure of a sum of terms with coefficients of size 1e3-1e8 that cancel to ~1e-7 at
every point; the enclosure does not see the cancellation, so the certified mu is 100-400 times the true residual
(measured 2026-11-12: K = 8, nseg = 300: mu = 0.6e-3 .. 2e-3 certified, 5e-6 true; it falls like nseg^-2).
Here: Taylor expansion of order P at the segment midpoint with the Lagrange remainder,
     sup_seg |u| <= sum_{i<P} |u_i(t_m)| (h/2)^i + |U_P(seg)| (h/2)^P,
u_i = i-th Taylor coefficient of t -> u(q0 + t e) at t_m (thin balls: the cancellation is seen), U_P = an enclosure of
the P-th Taylor coefficient at every point of the segment (same formulas with the interval t in place of t_m).
Taylor coefficients by power-series arithmetic (flint arb_series, truncated at length P + 1):
  corner frame j: w(t) = w_m + s d (affine in s = t - t_m),  r^2 = |w|^2 (quadratic),  r = sqrt(r^2),
  theta' = (w x d) / r^2 with CONSTANT numerator,  theta = theta_m + integral,
  J_nu(k r): Taylor coefficients b_i of J_nu at z0 = k r_m from b_0 = J_nu(z0), b_1 = (nu/z0) J_nu(z0) - J_{nu+1}(z0) and
  the recurrence obtained from z^2 y'' + z y' + (z^2 - nu^2) y = 0 at z = z0 + delta,
     b_{n+2} = -[ z0 (n+1)(2n+1) b_{n+1} + (n^2 + z0^2 - nu^2) b_n + 2 z0 b_{n-1} + b_{n-2} ] / (z0^2 (n+2)(n+1)),
  composed with delta(s) = k (r(s) - r_m) by Horner's rule;  sin(nu theta(s)) by arb_series.sin.
Only corners j not in {i, i+1} enter on edge i (their terms vanish identically on the edge), so z0 > 0.
Same ArbU object, same vertices / coefficients / branch cuts as rig_box.  2 Bessel calls per (corner, mode, pass)."""
from flint import arb, arb_series, ctx


def _bessel_taylor(nu, z0, P):
    """Taylor coefficients b_0..b_P of J_nu at z0 (z0 > 0; arb balls, thin or wide)"""
    J0 = z0.bessel_j(nu); J1 = z0.bessel_j(nu + 1)
    b = [J0, nu / z0 * J0 - J1]; iz2 = 1 / (z0 * z0)
    for n in range(P - 1):
        v = z0 * ((n + 1) * (2 * n + 1)) * b[n + 1] + (n * n + z0 * z0 - nu * nu) * b[n]
        if n >= 1:
            v += 2 * z0 * b[n - 1]
        if n >= 2:
            v += b[n - 2]
        b.append(-v * iz2 / ((n + 2) * (n + 1)))
    return b


def _edge_series(U, i, t, e, q0, P):
    """the Taylor coefficients u_0..u_P of s -> u(q0 + (t + s) e) (t an arb: a point or an interval)"""
    x = q0[0] + t * e[0]; y = q0[1] + t * e[1]; k = U.k; tot = None
    for j in range(U.n):
        if j in (i, (i + 1) % U.n):
            continue
        p, c0, s0, al, nus = U.fr[j]
        r, th, wx, wy = U.polar(j, x, y)
        lex = c0 * e[0] + s0 * e[1]; ley = -s0 * e[0] + c0 * e[1]
        r2 = arb_series([wx * wx + wy * wy, 2 * (wx * lex + wy * ley), lex * lex + ley * ley])
        rs = r2.sqrt()
        ths = arb_series([th]) + ((wx * ley - wy * lex) * r2.inv()).integral()
        z0 = k * r
        dl = (k * rs).coeffs(); dl[0] = arb(0); delta = arb_series(dl)
        for mm, nu in enumerate(nus):
            b = _bessel_taylor(nu, z0, P)
            acc = arb_series([b[P]])
            for q in range(P - 1, -1, -1):
                acc = acc * delta + b[q]
            term = (U.c[j * U.K + mm] * acc) * (nu * ths).sin()
            tot = term if tot is None else tot + term
    c = tot.coeffs()
    return c + [arb(0)] * (P + 1 - len(c))


def sup_boundary_taylor(U, nseg, P=6):
    A = lambda v: arb(float(v))
    old = ctx.cap; ctx.cap = P + 1
    try:
        best = arb(0); V = U.V; n = U.n; h2 = arb(1) / (2 * nseg)
        for i in range(n):
            q0 = [A(V[i][0]), A(V[i][1])]; q1 = [A(V[(i + 1) % n][0]), A(V[(i + 1) % n][1])]
            e = (q1[0] - q0[0], q1[1] - q0[1])
            for s in range(nseg):
                tm = (arb(s) + arb("0.5")) / nseg
                cm = _edge_series(U, i, tm, e, q0, P)
                tI = tm + arb(0, 0.5 / nseg + 1e-18)
                cI = _edge_series(U, i, tI, e, q0, P)
                bound = arb(0); w = arb(1)
                for q in range(P):
                    bound += abs(cm[q]) * w; w = w * h2
                bound += abs(cI[P]) * w
                best = arb(max(best.upper(), bound.upper()))
        return best
    finally:
        ctx.cap = old
