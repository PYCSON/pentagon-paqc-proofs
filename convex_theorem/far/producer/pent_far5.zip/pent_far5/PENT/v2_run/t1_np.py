"""T1 branch-and-bound in vectorised binary64 interval arithmetic (Claude, 2026-11-12; EXPERIMENT, NEAR_SPEC section 16).
Same statement, same formulas and same box test as rig_t1_v2.py (emode 'es', v6): on a box U = prod [c_i - r_i, c_i + r_i]
of the parameter cube,   B(u) = min_{k,k'} Q_k(u) (1 - eps_k'(u)),  each of the 25 products bounded below by its second-order
Taylor form (centre value and gradient, Hessian enclosure over the box), eps_k' = (1 + tau) main + (1 + 1/tau) dev with
the trace or AM-GM polynomial majorants of lam_max; the box is accepted when the bound exceeds F*_up.
What changes is only the arithmetic: instead of one arb ball per number in Python loops, every quantity is a pair of
numpy float64 arrays (lower, upper) and a whole batch of boxes is processed at once.
Rigour of the arithmetic.  IEEE-754 binary64 +, -, *, / and sqrt are correctly rounded (numpy calls the hardware
operations element by element; no fused multiply-add, no reordered sums: every sum below is a chain of explicit
two-operand additions).  After each operation the lower endpoint is moved one float down and the upper endpoint one
float up (dn / up below: at least one unit in the last place outward), which contains the exact result of that
operation on any pair of reals in the operand intervals.  Products take the min / max of the four endpoint products.  Powers of two (weights (1 +- u)/2 with dyadic
u, divisions by 2 r_i, by 64, 32, 16) are exact scalings.  The cell data (corner tensors J_k, N_k, A, Efron-Stein
constants) are computed in arb exactly as in rig_t1_v2.CellData and converted outward (rig_paqc.f_down / f_up).
The accepted leaves have the same format as rig_t1_v2 ([centre, radius, tau, lower bound]) and can be replayed by any
checker of T1 leaves; the tree is the same halving tree (split coordinate = largest Taylor-loss contribution)."""
import sys, time, heapq
import numpy as np
import rig_paqc as R

N = 6
NINF = -np.inf; PINF = np.inf


EPS = 2.0 ** -52; TINY = 5e-324


def dn(x):
    """a float <= the predecessor of x (elementwise).  x - t with t = |x| 2^-52 + 2^-1074 >= ulp(x): the real number
    x - t is <= pred(x), and rounding to nearest is monotone, so fl(x - t) <= pred(x).  (|x| 2^-52 is exact unless it
    underflows, where its rounding error is <= 2^-1075 and the added 2^-1074 covers it.)  4 times faster than
    np.nextafter; an infinite or nan entry gives nan, which is never accepted by the box test."""
    x = np.asarray(x, dtype=float)
    if x.ndim == 0:
        return x - (np.abs(x) * EPS + TINY)
    t = np.abs(x); t *= EPS; t += TINY
    return np.subtract(x, t, out=t)


def up(x):
    x = np.asarray(x, dtype=float)
    if x.ndim == 0:
        return x + (np.abs(x) * EPS + TINY)
    t = np.abs(x); t *= EPS; t += TINY
    return np.add(x, t, out=t)


class IV:
    """interval array: lo <= exact <= hi elementwise"""
    __slots__ = ('lo', 'hi')

    def __init__(self, lo, hi):
        self.lo = lo; self.hi = hi

    def __add__(a, b):
        if isinstance(b, IV):
            return IV(dn(a.lo + b.lo), up(a.hi + b.hi))
        return IV(dn(a.lo + b), up(a.hi + b))
    __radd__ = __add__

    def __sub__(a, b):
        if isinstance(b, IV):
            return IV(dn(a.lo - b.hi), up(a.hi - b.lo))
        return IV(dn(a.lo - b), up(a.hi - b))

    def __rsub__(a, b):               # b - a, b an exact float (array)
        return IV(dn(b - a.hi), up(b - a.lo))

    def __neg__(a):
        return IV(-a.hi, -a.lo)

    def __mul__(a, b):
        if isinstance(b, IV):
            p1 = a.lo * b.lo; p2 = a.lo * b.hi; p3 = a.hi * b.lo; p4 = a.hi * b.hi
            return IV(dn(np.minimum(np.minimum(p1, p2), np.minimum(p3, p4))), up(np.maximum(np.maximum(p1, p2), np.maximum(p3, p4))))
        p1 = a.lo * b; p2 = a.hi * b                      # b: float array (exact numbers)
        return IV(dn(np.minimum(p1, p2)), up(np.maximum(p1, p2)))
    __rmul__ = __mul__

    def scale2(a, s):
        """multiplication by a power of two (exact unless it underflows; s > 0)"""
        return IV(a.lo * s, a.hi * s)

    def recip(a):
        """1/a for a > 0 (the caller checks positivity; entries with lo <= 0 give (-inf, +inf))"""
        ok = a.lo > 0
        with np.errstate(divide='ignore', invalid='ignore'):
            lo = np.where(ok, dn(1.0 / a.hi), NINF); hi = np.where(ok, up(1.0 / a.lo), PINF)
        return IV(lo, hi)

    def mag(a):
        """upper bound of |a| (exact: max of the endpoint magnitudes)"""
        return np.maximum(np.abs(a.lo), np.abs(a.hi))

    def __getitem__(a, idx):
        return IV(a.lo[idx], a.hi[idx])

    @property
    def shape(a):
        return a.lo.shape


def iv_const(x, shape=()):
    """thin interval of an exact float"""
    a = np.full(shape, float(x)); return IV(a, a.copy())


def take(a, i, axis):
    return IV(np.take(a.lo, i, axis=axis), np.take(a.hi, i, axis=axis))


def stack2(a, b, axis):
    return IV(np.stack([a.lo, b.lo], axis=axis), np.stack([a.hi, b.hi], axis=axis))


def halve_sum(a, naxes):
    """sum over the last `naxes` axes of length 2 (explicit pairwise interval additions)"""
    for _ in range(naxes):
        a = take(a, 0, -1) + take(a, 1, -1)
    return a


def hull_last(a, naxes):
    lo = a.lo; hi = a.hi
    for _ in range(naxes):
        lo = lo.min(axis=-1); hi = hi.max(axis=-1)
    return IV(lo, hi)


class JetA:
    """second-order jets as interval arrays: v (...), g (..., 6), h (..., 6, 6) (h symmetric)"""
    __slots__ = ('v', 'g', 'h')

    def __init__(self, v, g, h):
        self.v = v; self.g = g; self.h = h

    def __add__(a, b):
        return JetA(a.v + b.v, a.g + b.g, a.h + b.h)

    def __sub__(a, b):
        return JetA(a.v - b.v, a.g - b.g, a.h - b.h)

    def __neg__(a):
        return JetA(-a.v, -a.g, -a.h)

    def __mul__(a, b):
        if isinstance(b, JetA):
            av = a.v[..., None]; bv = b.v[..., None]
            g = av * b.g + bv * a.g
            ag = a.g[..., :, None]; bg = b.g[..., None, :]; ag2 = a.g[..., None, :]; bg2 = b.g[..., :, None]
            h = a.v[..., None, None] * b.h + b.v[..., None, None] * a.h + ag * bg + bg2 * ag2
            return JetA(a.v * b.v, g, h)
        # b: IV broadcastable to v (a constant in u)
        return JetA(a.v * b, a.g * b[..., None], a.h * b[..., None, None])

    def recip(a):
        iv = a.v.recip(); iv2 = iv * iv; iv3 = iv2 * iv
        g = -(a.g * iv2[..., None])
        gg = a.g[..., :, None] * a.g[..., None, :]
        h = (gg * iv3[..., None, None]).scale2(2.0) - a.h * iv2[..., None, None]
        return JetA(iv, g, h)

    def one_minus(a):
        return JetA(1.0 - a.v, -a.g, -a.h)

    def sel(a, idx):
        return JetA(a.v[idx], a.g[idx], a.h[idx])


def taylor(jc, jb, rad, sign):
    """second-order Taylor bound over the boxes (sign -1: lower, +1: upper) as float arrays, rounded outward, and the
    per-coordinate loss contributions.  jc: centre jets (value, gradient used), jb: box jets (Hessian used).
    rad: (M, 6) broadcast against the leading axes."""
    extra = jc.v.lo.ndim - 1
    r = rad.reshape((rad.shape[0],) + (1,) * extra + (N,))
    gi = up(jc.g.mag() * r)                                     # (..., 6)
    hij = up(up(jb.h.mag() * r[..., :, None]) * r[..., None, :]) * 0.5      # (..., 6, 6); the factor 1/2 is exact
    con = gi.copy(); tot = np.zeros(jc.v.lo.shape)
    for i in range(N):
        tot = up(tot + gi[..., i])
        for j in range(N):
            tot = up(tot + hij[..., i, j])
            con[..., i] = up(con[..., i] + hij[..., i, j])
    if sign < 0:
        return dn(jc.v.lo - tot), con
    return up(jc.v.hi + tot), con


class CellNP:
    """outward binary64 copy of the data of rig_t1_v2.CellData (emode 'es')"""

    def __init__(self, cd):
        assert cd.emode == 'es'
        T = [cd.Jt[k] for k in range(5)] + [cd.Nt[k] for k in range(5)] + [cd.At]
        lo = np.array([[R.f_down(x) for x in t.ravel()] for t in T]); hi = np.array([[R.f_up(x) for x in t.ravel()] for t in T])
        self.T = IV(lo.reshape((11,) + (2,) * N), hi.reshape((11,) + (2,) * N))

        def cv(xs):
            return IV(np.array([R.f_down(x) for x in xs]), np.array([R.f_up(x) for x in xs]))
        self.Jmax = cv([cd.pre[k]['Jmax'] for k in range(5)])                               # (5,)
        self.Ra = IV(*[np.array([[f(cd.pre[k]['Rt'][i][0]) for i in range(N)] for k in range(5)]) for f in (R.f_down, R.f_up)])   # (5, 6)
        self.Rb = IV(*[np.array([[f(cd.pre[k]['Rt'][i][1]) for i in range(N)] for k in range(5)]) for f in (R.f_down, R.f_up)])
        self.Rd = IV(*[np.array([[f(cd.pre[k]['Rt'][i][2]) for i in range(N)] for k in range(5)]) for f in (R.f_down, R.f_up)])
        self.dev = IV(*[np.array([[f(cd.pre[k]['dev'][i]) for i in range(N)] for k in range(5)]) for f in (R.f_down, R.f_up)])


def ma_jets(T, cen, rad):
    """centre and box jets of the 11 multiaffine tensors on M boxes.  T: IV (11, 2,..,2); cen, rad: (M, 6) dyadic.
    Returns (JetA centre, JetA box) with leading shape (M, 11)."""
    M = cen.shape[0]
    S = IV(np.broadcast_to(T.lo, (M,) + T.lo.shape).copy(), np.broadcast_to(T.hi, (M,) + T.hi.shape).copy())
    a = cen - rad; b = cen + rad                                 # exact (dyadic)
    for i in range(N):
        ax = 2 + i
        sh = (M, 1) + (1,) * (N - 1)
        w0a = ((1 - a[:, i]) / 2).reshape(sh); w1a = ((1 + a[:, i]) / 2).reshape(sh)
        w0b = ((1 - b[:, i]) / 2).reshape(sh); w1b = ((1 + b[:, i]) / 2).reshape(sh)
        S0 = take(S, 0, ax); S1 = take(S, 1, ax)
        S = stack2(S0 * w0a + S1 * w1a, S0 * w0b + S1 * w1b, ax)
    vc = halve_sum(S, N).scale2(1 / 64); vb = hull_last(S, N)
    gcl = []; gch = []; gbl = []; gbh = []
    hc_lo = np.zeros((M, 11, N, N)); hc_hi = np.zeros((M, 11, N, N)); hb_lo = np.zeros((M, 11, N, N)); hb_hi = np.zeros((M, 11, N, N))
    for i in range(N):
        ax = 2 + i; S1 = take(S, 1, ax); S0 = take(S, 0, ax)
        inv = (1 / (2 * rad[:, i])).reshape((M, 1) + (1,) * (N - 1))          # power of two: exact
        d = (S1 - S0).scale2(inv)
        gc = halve_sum(d, N - 1).scale2(1 / 32); gb = hull_last(d, N - 1)
        gcl.append(gc.lo); gch.append(gc.hi); gbl.append(gb.lo); gbh.append(gb.hi)
        for j in range(i + 1, N):
            axj = 2 + j - 1
            inv2 = (1 / (4 * rad[:, i] * rad[:, j])).reshape((M, 1) + (1,) * (N - 2))
            d2 = ((take(S1, 1, axj) - take(S1, 0, axj)) - (take(S0, 1, axj) - take(S0, 0, axj))).scale2(inv2)
            c2 = halve_sum(d2, N - 2).scale2(1 / 16); b2 = hull_last(d2, N - 2)
            hc_lo[:, :, i, j] = hc_lo[:, :, j, i] = c2.lo; hc_hi[:, :, i, j] = hc_hi[:, :, j, i] = c2.hi
            hb_lo[:, :, i, j] = hb_lo[:, :, j, i] = b2.lo; hb_hi[:, :, i, j] = hb_hi[:, :, j, i] = b2.hi
    Jc = JetA(vc, IV(np.stack(gcl, -1), np.stack(gch, -1)), IV(hc_lo, hc_hi))
    Jb = JetA(vb, IV(np.stack(gbl, -1), np.stack(gbh, -1)), IV(hb_lo, hb_hi))
    return Jc, Jb


def pq_parts(u):
    """pq_i(u) = (1 - u_i^2)/4 as jets, for u: IV (M, 6).  Returns v (M, 6), g_i (M, 6), h_ii = -1/2 (exact)."""
    sq_hi = up(np.maximum(u.lo * u.lo, u.hi * u.hi))
    sq_lo = np.where((u.lo <= 0) & (u.hi >= 0), 0.0, dn(np.minimum(u.lo * u.lo, u.hi * u.hi)))
    v = IV(dn(1.0 - sq_hi) * 0.25, up(1.0 - sq_lo) * 0.25)
    g = IV(-u.hi * 0.5, -u.lo * 0.5)
    return v, g


def es_pieces(cn, u):
    """jets of a, b, d (entries of Mt = sum_i pq_i Rt_i) and dv = sum_i pq_i dev_i; leading shape (M, 5)"""
    pv, pg = pq_parts(u)                                         # (M, 6)
    M = pv.lo.shape[0]
    out = []
    for C in (cn.Ra, cn.Rb, cn.Rd, cn.dev):                      # C: IV (5, 6)
        t = pv[:, None, :] * C[None]                             # (M, 5, 6)
        v = IV(np.zeros((M, 5)), np.zeros((M, 5)))
        for i in range(N):
            v = v + t[:, :, i]
        g = pg[:, None, :] * C[None]                             # gradient: only component i from pq_i
        hd = C.scale2(-0.5)                                      # h_ii = -1/2 * C_i   (exact scaling)
        h_lo = np.zeros((M, 5, N, N)); h_hi = np.zeros((M, 5, N, N))
        for i in range(N):
            h_lo[:, :, i, i] = hd.lo[None, :, i]; h_hi[:, :, i, i] = hd.hi[None, :, i]
        out.append(JetA(v, g, IV(h_lo, h_hi)))
    return out


def box_lower(cn, cen, rad, taus=(0.03, 0.1, 0.3)):
    """rigorous lower bounds of B on M boxes.  Returns (lb (M,), con (M, 6), tau index (M,), ok (M,))"""
    M = cen.shape[0]
    Jc, Jb = ma_jets(cn.T, cen, rad)
    res = []
    for J in (Jc, Jb):
        Jk = J.sel((slice(None), slice(0, 5))); Nk = J.sel((slice(None), slice(5, 10))); A = J.sel((slice(None), slice(10, 11)))
        res.append(((A * Nk) * Jk.recip(), Jk))
    (Qc, Jkc), (Qb, Jkb) = res
    ok = (Jkb.v.lo > 0).all(axis=1)
    uc = IV(cen, cen); ub = IV(cen - rad, cen + rad)
    mains = []; dvs = []
    Jm = cn.Jmax[None, :]
    s_vals = None
    for which, u in (('c', uc), ('b', ub)):
        a, b, d, dv = es_pieces(cn, u)
        tr = a + d; hd = (a - d) * iv_const(0.5); q = hd * hd + b * b
        if which == 'c':
            t0 = np.maximum(tr.v.hi, 0.0); q0 = np.sqrt(np.maximum(q.v.hi, 0.0))
            s_vals = [np.maximum(q0, 0.02 * t0), np.maximum(2 * q0, 0.1 * t0), 0.25 * t0, 0.4 * t0]      # any s > 0 is valid
        ms = [tr * Jm]
        for sv in s_vals:
            good = sv > 0; s = np.where(good, sv, 1.0)
            inv2s = IV(dn(0.5 / s), up(0.5 / s)); s2 = IV(dn(s * s), up(s * s))
            qq = JetA(q.v + s2, q.g, q.h)
            cand = (tr * iv_const(0.5) + qq * inv2s) * Jm
            # where s is not positive fall back to the trace majorant
            g3 = good[..., None]; g4 = good[..., None, None]
            cand = JetA(IV(np.where(good, cand.v.lo, ms[0].v.lo), np.where(good, cand.v.hi, ms[0].v.hi)),
                        IV(np.where(g3, cand.g.lo, ms[0].g.lo), np.where(g3, cand.g.hi, ms[0].g.hi)),
                        IV(np.where(g4, cand.h.lo, ms[0].h.lo), np.where(g4, cand.h.hi, ms[0].h.hi)))
            ms.append(cand)
        mains.append(ms); dvs.append(dv * Jm)
    best_lb = np.full(M, NINF); best_con = np.zeros((M, N)); best_tau = np.zeros(M, int)
    ar = np.arange(M)[:, None]; ak = np.arange(5)[None, :]
    for ti, tau in enumerate(taus):
        f1 = IV(np.array(dn(1.0 + tau)), np.array(up(1.0 + tau)))
        it = 1.0 / tau; f2 = IV(np.array(dn(1.0 + dn(it))), np.array(up(1.0 + up(it))))
        cc = [m * f1 + dvs[0] * f2 for m in mains[0]]; cb = [m * f1 + dvs[1] * f2 for m in mains[1]]
        ups = np.stack([taylor(c_, b_, rad, +1)[0] for c_, b_ in zip(cc, cb)], axis=-1)       # (M, 5, V)
        ch = ups.argmin(axis=-1)                                                              # (M, 5)

        def pick(js):
            v = IV(np.stack([j.v.lo for j in js], -1)[ar, ak, ch], np.stack([j.v.hi for j in js], -1)[ar, ak, ch])
            g = IV(np.stack([j.g.lo for j in js], -1)[ar, ak, :, ch], np.stack([j.g.hi for j in js], -1)[ar, ak, :, ch])
            h = IV(np.stack([j.h.lo for j in js], -1)[ar, ak, :, :, ch], np.stack([j.h.hi for j in js], -1)[ar, ak, :, :, ch])
            return JetA(v, g, h)
        ec = pick(cc).one_minus(); eb = pick(cb).one_minus()                                  # (M, 5) jets of 1 - eps_k'

        def outer(Q, E):       # (M, 5 k, 5 k') products
            Qe = JetA(Q.v[:, :, None], Q.g[:, :, None, :], Q.h[:, :, None, :, :])
            Ee = JetA(E.v[:, None, :], E.g[:, None, :, :], E.h[:, None, :, :, :])
            return Qe * Ee
        Pc = outer(Qc, ec); Pb = outer(Qb, eb)
        lows, cons = taylor(Pc, Pb, rad, -1)                                                  # (M, 5, 5), (M, 5, 5, 6)
        lows = np.where(np.isnan(lows), NINF, lows)
        flat = lows.reshape(M, 25); idx = flat.argmin(axis=1); lb = flat[np.arange(M), idx]
        con = cons.reshape(M, 25, N)[np.arange(M), idx]
        better = lb > best_lb
        best_lb = np.where(better, lb, best_lb); best_con = np.where(better[:, None], con, best_con); best_tau = np.where(better, ti, best_tau)
    best_lb = np.where(ok, best_lb, NINF)
    return best_lb, best_con, best_tau, ok


def certify_T1(cd, Fstar_up, max_boxes=20000, min_rad=1e-3, taus=(0.03, 0.1, 0.3), batch=128):
    """same contract as rig_t1_v2.certify_T1 (status certified / budget / fail, leaves [centre, radius, tau, lower])"""
    t0 = time.time(); cn = CellNP(cd); fstar = R.f_up(Fstar_up) if not isinstance(Fstar_up, float) else Fstar_up
    heap = [(0.0, 0, tuple([0.0] * N), tuple([1.0] * N))]; seq = 1
    cnt = 0; nacc = 0; worst = None; vol = 0.0; leaves = []
    while heap:
        todo = [heapq.heappop(heap) for _ in range(min(batch, len(heap)))]
        if cnt + len(todo) > max_boxes:
            return dict(status='budget', boxes=cnt + len(todo), accepted=nacc, vol_frac=vol, sec=round(time.time() - t0, 1))
        cnt += len(todo)
        cen = np.array([t[2] for t in todo]); rad = np.array([t[3] for t in todo])
        with np.errstate(all='ignore'):
            lb, con, ti, ok = box_lower(cn, cen, rad, taus)
        for m in range(len(todo)):
            c = todo[m][2]; r = todo[m][3]
            if lb[m] > fstar:
                nacc += 1; vol += float(np.prod(r)); leaves.append([list(c), list(r), taus[int(ti[m])], float(lb[m])])
                worst = lb[m] if worst is None else min(worst, lb[m]); continue
            cm = con[m] if ok[m] and np.all(np.isfinite(con[m])) else np.array(r, float)     # no bound: split the widest
            i = int(np.argmax(cm * (np.array(r) > min_rad)))
            if r[i] <= min_rad:
                return dict(status='fail', boxes=cnt, accepted=nacc, at=list(c), rad=list(r), lower=float(lb[m]), vol_frac=vol, sec=round(time.time() - t0, 1))
            r2 = list(r); r2[i] = r[i] / 2
            for sgn in (-1, 1):
                c2 = list(c); c2[i] = c[i] + sgn * r[i] / 2
                heapq.heappush(heap, (float(lb[m]), seq, tuple(c2), tuple(r2))); seq += 1
    return dict(status='certified', boxes=cnt, accepted=nacc, vol_frac=vol, min_lower=float(worst), sec=round(time.time() - t0, 1), leaves=leaves,
                arithmetic='t1_np/1 (binary64 intervals, outward rounding)',
                cover_note='leaves are the accepted nodes of a halving tree rooted at [-1,1]^6: an exact partition (vol_frac=1)')
