"""T1 with the TANGENT majorant and Bernstein products (Claude, 2026-11-12; EXPERIMENT until reviewed, NEAR_SPEC section 17).
A different box test for the same T1 statement as rig_t1_v2.py.  No Efron-Stein, no Taylor expansion, no derivative.

Setting (rig_paqc / rig_t1_v2): cell = box of a chart whose vertex map is multi-affine and ruled; u in [-1,1]^6, a_c(u) the
multilinear weights of the 64 cell corners.  For each sector k:  D_k(u) (2x2) and J_k(u) = det D_k(u) > 0 are multi-affine,
   B_k(u) := adj D_k(u) = sum_c a_c adj D_c,k            (adj is linear on 2x2 matrices),
   G_P,k(u) = J_k D_k^{-1} D_k^{-T} = B_k B_k' / J_k     (the metric of the fan map of P(u)),
   S_k(u)  := sum_c a_c G_c,k,   N_k(u) := sum_c a_c lambda_c J_c,k,   A(u) = sum_j a0_j J_j(u)  (all multi-affine).
T1 (proved in rig_t1_v2):  if  G_P,k(u) >= (1 - e) S_k(u)  (Loewner order) for all k, then
   F(P(u)) >= (1 - e) min_k A(u) N_k(u) / J_k(u).

Lemma TV (tangent minorant).  For every constant real 2x2 matrix Y and every u,
   G_P,k(u) - L_Y,k(u) = J_k (B_k/J_k - Y)(B_k/J_k - Y)' >= 0,     L_Y,k(u) := Y B_k(u)' + B_k(u) Y' - J_k(u) Y Y'.
L_Y,k is MULTI-AFFINE in u.  So is  L_Y,k - (1 - e) S_k,  and a multi-affine symmetric-matrix function is a convex
combination of its values at the corners of any box U.  Hence
   (1 - e) S_k(s) <= L_Y,k(s) at the 64 corners s of U   ==>   G_P,k(u) >= L_Y,k(u) >= (1 - e) S_k(u) for all u in U.
The smallest such e is  e_k(U; Y) = max_s lam_max( S_k(s)^{-1} (S_k(s) - L_Y,k(s)) )  (>= 0 because S_k - L_Y >= S_k - G_P >= 0).
Y is free (a heuristic choice does not affect validity); Y = B_k/J_k at the box centre makes the loss
J (X_P(u) - Y)(X_P(u) - Y)' second order in the box radius, and e_k(U) -> the sharp pointwise constant
lam_max(S_k^{-1}(S_k - G_P,k)) as U shrinks.

Lemma BP (Bernstein product).  f, g multi-affine on U with corner values f_s, g_s (s in {0,1}^6).  Then
   f g = sum_{m in {0,1,2}^6} C[m] prod_i B2_{m_i}(t_i),   C[m] = sum_{s + s' = m} f_s g_s' prod_{i: m_i = 1} 1/2,
(B2 the degree-2 Bernstein polynomials in the local coordinates t_i in [0,1]: (1-t)^2, 2t(1-t), t^2), because
(1-t)(1-t) = B2_0, (1-t) t = B2_1 / 2, t t = B2_2.  The basis is non-negative.  With CJ = the coefficients of J_k * 1:
   c * CAN_k[m] > F* CJ_k[m] for all m    ==>    c A(u) N_k(u) > F* J_k(u) on U.

Box test (accept U):  e_U := max_k e_k(U) < 1  and  (1 - e_U) CAN_k[m] > F*_up (1 + slack) CJ_k[m]  for all k and m.
Then F(P(u)) > F*_up on U.  The reported lower bound is (1 - e_U) min_{k,m} CAN_k[m] / CJ_k[m].
Arithmetic: binary64 intervals with outward rounding (t1_np.IV); the corner tensors come from rig_t1_v2.CellData in arb
and are rounded outward.  Split coordinate and Y are float heuristics.
Leaves: [centre, radius, e_U (upper bound), lower bound]; a checker recomputes the test on each leaf with its own Y."""
import time, heapq
import numpy as np
import rig_paqc as R
from t1_np import IV, dn, up, take, stack2, N, NINF

NC = 46                      # per sector: S11, S12, S22, B11, B12, B21, B22, J, N (9); then A
SLACK = 2.0 ** -30           # accepted boxes clear F*_up by this relative amount (so that independent replays agree)


class CellTV:
    """outward binary64 copy of the multi-affine corner tensors of rig_t1_v2.CellData"""

    def __init__(self, cd):
        T = []
        for k in range(5):
            T += [cd.St[k][0], cd.St[k][1], cd.St[k][2], cd.Adt[k][0], cd.Adt[k][1], cd.Adt[k][2], cd.Adt[k][3], cd.Jt[k], cd.Nt[k]]
        T.append(cd.At)
        lo = np.array([[R.f_down(x) for x in t.ravel()] for t in T]); hi = np.array([[R.f_up(x) for x in t.ravel()] for t in T])
        self.T = IV(lo.reshape((NC,) + (2,) * N), hi.reshape((NC,) + (2,) * N))


def restrict(T, cen, rad):
    """values of the NC multi-affine tensors at the 64 corners of M boxes: IV (M, NC, 2,..,2).  cen, rad dyadic, so the
    weights (1 -+ a)/2 are exact and non-negative."""
    M = cen.shape[0]
    S = IV(np.broadcast_to(T.lo, (M,) + T.lo.shape).copy(), np.broadcast_to(T.hi, (M,) + T.hi.shape).copy())
    a = cen - rad; b = cen + rad
    for i in range(N):
        ax = 2 + i; sh = (M, 1) + (1,) * (N - 1)
        w0a = ((1 - a[:, i]) / 2).reshape(sh); w1a = ((1 + a[:, i]) / 2).reshape(sh)
        w0b = ((1 - b[:, i]) / 2).reshape(sh); w1b = ((1 + b[:, i]) / 2).reshape(sh)
        S0 = take(S, 0, ax); S1 = take(S, 1, ax)
        S = stack2(S0 * w0a + S1 * w1a, S0 * w0b + S1 * w1b, ax)
    return S


def _pmul(a, b):
    """product of two POSITIVE intervals (the caller checks lo > 0)"""
    return IV(dn(a.lo * b.lo), up(a.hi * b.hi))


def bernstein_product(f, g):
    """f: IV (M, 2^6 as six axes), g: IV (M, 5, six axes), both positive.  Returns the 3^6 Bernstein coefficients of f g:
    IV (M, 5, 3,..,3)."""
    M = f.lo.shape[0]
    fl = f.lo.reshape((M, 1) + (2,) * N + (1,) * N); fh = f.hi.reshape((M, 1) + (2,) * N + (1,) * N)
    gl = g.lo.reshape((M, 5) + (1,) * N + (2,) * N); gh = g.hi.reshape((M, 5) + (1,) * N + (2,) * N)
    T = IV(dn(fl * gl), up(fh * gh))                                  # (M, 5, a1..a6, b1..b6)
    for done in range(N):
        ax_a = 2 + done; ax_b = 8
        Tb0 = take(T, 0, ax_b); Tb1 = take(T, 1, ax_b)
        c0 = take(Tb0, 0, ax_a); c2 = take(Tb1, 1, ax_a)
        c1 = (take(Tb1, 0, ax_a) + take(Tb0, 1, ax_a)).scale2(0.5)
        T = IV(np.stack([c0.lo, c1.lo, c2.lo], axis=ax_a), np.stack([c0.hi, c1.hi, c2.hi], axis=ax_a))
    return T


def bernstein_elevate(g):
    """g: IV (M, 5, six axes of length 2).  Coefficients of g * 1 in the degree-2 basis: IV (M, 5, 3,..,3)."""
    T = g
    for i in range(N):
        ax = 2 + i
        c0 = take(T, 0, ax); c2 = take(T, 1, ax); c1 = (c0 + c2).scale2(0.5)
        T = IV(np.stack([c0.lo, c1.lo, c2.lo], axis=ax), np.stack([c0.hi, c1.hi, c2.hi], axis=ax))
    return T


def box_lower(cn, cen, rad):
    """M boxes.  Returns lb (M,) rigorous lower bounds of (1 - e) min_k Q_k on the boxes (-inf where the test is not
    applicable), e_U (M,) upper bounds, and float heuristics: split scores w (M, 6), q (M, 6), flag eps_dominates (M,),
    ok (M,), e0 (M,) = the sharp constant at the box centre (float)."""
    M = cen.shape[0]
    S = restrict(cn.T, cen, rad)                                       # (M, 46, 2^6)
    lo = S.lo.reshape(M, NC, 64); hi = S.hi.reshape(M, NC, 64)

    def comp(i):                                                       # (M, 5, 64) of component i of every sector
        idx = [k * 9 + i for k in range(5)]
        return IV(lo[:, idx, :], hi[:, idx, :])
    S11, S12, S22, B11, B12, B21, B22, J, Nn = [comp(i) for i in range(9)]
    A = IV(lo[:, 45, :], hi[:, 45, :])                                 # (M, 64)
    mid = (lo + hi) * 0.5                                              # float copies for the heuristics
    mc = mid.mean(axis=2)                                              # centre values (M, 46)
    k9 = np.arange(5) * 9
    Jc = mc[:, k9 + 7]
    Y = np.stack([mc[:, k9 + 3] / Jc, mc[:, k9 + 4] / Jc, mc[:, k9 + 5] / Jc, mc[:, k9 + 6] / Jc], axis=-1)   # (M, 5, 4): Y11 Y12 Y21 Y22
    Y = np.where(np.isfinite(Y), Y, 0.0)
    y11, y12, y21, y22 = [Y[:, :, i][:, :, None] for i in range(4)]                     # exact floats, (M, 5, 1)
    Yi = [IV(v, v) for v in (y11, y12, y21, y22)]
    yy11 = Yi[0] * Yi[0] + Yi[1] * Yi[1]; yy12 = Yi[0] * Yi[2] + Yi[1] * Yi[3]; yy22 = Yi[2] * Yi[2] + Yi[3] * Yi[3]
    L11 = (B11 * y11 + B12 * y12).scale2(2.0) - J * yy11
    L12 = (B21 * y11 + B22 * y12) + (B11 * y21 + B12 * y22) - J * yy12
    L22 = (B21 * y21 + B22 * y22).scale2(2.0) - J * yy22
    T11 = S11 - L11; T12 = S12 - L12; T22 = S22 - L22
    dS = S11 * S22 - S12 * S12
    b = S11 * T22 + S22 * T11 - (S12 * T12).scale2(2.0)
    dT = T11 * T22 - T12 * T12
    disc = b * b - (dS * dT).scale2(4.0)
    num = up(b.hi + up(np.sqrt(np.maximum(disc.hi, 0.0))))
    num = np.maximum(num, 0.0)
    good = (dS.lo > 0) & (S11.lo > 0) & (J.lo > 0) & (Nn.lo > 0)
    with np.errstate(divide='ignore', invalid='ignore'):
        e = up(num / (2.0 * dS.lo))                                    # (M, 5, 64) upper bounds of lam_max(S^-1 (S - L))
    ok = good.all(axis=(1, 2)) & (A.lo > 0).all(axis=1)
    eU = np.where(ok, np.where(good, e, np.inf).max(axis=(1, 2)), np.inf)
    ok &= eU < 1
    one_minus = dn(1.0 - eU)                                           # (M,) lower bound of 1 - e_U
    sh6 = (2,) * N
    CAN = bernstein_product(IV(A.lo.reshape((M,) + sh6), A.hi.reshape((M,) + sh6)),
                            IV(Nn.lo.reshape((M, 5) + sh6), Nn.hi.reshape((M, 5) + sh6)))
    CJ = bernstein_elevate(IV(J.lo.reshape((M, 5) + sh6), J.hi.reshape((M, 5) + sh6)))
    with np.errstate(divide='ignore', invalid='ignore'):
        ratio = dn(CAN.lo.reshape(M, -1) / CJ.hi.reshape(M, -1)).min(axis=1)             # lower bound of min_k min_U Q_k
        lb = dn(one_minus * ratio)
    lb = np.where(ok & np.isfinite(lb), lb, NINF)
    # ---- float heuristics for the split (no effect on validity) ----
    with np.errstate(all='ignore'):
        Sc = mc[:, k9[:, None] + np.array([0, 1, 2])]                  # (M, 5, 3)
        Bc = mc[:, k9[:, None] + np.array([3, 4, 5, 6])]               # (M, 5, 4)
        g11 = (Bc[..., 0] ** 2 + Bc[..., 1] ** 2) / Jc; g12 = (Bc[..., 0] * Bc[..., 2] + Bc[..., 1] * Bc[..., 3]) / Jc
        g22 = (Bc[..., 2] ** 2 + Bc[..., 3] ** 2) / Jc
        h11 = Sc[..., 0] - g11; h12 = Sc[..., 1] - g12; h22 = Sc[..., 2] - g22
        ds = Sc[..., 0] * Sc[..., 2] - Sc[..., 1] ** 2
        bb = Sc[..., 0] * h22 + Sc[..., 2] * h11 - 2 * Sc[..., 1] * h12; dt = h11 * h22 - h12 ** 2
        e0 = ((bb + np.sqrt(np.maximum(bb * bb - 4 * ds * dt, 0))) / (2 * ds)).max(axis=1)          # exact e at the centre
        Ac = mc[:, 45]; Qc = (Ac[:, None] * mc[:, k9 + 8] / Jc).min(axis=1)
        m6 = mid.reshape((M, NC) + sh6); w = np.zeros((M, N)); q = np.zeros((M, N))
        for i in range(N):
            ax = tuple(2 + a for a in range(N) if a != i)
            f = m6.mean(axis=ax)                                       # (M, 46, 2): face centres
            Jf = f[:, k9 + 7, :]
            Xf = np.stack([f[:, k9 + 3 + t, :] / Jf for t in range(4)], axis=-1)        # (M, 5, 2, 4)
            w[:, i] = (np.abs(Xf[:, :, 1] - Xf[:, :, 0]).sum(-1) / np.abs(Y).sum(-1)).max(axis=1)
            Qf = f[:, 45:46, :] * f[:, k9 + 8, :] / Jf
            q[:, i] = np.abs(Qf[:, :, 1] - Qf[:, :, 0]).max(axis=1) / Qc
        eps_dom = (eU - e0) >= (Qc - ratio) / Qc
    return lb, eU, w, q, eps_dom, ok, e0, (1 - e0) * Qc


def certify_T1(cd, Fstar_up, max_boxes=20000, min_rad=1e-3, batch=32, slack=SLACK, fail_point=False):
    """branch-and-bound over [-1,1]^6 with the tangent / Bernstein box test.  Same contract as rig_t1_v2.certify_T1:
    status certified / budget / fail; leaves [centre, radius, e_U, lower bound] (an exact partition of the cube).
    fail_point: stop with status 'fail' (why 'point') as soon as the FLOAT value of the sharp pointwise bound
    (1 - e0) min_k Q_k at some box centre is below F* (no subdivision can then certify that point; it only saves time)."""
    t0 = time.time(); cn = CellTV(cd); fstar = R.f_up(Fstar_up) if not isinstance(Fstar_up, float) else Fstar_up
    thr = float(up(np.float64(fstar) * (1.0 + slack)))
    heap = [(0.0, 0, tuple([0.0] * N), tuple([1.0] * N))]; seq = 1
    cnt = 0; nacc = 0; worst = None; vol = 0.0; leaves = []
    while heap:
        todo = [heapq.heappop(heap) for _ in range(min(batch, len(heap)))]
        if cnt + len(todo) > max_boxes:
            return dict(status='budget', boxes=cnt + len(todo), accepted=nacc, vol_frac=vol, sec=round(time.time() - t0, 1))
        cnt += len(todo)
        cen = np.array([t[2] for t in todo]); rad = np.array([t[3] for t in todo])
        with np.errstate(all='ignore'):
            lb, eU, w, q, eps_dom, ok, e0, Bc = box_lower(cn, cen, rad)
        if fail_point:
            bad = np.isfinite(Bc) & (Bc < fstar * (1 - 1e-7))
            if bad.any():
                m = int(np.argmax(bad))
                return dict(status='fail', why='point', boxes=cnt, accepted=nacc, at=list(todo[m][2]), rad=list(todo[m][3]), lower=float(Bc[m]),
                            w=[float(v) for v in w[m]], vol_frac=vol, sec=round(time.time() - t0, 1))
        for m in range(len(todo)):
            c = todo[m][2]; r = todo[m][3]
            if lb[m] > thr:
                nacc += 1; vol += float(np.prod(r)); leaves.append([list(c), list(r), float(eU[m]), float(lb[m])])
                worst = lb[m] if worst is None else min(worst, lb[m]); continue
            ra = np.array(r); live = ra > min_rad
            sc = (w[m] if (eps_dom[m] or not ok[m]) else q[m])
            sc = np.where(np.isfinite(sc), sc, 0.0) * live
            if not sc.any():
                sc = ra * live                                           # no information: the widest coordinate
            i = int(np.argmax(sc))
            if r[i] <= min_rad:
                return dict(status='fail', boxes=cnt, accepted=nacc, at=list(c), rad=list(r), lower=float(lb[m]), vol_frac=vol, sec=round(time.time() - t0, 1))
            r2 = list(r); r2[i] = r[i] / 2
            for sgn in (-1, 1):
                c2 = list(c); c2[i] = c[i] + sgn * r[i] / 2
                heapq.heappush(heap, (float(lb[m]) if np.isfinite(lb[m]) else -1e300, seq, tuple(c2), tuple(r2))); seq += 1
    return dict(status='certified', boxes=cnt, accepted=nacc, vol_frac=vol, min_lower=float(worst), sec=round(time.time() - t0, 1), leaves=leaves,
                method='t1_tv/1 (tangent majorant + Bernstein products; binary64 intervals, outward rounding)', slack=slack,
                cover_note='leaves are the accepted nodes of a halving tree rooted at [-1,1]^6: an exact partition (vol_frac=1)')


def geometry_probe(cd):
    """float information about a cell BEFORE any corner eigenvalue is known (cd built with dummy corner values):
    e0 = sharp constant at the cell centre, eU = tangent constant of the whole cell, w = relative variation of the
    sector maps along each coordinate (the coordinate to split first).  Heuristic use only."""
    cn = CellTV(cd)
    with np.errstate(all='ignore'):
        lb, eU, w, q, eps_dom, ok, e0, Bc = box_lower(cn, np.zeros((1, N)), np.ones((1, N)))
    # ok = the corner tensors are valid on the cell (S positive definite, J, N, A > 0) and e0 is a number < 1.
    # (Until 2026-11-15 this also required the tangent constant of the WHOLE cell to be < 1, which refused large cells
    # that the branch-and-bound certifies after one or two splits.)
    valid = bool(np.isfinite(eU[0])) and bool(np.isfinite(e0[0])) and float(e0[0]) < 1
    return dict(e0=float(e0[0]), eU=float(eU[0]), w=[float(v) for v in w[0]], ok=valid)
