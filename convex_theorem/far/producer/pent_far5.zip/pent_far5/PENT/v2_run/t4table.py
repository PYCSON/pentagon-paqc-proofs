"""Quadrilateral table T4 for the cut-chart far proof (Claude, 2026-11-12; FAR_SPEC section 9.7).  DRAFT for review.
Chart: Q(q) = (0, (1,0), q2, q3), q = (q2x, q2y, q3x, q3y).  Cells: dyadic boxes of side S = S0 / 2^lev, key
(lev, i0, i1, i2, i3), lo = idx * S (exact binary64).  For every cell the table stores a number LB with
        F(Q) = lambda_1(Q) |Q| >= LB      for every CONVEX quadrilateral Q(q), q in the cell,
the best of the following rigorous bounds (the record says which):
  noncvx : the cell contains no convex quadrilateral (a multiaffine orientation determinant is <= 0 at all 16 corners)
           -> LB = +inf;
  paqc   : n = 4 PAQC min-corner form (rig_paqc_n: convexity gate at the corners, geometry factor) times the smallest of
           the 16 corner certificates (MPS + Fox-Henrici-Moler + Hong-Krahn-Szego index, boundary sup by sup_taylor);
  u3     : Q inside the triangle T_e of the three edge lines other than edge e (C_e > 0):  F(Q) >= F(T_e) |Q|/|T_e| >=
           (4 pi^2 / sqrt 3) rho_lo,  rho = 1/(1 + A_e B_e / (2 C_e |Q|))  (the equilateral triangle minimises lambda_1 |T|
           among triangles); turn intervals A_e, B_e intersected with [0, inf) because only convex members matter;
  hp     : F >= pi^2 Per^2 / (16 |Q|) for convex Q (Hersch-Protter form, as far_exclude 'HP');
  floor  : F >= 2 pi^2 for every convex quadrilateral (Polya-Szego for quadrilaterals).
'outside' cells (edge 1, 2 or 3 longer than the base on the whole cell) are not needed by the cut chart (base = longest
edge) and get no record.
Files in OUT: corners.jsonl (key = the four coordinates as exact reprs + solver settings; F_lo or null),
cells.jsonl (key, LB, how, parts), table_info.json.  Resumable; corners in parallel.
Usage: python3 t4table.py OUT [--S0 0.0625] [--jobs 2] [--limit N] [--region i0lo,i0hi,...]"""
import os, sys, json, time, math, itertools, argparse
from multiprocessing import Pool
HERE = os.path.dirname(os.path.abspath(__file__))
for p in ('.', '../v2_quad', '../far/qtable', '../scripts', '../far'):
    sys.path.insert(0, os.path.join(HERE, p))
import numpy as np
from flint import arb
import dimdesc as DD
import rig_paqc as R
import jsonl_safe as JS

C4 = DD.C4
TRI_MIN = 4 * arb.pi() ** 2 / arb(3).sqrt()
TWO_PI2 = 2 * arb.pi() ** 2
SETTINGS = dict(K=8, nseg=40, P=6, solver='t4corner/1 (PolyMPS + rig_box FHM/HKS + sup_taylor)')
BOUNDS = ((0, 2), (0, 1), (-1, 1), (0, 1))          # chart region containing every convex Q with base = longest edge


def iv(a, b):
    return arb(float(a)).union(arb(float(b)))


def cell_box(key, S0):
    lev, idx = key[0], key[1:]; s = S0 / 2 ** lev
    lo = [i * s for i in idx]; return lo, [v + s for v in lo]


def quad_verts(z):
    o = z[0] * 0
    return [(o, o), (o + 1, o), (z[0], z[1]), (z[2], z[3])]


def crs(u, v):
    return u[0] * v[1] - u[1] * v[0]


def corners16(lo, hi):
    return [[hi[i] if (b >> i) & 1 else lo[i] for i in range(4)] for b in range(16)]


def noncvx(lo, hi):
    """no convex positively oriented quadrilateral in the cell: some d_ij = (V_{i+1}-V_i) x (V_j-V_i) is <= 0 at all 16
    corners (d_ij is multiaffine in q, so its maximum over the cell is attained at a corner)"""
    Vs = [quad_verts([arb(float(v)) for v in c]) for c in corners16(lo, hi)]
    for i in range(4):
        for j in range(4):
            if j in (i, (i + 1) % 4):
                continue
            if all(crs((V[(i + 1) % 4][0] - V[i][0], V[(i + 1) % 4][1] - V[i][1]), (V[j][0] - V[i][0], V[j][1] - V[i][1])).upper() <= 0 for V in Vs):
                return True
    return False


def outside(lo, hi):
    """some edge 1..3 is longer than the base on the whole cell"""
    z = [iv(lo[i], hi[i]) for i in range(4)]; V = quad_verts(z)
    for i in range(1, 4):
        dx = V[(i + 1) % 4][0] - V[i][0]; dy = V[(i + 1) % 4][1] - V[i][1]
        if (abs(dx) * abs(dx) + abs(dy) * abs(dy)).lower() > 1:
            return True
    return False


def fallback_bounds(lo, hi):
    """u3, hp, floor on the cell (convex members only); returns dict how -> float lower bound"""
    z = [iv(lo[i], hi[i]) for i in range(4)]; V = quad_verts(z)
    e = [(V[(i + 1) % 4][0] - V[i][0], V[(i + 1) % 4][1] - V[i][1]) for i in range(4)]
    A = (z[1] + z[0] * z[3] - z[2] * z[1]) / 2                      # |Q| (shoelace)
    out = dict(floor=R.f_down(TWO_PI2))
    if A > 0:
        best = None
        for k in range(4):
            Ak = crs(e[(k - 1) % 4], e[k]); Bk = crs(e[k], e[(k + 1) % 4]); Ck = crs(e[(k - 1) % 4], e[(k + 1) % 4])
            if not (Ck > 0) or Ak.upper() <= 0 or Bk.upper() <= 0:
                continue
            Ac = Ak if Ak.lower() >= 0 else arb(0).union(arb(Ak.upper())); Bc = Bk if Bk.lower() >= 0 else arb(0).union(arb(Bk.upper()))
            rho = 1 / (1 + Ac * Bc / (2 * Ck * A))
            if rho.is_finite():
                v = R.f_down(TRI_MIN * arb(rho.lower()))
                best = v if best is None or v > best else best
        if best is not None:
            out['u3'] = best
        per = arb(0)
        for i in range(4):
            l2 = (abs(e[i][0]) * abs(e[i][0]) + abs(e[i][1]) * abs(e[i][1])).lower()
            if l2 > 0:
                per += arb(l2).sqrt().lower()
        # strip (2026-11-12): a convex quadrilateral with base on y = 0 lies in the strip 0 <= y <= max(q2y, q3y), so
        # lambda_1 >= pi^2 / w^2 and F >= pi^2 |Q| / w^2  (convex members: |Q| >= A.lower() only where A > 0)
        w = arb(max(z[1].upper(), z[3].upper()))
        if w > 0 and A.lower() > 0:
            st = arb.pi() ** 2 * arb(A.lower()) / (w * w)
            if st.is_finite():
                out['strip'] = R.f_down(arb(st.lower()))
        if arb(A.upper()) > 0:
            hp = arb.pi() ** 2 * per * per / (16 * arb(A.upper()))
            if hp.is_finite():
                out['hp'] = R.f_down(arb(hp.lower()))
    return out


def corner_key(x):
    return tuple(repr(float(v)) for v in x)


def corner_job(args):
    key, x, st = args
    import far_design_probe as FD, rig_box as RB, sup_taylor as ST
    from mps import PolyMPS, poly_area
    V = np.array([[0, 0], [1, 0], x[0:2], x[2:4]], float); t0 = time.time()
    try:
        if not FD.convex(V) or min(FD.cross(V[(i + 1) % 4] - V[i], V[(i + 2) % 4] - V[(i + 1) % 4]) for i in range(4)) < 1e-9:
            return key, None, dict(why='degenerate')
        Ff = FD.F_float(V)
        if Ff is None:
            return key, None, dict(why='float guess')
        A = poly_area(V); best = None
        for K, width in ((st['K'], 0.03), (st['K'] + 2, 0.06)):
            m = PolyMPS(V, K=K); lam = m.solve(Ff / A, width=width, ngrid=11); U = RB.ArbU(m)
            sup = ST.sup_boundary_taylor(U, st['nseg'], st['P']); l2 = RB.l2_lower(U, None)
            xs = [RB.A(v[0]) for v in V]; ys = [RB.A(v[1]) for v in V]
            area = abs(sum(xs[i] * ys[(i + 1) % 4] - xs[(i + 1) % 4] * ys[i] for i in range(4))) / 2
            mu = area.sqrt() * sup / l2.sqrt(); lamt = arb(float(lam))
            g = Ff / A; at_edge = min(abs(float(lam) - g * (1 - width)), abs(float(lam) - g * (1 + width))) < 1e-9 * g
            if bool(mu < 1) and bool((lamt / (1 - mu) * area) < RB.HKS) and not at_edge and float(mu.upper()) <= 0.01:
                F = R.f_down(lamt / (1 + mu) * area)
                best = (F, dict(K=K, width=width, mu=float(mu.upper()), lam_tilde=repr(float(lam)), sec=round(time.time() - t0, 2)))
                break
        if best is None:
            return key, None, dict(why='index/mu')
        return key, best[0], best[1]
    except Exception as ex:
        return key, None, dict(why=repr(ex)[:80])


class Table:
    def __init__(self, out, S0=1 / 16):
        os.makedirs(out, exist_ok=True); self.out = out; self.S0 = S0
        self.fc = os.path.join(out, 'corners.jsonl'); self.fl = os.path.join(out, 'cells.jsonl')
        self.corners = {}; self.cells = {}
        for d in JS.read_jsonl(self.fc):
            self.corners[tuple(d['key'])] = d['F']
        for d in JS.read_jsonl(self.fl):
            self.cells[tuple(d['key'])] = d

    def level0_keys(self, region=None):
        n = round(1 / self.S0); rng = [range(math.floor(a * n), math.ceil(b * n)) for a, b in BOUNDS]
        if region:
            rng = [range(max(r.start, region[2 * i]), min(r.stop, region[2 * i + 1])) for i, r in enumerate(rng)]
        return [(0,) + idx for idx in itertools.product(*rng)]

    def classify(self, key):
        """'noncvx' / 'outside' / 'build'"""
        lo, hi = cell_box(key, self.S0)
        if noncvx(lo, hi):
            return 'noncvx'
        if outside(lo, hi):
            return 'outside'
        return 'build'

    def missing_corners(self, keys):
        need = {}
        for key in keys:
            lo, hi = cell_box(key, self.S0)
            if not C4.geometry_bound_box(lo, hi)['ok']:
                continue                                  # no PAQC bound possible: no corners needed
            for x in corners16(lo, hi):
                ck = corner_key(x)
                if ck not in self.corners:
                    need[ck] = [float(v) for v in x]
        return need

    def add_corners(self, results):
        with open(self.fc, 'a') as f:
            for key, F, info in results:
                self.corners[key] = F
                f.write(json.dumps(dict(key=list(key), F=F, info=info)) + '\n')
            JS.fsync(f)

    def cell_bound(self, key):
        if key in self.cells:
            return self.cells[key]
        lo, hi = cell_box(key, self.S0); rec = dict(key=list(key))
        cls = self.classify(key)
        if cls != 'build':
            rec.update(LB=float('inf') if cls == 'noncvx' else None, how=cls)
        else:
            parts = fallback_bounds(lo, hi)
            g = C4.geometry_bound_box(lo, hi)
            if g['ok']:
                Fl = [self.corners.get(corner_key(x), 'missing') for x in corners16(lo, hi)]
                if 'missing' in Fl:
                    return None
                if all(v is not None for v in Fl):
                    parts['paqc'] = R.f_down(g['factor'] * R.amin([arb(v) for v in Fl])); rec['factor'] = float(g['factor'].lower()); rec['Fmin'] = min(Fl)
                else:
                    rec['paqc_fail'] = 'corner'
            else:
                rec['paqc_fail'] = g['why']
            how = max(parts, key=lambda k: parts[k]); rec.update(LB=parts[how], how=how, parts=parts)
        self.cells[key] = rec
        with open(self.fl, 'a') as f:
            f.write(json.dumps(rec) + '\n')
        return rec


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('out'); ap.add_argument('--S0', type=float, default=1 / 16); ap.add_argument('--jobs', type=int, default=2)
    ap.add_argument('--limit', type=int, default=0); ap.add_argument('--region', default=''); ap.add_argument('--chunk', type=int, default=300)
    a = ap.parse_args(); T = Table(a.out, a.S0); t0 = time.time()
    region = [int(v) for v in a.region.split(',')] if a.region else None
    keys = T.level0_keys(region)
    todo = []; cnt = {}
    kf = os.path.join(a.out, 'classes.json')
    cls = json.load(open(kf)) if os.path.exists(kf) and not region else {}
    for key in keys:
        ks = ','.join(map(str, key))
        if ks not in cls:
            cls[ks] = T.classify(key)
        cnt[cls[ks]] = cnt.get(cls[ks], 0) + 1
        if cls[ks] == 'build' and key not in T.cells:
            todo.append(key)
    if not region:
        JS.atomic_json(kf, cls)
    if a.limit:
        todo = todo[:a.limit]
    print('cells', len(keys), cnt, 'to build', len(todo), '%.0fs' % (time.time() - t0), flush=True)
    # chunks of cells in a fixed random order (2026-11-12): every finished chunk is a usable random sample of the table
    import random
    random.Random(1).shuffle(todo); hows = {}; nc = 0
    JS.atomic_json(os.path.join(a.out, 'table_info.json'), dict(S0=a.S0, settings=SETTINGS, classes=cnt, complete=False))
    with Pool(a.jobs) as pool:
        for c0 in range(0, len(todo), a.chunk):
            chunk = todo[c0:c0 + a.chunk]; need = T.missing_corners(chunk)
            res = list(pool.imap_unordered(corner_job, [(k, x, SETTINGS) for k, x in need.items()], chunksize=4))
            T.add_corners(res); nc += len(res)
            for key in chunk:
                rec = T.cell_bound(key)
                if rec:
                    hows[rec['how']] = hows.get(rec['how'], 0) + 1
            print('cells %d/%d  corners %d  %s  %.0fs' % (min(c0 + a.chunk, len(todo)), len(todo), nc, hows, time.time() - t0), flush=True)
    JS.atomic_json(os.path.join(a.out, 'table_info.json'), dict(S0=a.S0, settings=SETTINGS, classes=cnt, built=len(todo), how=hows, complete=not a.limit and not region, sec=round(time.time() - t0, 1)))
    print('done', hows, '%.0fs' % (time.time() - t0), flush=True)


if __name__ == '__main__':
    main()
