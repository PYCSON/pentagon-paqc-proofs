"""Tangent / Bernstein box test for n-gons in a d-dimensional multi-affine ruled chart (Claude, 2026-11-15; DRAFT).
The same mathematics as t1_tv.py (NEAR_SPEC section 17: T1, Lemma TV, Lemma BP), written for any number n of vertices
and any chart dimension d, and with a second driver: `minimize` returns a rigorous LOWER BOUND of
      inf_{u in [-1,1]^d} F(P(u))   through   F(P(u)) >= (1 - e_U) min_k A N_k / J_k   on every box U of a partition.
Used for the quadrilateral table (n = 4, d = 4): FAR_SPEC 9.9.  t1_tv.py (n = 5, d = 6) is left untouched for review;
tests/tvn_check.py compares the two on pentagon cells.
Setting: reference regular n-gon P0 with centroid fan, E_k = [P0_k - c0, P0_{k+1} - c0]; for a polygon V with vertex
centroid c:  D_k = [V_k - c, V_{k+1} - c] E_k^{-1},  J_k = det D_k,  B_k = adj D_k,  G_k = B_k B_k' / J_k,
|V| = sum_k a0_k J_k (a0_k = area of the reference sector).  Cell = box of the chart with 2^d corner polygons, ordered as
itertools.product([-1, 1], repeat=d) (first coordinate most significant); lambda_c = F_c / |V_c| with F_c a certified
lower bound of F at corner c.  The chart must be multi-affine and ruled (then D_k, B_k, J_k are multi-affine in u).
Gate: every corner polygon strictly convex and positively oriented (then so is every polygon of the cell: the n(n-1)(n-2)/6
... here simply the n consecutive cross products and all J_k > 0 at the corners, both multi-affine)."""
import time, heapq, itertools
import numpy as np
from flint import arb
import rig_paqc as R
from t1_np import IV, dn, up, take, stack2, NINF
from mps import regular

SLACK = 2.0 ** -30


class CellN:
    def __init__(self, corner_verts, Fl):
        """corner_verts: 2^d lists of n vertices [arb x, arb y]; Fl: 2^d lower bounds of F (arb or float)."""
        nc = len(corner_verts); d = nc.bit_length() - 1; assert 1 << d == nc
        n = len(corner_verts[0]); self.n = n; self.d = d
        P0 = [[arb(float(v[0])), arb(float(v[1]))] for v in regular(n)]
        c0 = [sum(p[0] for p in P0) / n, sum(p[1] for p in P0) / n]
        Einv = []; a0 = []
        for k in range(n):
            a, b = P0[k][0] - c0[0], P0[(k + 1) % n][0] - c0[0]; c, e = P0[k][1] - c0[1], P0[(k + 1) % n][1] - c0[1]
            det = a * e - b * c; Einv.append([[e / det, -b / det], [-c / det, a / det]]); a0.append(abs(det) / 2)
        comps = [[] for _ in range(9 * n + 1)]
        for V, F in zip(corner_verts, Fl):
            for i in range(n):                                    # strict convexity, positive orientation
                p, q, r = V[i], V[(i + 1) % n], V[(i + 2) % n]
                assert (q[0] - p[0]) * (r[1] - q[1]) - (q[1] - p[1]) * (r[0] - q[0]) > 0, 'gate: corner polygon not strictly convex'
            c = [sum(v[0] for v in V) / n, sum(v[1] for v in V) / n]; Js = []; rows = []
            for k in range(n):
                m11, m12 = V[k][0] - c[0], V[(k + 1) % n][0] - c[0]; m21, m22 = V[k][1] - c[1], V[(k + 1) % n][1] - c[1]
                E = Einv[k]
                d11 = m11 * E[0][0] + m12 * E[1][0]; d12 = m11 * E[0][1] + m12 * E[1][1]
                d21 = m21 * E[0][0] + m22 * E[1][0]; d22 = m21 * E[0][1] + m22 * E[1][1]
                J = d11 * d22 - d12 * d21; assert J > 0, 'gate: sector Jacobian not positive'
                B = (d22, -d12, -d21, d11)                         # adj D = [[B11, B12], [B21, B22]]
                S11 = (B[0] * B[0] + B[1] * B[1]) / J; S12 = (B[0] * B[2] + B[1] * B[3]) / J; S22 = (B[2] * B[2] + B[3] * B[3]) / J
                Js.append(J); rows.append((S11, S12, S22) + B + (J,))
            A = sum(a0[k] * Js[k] for k in range(n)); lam = arb(F) / A
            for k in range(n):
                for i, v in enumerate(rows[k]):
                    comps[9 * k + i].append(v)
                comps[9 * k + 8].append(lam * Js[k])
            comps[9 * n].append(A)
        lo = np.array([[R.f_down(x) for x in t] for t in comps]); hi = np.array([[R.f_up(x) for x in t] for t in comps])
        sh = (9 * n + 1,) + (2,) * d
        self.T = IV(lo.reshape(sh), hi.reshape(sh))


def restrict(T, cen, rad, d):
    M = cen.shape[0]
    S = IV(np.broadcast_to(T.lo, (M,) + T.lo.shape).copy(), np.broadcast_to(T.hi, (M,) + T.hi.shape).copy())
    a = cen - rad; b = cen + rad
    for i in range(d):
        ax = 2 + i; sh = (M, 1) + (1,) * (d - 1)
        w0a = ((1 - a[:, i]) / 2).reshape(sh); w1a = ((1 + a[:, i]) / 2).reshape(sh)
        w0b = ((1 - b[:, i]) / 2).reshape(sh); w1b = ((1 + b[:, i]) / 2).reshape(sh)
        S0 = take(S, 0, ax); S1 = take(S, 1, ax)
        S = stack2(S0 * w0a + S1 * w1a, S0 * w0b + S1 * w1b, ax)
    return S


def bernstein_product(f, g, d, n):
    """f: IV (M, 2,..,2), g: IV (M, n, 2,..,2), positive.  Degree-2 Bernstein coefficients of f g: IV (M, n, 3,..,3)."""
    M = f.lo.shape[0]
    fl = f.lo.reshape((M, 1) + (2,) * d + (1,) * d); fh = f.hi.reshape((M, 1) + (2,) * d + (1,) * d)
    gl = g.lo.reshape((M, n) + (1,) * d + (2,) * d); gh = g.hi.reshape((M, n) + (1,) * d + (2,) * d)
    T = IV(dn(fl * gl), up(fh * gh))
    for done in range(d):
        ax_a = 2 + done; ax_b = 2 + d
        Tb0 = take(T, 0, ax_b); Tb1 = take(T, 1, ax_b)
        c0 = take(Tb0, 0, ax_a); c2 = take(Tb1, 1, ax_a)
        c1 = (take(Tb1, 0, ax_a) + take(Tb0, 1, ax_a)).scale2(0.5)
        T = IV(np.stack([c0.lo, c1.lo, c2.lo], axis=ax_a), np.stack([c0.hi, c1.hi, c2.hi], axis=ax_a))
    return T


def bernstein_elevate(g, d):
    T = g
    for i in range(d):
        ax = 2 + i
        c0 = take(T, 0, ax); c2 = take(T, 1, ax); c1 = (c0 + c2).scale2(0.5)
        T = IV(np.stack([c0.lo, c1.lo, c2.lo], axis=ax), np.stack([c0.hi, c1.hi, c2.hi], axis=ax))
    return T


def box_lower(cn, cen, rad):
    """M boxes.  Returns lb (rigorous lower bounds of (1 - e_U) min_k Q_k; -inf if not applicable), eU, and float
    heuristics w, q (split scores), eps_dom, e0, Bc (sharp pointwise bound at the centres)."""
    n, d = cn.n, cn.d; M = cen.shape[0]; NCMP = 9 * n + 1; nc = 1 << d
    S = restrict(cn.T, cen, rad, d)
    lo = S.lo.reshape(M, NCMP, nc); hi = S.hi.reshape(M, NCMP, nc)
    k9 = np.arange(n) * 9

    def comp(i):
        return IV(lo[:, k9 + i, :], hi[:, k9 + i, :])
    S11, S12, S22, B11, B12, B21, B22, J, Nn = [comp(i) for i in range(9)]
    A = IV(lo[:, 9 * n, :], hi[:, 9 * n, :])
    mid = (lo + hi) * 0.5; mc = mid.mean(axis=2); Jc = mc[:, k9 + 7]
    with np.errstate(all='ignore'):
        Y = np.stack([mc[:, k9 + 3] / Jc, mc[:, k9 + 4] / Jc, mc[:, k9 + 5] / Jc, mc[:, k9 + 6] / Jc], axis=-1)
    Y = np.where(np.isfinite(Y), Y, 0.0)
    y11, y12, y21, y22 = [Y[:, :, i][:, :, None] for i in range(4)]
    Yi = [IV(v, v) for v in (y11, y12, y21, y22)]
    yy11 = Yi[0] * Yi[0] + Yi[1] * Yi[1]; yy12 = Yi[0] * Yi[2] + Yi[1] * Yi[3]; yy22 = Yi[2] * Yi[2] + Yi[3] * Yi[3]
    L11 = (B11 * y11 + B12 * y12).scale2(2.0) - J * yy11
    L12 = (B21 * y11 + B22 * y12) + (B11 * y21 + B12 * y22) - J * yy12
    L22 = (B21 * y21 + B22 * y22).scale2(2.0) - J * yy22
    T11 = S11 - L11; T12 = S12 - L12; T22 = S22 - L22
    dS = S11 * S22 - S12 * S12
    b = S11 * T22 + S22 * T11 - (S12 * T12).scale2(2.0)
    dT = T11 * T22 - T12 * T12
    disc = b * b - (dS * dT).scale2(4.0)
    num = np.maximum(up(b.hi + up(np.sqrt(np.maximum(disc.hi, 0.0)))), 0.0)
    good = (dS.lo > 0) & (S11.lo > 0) & (J.lo > 0) & (Nn.lo > 0)
    with np.errstate(divide='ignore', invalid='ignore'):
        e = up(num / (2.0 * dS.lo))
    ok = good.all(axis=(1, 2)) & (A.lo > 0).all(axis=1)
    eU = np.where(ok, np.where(good, e, np.inf).max(axis=(1, 2)), np.inf)
    ok &= eU < 1
    one_minus = dn(1.0 - eU); shd = (2,) * d
    CAN = bernstein_product(IV(A.lo.reshape((M,) + shd), A.hi.reshape((M,) + shd)), IV(Nn.lo.reshape((M, n) + shd), Nn.hi.reshape((M, n) + shd)), d, n)
    CJ = bernstein_elevate(IV(J.lo.reshape((M, n) + shd), J.hi.reshape((M, n) + shd)), d)
    with np.errstate(divide='ignore', invalid='ignore'):
        ratio = dn(CAN.lo.reshape(M, -1) / CJ.hi.reshape(M, -1)).min(axis=1)
        lb = dn(one_minus * ratio)
    lb = np.where(ok & np.isfinite(lb), lb, NINF)
    with np.errstate(all='ignore'):                               # float heuristics
        Sc = mc[:, k9[:, None] + np.array([0, 1, 2])]; Bc_ = mc[:, k9[:, None] + np.array([3, 4, 5, 6])]
        g11 = (Bc_[..., 0] ** 2 + Bc_[..., 1] ** 2) / Jc; g12 = (Bc_[..., 0] * Bc_[..., 2] + Bc_[..., 1] * Bc_[..., 3]) / Jc
        g22 = (Bc_[..., 2] ** 2 + Bc_[..., 3] ** 2) / Jc
        h11 = Sc[..., 0] - g11; h12 = Sc[..., 1] - g12; h22 = Sc[..., 2] - g22
        ds = Sc[..., 0] * Sc[..., 2] - Sc[..., 1] ** 2
        bb = Sc[..., 0] * h22 + Sc[..., 2] * h11 - 2 * Sc[..., 1] * h12; dt = h11 * h22 - h12 ** 2
        e0 = ((bb + np.sqrt(np.maximum(bb * bb - 4 * ds * dt, 0))) / (2 * ds)).max(axis=1)
        Ac = mc[:, 9 * n]; Qc = (Ac[:, None] * mc[:, k9 + 8] / Jc).min(axis=1)
        m6 = mid.reshape((M, NCMP) + shd); w = np.zeros((M, d)); q = np.zeros((M, d))
        for i in range(d):
            ax = tuple(2 + a for a in range(d) if a != i)
            f = m6.mean(axis=ax); Jf = f[:, k9 + 7, :]
            Xf = np.stack([f[:, k9 + 3 + t, :] / Jf for t in range(4)], axis=-1)
            w[:, i] = (np.abs(Xf[:, :, 1] - Xf[:, :, 0]).sum(-1) / np.abs(Y).sum(-1)).max(axis=1)
            Qf = f[:, 9 * n:9 * n + 1, :] * f[:, k9 + 8, :] / Jf
            q[:, i] = np.abs(Qf[:, :, 1] - Qf[:, :, 0]).max(axis=1) / Qc
        eps_dom = (eU - e0) >= (Qc - ratio) / Qc
    return lb, eU, w, q, eps_dom, ok, e0, (1 - e0) * Qc


def _split(heap, seq, item, lbv, w, q, eps_dom, ok, min_rad):
    c, r = item; ra = np.array(r); live = ra > min_rad
    sc = (w if (eps_dom or not ok) else q); sc = np.where(np.isfinite(sc), sc, 0.0) * live
    if not sc.any():
        sc = ra * live
    if not sc.any():
        return seq, False
    i = int(np.argmax(sc)); r2 = list(r); r2[i] = r[i] / 2
    for sgn in (-1, 1):
        c2 = list(c); c2[i] = c[i] + sgn * r[i] / 2
        heapq.heappush(heap, (lbv, seq, tuple(c2), tuple(r2))); seq += 1
    return seq, True


def certify(cn, Fstar_up, max_boxes=20000, min_rad=1e-3, batch=32, slack=SLACK):
    """threshold driver (same contract as t1_tv.certify_T1)"""
    t0 = time.time(); d = cn.d; fstar = R.f_up(Fstar_up) if not isinstance(Fstar_up, float) else Fstar_up
    thr = float(up(np.float64(fstar) * (1.0 + slack)))
    heap = [(0.0, 0, tuple([0.0] * d), tuple([1.0] * d))]; seq = 1; cnt = 0; leaves = []; worst = None
    while heap:
        todo = [heapq.heappop(heap) for _ in range(min(batch, len(heap)))]
        if cnt + len(todo) > max_boxes:
            return dict(status='budget', boxes=cnt + len(todo), sec=round(time.time() - t0, 1))
        cnt += len(todo); cen = np.array([t[2] for t in todo]); rad = np.array([t[3] for t in todo])
        with np.errstate(all='ignore'):
            lb, eU, w, q, eps_dom, ok, e0, Bc = box_lower(cn, cen, rad)
        for m in range(len(todo)):
            if lb[m] > thr:
                leaves.append([list(todo[m][2]), list(todo[m][3]), float(eU[m]), float(lb[m])]); worst = lb[m] if worst is None else min(worst, lb[m]); continue
            seq, done = _split(heap, seq, (todo[m][2], todo[m][3]), float(lb[m]) if np.isfinite(lb[m]) else -1e300, w[m], q[m], eps_dom[m], ok[m], min_rad)
            if not done:
                return dict(status='fail', boxes=cnt, at=list(todo[m][2]), sec=round(time.time() - t0, 1))
    return dict(status='certified', boxes=cnt, min_lower=float(worst), leaves=leaves, sec=round(time.time() - t0, 1), method='tvn/1')


def minimize(cn, max_boxes=400, tol=2e-3, min_rad=1 / 64):
    """rigorous lower bound of inf over the cell of F(P(u)): the smallest box bound of a partition, refined (always the
    box with the smallest bound) until that bound is within tol of the smallest FLOAT pointwise value seen at a box
    centre, or the budget is used.  Returns dict(lower (float, -inf if no box is valid), boxes, point (float), leaves)."""
    d = cn.d; t0 = time.time()
    with np.errstate(all='ignore'):
        lb, eU, w, q, eps_dom, ok, e0, Bc = box_lower(cn, np.zeros((1, d)), np.ones((1, d)))
    heap = [(float(lb[0]) if np.isfinite(lb[0]) else -1e300, 0, tuple([0.0] * d), tuple([1.0] * d), (w[0], q[0], eps_dom[0], ok[0]))]
    seq = 1; cnt = 1; point = float(Bc[0]) if np.isfinite(Bc[0]) else np.inf
    while cnt < max_boxes:
        lbv, _, c, r, (w0, q0, ed0, ok0) = heap[0]
        if lbv >= point * (1 - tol):
            break
        ra = np.array(r); live = ra > min_rad
        sc = (w0 if (ed0 or not ok0) else q0); sc = np.where(np.isfinite(sc), sc, 0.0) * live
        if not sc.any():
            sc = ra * live
        if not sc.any():
            break
        heapq.heappop(heap); i = int(np.argmax(sc)); r2 = list(r); r2[i] = r[i] / 2
        cen = np.array([[c[k] + (sgn * r[i] / 2 if k == i else 0.0) for k in range(d)] for sgn in (-1, 1)]); rad = np.array([r2, r2])
        with np.errstate(all='ignore'):
            lb, eU, w, q, eps_dom, ok, e0, Bc = box_lower(cn, cen, rad)
        for m in range(2):
            heapq.heappush(heap, (float(lb[m]) if np.isfinite(lb[m]) else -1e300, seq, tuple(cen[m]), tuple(r2), (w[m], q[m], eps_dom[m], ok[m]))); seq += 1
            if np.isfinite(Bc[m]):
                point = min(point, float(Bc[m]))
        cnt += 2
    lower = heap[0][0]
    return dict(lower=lower if lower > -1e299 else float('-inf'), boxes=cnt, point=point, leaves=len(heap), sec=round(time.time() - t0, 2))
