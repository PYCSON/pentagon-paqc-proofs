# pent_far5：远区整片，不用 T1 的版本（本地，Claude，2026-11-17）

**这是远区的第二遍，和正在跑的 pent_far4g 互不影响（目录、锁、结果都是分开的）。pent_far4g 不要停。**

为什么要跑第二遍：pent_far4g 的证明用到"角点值 + T1 切线判据"，T1 这一块 GPT 还没审完（PENT-19 B）。pent_far5 把 T1 整个换掉：每个排队的盒子直接用"盒子证书"（Lemma LG + 多项式正性，GPT 在 PENT-21 里已经认可了公式并独立重放了 240 个扇形证书），四边形表也改用同一种证书。跑完之后，远区的证明只依赖 Lemma LG、多项式正性和闭式标签，独立检查器要做的事少得多。代价是慢：每个盒子证书 0.5–0.9 秒，T1 路线只要几十毫秒。

## 做什么
和 pent_far4g 一样的 1,260 个块（E2 384、E3 448、标准图卡 428），一样的三个阶段、一样的"每块先给 15 分钟、没跑完的放下、之后每遍上限翻倍"。最后自动自检（比 far4g 的自检多三项：重算闭式标签、重证四边形表、检查根格子盖住了整个定义域），自检本身约 2 小时，结果在 `verify.txt`，最后一行应该是 `VERIFY OK`。

预计 **1 到 1.5 天**（8 个进程，内存 < 4 GB）。依据：沙箱里同样的 20 个随机块两种模式各跑一遍，这个版本在 E2 上慢 12 倍、E3 上慢 5 倍、标准图卡上慢 3–4 倍，合计约 150 CPU 小时（far4g 约 30）；重块有长尾，实际可能偏差一倍。随时可以停，重启会接着跑。结果目录 `~/pent_far5/out` 很小（估计 1 GB 以内，没有角点数据）。

**什么时候启动**：等 pent_near_lg1 或 pent_far4g 任何一个跑完再启动最稳妥（这样同时只有两个任务）。现在就启动也可以，内存够，只是三个任务都会慢一些。

## 第一步：解压并校验
PowerShell 里先输入 `wsl`，然后：
```
cd ~ && unzip -q /mnt/c/Users/<you>/Downloads/pent_far5.zip && cd pent_far5 && sha256sum -c --quiet SHA256SUMS && echo INSTALL_OK
```
最后一行应该是 `INSTALL_OK`。（如果提示文件已存在，说明已经解压过，直接做第二步。）

## 第二步：后台运行（一行；电脑别睡眠，留一个 WSL 窗口开着）
```
cd ~/pent_far5 && setsid nohup nice -n 19 ./far5_run.sh 8 900 >> run.log 2>&1 < /dev/null &
```
- 重复粘贴也没关系：第二次会显示 `ALREADY RUNNING` 然后自己退出。
- 中途停了（关机、WSL 被关）：用同一行重启，会从停下的地方接着跑。
- 想停掉它（只停 far5，不影响 far4g）：`pkill -f far5_run.sh; pkill -f pent_far5/out`

## 查进度（一行）
```
cd ~/pent_far5/PENT/v2_run && python3 far_runner.py status ~/pent_far5/out; grep -E "pass|STOPPED|ALL STAGES" ~/pent_far5/run.log | tail -n 2; pgrep -fc pent_far5/out
```
- 每个图卡一行：`blocks done 做完的块/总块数, unfinished 没跑完的块`。
- 中间两行是现在跑到第几遍；最后一个数是正在跑的进程数（0 = 没在跑）。
- 出现 `ALL STAGES DONE` 就是全部结束；出现 `STOPPED` 请把那一行发给 Claude。

## 把结果发给 Claude（一行；跑的过程中也能用）
```
cd ~/pent_far5 && python3 PENT/v2_run/far_runner.py status out > status.txt; touch verify.txt; tar czf far5_results.tgz status.txt verify.txt run.log COMMIT out/config.json out/*/roots.json $(find out -name done.json -o -name state.json -o -name block.log -o -name table_info.json) 2>/dev/null; sha256sum far5_results.tgz && cp far5_results.tgz /mnt/c/Users/<you>/Downloads/
```
把 `far5_results.tgz` 发给 Claude，附上屏幕上那行 SHA256。第 1 遍跑完（`run.log` 里出现 `pass 2`）就值得发一次。`out/` 目录留在电脑上，不要删（里面是证书数据，以后给 GPT 的独立检查器用）。
