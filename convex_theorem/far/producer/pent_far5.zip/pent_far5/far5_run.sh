#!/bin/bash
# pent_far5: far region without T1 (Claude, 2026-11-17): box certificates for the queued boxes (PENT_LGBOX=1) and for the
# quadrilateral table (PENT_QLG=1).  Usage: far5_run.sh [JOBS] [BLOCK_SEC]
# Pass 1 (every block gets at most BLOCK_SEC seconds, then it is paused with its state saved):
#   1. edge charts E2, E3;  2. quadrilateral table of the standard chart;  3. standard chart.
# Passes 2, 3, ...: the paused blocks are continued, each time with twice the budget, until none is left.
# Everything is restartable (finished work is skipped).  Only one instance can run (lock file).
set -u
P="$(cd "$(dirname "$0")" && pwd)"; J=${1:-8}; BS=${2:-900}; RUN="$P/out"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export PENT_LGBOX=1 PENT_QLG=1 PENT_NO_H=1
mkdir -p "$RUN"; exec 9>"$RUN/far5.lock"
if ! flock -n 9; then echo "ALREADY RUNNING: not started again"; exit 1; fi
cd "$P/PENT/v2_run" || exit 1
B=${FAR5_TEST_BLOCKS:-}                                   # testing only: 'E2:1_8,12_13 E3:24_15 std:27_7'
blk() { for t in $B; do [ "${t%%:*}" = "$1" ] && echo "--blocks=${t#*:}"; done; }
say() { echo "$(date '+%F %T') $*"; }
# exit codes of 'far_runner.py run': 0 all done, 3 some blocks paused (both fine); anything else stops the script
ok() { if [ "$1" != 0 ] && [ "$1" != 3 ]; then say "STOPPED: runner exit code $1 (a block ended with an error, the disk is nearly full, or another runner is active) -- see the lines above"; exit 1; fi; }
say "pass 1, stage 1: edge charts (budget $BS s per block)"
[ -f "$RUN/E2/roots.json" ] || python3 far_runner.py init "$RUN" --chart E2 $(blk E2) || exit 1
[ -f "$RUN/E3/roots.json" ] || python3 far_runner.py init "$RUN" --chart E3 $(blk E3) || exit 1
if [ ! -f "$RUN/pass1.edge" ]; then
  python3 far_runner.py run "$RUN" --jobs "$J" --block-sec "$BS" --charts E2,E3; rc=$?; ok $rc
  touch "$RUN/pass1.edge"
fi
say "pass 1, stage 2: quadrilateral table"
python3 qtable.py "$RUN/qtable" --chart std --std-keys "$P/T16" --jobs "$J" $(blk std) || exit 1
say "pass 1, stage 3: standard chart"
[ -f "$RUN/std/roots.json" ] || python3 far_runner.py init "$RUN" --chart std --std-keys "$P/T16" --qtable "$RUN/qtable" $(blk std) || exit 1
if [ ! -f "$RUN/pass1.std" ]; then
  python3 far_runner.py run "$RUN" --jobs "$J" --block-sec "$BS" --charts std; rc=$?; ok $rc
  touch "$RUN/pass1.std"
fi
python3 far_runner.py status "$RUN"
n=1
while :; do
  n=$((n + 1)); BS=$((BS * 2)); say "pass $n: paused blocks, budget $BS s per block"
  python3 far_runner.py run "$RUN" --jobs "$J" --block-sec "$BS"; rc=$?
  python3 far_runner.py status "$RUN"
  ok $rc
  [ $rc = 0 ] && break
  [ $n -ge 8 ] && { say "STOPPED after pass $n: some blocks are still unfinished"; exit 3; }
done
say "self-check: tiling of every root, 3 box certificates per block re-proved, 300 labels per block recomputed, table bounds (20 LG entries per block re-proved), roots cover the charts"
CMPL=--complete; [ -n "$B" ] && CMPL=                     # a test run on a few blocks is not complete
python3 far_verify.py "$RUN" --replay 3 --relabel 300 --table 20 --strict-table $CMPL > "$P/verify.txt" 2>&1; tail -n 1 "$P/verify.txt"
say "ALL STAGES DONE"
