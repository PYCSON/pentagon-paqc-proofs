# PENT-25c — GPT final tree review, 2026-11-22

**SIGN-OFF (final tree)** — only the stated Theorem L and the frozen v1.1 release material. Not publication authorization or peer review. Theorem N/F are outside scope.

## 1. Frozen input and byte difference
Input `PENT25c_bundle_acef9b0.zip` SHA256 `4ee111b32c335a5d2f65793d5afd8fcb3b9c83a4afb5b8b5d66c07f738c84fef`. Compared with actual previously signed `PENT25b_bundle_bf85c05.zip` extracted locally, not merely the supplied diff. 115 → 116 files, added only `ERRATUM-v1.0-section6.md`, none removed. Nine changed files: `.zenodo.json`, root `MANIFEST-SHA256.txt`, `README.md`, `local_theorem/MANIFEST-SHA256.txt`, `local_theorem/SOURCE_COMMIT`, `local_theorem/paper/paper.pdf`, `local_theorem/paper/paper.tex`, `local_theorem/proof/LG_LEMMA.md`, `local_theorem/second_party/replay_status.json`. All other bytes (including compressed data, previous evidence ZIPs, old v1.0 PDF, code) unchanged. Executed diff with identical exclusion rules; hunk bodies and coordinates exactly match `CHANGES-vs-PENT25b.diff` (only external path/timestamp headers normalized). SOURCE_COMMIT now equals bundled COMMIT `acef9b034350c2bbec56a13fb72183421ac16ec6`; manifest changes follow affected files. No unrelated change.

## 2. Eight passed entries (zero-based)
| Index | Check vs reports | Verdict |
|---|---|---|
|0|PENT-21 §1–6: Lemma S, admissibility, Proposition R, independently tested quadrature, error bounds and positivity logic; analytic review rather than full numeric proof at that time.| PASS |
|1|PENT-21 independent N=72 FE Hessian: 0.526982,0.557110,5.032706,5.700495,12.757855,15.312200, rounded as shown; explicitly numerical.| PASS |
|2|PENT-21 §6: 174+824+24=1022, min observed quotient 0.252899202455; no observed FE violation, not exact inequality.| PASS |
|3|PENT-21 §0: own Fraction fan integrals, 180 N=5 +60 N=12, 240/240, Lemma LG/fan analysis; not full box cover.| PASS |
|4|PENT-21b §1: all 64 vertices, pivot 0.0349222788388572, exact tiling 7939, I=32 O=965 P=6942, C++/GMP 21.7352 s, 3 negative controls. Missing entry restored.| PASS |
|5|PENT-21b §2: 100 Gram +35 mass equal; nine interval intersections, 21 quadratic K binary64 AD (max ~8.23e-16, rounded 8e-16), 42 numerical dual norms below stored values; 7 low-degree checks. This is spot checking, not strict coefficient-source replay.| PASS |
|6|PENT-21c §§1–6: 4655 matrix entries /15 primes, 4 one-sided constants, 13024 K exponents, Laurent dependence, both norms and remainder/support; route i 7086/13024 not pass; route ii new enclosure, 64/64 vertices, 6942/6942 P, 3 rejects. P25's direct ratio recheck 0.49053689070205314–1.0506111061937655 fits the outward bounds. Archived centres 12968 (current data independently counted), own 13024. Both tau/pivot values consistent. No duplicate old full-B entry.| PASS |
|7|Producer-side log `levelA_on_gpt_enclosure.log`: I32 O965, all 6942 P, 2.472e-08 margin, CERTIFICATE OK. Own direct Fraction comparison of centres using stored parts and reviewer enclosure matches producer's comparison within 0.07 (K_rad plus two grid steps); producer-side not new independent re-run.| PASS |

The corrected order is eight distinct statements. Historical PENT-21b `PARTIAL` for B is not erased; PENT-21c supersedes that gap by route ii. The diagnostic eps0 discrepancy remains explicitly recorded and not promoted into a proof-use failure.

## 3. Optional changes and final mechanics
Zenodo description precisely limits the *new local theorem*, not the old cells. Erratum `each generic shape` and dated heading accepted; cost estimate remains an engineering proxy, not evidence of global proof. Paper Section 1 links LG_LEMMA; working note's historical status separated from current status. `release_review` accurately records PENT-25b SIGN-OFF and two limits (own clean python-flint regeneration blocked; public version 1.0 tag not independently compared). Final date 22 November 2026, root README and JSON version 1.1. Erratum included here; if user declines, remove exactly that file and its README paragraph, update manifest, compare final tree; no other changes authorized.

## 4. Integrity and PDF
Bundle `SHA256SUMS` 120/120, root 115/115, local 42/42, all sha256sum exit 0. `.zenodo.json` parses, version 1.1. `pdfinfo` local paper 8 pages; first-page extracted title “Computer-assisted proof candidate, not peer reviewed”; version 1.1 dated 22 November 2026, no DRAFT in title. Original v1.0 PDF unchanged bytewise. No regeneration of producer numerical certificate in this narrow diff review; no claim of completing FLINT replay. Private external release checklist still needs user's decision and final producer checklist update. No public repository verification or mutation, no external contact, no producer programs run.

**SIGN-OFF (final tree)** for the exact tree in this bundle, subject to the stated scope and ordinary user publication decision.
