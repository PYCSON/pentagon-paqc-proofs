# PENT-26 第二方审查证据索引

- `GPT-REPORT-PENT26-FINAL.md`：正式中文AI第二方技术签字与审核边界。
- `PENT26-FINAL-HANDOFF.md`：Claude所需完成的最终发行树整改。
- `PENT26-51-STATUS.md` / `.json`：51项全部结论，数学部分与发行部分分开。
- `input_snapshots/`：本次用户提供的正式重放和Claude收货小报告**逐字节复制**，以及对比日志；没有约15GiB完整原始见证。
- `code/audit_t1.py`：直接解析当前审查目录下从报告解压得到的结果的68项校核程序，见头部输入路径。`logs/T1_audit.{log,json}`是真实运行输出。
- `code/t2.py`：读取近区生产侧历史重证文本，`logs/T2_near_reproof.json`为执行结果。
- `code/verify_release.py`：冻结输入、所有已列SHA清单和脱敏zip成员检查。
- `code/scan_release.py`：递归 ZIP/TAR/TGZ/XZ/GZIP/PDF metadata 路径扫描；`logs/T5_privacy.json`为真实输出。
- `code/final_tree_gate.py`：**可移植的仅只读最终发行闸门**。用草稿树和定稿树路径调用，exit 0才算通过；本轮对尚有占位符的草稿自测为exit 2，符合预期。
- `logs/T5_tree_diff.json`：用上轮真实249文件`v2_draft_tree.zip`比对目前273文件树的逐文件SHA。
- `SHA256SUMS`：本包内部所有其他文件的SHA256，严格排除自身。

只使用本地证据，无联网；不得把哈希列表的存在冒充在本次容器读过每个原始逐盒证书。报告中“签字”指AI第二方技术审查，不等于同行评审，也不是自动发布许可。
