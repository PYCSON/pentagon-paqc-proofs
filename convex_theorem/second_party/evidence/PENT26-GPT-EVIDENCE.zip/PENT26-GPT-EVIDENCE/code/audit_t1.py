import json,hashlib,re,collections,pathlib,tarfile,sys
ROOT=pathlib.Path('/mnt/data/pent26_audit/PENT26_final')
G=pathlib.Path('/mnt/data/pent26_work/reports/gpt/replay'); C=pathlib.Path('/mnt/data/pent26_work/reports/claude/claude_shards')
STAGES=['near','q_lg','q_other','far_std','far_E2','far_E3','B_std','B_E2','B_E3']
TARGETS={'near':38280,'q_lg':66138,'q_other':118962,'far_std':293846,'far_E2':47804,'far_E3':35865,'B_std':934801,'B_E2':185823,'B_E3':226305}
MAIN={'near':300,'q_lg':517,'q_other':930,'far_std':2296,'far_E2':374,'far_E3':281,'B_std':7304,'B_E2':1452,'B_E3':1769}
sh=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sha={'PENT26a_replay_report.tgz':'a9cd3b826d39b0e098aacebe1f192d7bb7fd71f2911a82f94671883ca1e48736','claude_accept_report.tgz':'4f77091685bd1c4ca8753aeddfe6096838f30d4d4867da6f034bceb20ef42b50','supplement_2.log':'c3f9a7d38ff5c3a2b64ab633e1b23447053b39b4e6c3f01ad7a1dc7330579d7b'}
checks={};detail={};errors=[]
def ck(key,condition,desc=''):
 checks[key]=bool(condition);print(('PASS' if condition else 'FAIL'),key,desc); 
 if not condition: errors.append(key)
for f,h in sha.items():ck('FILE_'+f,sh(ROOT/'final_reports'/f)==h,sh(ROOT/'final_reports'/f))
main=json.loads((G/'results_plan.json').read_text());s0=json.loads((G/'plan_snapshot.json').read_text());s=json.loads((G/'replay_summary.json').read_text());sp=json.loads((G/'supplement_plans.json').read_text());un=json.loads((G/'unscanned_shards.json').read_text());summ=json.loads((G/'results_summary.json').read_text())
ck('PLAN_SAMPLE',main['config'].get('sample')==0 and s['sample']==0)
ck('PLAN_FROZEN',main['config']['zip_sha256']=='1aba5f0a693313b515d9b3b0952747cd61ced2b4b5fb2d3c9c5783333ff2f958' and main['config']['code']=='7cf79beefbc81c796969279b7c4d8bf35c7ecb0525e41f2fe3d88d2c629e2d3b')
ck('PLAN_TARGETS', main['totals']==TARGETS and main['full_totals']==TARGETS and s0['plan']==main)
ck('PLAN_BIND',s0['sha256']=='2d41b5b3f813163c57283e24e5f746c33b8aeda977692862ad4eefd014054463')
ck('REPLAY_CODES',s0['replay_code']=='4bcad88762ad3853b72997aac34f1b139c68c78d3fb4c33c78dd8d3eccb8f141')
ck('SUPPLEMENT_PLAN',set(sp)=={'supplement_1','supplement_2'} and all(x['config']['main_plan_sha256']==s0['sha256'] and x['sample']==0 and x['config']['zip_sha256']==main['config']['zip_sha256'] and x['main_totals']==TARGETS for x in sp.values()) and sp['supplement_1']['config']['code']=='8ab8cb73fb880cb4a9af0cc895bd40913ab12722f91658d12e36dc9f342eb619' and sp['supplement_2']['config']['code']=='beb45023db067a2d2b38fa66746345cc0cdd3f5d5dee99086beb2c57da294e9b' and sp['supplement_2']['config']['budget']==256 and len(sp['supplement_2']['config']['ids'])==13)
ck('SUMMARY_GATES',all(s.get(x) is True for x in ['structure','all_shards_enumerated','q_table_closed','N_computational_gate','F_computational_gate']) and s.get('attempt_reject_stages')==[])
ck('UNSCANNED',un=={x:[] for x in STAGES})
ck('STRUCTURE_JOURNAL',any('"status":"PROVED"' in x for x in (G/'structure.jsonl').read_text().splitlines()))
for st in STAGES:
 rows={};stats=collections.Counter();bad=[];binds=[];with_list={};
 for line in (G/f'{st}.jsonl').read_text().splitlines():
  r=json.loads(line);i=r['shard'];rows[i]=r
  if len(rows)!=0 and (r['n']!=sum(r['counts'].values()) or len(r['nonproved'])!=r['n']-r['counts'].get('PROVED',0) or r['shard']<0):bad.append(i)
  if r['binding']['plan_sha256']!=s0['sha256'] or r['binding']['replay_code']!=s0['replay_code']:bad.append(i)
  stats.update(r['counts']);binds.append(r['binding']);
  if r['shard_errors'] or any(a[2]=='REJECT' for a in r['attempt_nonproved']):bad.append(i)
 ck('SHARD_SEQUENCE_'+st, sorted(rows)==list(range(MAIN[st])) and len((G/f'{st}.jsonl').read_text().splitlines())==MAIN[st] and all(rows[i]['n']==min(128,TARGETS[st]-128*i) for i in rows) and not bad, f'{len(rows)} vs {MAIN[st]} bad={len(bad)}')
 ck('COUNTS_'+st,sum(stats.values())==TARGETS[st] and all(stats.get(x,0)==s['stats'][st][x] for x in s['stats'][st]),str(dict(stats)))
 ck('NO_FINAL_BAD_'+st,all(stats.get(x,0)==0 for x in ('MISSING','REJECT','ERROR','UNPROVED')))
 ck('MANIFEST_MAIN_'+st,(lambda lines:len(lines)==MAIN[st] and all(re.fullmatch(r'[0-9a-f]{64}  main/'+re.escape(st)+r'/\d{6}\.jsonl',v) for v in lines) and all(v.startswith((rows[i]['binding']['sources']['main'] or 'MISSING')+'  ') and v.endswith(f'{i:06d}.jsonl') for i,v in enumerate(lines)))( (G/f'{st}.shards.sha256').read_text().splitlines()))
 ck('CLAUDE_IDENTICAL_'+st,(G/f'{st}.shards.sha256').read_bytes()==(C/f'{st}.shards.sha256').read_bytes())
 detail[st]={'total':TARGETS[st],'shards':MAIN[st],'counts':dict(stats),'journal_rows':len(rows),'conditional_source':sum(r['counts'].get('CONDITIONAL_TABLE',0) for r in rows.values())}
for k in (1,2):
 f=G/f'near.supplement_{k}.shards.sha256';c=C/f'near.supplement_{k}.shards.sha256';lines=f.read_text().splitlines()
 ck(f'SUPPLEMENT_{k}_MANIFEST',len(lines)==8 and len(set(lines))==8 and all(re.fullmatch(r'[0-9a-f]{64}  supplement_'+str(k)+r'/near/\d{6}\.jsonl',x) for x in lines))
 ck(f'SUPPLEMENT_{k}_IDENTICAL',f.read_bytes()==c.read_bytes())
 ck(f'SUPPLEMENT_{k}_BINDS',sum(len([r for r in json.loads(line)['attempt_nonproved'] if r[1]==f'supplement_{k}']) for line in (G/'near.jsonl').read_text().splitlines())>=0)
ck('TOTAL_1947824',sum(TARGETS.values())==1947824)
ck('TOTAL_SHARDS_15239',sum(MAIN.values())+16==15239)
ck('B_STD_CONDITIONAL',s['stats']['B_std']['CONDITIONAL_TABLE']==299994 and s['stats']['B_std']['PROVED']==634807 and s['q_table_closed'] is True)
# read supplement_2.log only genuinely newly computed lines
lr=(ROOT/'final_reports/supplement_2.log').read_text().splitlines();records=[]
for l in lr:
 m=re.search(r'OUTSIDE RESULT (near/[0-9]+/[0-9]+) PROVED (\d+) (\d+)',l)
 if m:records.append((m.group(1),int(m.group(2)),int(m.group(3))))
ck('OUTSIDE_12_86_109',len(records)==12 and len(set(x[0] for x in records))==12 and sum(x[1] for x in records)==86 and sum(x[2] for x in records)==109 and set(x[0] for x in records).issubset(set(sp['supplement_2']['config']['ids'])))
ck('OUTSIDE_RESUME_NO_NEW',any('OUTSIDE SELECTED 12' in r and '17:51' in r for r in lr) and sum('OUTSIDE RESULT' in x for x in lr)==12)
print('TOTAL CHECKS',len(checks),'PASS',sum(checks.values()),'FAIL',len(errors),errors)
out={'checks':checks,'details':detail,'outside':{'records':records,'lg':sum(x[1] for x in records),'outside':sum(x[2] for x in records)},'errors':errors}
pathlib.Path('/mnt/data/pent26_work/evidence/logs/T1_audit.json').write_text(json.dumps(out,indent=2,ensure_ascii=False))
if errors:sys.exit(2)
