import re,json
from pathlib import Path
s=Path('/mnt/data/pent26_work/PENT26-FINAL-CHECKLIST-original.md').read_text();rows=[]
notes={
'A01':'冻结 ZIP、内部 11/11、r3八文件 code_id 均重算一致',
'A02':'24c/26a 更新身份、终端命令、成功结束记录一致',
'A03':'15,223 主分片完整；1,947,824 任务，严格清单身份一致',
'A04':'补跑1只解决1个；补跑2限制13 ID并解决其余12个',
'A05':'三个原始文件 SHA、snapshot、latest journals、五闸门核对',
'A06':'最终 0 UNPROVED/ERROR/MISSING/REJECT；保留历史失败轮次',
'A07':'185,100 表项全通过；57,093根链接的先前独立检查可追溯',
'A08':'结构 journal 与日志绑定，五闸门全部 true',
'A09':'Claude v2.1退出0，400×2点抽样0失败；不冒充全量',
'A10':'九阶段15,239行分轮清单逐字节相同，无重复',
'A11':'正式12件：86 LG +109 outside；outside 独立代码适用范围正确',
'A12':'终端记录显示用户机工作数据约15.487 GiB并可读取；原始见证未随包交付，保留义务继续有效',
'G1':'L/N/F 拼接只覆盖严格凸；退化情形依经典三、四边形界',
'G2':'重叠差 1/5242880>中心误差',
'G3':'D=18.919134195733914为精确十进制有理数',
'G4':'面积与特征值的相似不变性及反射/重标号成立',
'L1':'继承 PENT21解析审查，无局部范围扩张',
'L2':'7,939叶、64顶点、6,942正性历史全量复核',
'L3':'13,024系数、路径(ii)历史 FULL-PASS',
'L4':'v1.1历史签字保留，local_theorem文件字节不变',
'N1':'M2下简单性证明及范围按 PENT23 通过',
'N2':'镜像保距保F、固定中心',
'N3':'根盒覆盖闭球与边界',
'N4':'13,118 far和36 inner跳过判据重检',
'N5':'1,344块、51,434终态叶、38,280 LG及中心鲁棒性',
'N6':'outside只作精确域排除；LG子盒在目标点绕数1',
'N7':'独立精确LG判据、扇形函数、通量和多项式界的历史代码审查',
'N8':'KS有理独立包络下界36.336829070900…>36.33682907',
'N9':'正式38280/38280 PROVED，补跑1+12全量重放',
'N10':'由N1–N9并只对环上目标点推出N',
'F1':'保留表示和并列退化情况历史解析审查',
'F2':'三图卡角点原理历史6/6符号审查',
'F3':'根范围和E2/E3移交及根计数全量通过',
'F4':'八耳朵比较历史8/8符号审查',
'F5':'E3齐次角面与B_E3正式226305目标闭合',
'F6':'S/R/O/N/T/TX路线，M5无除零修复和全标签重放',
'F7':'纤维分段正性/OD/PS与界的已审证明',
'F8':'根格表和57,093根界链接已独立审查',
'F9':'66,138 q_lg +118,962 q_other全部PROVED',
'F10':'377,515 C盒全部PROVED；生产侧6块抽查不代替独立重放',
'F11':'1,346,929 B标签；299,994条件项经F9闭合',
'F12':'1,260块、196,798根列、1,724,444终态盒结构闭合',
'F13':'F1–F12及F14闭合后推导远区F',
'F14':'只认证严格凸成员，不推出非凸结果',
'C01':'纸面数学改文已到位，但签字/发布日期占位和PDF未重编',
'C02':'249→273：新增24、修改30、删除0；54项可追到白名单及四个根元数据',
'C03':'17处签字和1处发布日期仍待填，三个状态JSON与论文需重生成',
'C04':'原冻结包哈希一致，重放入口已包含；最终发行树干净烟雾测试尚未实际执行',
'C05':'根/near/far/convex/local已校验；独立检查器内层清单37项未覆盖6个新增文件',
'C06':'递归14,962成员：/home/rsn八处获用户授权；/mnt/data六十二处为GPT沙盒路径，保留原证据；公开需用户最终批准',
'C07':'本报告尚未装入定稿树，发行日期及最终签字闸门未跑；无公开授权'
}
fail=set(['C01','C03','C04','C05','C07'])
for line in s.splitlines():
 cs=[x.strip() for x in line.strip('|').split('|')]
 if not cs:continue
 id=cs[0]
 if re.fullmatch(r'(A\d\d|G\d|L\d|N\d\d?|F\d\d?|C\d\d)',id):
  rows.append({'id':id,'item':cs[1],'status':'❌' if id in fail else '🤝','details':notes[id]})
assert len(rows)==51
m='| ID | 事项 | 判定 | 独立审查依据 / 尚待动作 |\n|---|---|---|---|\n'
for r in rows:m+=f"| {r['id']} | {r['item']} | {r['status']} | {r['details']} |\n"
base=Path('/mnt/data/pent26_work/evidence');(base/'PENT26-51-STATUS.md').write_text('# PENT-26 51 项状态表\n\n数学义务与计算证据已完成AI第二方审阅；发行闸门未完成不等于数学反例。\n\n'+m)
(base/'PENT26-51-STATUS.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
print('states',len(rows),'agree',sum(r['status']=='🤝' for r in rows),'changes',sum(r['status']=='❌' for r in rows))
