#!/usr/bin/env python3
"""Read-only recursive path hygiene scanner. Never rewrites artifacts. Handles zip/tar/gz/xz and PDF metadata."""
import argparse,io,os,re,json,zipfile,tarfile,gzip,lzma,hashlib,pathlib,collections,subprocess
try:import fitz
except ImportError:fitz=None
patterns={'/home/rsn':b'/home/rsn','/mnt/data':b'/mnt/data','/mnt/c/Users/':b'/mnt/c/Users/','/home/claude':b'/home/claude','/tmp/claude':b'/tmp/claude','/Users/':b'/Users/'}
hits=collections.defaultdict(set);errors=[];scanned=0;pdfs=[];nested=0
ARCHIVE_SUFFIXES=('.zip','.tgz','.tar.gz','.tar.xz','.tar','.gz','.xz')
def examine(data,name,depth=0):
 global scanned,nested
 scanned+=1
 for label,needle in patterns.items():
  if needle in data:hits[label].add(name)
 if name.lower().endswith('.pdf') and fitz:
  try:
   with fitz.open(stream=data,filetype='pdf') as doc:
    meta=doc.metadata or {};v=json.dumps(meta,ensure_ascii=False)
    pdfs.append({'name':name,'pages':len(doc),'metadata':meta})
    for label in patterns:
     if label in v:hits[label].add(name+'!PDF_METADATA')
  except Exception as e:errors.append([name,'pdf',str(e)])
 if depth>=6:return
 try:
  if data[:4]==b'PK\x03\x04' or name.lower().endswith('.zip'):
   with zipfile.ZipFile(io.BytesIO(data)) as z:
    nested+=1
    for x in z.infolist():
     if x.is_dir():continue
     if x.file_size>300*1024*1024:errors.append([name+'!'+x.filename,'oversize',x.file_size]);continue
     examine(z.read(x),name+'!'+x.filename,depth+1)
  elif name.lower().endswith(('.tar.xz','.tar.gz','.tgz','.tar')):
   with tarfile.open(fileobj=io.BytesIO(data),mode='r:*') as t:
    nested+=1
    for x in t:
     if not x.isfile():continue
     if x.size>300*1024*1024:errors.append([name+'!'+x.name,'oversize',x.size]);continue
     f=t.extractfile(x)
     if f:examine(f.read(),name+'!'+x.name,depth+1)
  elif name.lower().endswith('.xz'):
   examine(lzma.decompress(data),name+'!xz',depth+1)
  elif name.lower().endswith('.gz'):
   examine(gzip.decompress(data),name+'!gz',depth+1)
 except Exception as e:errors.append([name,'archive',str(e)])
def main(root):
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  try:examine(p.read_bytes(),str(p.relative_to(root)))
  except Exception as e:errors.append([str(p),'read',str(e)])
 out={'root_files':sum(p.is_file() for p in root.rglob('*')),'members_scanned':scanned,'nested_archives':nested,'pdfs':pdfs,'hits':{k:sorted(v) for k,v in hits.items()},'errors':errors}
 print('ROOT FILES',out['root_files'],'MEMBERS',scanned,'ARCHIVES',nested,'PDFs',len(pdfs),'ERRORS',len(errors))
 for k,v in out['hits'].items():print('HIT',k,len(v),'sample',v[:3])
 pathlib.Path('/mnt/data/pent26_work/evidence/logs/T5_privacy.json').write_text(json.dumps(out,indent=2,ensure_ascii=False))
 return out
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root',type=pathlib.Path);a=p.parse_args();main(a.root)
