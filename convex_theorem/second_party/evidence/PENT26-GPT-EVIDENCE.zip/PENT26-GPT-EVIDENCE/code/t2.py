import re, json
from pathlib import Path
p=Path('/mnt/data/pent26_audit/PENT26_final/near_reproof_record')
A=[]
for i,line in enumerate((p/'reproof_full_20261118.txt').read_text().splitlines(),1):
 if not line.strip():continue
 matches=re.findall(r'\b([0-3]{6}) blocks checked',line)
 a=re.search(r'LG leaves re-proved (\d+)',line)
 if not matches or not a or 'VERIFY OK' not in line: print('BAD_A',i,line[:200])
 else: A.append((matches[0],int(a.group(1))))
B=[]
for f in sorted((p/'reproof_rest_20261120').glob('*.txt')):
 s=f.read_text();a=re.search(r'LG leaves re-proved (\d+)',s)
 if 'VERIFY OK' not in s or a is None: print('BAD_B',f.name,s[:300]);continue
 B.append((f.stem,int(a.group(1))))
AA={k for k,v in A};BB={k for k,v in B}
d={'A_entries':len(A),'A_unique':len(AA),'A_sum':sum(v for k,v in A),'B_entries':len(B),'B_unique':len(BB),'B_sum':sum(v for k,v in B),'intersection':sorted(AA&BB),'total_unique':len(AA|BB),'all_total':sum(v for k,v in A+B),'expected':38280}
print(json.dumps(d,indent=2));Path('/mnt/data/pent26_work/T2_near_reproof.json').write_text(json.dumps(d,indent=2))
