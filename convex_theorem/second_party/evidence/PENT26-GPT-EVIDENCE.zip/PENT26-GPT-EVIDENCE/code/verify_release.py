#!/usr/bin/env python3
"""T5 read-only tree manifest, frozen input, sanitised copy and status inventory audit."""
from pathlib import Path
import zipfile,hashlib,re,json,collections
ROOT=Path('/mnt/data/pent26_audit/PENT26_final/v2tree/pentagon-paqc-proofs');O=Path('/mnt/data/pent26_work/evidence/logs/T5_release.json')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
res={};err=[]
for f in ROOT.rglob('MANIFEST-SHA256.txt'):
 base=f.parent;lines=f.read_text().splitlines();bad=[];seen=set()
 for row in lines:
  m=re.fullmatch(r'([a-f0-9]{64})  (.+)',row)
  if not m:bad.append('bad format '+row[:120]);continue
  h,rel=m.groups()
  if rel in seen:bad.append('duplicate '+rel)
  seen.add(rel);p=base/rel
  if not p.is_file() or sha(p)!=h:bad.append('hash mismatch '+rel)
 # verify complete listing: all files under base excluding this manifest and nested manifests whose parents are deeper? lists recursive? 
 res[str(f.relative_to(ROOT))]={'count':len(lines),'bad':bad}
 if bad:err.extend(bad)
q=ROOT/'convex_theorem/second_party/independent_checker/PENT24_bundle_b8ab7c1.zip'
res['frozen_zip']={'sha256':sha(q),'expected':'1aba5f0a693313b515d9b3b0952747cd61ced2b4b5fb2d3c9c5783333ff2f958'}
if res['frozen_zip']['sha256']!=res['frozen_zip']['expected']:err.append('frozen_zip')
f=ROOT/'convex_theorem/far/producer/pent_far5.zip';note=(ROOT/'convex_theorem/far/producer/ABOUT_pent_far5.md').read_text();expected_new=re.search(r'SHA-256 of this copy: `([a-f0-9]{64})`',note).group(1)
res['sanitized_zip']={'sha256':sha(f),'expected_sha256':expected_new};
if sha(f)!=expected_new:err.append('sanitized_sha')
rows=[]
with zipfile.ZipFile(f) as z:
 for row in note.splitlines():
  if row.startswith('| `pent_far5/'):
   cells=[x.strip() for x in row.split('|') if x.strip()]
   name=cells[0].strip('`'); orig=cells[1].strip('`'); new=cells[2].strip('`'); replacements=int(cells[3]); b=z.read(name)
   rows.append({'name':name,'original_sha_claimed':orig,'new_sha_claimed':new,'new_sha_actual':hashlib.sha256(b).hexdigest(),'replacements':replacements})
   if rows[-1]['new_sha_claimed']!=rows[-1]['new_sha_actual']:err.append('sanitized member '+name)
res['sanitized_changed_members']=rows
with zipfile.ZipFile(f) as z:
 allnames=z.namelist();assert len(allnames)>len(rows)
 # these rows all point to auxiliary/probe scripts, no v2_run producer runtime
 if any(name.startswith('pent_far5/v2_run/') for name in [r['name'] for r in rows]):err.append('producer modified')
 res['sanitized_total_members']=len(allnames)
for key,rel in {'near':'convex_theorem/near/second_party/replay_status.json','far':'convex_theorem/far/second_party/replay_status.json','convex':'convex_theorem/second_party/replay_status.json'}.items():
 p=ROOT/rel
 try:
  d=json.loads(p.read_text());res['status_'+key]={'status':d.get('status'),'parts':list(d.get('parts',{}))}
 except Exception as e:err.append('json parse '+rel+repr(e))
res['root_file_count']=sum(x.is_file() for x in ROOT.rglob('*'))
res['errors']=err
O.write_text(json.dumps(res,indent=2,ensure_ascii=False))
for k,v in res.items():
 if isinstance(v,dict) and 'count' in v:print(k,v['count'],'PASS' if not v['bad'] else 'FAIL')
print('frozen ZIP',res['frozen_zip']['sha256'],'sanitized members',len(rows),'zip members',res['sanitized_total_members'],'ERRORS',err)
