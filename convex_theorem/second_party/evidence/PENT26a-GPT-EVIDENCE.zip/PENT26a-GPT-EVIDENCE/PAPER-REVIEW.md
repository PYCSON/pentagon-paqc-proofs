# PENT26a 任务 3 — 全文 14 页论文数学预审

已阅读包内 paper_full/paper.tex 和 14 页 PDF 的提取文本（原始提取 logs/paper_full_extracted.txt），核对 NEAR_THEOREM、FAR_THEOREM、签字总表、历史 LOCAL_LEMMA 与本次 r3 程序常数。本次不审排版、不修改论文，不外联。结论：主体三段拼接与 LG/图卡路线可接受；**CHANGES-REQUIRED（数学文字和统一常数）**，非对现有计算证书的否定，非 N/F 签字。

## 一、陈述一致性
- L：0<||z−c||₂<52429/2²⁰；18.9191028942<F(P(c))<18.9191047951 与历史局部签字一致。
- N：1/20≤||z−C||₂<3/5；原 note 还给出 star-shaped with respect to an interior point，论文漏写。C 与 c 不是同一个点，统一使用原六个 binary64 C 和 |C−c|∞≤2⁻⁵⁰。镜像面论文 z₃=1/2 对应零基 x₂。
- F：严格凸五边形，F>F* 或 d(P)<3/5（存在至少一个归一标号），与原 note 相符。不要把 d(P)<3/5 误写为所有标号均满足。N 与 L 的重叠有严格裕量。
- 主定理当前写 convex pentagon，矩阵第0节严格凸；平角时退化为至多四边形并用已知三/四边形不等式，逻辑成立。建议在主定理明确正面积简单凸五边形、等号 up to similarity，严格凸为计算证明的主范围。一般非凸不在结论中。
- Wang：参考文献和引言与随包摘要一致，未核对他的证明、不依赖其论证。任务25d 无原文 PDF，不能断言其证明没有计算机辅助；当前仍是未全量闭合的 proof candidate，因此草稿中 “independent computer-assisted argument” 最好显式标明候选及未签字，闭合后可改为 proof，不作优先权主张。详见 PENT25d-HANDOFF.md。

## 二、必须改（在最后签字之前）

### M1 — F* 的精确数值含义（Chart 定义、N/F note、G3、接受合同）
`paper.tex` 约第68行说 `18.919134195733914 (a binary64 number)`，而生成与独立验收 r3 的 `lg_exact.py` 定义 `TARGET=Q('18.919134195733914')`，使用精确十进制有理数。比较：十进制为 9459567097866957/500000000000000；binary64 为 5325262857129979/281474976710656；binary64 略大，差 715956287/8589934592000000000000000 ≈ 8.3348281565e−17。即使差极小，证明 F>较小的数不能无条件推出 F>较大的数。**最小修复不改变 r3，不要求重跑：论文及签字总表共同把 F* 定义为精确有理数，生产侧若使用更大的 binary64 阈值其证书仍比新阈值强。核实所有标签、表根及 tie/conditional 接受使用其规定的有理常数，勿将 float LB 的精确值悄悄改成十进制值。** 最终严格目标仍远大于正五边形 F 的已证上界。替换：

> Throughout the independent certificate system, $F^*:=18.919134195733914$ denotes the exact terminating decimal rational. It is strictly greater than the certified upper bound for $F(P_{\rm reg})$. Any producer certificate proved with a larger threshold also implies the stated inequality. Binary64 geometric inputs and stored bounds are interpreted as their exact encoded rationals.

### M2 — Lemma S 论文证明省略 distinct vertices 与相邻边
NEAR_THEOREM 的完整版成立；论文第 near cover 证明只列非相邻边、非相接点边距离，没有显式 distinct vertices、相邻边交叠排除和 Hausdorff 距离控制。建议直接替换原段：

> In the regular unit-edge pentagon, the distance between two distinct vertices, between two nonadjacent edges, and between a vertex and a nonincident edge is at least one. This follows from its obtuse vertex angles and the distance to the opposite edge (which exceeds one). Moving the endpoints of a segment by at most $a$ moves the segment by at most $a$ in Hausdorff distance. In each of the three cases the objects use disjoint vertex sets; if their maximal displacements are $a,b$, then $a+b\le\sqrt{2}\,\|z-c\|_2<0.85<1$. Thus the three distances remain positive. Two adjacent segments which meet at a further point must overlap on their common line, placing a nonincident endpoint on the other segment, a contradiction. Hence $P(z)$ is simple.

N 声明替换为：

> For every $z$ with $1/20\le\|z-C\|_2<3/5$, the polygon $P(z)$ is a simple pentagon, star-shaped with respect to an interior point, and $F(P(z))>F^*$.

### M3 — 备用 outside 子叶及绕数
当前原盒全证的语句不覆盖新增备用路线。如果最终使用 outside 见证，加入 SIGNOFF-MATRIX-REVIEW 中的交集论证。替换句：

> Each original LG box is either certified in full or partitioned exactly into closed dyadic subboxes. A near-only supplementary subbox may be labelled outside when its exact squared distance from $C$ is at least $(3/5+2^{-40})^2$. Such a subbox cannot contain the point of the annulus under consideration. Every remaining point of the annulus is contained in an LG subbox. At that point the polygon is simple by the preceding lemma; positive fan determinants throughout that subbox make the winding number about the fan centre constant and equal to one. The LG inequality therefore applies at the point. No bound is asserted on an outside subbox.

切记：不能说整个原 LG 盒已经 star-shaped。也不能把 outside 的一个标号在球外当作所有标号在远区；不依赖 F 证明 N。

### M4 — 一点 LG 的 admissibility
Certificates 的首段/One polygon 原文只要求全部 fan det>0，后面的 box paragraph 正确提醒 pentagram 绕数2；前段自身仍缺假设。替换：

> Let $P$ be a simple polygon and $O$ a fan centre with all fan determinants positive and winding number one. In particular these conditions hold for a strictly convex polygon with an interior fan centre. Then the fan triangles tile $P$, and the prescribed continuous trial functions satisfy the stated Sobolev and boundary conditions.

LG lemma 的 u≠0、−div w=u、ν≤λ₂、A₀<νA₁ 与正分母必须保留；PD/PC 正性确实是严格接受所需。原盒中若非凸成员或自交成员，不可从正 det 自动推广。

### M5 — 远区标签中省写的严格侧条件
- T/TX：除引用 (F1)，须有有效的 LB>F*、用于除法的 sup τ_j>0、而且 X 的 g 分母符号正确，TX 要用严格 θ_T>sup g 保证边界 tu=θ_T 时仍被 X 严格排除。替换："Assume the certified table bound LB is strictly greater than $F^*$ and the upper bound on $\tau_j$ is positive. All denominators occurring in the ear comparisons are certified positive after the indicated sign choices. For TX we require the strict separation $\theta_T>\sup g$." 如有不依赖表的三角路线，另用 LABEL_ROUTES 的完整陈述。
- S(a) 原文 `F≥π² min_corners |P|/W_n²` 未指定 n 是单位向量，若 `W_n=max⟨V,n⟩−min⟨V,n⟩` 非物理宽度缺 |n|²；正文的后半句又是逐坐标凹性不等式而非直接最小面积除以最大投影宽。替换："For a nonzero vector $n$, write $W_n=\max_{i,k}|\langle V_i-V_k,n\rangle|$. A sufficient strip test is $|P|\ge\tau W_n^2/\|n\|^2$, certified for every vertex pair by coordinatewise concavity and corner evaluation. The resulting bound is $F(P)\ge\pi^2\tau$." 若要严格超过目标，需严格余量（B 的抬高目标方式可用）。退化角点不能直接除零。
- R：“with C>0” 改成 “with $C_m>0$ and $C_{m+2}>0$”。
- N："The denominator $\min_{\rm corners}\operatorname{Re}(D\bar e)$ is certified strictly positive; $C_p$ denotes the corresponding complex pair of the fixed six-coordinate centre $C$, with conjugation/reflection as required by the chart labelling." 使用向上误差，中心不一致时补足误差。

### M6 — fibre 的数学呈现及独立计算路径
OD/PS 的解析思路成立。Fubini 一维 x 下界对固定 y 的 u 必须以零延拓到投影区间；紧支光滑 u 使其为适用的测试函数。正解 φ 可端点为零，但在开区间必须严格正，须 C¹ 匹配各 piece。补充：

> Extend each compactly supported horizontal slice by zero to the projection interval before applying its one-dimensional variational bound. The ground-state identity is applied to compactly supported test functions, so no endpoint term remains. The piecewise solutions are matched in both value and derivative and their positivity is certified throughout each open piece, not merely at mesh nodes.

生产侧 128 段与 ball arithmetic 叙述可保留并明确是生产路线；独立 verifier 用真实凸包折点、严格矩形宽及有理数传播/余项，适用条件、全段正性和判据见 `LABEL_ROUTES.md`，例如 |(V−m)h²|≤4 控制振荡段相位≤2<π，不可只用端点正性在任意长段推正性。把 LABEL_ROUTES 作为全文证明附件引用，覆盖 triangle_joint、q_strip、P_fibre 等独立替代路线。

### M7 — 状态与全量声明
第 verification status 表及下文必须清楚分开生产自检、第二实现、GPT 真正独立全量重证。生产 C 的 std 6块1,538盒仅抽样；“certified boxes and table entries are re-proved” 改为准确覆盖清单，不暗示全量生产重放。远区 13 个切分标签与本轮近区 13 个未证盒是两批不同对象。推荐："Producer-side replay of the certified boxes has the scope listed in the accompanying manifest (including the 1,538 std boxes checked by sampling only). Independent full re-certification and replay is a separate requirement. The present draft does not assert a second-party sign-off of N or F." 待最终报告再准确替换数字。若使用外部经典定理，应列适用条件和引用，不宣称新证明了这些已知结论。

## 三、建议改（非独立数学否决理由）
- 主 theorem 明确 "For every simple convex pentagon of positive area ... equality precisely for pentagons similar to a regular pentagon." 将有平角的情形作为已知三/四边形推论；避免含自交或零面积。非凸的数值 infimum 改为 "Numerical experiments suggest that ...; no assertion for general non-convex pentagons is proved here." 
- 称 Wang preprint "claims"，不写已证明整个猜想，不写本成果为 'verification of Wang's proof'。闭合前用 independent proof candidate；闭合后 different method / replayable certificates，no priority claim。保留 AI 角色及非同行评审披露。
- “three gaps” 配套括号列全三个已修复问题，或改为 "gaps"，避免读者误计。局部部分引用 v1.1 不重复改变已签阈值。
- 经典 Pólya–Szegő，Makai，Krahn/Hong 等参考文献已列；依据包内记录支持所用范围。未联网核对外部出版信息；v2 正式发布人需确认准确来源及版本。

## 结论
解析主体保持成立的条件已列。M1 是必须消除的精确阈值语义差异；其余主要为补足已有证明前提、outside 分支及真实证据状态。不建议为此修改生成器或中断正在运行的 r3。签字应在 N/F 全量结果、重放、表/结构等条件同时闭合并修订文本之后；当下 N/F NOT SIGNED。
