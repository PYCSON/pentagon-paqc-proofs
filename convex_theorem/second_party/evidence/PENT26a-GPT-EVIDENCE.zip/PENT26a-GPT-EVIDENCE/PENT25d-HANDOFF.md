# PENT-25d — 最小差异最终审查（2026-11-23）

**SIGN-OFF (final tree)**，限 v1.1 Theorem L 与发布材料；不签署 N、F 或 Wang 的证明，不执行公开发布。

## 1. 冻结身份和最小差异
输入 PENT25d_bundle_cc3a52a (1).zip SHA256 `967b2c08cff6255a12581c77db441462617a8518848483e3fa7d2ce10e11d587`。包 121/121、根清单 115/115、local_theorem 清单 42/42 均通过。直接用此前 PENT25c 冻结树比较：两树各 116 文件，增加 0、删除 0，变更 9。逐 hunk 去除 diff 工具的标题差异后，134/134 行一致。变更仅 `.zenodo.json`、`ERRATUM-v1.0-section6.md`、根 `MANIFEST-SHA256.txt`、`README.md`、`local_theorem/MANIFEST-SHA256.txt`、`local_theorem/README.md`、`local_theorem/SOURCE_COMMIT`、`local_theorem/paper/paper.pdf`、`local_theorem/paper/paper.tex`。证书和生成代码未变。Zenodo JSON 可解析；PDF 8 页，标题无 DRAFT，日期 23 November 2026。原始日志见 evidence/logs/input.log、p25diff.log。无新增必改项。

## 2. Wang 引文及中立性
四处表述（根 README、local README、论文引言及文献、Zenodo）均作 claim 限定，明确未核对、两版不依赖其证明；不暗示 Wang 正确或错误，且不改变局部证书的有效性。作者 H. Wang、全名 Hedong Wang、题名 *The Pólya–Szegő inequalities for polygons*、arXiv:2611.22305v1、2026-11-17 均与随包 `LITERATURE_UPDATE_20261123.md` 一致。书目与预印本评审状态的独立外部核查不在本轮证据内。可选措辞："Wang (arXiv:2611.22305v1, 17 November 2026) claims the Pólya–Szegő inequalities for simple polygons with at most n sides, for every n ≥ 5, at fixed area. We have not verified the proof. The results and certificates of this repository do not rely on it, and we make no priority claim." 非必须。

## 3. Wang 原文阅读的边界及 v2 定位
上传的三 ZIP 内没有该预印本 PDF/全文；按任务书明确的离线分支，只读两份 LITERATURE_UPDATE 的阅读记录，没有外联。因此本轮不是对 Wang 原文的独立通读，不能断言其证明完全解析、没有计算机辅助，或任何引理成立。根据供方摘要，Theorem 1.1 声称所有 n≥5、同面积的至多 n 边简单多边形（含非凸）的 λ1 下界及扭转刚度上界，等号仅全等；若成立覆盖本课题。摘要描述凸情形用分区混合 D/N 边值比较、开角相同的等腰三角形比较，配合角度和及支撑线/凹性估计；非凸情形由外角与扭转亏量等处理。补记称附录为解析论证及手工数值不等式，未见机器验证声明；不能由摘要外推为完全没有计算辅助。供方未找到正五边形 F 的显式区间或六维 Hessian 特征值可逐项比对；故不能声称彼此数值印证。其摘要中的 Bessel 常数估计与本轮独立 KS 包络相容，但精度不同，不能替代本轮验证。

v2 在全量计算闭合前宜写："We develop an independent computer-assisted proof candidate for the strictly convex pentagon case, using Lehmann–Goerisch lower bounds and exact, boxwise replayable certificates. The argument does not rely on Wang's claimed proof. We make no priority claim." 闭合并签字后可去掉 candidate；避免 "verification of Wang's proof"，因为我们的证书证明同一命题的特例而不检验他的推导。没有外部人工同行评审，不把 AI 审查表述为同行评审。建议 v1.1 依当前树由用户决定发布日期；若再动任何实质内容应重新最小差异审查。
