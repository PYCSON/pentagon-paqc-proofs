"""Run the supplied verifier as a reader, on the independently generated diagnostic data."""
import sys,json,importlib.util,hashlib,pathlib
from fractions import Fraction as Q
import outside26a as O
from proofs24b import mid_split
from test26a import read_targets
z,box,accept,results=sys.argv[1:];spec=importlib.util.spec_from_file_location('claude_accept',accept);A=importlib.util.module_from_spec(spec);spec.loader.exec_module(A)
assert list(O.C)==A.C_NEAR and O.OUT2==A.OUT2
print('same C, margin and >= predicate; C:',list(map(str,O.C)), 'radius²:',O.OUT2)
rows={r['id']:r['row'] for r in map(json.loads,open(box))};ts=read_targets(z,rows)
lg=out=nodes=0
for x in map(json.loads,open(results)):
 r=x['generation'];t=ts[r['id']];lo,hi=map(lambda a:list(map(Q,a)),(t['lo'],t['hi']));leaves=[];outside=[]
 target=(t['chart'],t['j'],lo,hi,Q(t['L']))
 why=A.walk(r['witness'],lo,hi,target,leaves,0,outside);assert why is None and len(leaves)>0 and len(leaves)<=256
 def check(w,lo,hi):
  global nodes
  assert O.inf_d2(lo,hi)==A.inf_d2(lo,hi);nodes+=1
  if 'axis' in w:
   a,b=mid_split(lo,hi,w['axis']);check(w['left'],*a);check(w['right'],*b)
 check(r['witness'],lo,hi)
 assert len(outside)==r['outside_leaves'] and len(leaves)==r['parts'];lg+=len(leaves);out+=len(outside)
 assert A.walk(r['witness'],lo,hi,target,[],0,None)=='outside leaf not allowed here'
 print(r['id'],'v2.1 geometry PASS','LG',len(leaves),'outside',len(outside))
print('AGREEMENT',len(ts),'targets',nodes,'exact node predicates',lg,'LG',out,'outside')
