from fractions import Fraction as Q
from decimal import Decimal,localcontext

def arctan_bounds(x,m):
 s=sum(((-1)**k*x**(2*k+1)/ (2*k+1) for k in range(m)),Q(0)); t=(-1)**m*x**(2*m+1)/(2*m+1)
 return min(s,s+t),max(s,s+t)
def j0_bounds(x,m):
 # |term_{k+1}/term_k| = x²/(4(k+1)²), decreasing and <1 after k=1 on [0,b].
 t=Q(1);s=t
 for k in range(1,m):t*=-x*x/(4*k*k);s+=t
 tail=t*(-x*x)/(4*m*m)
 assert x*x<4*m*m
 return min(s,s+tail),max(s,s+tail),abs(tail)
def out(q,direction,places=22):
 k=q*10**places;n=k.numerator//k.denominator
 if direction=='up' and k!=n:n+=1
 return str(Decimal(n).scaleb(-places))
a=Q('2.40482555769');b=Q('2.40482555770');x,y=arctan_bounds(Q(1,5),40);u,v=arctan_bounds(Q(1,239),40);pl=16*x-4*v;ph=16*y-4*u
al,ah,ae=j0_bounds(a,30);bl,bh,be=j0_bounds(b,30)
assert al>0 and bh<0 and b*b<8
# J0'=-J1 ; J1(x)/(x/2)=1-x²/8+... alternating with ratios x²/(4(k+1)(k+2))<1.
# Therefore J1(x)>0 for 0<x<=b, by alternating series lower bound 1-x²/8>0.
lo=2*pl*a*a;hi=2*ph*b*b;target=Q('36.33682907');assert lo>target
print('pi',out(pl,'down'),out(ph,'up'))
print('J0(a)',out(al,'down'),out(ah,'up'),'tail <=',out(ae,'up',75))
print('J0(b)',out(bl,'down'),out(bh,'up'),'tail <=',out(be,'up',75))
print('root bracket',a,b,'J1 positive',b*b<8)
print('KS enclosure',out(lo,'down'),out(hi,'up'),'margin >=',out(lo-target,'down'))
print('PASS')
