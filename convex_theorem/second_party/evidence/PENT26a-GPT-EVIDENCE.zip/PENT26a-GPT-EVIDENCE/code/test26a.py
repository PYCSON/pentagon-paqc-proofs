import json,sys,time,zipfile,tarfile,io,pathlib
from fractions import Fraction as Q
import driver as D
import outside26a as O
import replay26a as R
from proofs24b import mid_split
P=pathlib.Path

def read_targets(zpath,rows):
 if D.sha(zpath)!=D.ZIP_SHA:raise ValueError('frozen hash')
 with zipfile.ZipFile(zpath) as z,tarfile.open(fileobj=io.BytesIO(z.read('PENT24_bundle_b8ab7c1/data/near/blocks.tgz')),mode='r:gz') as t:
  target={}
  for m in t.getmembers():
   if not m.isfile() or P(m.name).suffix!='.jsonl':continue
   block=P(m.name).stem
   for i,line in enumerate(t.extractfile(m),0):
    if i==0:continue
    k=f'near/{block}/{i}'
    if k not in O.IDS:continue
    row=json.loads(line);assert row==rows[k];lo,hi,lab,n=row;assert lab=='LG'
    from lg_exact import TARGET
    target[k]=dict(id=k,chart='near',lo=lo,hi=hi,j=3,N=n,L=str(TARGET),block=block,stage='near')
 assert set(target)==O.IDS
 return target

def main():
 zpath,boxes,out=sys.argv[1:4];rows={r['id']:r['row'] for r in map(json.loads,open(boxes))};ts=read_targets(zpath,rows)
 print('FROZEN 13/13 row matches, r3',D.code_id(),flush=True)
 for k,t in sorted(ts.items()):
  counts=[0,0]
  def cut(lo,hi,dep):
   if O.outside(lo,hi):counts[0]+=1;return
   if dep==6:counts[1]+=1;return
   a,b=mid_split(lo,hi,dep);cut(*a,dep+1);cut(*b,dep+1)
  cut(t['lo'],t['hi'],0);print(k,'outside compressed leaves',counts[0],'retained',counts[1],'inf²',float(O.inf_d2(t['lo'],t['hi'])),flush=True)
 t=ts['near/132012/7'];bad={'id':t['id'],'task_sha256':D.identity(t),'status':'PROVED','witness':{'outside':True}}
 for k,mode,u in [('CROSSING','outside',t),('MAIN',False,t),('NORMAL SUPPLEMENT',True,t),('far_std','outside',dict(t,stage='far_std',chart='std')),('q_lg','outside',dict(t,stage='q_lg',chart='qstd')),('NO LG','outside',dict(t,lo=[2]*6,hi=[3]*6))]:
  b=dict(bad,task_sha256=D.identity(u));v=R.verify_one((u,b,mode,256));print(k,v,flush=True);assert v['status']=='REJECT'
 r=O.search(t);P(out).write_text(D.canonical(r)+'\n');print('SEARCH', {k:v for k,v in r.items() if k!='witness'},flush=True)
 if r['status']!='PROVED':raise SystemExit(2)
 valid=R.verify_one((t,r,'outside',256));print('VALID',valid,flush=True);assert valid['status']=='PROVED'
 print('ALL CONTROLS PASS',flush=True)
if __name__=='__main__':main()
