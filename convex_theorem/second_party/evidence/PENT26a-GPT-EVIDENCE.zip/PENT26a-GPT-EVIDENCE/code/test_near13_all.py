"""Diagnostics only: actual frozen 13 tasks, no user main records fabricated."""
import sys,json,multiprocessing as mp,time,os
from pathlib import Path
from test26a import read_targets
import driver as D
import outside26a as O
import replay26a as R

def worker(t):
 r=O.search(t);v=R.verify_one((t,r,'outside',256));return r,v
if __name__=='__main__':
 z,box,out=sys.argv[1:];ts=read_targets(z,{r['id']:r['row'] for r in map(json.loads,open(box))});st=time.monotonic()
 with open(out,'w') as f,mp.get_context('spawn').Pool(3,maxtasksperchild=1) as p:
  for r,v in p.imap_unordered(worker,ts.values()):
   f.write(D.canonical({'generation':r,'replay':v})+'\n');f.flush();os.fsync(f.fileno()); print({k:r[k] for k in ('id','status','seconds','parts','outside_leaves','attempts')},'replay',v['status'],v['seconds'],flush=True)
 print('DONE elapsed',time.monotonic()-st,flush=True)
