# PENT-21c / 22 / 23 — second-party audit evidence (2026-11-19)

**Scope**: real independently executed exact structural tests, symbolic chart proof, selected exact label tests and negative controls. No producer code executed, imported or otherwise run. Frozen user input ZIPs are not included here; their SHA256 digests are fixed in the individual reports.

**Conclusions**:
- 21c input: same SHA256 as previously audited FULL-PASS; no new full Level B run.
- 22: 1,452/1,452 sample 6D root-columns exactly tiled; 370/370 sampled qtable root entries have geometrically complete parts (60 omitted strictly nonconvex children); all 262,144 std and 225,280 E-root cells independently classified. Theorem F remains **PARTIAL**, LG/T1-free C and qtable numeric certificates not replayed.
- 23: 1,344/1,344 stored blocks, 51,434 terminal leaves and 4,096 initial 6D grid cells reclassified exactly; 10k geometric stress-test points pass. Theorem N remains **PARTIAL** because zero of 38,280 LG leaves have an independent PC/PD mathematical replay.
- 8/8 selected structural tamperings rejected, NOT a complete polynomial tamper suite.

**Environment:** Python 3.13 (stdlib), with SymPy only for `independent_cut_algebra.py` and mpmath only for `independent_near_analytic.py` diagnostic. No network access.

## Scripts / truthful capabilities

- `independent_structure.py`: stdlib, near and far exact dyadic tiling/skip checks; it does NOT check LG.
- `far_structure_runner.py`: stdlib, incremental parallel far STRUCTURE-only checker for a complete run directory; has `--jobs`, `--chart`, `--blocks`, `--out`. It does NOT fulfill the requested full multi-label and LG certificate checker; `--sample-c` is not implemented (warns).
- `independent_std_roots.py`, `independent_edge_roots.py`: root geometric necessary-condition enumerations.
- `independent_qtable_structure.py`: qtable geometric subdivisions only, NOT numeric bound validation.
- `independent_cut_algebra.py`: own SymPy cross-product algebra, eight ear comparisons and multi-affinity.
- `independent_far_labels.py`, `independent_far_strip.py`, `independent_far_nearlabel.py`: independently sufficient label tests, with conservative undecided outcomes. T PASS is conditional on unverified archived LB.
- `independent_near_analytic.py`: rational mirror/splice inequalities and mpmath geometric diagnostic.
- `independent_near_points.py`: random point geometry, not FE.
- `independent_mutations.py`: 8 in-memory corruptions; frozen input bytes untouched.

## Example commands (from this evidence directory)

```
python3 -I code/independent_structure.py near /path/to/unpacked/PENT23_bundle_674a571/near_theorem
python3 -I code/independent_structure.py far /path/to/unpacked/PENT22_bundle_674a571/far5_sample/out
python3 -I code/far_structure_runner.py /path/to/completed/far5_run --jobs 8 --out /path/outside_input/results
python3 -I code/independent_far_labels.py /path/to/far5_sample/out
python3 -I code/independent_far_strip.py /path/to/far5_sample/out
python3 -I code/independent_far_nearlabel.py /path/to/far5_sample/out
python3 -I code/independent_std_roots.py /path/to/PENT22_bundle_674a571/T16/classes.json
python3 -I code/independent_edge_roots.py
python3 -I code/independent_qtable_structure.py /path/to/far5_sample/out
python3 -I code/independent_cut_algebra.py
python3 -I code/independent_near_points.py /path/to/near_theorem/certificate/blocks.tgz 10000
```

`independent_mutations.py` uses the fixed sandbox input paths from this GPT audit session for adversarial runs; adjust inputs if re-running elsewhere.

**Audit outputs** in `logs/` are raw program JSON stdout from this actual session. The reports do not rely on a producer `VERIFY OK` as independent proof. The whole archive is hashed by `SHA256SUMS` excluding itself.
