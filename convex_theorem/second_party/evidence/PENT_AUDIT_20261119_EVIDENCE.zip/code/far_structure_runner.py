#!/usr/bin/env python3
"""Portable incremental parallel *STRUCTURE ONLY* replay of far5 run blocks.
Usage: python3 -I far_structure_runner.py RUN_DIR --jobs 8 [--chart std|E2|E3] [--blocks 18_5,24_6] [--sample-c 0] [--out DIR]
Requires Python 3.13+ standard library. Input is never changed. A PASS does NOT
certify LG polynomials, numerical LB/table values, fibre bounds, or all labels.
"""
import argparse, collections, concurrent.futures, hashlib, importlib.util, json, os, pathlib, sys, time
THIS=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('own_structure',str(THIS/'independent_structure.py'))
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)

def check_block(chart,block,path,rs):
    path=pathlib.Path(path);ct=collections.Counter();errs=[];start=time.perf_counter();cols=0;nodes=0
    done=json.loads((path/'done.json').read_text())
    for file in ('leaves.jsonl','cert.jsonl'):
        if mod.sha(path/file)!=done['sha256'][file]:errs.append((file,'SHA mismatch'))
    parts={}
    for key,j,lo,hi,label in mod.jlines((path/'leaves.jsonl').read_text()):
        ct[label]+=1;parts.setdefault((tuple(key),j),[]).append(mod.unit_box(lo,hi))
    for obj in mod.jlines((path/'cert.jsonl').read_text()):
        if obj.get('status')!='certified' or obj.get('how')!='LG':errs.append(('C','invalid status'))
        k,j=tuple(obj['key']),obj['j'];ct['C']+=1;parts.setdefault((k,j),[]).append(mod.unit_box(obj['lo'],obj['hi']))
    expected={(tuple(r[0]),j) for r in rs for j in (0,3)}
    if expected!=set(parts):errs.append(('root-column mismatch',len(expected),len(parts)))
    rootmap={tuple(r[0]):mod.unit_box(r[1],r[2]) for r in rs}
    for (k,j),boxes in parts.items():
        if k not in rootmap:errs.append((k,j,'unknown root'));continue
        q=rootmap[k];root=(q[0]+(0,0),q[1]+(mod.S,mod.S))
        ok,n,msg=mod.cover(root,boxes);cols+=int(ok);nodes+=n
        if not ok:errs.append((k,j,msg))
    return {'chart':chart,'block':block,'passed_columns':cols,'expected_columns':len(expected),'labels':dict(ct),'errors':errs[:10],'error_count':len(errs),'seconds':round(time.perf_counter()-start,3),'nodes':nodes}

def main(argv):
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('run_dir');ap.add_argument('--jobs',type=int,default=1)
    ap.add_argument('--chart',choices=('std','E2','E3'))
    ap.add_argument('--blocks',type=str,default='')
    ap.add_argument('--sample-c',type=int,default=0,help='Ignored: C arithmetic is not implemented in this structural checker')
    ap.add_argument('--out',default=None)
    z=ap.parse_args(argv)
    root=pathlib.Path(z.run_dir).resolve()
    if not (root/'std/roots.json').exists() and (root/'out/std/roots.json').exists():root=root/'out'
    charts=[z.chart] if z.chart else ['std','E2','E3']
    out=pathlib.Path(z.out).resolve() if z.out else root.parent/(root.name+'_GPT_structure_results')
    out.mkdir(parents=True,exist_ok=True)
    wanted=set(z.blocks.split(',')) if z.blocks else None
    tasks=[];res=[];own_sha=mod.sha(__file__)
    for chart in charts:
        r=json.loads((root/chart/'roots.json').read_text())['blocks']
        for b,roots in r.items():
            if wanted is not None and b not in wanted:continue
            path=root/chart/'blocks'/b
            folder=out/chart;folder.mkdir(exist_ok=True)
            final=folder/(b+'.json')
            inp={fn:mod.sha(path/fn) for fn in ('leaves.jsonl','cert.jsonl','done.json')}
            if final.exists():
                try:
                    old=json.loads(final.read_text())
                    if old.get('_input')==inp and old.get('_script')==own_sha:
                        res.append(old);continue
                except (ValueError,OSError):pass
            tasks.append((chart,b,path,roots,inp,final))
    if z.sample_c>0: print('WARNING: --sample-c is not yet implemented; C arithmetic is UNVERIFIED',file=sys.stderr)
    def store(t,o):
        o['_input']=t[4];o['_script']=own_sha
        tmp=t[5].with_suffix('.tmp')
        tmp.write_text(json.dumps(o,ensure_ascii=False,sort_keys=True,indent=2))
        os.replace(tmp,t[5]);res.append(o)
    if z.jobs==1:
        for t in tasks:store(t,check_block(*t[:4]))
    else:
        with concurrent.futures.ProcessPoolExecutor(max_workers=z.jobs) as pool:
            futures={pool.submit(check_block,*t[:4]):t for t in tasks}
            for fu in concurrent.futures.as_completed(futures):store(futures[fu],fu.result())
    cs=collections.Counter();tot=0;bad=[]
    for x in res:
        tot+=x['expected_columns'];cs.update(x['labels'])
        if x['passed_columns']!=x['expected_columns'] or x['error_count']:bad.append((x['chart'],x['block'],x['errors']))
    r={'status':'STRUCTURAL_PASS_ONLY' if not bad else 'STRUCTURAL_FAIL', 'blocks':len(res),'columns':tot,'labels':dict(cs),'error_count':len(bad),'errors':bad[:20],'unverified':['X/T/S/R/O/N etc beyond own partial spot-checker','C LG box certificates','root numeric LB and qtable polynomial bounds','full root coverage unless separately audited'],'out':str(out)}
    print(json.dumps(r,ensure_ascii=False,indent=2));return 1 if bad else 0
if __name__=='__main__':sys.exit(main(sys.argv[1:]))
