#!/usr/bin/env python3
"""Independent symbolic derivation of eight far5 ear comparisons and multi-affinity.
Uses only geometric definitions in theorem; does NOT read or execute producer code.
"""
import sympy as s, itertools, json, time
x,y,z,w,t,u,a,b,h=s.symbols('x y z w t u a b h',real=True)
def cross(P,Q):return s.expand(P[0]*Q[1]-P[1]*Q[0])
def pair_sub(P,Q):return (s.expand(P[0]-Q[0]),s.expand(P[1]-Q[1]))
def scale(k,P):return tuple(s.expand(k*v) for v in P)
def add(P,Q):return tuple(s.expand(P[i]+Q[i]) for i in (0,1))
q0=(s.S(0),s.S(0));q1=(s.S(1),s.S(0));q2=(x,y);q3=(z,w)
def charts(chart):
    if chart=='std': return [q0,q1,q2,q3],[x,y,z,w,t,u]
    if chart=='E2': return [q0,q1,(1+a*(z-1),a*w+h),q3],[z,w,a,h,t,u]
    if chart=='E3': return [q0,q1,q2,(b*x,b*y+h)],[x,y,b,h,t,u]
    raise ValueError(chart)
def pentagon(q,j):
    v0,v1,v2,v3=q
    if j==3: return [v0,v1,v2, add(scale(1-t,v3),scale(t,v2)), scale(1-u,v3)]
    return [add(scale(1-t,v0),scale(t,v1)),v1,v2,v3,add(scale(1-u,v0),scale(u,v3))]
def ear_terms(V,k):
    E=[pair_sub(V[(i+1)%5],V[i]) for i in range(5)]
    AA=cross(E[(k-1)%5],E[k]);BB=cross(E[k],E[(k+1)%5]);CC=cross(E[(k-1)%5],E[(k+1)%5])
    return AA,BB,CC

def main():
    K=w*(x-1)+y*(1-z);D=x*w-y*z;M=D-w;L=w-y
    jdef={3:(3,D),0:(4,w)}
    target={
      (3,0):(2*M,2*y*w), # equality AB-C*tu*D= (common) * (y*w - M*tu*D)
      (3,1):(2*L*D,2*y*K),
      (3,2):(K*(1-2*t)+t*u*M),
      (3,4):(w*(1-2*u)-t*u*(y-w)),
      (0,1):(2*w*L,2*y*K),
      (0,2):(2*w*(-M),2*D*K),
      (0,0):(y*(1-2*t)-t*u*M),
      (0,3):(D*(1-2*u)-t*u*(y-w))
    }
    entries=[];failure=[]
    for j,(cut,base) in jdef.items():
        P=pentagon([q0,q1,q2,q3],j)
        Ccut=s.simplify(ear_terms(P,cut)[2]);
        for k in range(5):
            if k==cut:continue
            A,B,C=ear_terms(P,k)
            num=s.factor(A*B -t*u*base*C)
            fact=s.factor(num)
            # Verify that the ear-cut formula gives t*u*base/2.
            if s.simplify(ear_terms(P,cut)[0]*ear_terms(P,cut)[1]-t*u*base*Ccut)!=0:
                failure.append(('ear-cut',j))
            entries.append({'j':j,'k':k,'C':str(s.factor(C)),'comparison_numerator':str(fact)})
            # Verify expected inequality target's factorization, allowing positive t,u,(1-t),(1-u),D/y factors.
            if (j,k) in ((3,2),(3,4),(0,0),(0,3)):
                rhs=target[(j,k)];ratio=s.cancel(num/rhs)
                entries[-1]['reduced_factor']=str(s.factor(ratio))
    multaff=[]
    for chart in ('std','E2','E3'):
        qq,vars=charts(chart)
        for j in (3,0):
            V=pentagon(qq,j)
            tests=[]
            for m,var in enumerate(vars):
                # Every derivative for the same coordinate is parallel, checked via all vertex pairs.
                deriv=[tuple(s.diff(coord,var) for coord in v) for v in V]
                for A,B in itertools.combinations(deriv,2):
                    if s.simplify(cross(A,B))!=0:failure.append(('direction',chart,j,m))
                for q1i,q2i,q3i,q4i in itertools.product(range(5),repeat=4):
                    if q1i>=q2i or q3i>=q4i:continue
                    e1=pair_sub(V[q1i],V[q2i]);e2=pair_sub(V[q3i],V[q4i]);dd=s.diff(cross(e1,e2),var,2)
                    if dd!=0 and s.simplify(dd)!=0:failure.append(('multaffine',chart,j,m,q1i,q2i,q3i,q4i))
                tests.append(True)
            multaff.append({'chart':chart,'cutj':j,'coords_pass':len(tests)})
    return {'ear_comparisons':entries,'multi_affine':multaff,'failed':failure}
if __name__=='__main__':
    t0=time.perf_counter()
    o=main();o['seconds']=round(time.perf_counter()-t0,3)
    print(json.dumps(o,indent=2));exit(0 if not o['failed'] else 1)
