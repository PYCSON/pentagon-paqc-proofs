#!/usr/bin/env python3
"""Count exact E2/E3 1/16 root charts, without producer code or data lists.
All four positive-necessary Q convexity invariants are multi-affine.
Reject root only if one invariant has nonpositive maximum over its 16 corners.
"""
import itertools,collections,time,json

def maxcorner(lo,fun):
    return max(fun(*arg) for arg in itertools.product(*[(v,v+1) for v in lo]))

def e2root(c,d,a,h):
    pts=itertools.product((c,c+1),(d,d+1),(a,a+1),(h,h+1))
    mx=[-10**9]*4
    for x,y,z,v in pts:
        vals=[z*y+16*v,16*y,v*(16-x),(16-z)*y-v*x]
        for i in range(4):mx[i]=max(mx[i],vals[i])
    return all(u>0 for u in mx)

def e3root(x,y,b,h):
    pts=itertools.product((x,x+1),(y,y+1),(b,b+1),(h,h+1));mx=[-10**9]*4
    for a,c,z,v in pts:
        vals=[16*c,z*c+16*v,c*(16-z)+v*(a-16),a*v]
        for i in range(4):mx[i]=max(mx[i],vals[i])
    return all(u>0 for u in mx)

def main():
    st=time.perf_counter();raw={};good={}
    for name,ranges,fn in (
      ('E2',[range(-16,16),range(4,16),range(-72,72),range(0,2)],e2root),
      ('E3',[range(4,32),range(0,16),range(-64,64),range(0,2)],e3root)):
        a=b=0
        for v in itertools.product(*ranges):
            a+=1
            if fn(*v):b+=1
        raw[name]=a;good[name]=b
    return {'all_grid_cells':raw,'independently_retained':good,'expected_from_theorem':{'E2':15646,'E3':25660},'matching':good=={'E2':15646,'E3':25660},'seconds':round(time.perf_counter()-st,3)}
if __name__=='__main__':print(json.dumps(main(),indent=2))
