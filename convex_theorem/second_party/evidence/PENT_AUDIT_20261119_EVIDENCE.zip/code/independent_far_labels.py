#!/usr/bin/env python3
"""New, read-only exact dyadic validator of selected far5 labels.
For T, LB is an unverified hypothesis from stored roots/table, so result is CONDITIONAL.
Only makes PASS claims when independent exact inequalities hold. Other labels are UNPROVED.
No producer imports or program execution.
"""
import collections, itertools, json, pathlib, sys, time
from fractions import Fraction as F
Q=1<<120
FSTAR=F(18.919134195733914)

def f(x):return F(x)
def boxc(lo,hi):
    return [tuple(lo[i] if b[i]==0 else hi[i] for i in range(len(lo))) for b in itertools.product((0,1),repeat=len(lo))]

def qmap(chart,z):
    a,b,c,d=z[:4]
    if chart=='std':return (a,b,c,d)
    if chart=='E2':return (1+c*(a-1),c*b+d,a,b)
    if chart=='E3':return (a,b,a*c,b*c+d)
    raise ValueError(chart)

def invariants(q):
    x,y,z,w=q
    D=x*w-y*z;K=w*(x-1)+y*(1-z);M=D-w;L=w-y
    return {'y':y,'w':w,'K':K,'D':D,'M':M,'L':L}

def rnge(chart,lo,hi):
    rr=collections.defaultdict(list)
    for p in boxc(lo,hi):
        for name,v in invariants(qmap(chart,p)).items():rr[name].append(v)
    return {k:(min(v),max(v)) for k,v in rr.items()}

def test_V(chart,lo,hi):
    rg=rnge(chart,lo,hi)
    return any(rg[k][1]<=0 for k in ('y','w','K','D'))

def test_E(chart,lo,hi,label):
    if chart!='std':return False
    corners=[invariants(qmap('std',p)) for p in boxc(lo,hi)]
    if label=='E2':return lo[3]>=F(1,4) and all(v['K']-F(1,8)*(1-p[2])<0 for v,p in zip(corners,boxc(lo,hi)))
    if label=='E3':return lo[0]>=F(1,4) and all(v['D']-F(1,8)*p[0]<0 for v,p in zip(corners,boxc(lo,hi)))
    return False

def test_T(chart,lo,hi,LB):
    if LB<=FSTAR:return False,False
    rg=rnge(chart,lo,hi)
    y_lo=max(0,rg['y'][0]);D_lo=max(0,rg['D'][0]);D_hi=rg['D'][1]
    if D_hi<=0:return False
    # conservative strict upper bound for tau_j over convex members
    if min(y_lo,D_lo)==0:tau3=F(1)
    else:tau3=min(F(1),D_hi/(y_lo+D_hi))
    den_lo=y_lo+D_lo
    if den_lo<=0:tau0=F(1)
    else:tau0=min(F(1), max(0,rg['w'][1])/den_lo)
    tmax,umax=hi[4],hi[5]
    return LB*(1-tmax*umax*tau3)>FSTAR,LB*(1-tmax*umax*tau0)>FSTAR

def test_X(chart,lo,hi,j):
    rg=rnge(chart,lo,hi)
    lo_t,lo_u=lo[4],lo[5]
    R={k:(max(F(0),v[0]) if k in ('y','w','K','D') else v[0],v[1]) for k,v in rg.items()}
    def positive(k):return R[k][0]>0
    def maxv(k):return max(F(0),R[k][1])
    def minv(k):return R[k][0]
    # untouched-edge sufficient bounds from derived ear comparisons
    if j==3:
        if minv('M')>0 and positive('D') and lo_t*lo_u*minv('D')*minv('M')>maxv('y')*maxv('w'):return True,'untouched 0'
        if minv('L')>0 and positive('D') and lo_t*lo_u*minv('L')*minv('D')>maxv('y')*maxv('K'):return True,'untouched 1'
    else:
        if minv('L')>0 and positive('w') and lo_t*lo_u*minv('w')*minv('L')>maxv('y')*maxv('K'):return True,'untouched 1'
        if maxv('M')<0 and positive('w') and lo_t*lo_u*minv('w')*(-maxv('M'))>maxv('D')*maxv('K'):return True,'untouched 2'
    # stub comparisons: exact multi-affine expressions; test every corner
    arr=[]
    for p in boxc(lo,hi):
        v=invariants(qmap(chart,p));Y,W,K,D,M,L=v['y'],v['w'],v['K'],v['D'],v['M'],v['L'];t,u=p[4:]
        if j==3:
            arr.append(((t*K-u*M,K*(1-2*t)+t*u*M),(u*W+t*(Y-W),W*(1-2*u)-t*u*(Y-W))))
        else:
            arr.append(((u*M+t*Y,Y*(1-2*t)-t*u*M),(u*D+t*(Y-W),D*(1-2*u)-t*u*(Y-W))))
    for idx in (0,1):
        if all(c[idx][0]>0 and c[idx][1]<0 for c in arr): return True,'stub'+str(idx)
    return False,'undecided'

def main(dat):
    base=pathlib.Path(dat)
    counts=collections.Counter();passcount=collections.Counter();why=collections.Counter();fails=[];start=time.perf_counter()
    for chart in ('std','E2','E3'):
        roots=json.loads((base/chart/'roots.json').read_text())['blocks']
        rm={tuple(ent[0]):F(ent[3]) for arr in roots.values() for ent in arr}
        for block in (base/chart/'blocks').iterdir():
            if not block.is_dir(): continue
            for line in (block/'leaves.jsonl').read_text().splitlines():
                if not line.strip(): continue
                key,j,alo,ahi,label=json.loads(line)
                lo=tuple(map(f,alo));hi=tuple(map(f,ahi))
                counts[label]+=1
                if label=='V':ok=test_V(chart,lo,hi);keyreason='V exact'
                elif label in ('E2','E3'):ok=test_E(chart,lo,hi,label);keyreason='handover exact'
                elif label=='T':ok=test_T(chart,lo,hi,rm[tuple(key)])[0 if j==3 else 1];keyreason='T conditional on archived LB'
                elif label=='X':ok,keyreason=test_X(chart,lo,hi,j)
                else: continue
                if ok:passcount[label]+=1;why[label+' '+keyreason]+=1
                elif len(fails)<30:fails.append((chart,block.name,str(key),j,label,'not independently closed by these criteria'))
    return {'counts':dict(counts),'conditional_or_independent_pass':dict(passcount),'pass_breakdown':dict(why),'sample_unclosed':fails,'seconds':round(time.perf_counter()-start,3),'note':'X/V/E checks require only geometry; T checks assume archived LB (not yet independently certified). Non-PASS means UNPROVED, not FALSE.'}
if __name__=='__main__':print(json.dumps(main(sys.argv[1]),ensure_ascii=False,indent=2))
