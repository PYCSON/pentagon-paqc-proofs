#!/usr/bin/env python3
"""Independent exact interval proof for some far5 N leaves.
Reconstructs vertices and ten normalized labellings from theorem only.
Very conservative interval arithmetic; may leave true certificates unresolved.
"""
import itertools, pathlib, json, collections, time, sys
from fractions import Fraction as F
def boxc(lo,hi):
    return [tuple(lo[i] if b[i]==0 else hi[i] for i in range(len(lo))) for b in itertools.product((0,1),repeat=len(lo))]
def qmap(chart,z):
    a,b,c,d=z[:4]
    if chart=='std':return (a,b,c,d)
    if chart=='E2':return (1+c*(a-1),c*b+d,a,b)
    if chart=='E3':return (a,b,a*c,b*c+d)
    raise ValueError(chart)
C=tuple(F(float.fromhex(h)) for h in ('0x1.4f1bbcdcbfa53p+0','0x1.e6f0e134454ffp-1','0x1.0000000000000p-1','0x1.89f188bdcd7aep+0','-0x1.3c6ef372fe94cp-2','0x1.e6f0e134454ffp-1'))
ZERO=F(0)
class IV:
    __slots__=('a','b')
    def __init__(self,a,b=None):
        self.a=F(a);self.b=F(a if b is None else b);assert self.a<=self.b
    def __add__(self,v):
        if not isinstance(v,IV):v=IV(v)
        return IV(self.a+v.a,self.b+v.b)
    __radd__=__add__
    def __neg__(self):return IV(-self.b,-self.a)
    def __sub__(self,v):return self+(-v if isinstance(v,IV) else IV(-v))
    def __mul__(self,v):
        if not isinstance(v,IV):v=IV(v)
        z=[self.a*v.a,self.a*v.b,self.b*v.a,self.b*v.b];return IV(min(z),max(z))
    __rmul__=__mul__
    def __truediv__(self,v):
        assert isinstance(v,IV) and v.a>0
        return self*IV(1/v.b,1/v.a)
    def sqmax(self):return max(self.a*self.a,self.b*self.b)
    def sqmin(self):
        if self.a<=0<=self.b:return ZERO
        return min(self.a*self.a,self.b*self.b)
    def __repr__(self):return f'IV({float(self.a)},{float(self.b)})'

def vertices(q,j,t,u):
    x,y,z,w=q;v0=(ZERO,ZERO);v1=(F(1),ZERO);v2=(x,y);v3=(z,w)
    if j==3:return [v0,v1,v2,((1-t)*z+t*x,(1-t)*w+t*y),((1-u)*z,(1-u)*w)]
    return [(t,ZERO),v1,v2,v3,(u*z,u*w)]

def prove_one(chart,j,lo,hi):
    corners=boxc(lo,hi)
    vv=[vertices(qmap(chart,p),j,p[4],p[5]) for p in corners]
    P=[(IV(min(g[i][0] for g in vv),max(g[i][0] for g in vv)),IV(min(g[i][1] for g in vv),max(g[i][1] for g in vv))) for i in range(5)]
    # multiaffine proof of vertex coordinate range: done independently in independent_cut_algebra.py
    for i in range(5):
        for sign in (1,-1):
            W=[P[(i+sign*k)%5] for k in range(5)]
            dx=W[1][0]-W[0][0];dy=W[1][1]-W[0][1]
            denom=IV(dx.sqmin()+dy.sqmin(),dx.sqmax()+dy.sqmax())
            if denom.a<=0:continue
            mx=ZERO;bad=False
            for k in (2,3,4):
                a=W[k][0]-W[0][0];b=W[k][1]-W[0][1]
                re=(a*dx+b*dy)/denom
                im=(b*dx-a*dy)/denom
                if sign==-1:im=-im
                mx += (re-IV(C[2*(k-2)])).sqmax()+(im-IV(C[2*(k-2)+1])).sqmax()
                if mx>=F(9,25): bad=True;break
            if not bad and mx<F(9,25):return True,sign,i,mx
    return False,None,None,None

def main(path):
    root=pathlib.Path(path);count=collections.Counter();passed=collections.Counter();samples=[];ts=time.perf_counter()
    for chart in ('std','E2','E3'):
        for blk in (root/chart/'blocks').iterdir():
            if not blk.is_dir():continue
            for ln in (blk/'leaves.jsonl').read_text().splitlines():
                if not ln.strip():continue
                key,j,a,b,label=json.loads(ln)
                if label!='N':continue
                count[chart]+=1
                ok,sign,i,margin=prove_one(chart,j,tuple(F(z) for z in a),tuple(F(z) for z in b))
                if ok:passed[chart]+=1
                elif len(samples)<20:samples.append((chart,blk.name,key,j,a,b))
    return {'N_total':dict(count),'N_strict_interval_proved':dict(passed),'N_unproved_count':{x:count[x]-passed[x] for x in count},'examples_unproved':samples[:4],'seconds':round(time.perf_counter()-ts,3),'scope':'pass exact for all strictly convex members; nonpass undecided due coarse intervals'}
if __name__=='__main__':print(json.dumps(main(sys.argv[1]),indent=2))
