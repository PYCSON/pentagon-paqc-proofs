#!/usr/bin/env python3
"""Strict rational independent recheck of far5 S leaves via strip and edge-strip bounds.
The only transcendental fact used is the published elementary bound pi > 3.14159265358979.
No producer imports; all directions independently selected from each leaf's midpoint.
"""
import collections,itertools,json,pathlib,sys,time
from fractions import Fraction as F
PI_LO=F('3.14159265358979');FSTAR=F(18.919134195733914)

def qmap(chart,z):
    a,b,c,d=z[:4]
    if chart=='std':return (a,b,c,d)
    if chart=='E2':return (1+c*(a-1),c*b+d,a,b)
    if chart=='E3':return (a,b,a*c,b*c+d)
    raise ValueError(chart)
def P(chart,j,z):
    a,b,c,d=qmap(chart,z);t,u=z[4:]
    if j==3:return [(F(0),F(0)),(F(1),F(0)),(a,b),((1-t)*c+t*a,(1-t)*d+t*b),((1-u)*c,(1-u)*d)]
    return [(t,F(0)),(F(1),F(0)),(a,b),(c,d),(u*c,u*d)]
def cr(a,b):return a[0]*b[1]-a[1]*b[0]
def sub(a,b):return (a[0]-b[0],a[1]-b[1])
def area(v):return sum(cr(v[i],v[(i+1)%5]) for i in range(5))/2

def minsq(a,b):
    if a<=0<=b:return F(0)
    return min(a*a,b*b)

def test(chart,j,lo,hi):
    corners=[P(chart,j,tuple(hi[i] if bit[i] else lo[i] for i in range(6))) for bit in itertools.product((0,1),repeat=6)]
    Areas=[area(v) for v in corners]
    if min(Areas)<=0:return False,'area corner not certified positive',0
    Pmid=P(chart,j,tuple((lo[i]+hi[i])/2 for i in range(6)))
    directions=[(F(1),F(0)),(F(0),F(1)),(F(1),F(1)),(F(1),F(-1))]
    for i in range(5):
        vx,vy=sub(Pmid[(i+1)%5],Pmid[i]);directions.append((vy,-vx))
    # Independent S(a): min corner ratio * pi_lo^2 > target. Proof by separate concavity.
    for n in directions:
        nx,ny=n
        nn=nx*nx+ny*ny
        if nn==0:continue
        z=[]
        for vv,A in zip(corners,Areas):
            rr=[nx*x+ny*y for x,y in vv];wide=max(rr)-min(rr)
            if wide<=0:break
            z.append(nn*A/wide**2)
        if len(z)==64 and min(z)*PI_LO**2>FSTAR:
            return True,'strip-n',float(min(z)*PI_LO**2-FSTAR)
    # Independent S(b): perimeter-edge strip + largest vertex height bound; use corner extrema.
    for i in range(5):
        dx=[];dy=[];cmax=F(0)
        for vv in corners:
            A,B=vv[i],vv[(i+1)%5]
            ex,ey=sub(B,A);dx.append(ex);dy.append(ey)
            for vk in vv: cmax=max(cmax,cr((ex,ey),sub(vk,A)))
        if cmax<=0:continue
        l_sq=minsq(min(dx),max(dx))+minsq(min(dy),max(dy))
        if l_sq*PI_LO**2>2*cmax*FSTAR:
            return True,'edge-strip',float(l_sq*PI_LO**2/(2*cmax)-FSTAR)
    return False,'not closed by tested strips',0

def main(root):
    root=pathlib.Path(root);cnt=collections.Counter();p=collections.Counter();margin=[];example=[];st=time.perf_counter()
    for chart in ('std','E2','E3'):
        for blk in (root/chart/'blocks').iterdir():
            if not blk.is_dir():continue
            for line in (blk/'leaves.jsonl').read_text().splitlines():
                if not line:continue
                key,j,a,b,label=json.loads(line)
                if label!='S':continue
                cnt[chart]+=1
                good,reason,m=test(chart,j,tuple(map(F,a)),tuple(map(F,b)))
                if good: p[(chart,reason)]+=1;margin.append(m)
                elif len(example)<10:example.append((chart,blk.name,key,j,a,b,reason))
    return {'S_total':dict(cnt),'S_pass':{str(k):v for k,v in p.items()},'S_pass_total':sum(p.values()),'S_min_margin':min(margin) if margin else None,'undecided_examples':example[:3],'seconds':round(time.perf_counter()-st,3)}
if __name__=='__main__':print(json.dumps(main(sys.argv[1]),indent=2))
