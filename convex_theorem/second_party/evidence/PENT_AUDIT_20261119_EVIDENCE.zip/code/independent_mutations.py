#!/usr/bin/env python3
"""Intentional in-memory corruption tests for own exact partition and skip validators.
Frozen input bytes are never modified. Only our independently authored checkers execute.
"""
import pathlib, json, runpy, tarfile
P=pathlib.Path(__file__).resolve().parent
ns=runpy.run_path(str(P/'independent_structure.py'))
cover=ns['cover'];unit_box=ns['unit_box'];I=ns['I'];S=ns['S']
farn=runpy.run_path(str(P/'independent_far_labels.py'))
test_T=farn['test_T']
results={}

def test(name,condition):results[name]='REJECTED_EXPECTED' if condition else 'UNEXPECTED_ACCEPT'

near='/mnt/data/pent-audit-20261119/input/23/PENT23_bundle_674a571/near_theorem/certificate/blocks.tgz'
with tarfile.open(near) as tar:
    found=None
    for m in tar:
        if not m.isfile():continue
        l=tar.extractfile(m).read().decode().splitlines();h=json.loads(l[0]);a=[json.loads(s) for s in l[1:]]
        if any(v[2]=='LG' for v in a) and any(v[2]=='far' for v in a):found=(h,a);break
h,arr=found
root=unit_box(h['lo'],h['hi']);boxes=[unit_box(v[0],v[1]) for v in arr]
assert cover(root,boxes)[0]
# remove a leaf
b=boxes[1:]
test('near delete leaf',not cover(root,b)[0])
# inflate an LG leaf outside its root
j=next(i for i,v in enumerate(arr) if v[2]=='LG')
a=list(boxes);lo,hi=boxes[j];newhi=list(hi);newhi[0]=root[1][0]+S//16;a[j]=(lo,tuple(newhi))
test('near LG extends beyond block',not cover(root,a)[0])
# mislabel a genuine far leaf after expanding intervals toward C (without altering other leaves)
cf=('0x1.4f1bbcdcbfa53p+0','0x1.e6f0e134454ffp-1','0x1.0000000000000p-1','0x1.89f188bdcd7aep+0','-0x1.3c6ef372fe94cp-2','0x1.e6f0e134454ffp-1')
C=[I(float.fromhex(v)) for v in cf]
farbox=next(boxes[i] for i,v in enumerate(arr) if v[2]=='far')
fal, fah=farbox
newlo=[min(fal[i],C[i]) for i in range(6)];newhi=[max(fah[i],C[i]) for i in range(6)]
inf=sum((newlo[i]-C[i])**2 if C[i]<newlo[i] else (newhi[i]-C[i])**2 if C[i]>newhi[i] else 0 for i in range(6))
test('near corrupted far lower bound',not (25*inf>=9*S*S))
# mirror label imposed on positive-half-space leaf
lgi=next(i for i,v in enumerate(arr) if v[2]=='LG' and boxes[i][1][2]>S//2)
test('near LG forged as mirror',not (boxes[lgi][1][2]<=S//2))

far='/mnt/data/pent-audit-20261119/input/22/PENT22_bundle_674a571/far5_sample/out'
F=pathlib.Path(far); blk=F/'std/blocks/18_5';rootdict=json.loads((F/'std/roots.json').read_text())['blocks']['18_5']
rootmap={tuple(r[0]):unit_box(r[1],r[2]) for r in rootdict}
L=[json.loads(z) for z in (blk/'leaves.jsonl').read_text().splitlines() if z]
CC=[json.loads(z) for z in (blk/'cert.jsonl').read_text().splitlines() if z]
col={}
for key,j,lo,hi,label in L:col.setdefault((tuple(key),j),[]).append(unit_box(lo,hi))
for c in CC:col.setdefault((tuple(c['key']),c['j']),[]).append(unit_box(c['lo'],c['hi']))
key,j=next(k for k,boxes in col.items() if len(boxes)>1)
root=rootmap[key];R=(root[0]+(0,0),root[1]+(S,S));boxes=col[(key,j)]
assert cover(R,boxes)[0]
test('far delete leaf',not cover(R,boxes[1:])[0])
# double a certified box into overlapping column where possible
ci=next(c for c in CC if tuple(c['key']) in rootmap)
k=tuple(ci['key']);jj=ci['j'];R=(rootmap[k][0]+(0,0),rootmap[k][1]+(S,S));bs=list(col[(k,jj)])
orig=unit_box(ci['lo'],ci['hi']);idx=bs.index(orig);a,b=orig;bh=list(b)
# extend t to double its size, or outside column
bh[4]=b[4]+(b[4]-a[4]);bs[idx]=(a,tuple(bh))
test('far C box doubled',not cover(R,bs)[0])
# make an X leaf into a T leaf even though it has no T inequality
rootLB={tuple(r[0]):farn['F'](r[3]) for r in rootdict}
corrupt=None
for entry in L:
    kk,jj,la,ha,label=entry
    if label!='X':continue
    z=farn['test_T']('std',tuple(map(farn['F'],la)),tuple(map(farn['F'],ha)),rootLB[tuple(kk)])
    if not z[0 if jj==3 else 1]:corrupt=(kk,jj);break
test('far X leaf forged as T (conditional LB test)',corrupt is not None)
# stretch one T leaf past root or into a sibling
entry=next(q for q in L if q[4]=='T')
k,jj,la,ha,_=entry;R=(rootmap[tuple(k)][0]+(0,0),rootmap[tuple(k)][1]+(S,S));bs=list(col[(tuple(k),jj)])
orig=unit_box(la,ha);i=bs.index(orig);a,b=orig;bb=list(b);bb[5]=b[5]+(b[5]-a[5]);bs[i]=(a,tuple(bb))
test('far T u-end expanded',not cover(R,bs)[0])

print(json.dumps({'tests':results,'expected_rejections':sum(x=='REJECTED_EXPECTED' for x in results.values()),'total':len(results)},indent=2))
