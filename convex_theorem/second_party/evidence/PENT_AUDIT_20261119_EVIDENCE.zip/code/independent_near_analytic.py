#!/usr/bin/env python3
"""Independent exact near-interface and mirror identities; high-precision geometry diagnostic.
Only rational interface inequalities are used for PASS. The min-distance scan is diagnostic.
"""
from fractions import Fraction as F
import json, mpmath as mp, itertools
mp.mp.dps=80
c72=(mp.sqrt(5)-1)/4;s72=mp.sqrt(10+2*mp.sqrt(5))/4
P=[(mp.mpf(0),mp.mpf(0)),(mp.mpf(1),mp.mpf(0)),(1+c72,s72),(mp.mpf('0.5'),s72/(2*c72)),(-c72,s72)]

def norm2(v):return v[0]*v[0]+v[1]*v[1]
def sub(v,w):return (v[0]-w[0],v[1]-w[1])
def segpoint(p,a,b):
    v=sub(b,a);t=((p[0]-a[0])*v[0]+(p[1]-a[1])*v[1])/norm2(v)
    t=max(mp.mpf('0'),min(mp.mpf('1'),t))
    return mp.sqrt(norm2(sub(p,(a[0]+t*v[0],a[1]+t*v[1]))))
def segseg(a,b,c,d):
    # In the convex regular pentagon, disjoint non-adjacent edges do not intersect,
    # so minimum occurs at one of the endpoint-to-segment feet.
    return min(segpoint(a,c,d),segpoint(b,c,d),segpoint(c,a,b),segpoint(d,a,b))
ved=[];ed=[];vv=[]
for i in range(5):
    for k in range(5):
        if k not in (i,(i-1)%5):ved.append((i,k,segpoint(P[i],P[k],P[(k+1)%5])))
    for j in range(i+1,5):
        if (j-i)%5 not in (1,4):ed.append((i,j,segseg(P[i],P[(i+1)%5],P[j],P[(j+1)%5])))
        vv.append((i,j,mp.sqrt(norm2(sub(P[i],P[j])))))
R=F(52429,2**20)
margin=R-F(1,20)
assert margin==F(1,5242880)
assert margin>F(3,2**50) # enough for sqrt(6)*2^-50
assert mp.sqrt(2)*(mp.mpf('0.6')+3/mp.power(2,50))<1
c_hex=('0x1.4f1bbcdcbfa53p+0','0x1.e6f0e134454ffp-1','0x1.0000000000000p-1','0x1.89f188bdcd7aep+0','-0x1.3c6ef372fe94cp-2','0x1.e6f0e134454ffp-1')
C=tuple(F(float.fromhex(v)) for v in c_hex)
mirror=(1-C[4],C[5],1-C[2],C[3],1-C[0],C[1])
assert C==mirror
assert min(v[-1] for v in ved)>mp.mpf('0.999999999999999999')
assert min(v[-1] for v in ed)>mp.mpf('0.999999999999999999')
assert min(v[-1] for v in vv)>mp.mpf('0.999999999999999999')
print(json.dumps({'exact_mirror_fixed_point':True,'R_minus_1_over_20':str(margin),'radius_splice_strict':True,'min_distance_vertex_nonincident_edge_approx':str(min(v[-1] for v in ved))[:26],'min_distance_nonadjacent_edges_approx':str(min(v[-1] for v in ed))[:26],'min_distance_distinct_vertices_approx':str(min(v[-1] for v in vv))[:26],'lemma_S_geometry':'No counterexample; high precision scan supplements geometric argument; not a machine formalization.'},indent=2))
