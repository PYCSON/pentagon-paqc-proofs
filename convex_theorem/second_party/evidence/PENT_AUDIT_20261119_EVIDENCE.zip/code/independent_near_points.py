#!/usr/bin/env python3
"""Independent nonrigorous geometry / leaf membership challenge: 10,000 annulus points.
Never calls producer or numerical eigensolver; not an LG mathematical certificate.
"""
import collections,json,math,random,tarfile,pathlib,sys,time
C=[float.fromhex(v) for v in ('0x1.4f1bbcdcbfa53p+0','0x1.e6f0e134454ffp-1','0x1.0000000000000p-1','0x1.89f188bdcd7aep+0','-0x1.3c6ef372fe94cp-2','0x1.e6f0e134454ffp-1')]
R=[round(v*1024)/1024 for v in C];A=[v-.625 for v in R];unit=.3125

def cc(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def geom(x):
    p=[(0.,0.),(1.,0.),(x[0],x[1]),(x[2],x[3]),(x[4],x[5])]
    nconv=sum(cc(p[i],p[(i+1)%5],p[(i+2)%5])>0 for i in range(5))==5
    def meet(i,j):
        a,b=p[i],p[(i+1)%5];c,d=p[j],p[(j+1)%5]
        return cc(a,b,c)*cc(a,b,d)<0 and cc(c,d,a)*cc(c,d,b)<0
    nonadj=[(i,j) for i in range(5) for j in range(i+1,5) if (j-i)%5 not in (1,4)]
    simple=not any(meet(i,j) for i,j in nonadj)
    return simple,nconv

def mirror(x):return [1-x[4],x[5],1-x[2],x[3],1-x[0],x[1]]

def main(file,N):
    st=time.perf_counter();rng=random.Random(20261119);blocks={}
    with tarfile.open(file,'r:gz') as tf:
        for member in tf:
            if not member.isfile():continue
            rows=tf.extractfile(member).read().decode().splitlines()
            blocks[json.loads(rows[0])['block']]=[json.loads(z) for z in rows[1:]]
    counts=collections.Counter();errors=[]
    for n in range(N):
        v=[rng.gauss(0,1) for _ in range(6)];scale=1/math.sqrt(sum(q*q for q in v))
        r=.05+(0.6-.05)*(rng.random() if n%3 else rng.random()**16)
        if n%5==0:r=.6-(.6-.05)*rng.random()**12
        x=[C[i]+v[i]*scale*r for i in range(6)]
        simple,conv=geom(x);counts['simple' if simple else 'non-simple']+=1;counts['strictly convex' if conv else 'non-convex']+=1
        if x[2]<.5:x=mirror(x);counts['mirrored']+=1
        digits=[int(math.floor((x[i]-A[i])/unit)) for i in range(6)]
        if not all(0<=d<=3 for d in digits):errors.append(('outside root',n));continue
        key=''.join(map(str,digits));count=0;labels=[]
        if key not in blocks:errors.append(('missing block',n,key));continue
        for lo,hi,label,N_degree in blocks[key]:
            if all(lo[i]<=x[i]<=hi[i] for i in range(6)):
                count+=1;labels.append(label)
        if count!=1 or labels!=['LG']:
            if len(errors)<25:errors.append(('bad point',n,key,count,labels))
        else:counts['LG leaf unique match']+=1
    return {'point_count':N,'counts':dict(counts),'errors':errors,'error_count':len(errors),'seconds':round(time.perf_counter()-st,3),'nonrigorous':'no eigenvalue calculation, only geometric sampling'}
if __name__=='__main__':print(json.dumps(main(sys.argv[1],int(sys.argv[2]) if len(sys.argv)>2 else 10000),ensure_ascii=False,indent=2))
