#!/usr/bin/env python3
"""Independent exact tiling and non-convex-hole checks for stored far5 qtable.
No numerical LG, fibre, strip, or table-bound claim is certified by this script.
"""
import itertools,collections,json,pathlib,sys,time
from fractions import Fraction as F

def inv(q):
    x,y,z,w=q
    return [y,w,w*(x-1)+y*(1-z),x*w-y*z]

def nonconvex(lo,hi):
    corners=itertools.product(*[(lo[i],hi[i]) for i in range(4)])
    mx=[F(-999)]*4
    for q in corners:
        qq=inv(q)
        mx=[max(x,y) for x,y in zip(mx,qq)]
    return any(v<=0 for v in mx)

def main(dir):
    root=pathlib.Path(dir);table=[json.loads(l) for l in (root/'qtable/cells.jsonl').read_text().splitlines() if l.strip()]
    entries=json.loads((root/'std/roots.json').read_text())['blocks']
    rmap={tuple(e[0]):(tuple(map(F,e[1])),tuple(map(F,e[2])),F(e[3])) for li in entries.values() for e in li}
    results=collections.Counter();errs=[];t=time.perf_counter()
    if set(rmap)!={tuple(x['key']) for x in table}:errs.append(('qtable key mismatch',len(table),len(rmap)))
    for entry in table:
        key=tuple(entry['key']);lo,hi,storedLB=rmap[key]
        if storedLB!=F(entry['LB']):errs.append((key,'LB mismatch'))
        if 'lg' not in entry:continue
        parts=entry['lg']['parts'];results['LG roots']+=1;results['parts']+=len(parts)
        widths=[(hi[i]-lo[i])/2 for i in range(4)];children={tuple(bits):(tuple(lo[i]+bits[i]*widths[i] for i in range(4)),tuple(lo[i]+(bits[i]+1)*widths[i] for i in range(4))) for bits in itertools.product((0,1),repeat=4)}
        used=set();whole=False
        for z in parts:
            a,b,bound,kind=z;a=tuple(map(F,a));b=tuple(map(F,b))
            if any(a[i]<lo[i] or b[i]>hi[i] for i in range(4)):errs.append((key,'part outside root'));continue
            if a==lo and b==hi:
                if len(parts)!=1:errs.append((key,'root-wide part alongside subparts'))
                whole=True;break
            matches=[k for k,v in children.items() if v==(a,b)]
            if len(matches)!=1:errs.append((key,'nonmatching subdivision'));continue
            k=matches[0]
            if k in used:errs.append((key,'duplicate part',k))
            used.add(k)
        if whole:
            results['full root LG']+=1
        else:
            for k,(a,b) in children.items():
                if k in used:continue
                results['omitted child cells']+=1
                if nonconvex(a,b):results['omitted nonconvex confirmed']+=1
                else:errs.append((key,'omitted child may be strictly convex',k))
    return {'roots':len(table),'results':dict(results),'errors':errs[:40],'error_count':len(errs),'seconds':round(time.perf_counter()-t,3),'bound_reproof':'NOT RUN (LG + fibre + strip sub-part bounds need independent certificates)'}
if __name__=='__main__':print(json.dumps(main(sys.argv[1]),ensure_ascii=False,indent=2))
