#!/usr/bin/env python3
"""Independent exact 1/16-grid safety check for Theorem F std-root exclusions.
Every rejected cell must have an independently established geometric reason.
No producer source imported/executed.
"""
import collections,itertools,json,sys,time

def mindist0(a,b):
    if a<=0<=b:return 0
    return min(a*a,b*b)

def certify(k):
    _,i,j,u,v=k
    if j+1<=0 or v+1<=0:return 'noncvx'
    corners=itertools.product((i,i+1),(j,j+1),(u,u+1),(v,v+1))
    maxK,maxD=-(10**10),-(10**10)
    for x,y,z,w in corners:
        K=w*(x-16)+y*(16-z)
        D=x*w-y*z
        if K>maxK:maxK=K
        if D>maxD:maxD=D
    if maxK<=0 or maxD<=0:return 'noncvx'
    # Each one of the three off-base Q edges must have length<=1.
    e1=mindist0(i-16,i+1-16)+mindist0(j,j+1)
    e3=mindist0(u,u+1)+mindist0(v,v+1)
    e2=mindist0(u-i-1,u+1-i)+mindist0(v-j-1,v+1-j)
    if min((e1,e2,e3))>256:return 'outside' # all three > 1 (stronger than necessary)
    if max((e1,e2,e3))>256:return 'outside'
    return 'build'

if __name__=='__main__':
    a=json.load(open(sys.argv[1]));assert len(a)==32*16*32*16
    c=collections.Counter();d=collections.Counter();unsafe=[];start=time.perf_counter()
    for s,label in a.items():
        k=tuple(map(int,s.split(','))); calc=certify(k)
        c[label]+=1
        if label!='build' and calc=='build':
            if len(unsafe)<25:unsafe.append((s,label))
            d['uncertified exclusion']+=1
        elif label=='build':d['archived build retained']+=1
        else:d['safe geometric exclusion']+=1
    print(json.dumps({'total':len(a),'labels':dict(c),'validation':dict(d),'unsafe_examples':unsafe,'seconds':round(time.perf_counter()-start,3)},indent=2))
