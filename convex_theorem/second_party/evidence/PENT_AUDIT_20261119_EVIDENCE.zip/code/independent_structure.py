#!/usr/bin/env python3
"""Independently authored, stdlib-only dyadic exact-cover and geometry audits.
Does not import or execute producer sources. Exact arithmetic is integer scaled by 2**60.

usage: python -I independent_structure.py near NEAR_THEOREM_DIR
       python -I independent_structure.py far FAR_SAMPLE_OUT_DIR
"""
import collections, hashlib, itertools, json, math, pathlib, sys, tarfile, time
S=1<<60

def I(x):
    if isinstance(x,int): return x*S
    a,b=x.as_integer_ratio()
    assert S%b==0, ('non-dyadic precision > 2**60',x,b)
    return a*(S//b)

def unit_box(lo,hi):
    lo=tuple(I(x) for x in lo);hi=tuple(I(x) for x in hi)
    assert len(lo)==len(hi) and all(a<b for a,b in zip(lo,hi)), (lo,hi)
    return lo,hi

def cover(root, boxes):
    """Prove closed dyadic subboxes tile root via recursively recovered midpoint binary tree.
    Returns (status, nodes, issue); not just matching volume.
    A valid tree is a constructive partition proof with no positive interior overlap or gap.
    """
    if not boxes: return False,0,'empty'
    seen=[0]
    def rec(lo,hi,arr):
        seen[0]+=1
        if len(arr)==1:
            return (arr[0]==(lo,hi),'mismatched terminal bounds')
        for d in range(len(lo)):
            s=lo[d]+hi[d]
            if s%2:continue
            m=s//2
            left=[];right=[];valid=True
            for a,b in arr:
                if b[d]<=m:left.append((a,b))
                elif a[d]>=m:right.append((a,b))
                else:valid=False;break
            if valid and left and right:
                lh=list(hi);lh[d]=m;rl=list(lo);rl[d]=m
                a,err=rec(lo,tuple(lh),left)
                if not a:return False,err
                return rec(tuple(rl),hi,right)
        return False,'no globally separating midpoint (non-dyadic partition, overlap or gap)'
    for a,b in boxes:
        if any(a[d]<root[0][d] or b[d]>root[1][d] for d in range(len(a))):
            return False,seen[0],'box outside parent'
    yes,why=rec(*root,boxes)
    return yes,seen[0],why if not yes else ''

def jlines(s):
    for ln in s.splitlines():
        if ln.strip():yield json.loads(ln)

def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def near(dirname):
    base=pathlib.Path(dirname)
    tar=base/'certificate/blocks.tgz'
    # Reference point C is stated exactly in the theorem-compatible hex listing; read-only literal.
    c_hex=('0x1.4f1bbcdcbfa53p+0','0x1.e6f0e134454ffp-1','0x1.0000000000000p-1',
      '0x1.89f188bdcd7aep+0','-0x1.3c6ef372fe94cp-2','0x1.e6f0e134454ffp-1')
    C=tuple(I(float.fromhex(v)) for v in c_hex)
    H=I(.625); blockside=I(.3125);half=I(.5)
    root_c=tuple((v+(1<<49))//(1<<50)*(1<<50) for v in C) # round to multiples of 2^-10; same for these values
    root_lo=tuple(v-H for v in root_c);root_hi=tuple(v+H for v in root_c)
    assert all(abs(a-b)<I(1/2048)+2 for a,b in zip(C,root_c))
    assert H-I(.6)>max(abs(a-b) for a,b in zip(C,root_c)), 'root fails to include open radius 3/5 ball'
    assert C[2]==half and C[4]==S-C[0] and C[5]==C[1]
    assert root_lo[2]+2*blockside == half
    labels=collections.Counter();errors=[];types=collections.Counter();ids=set();max_nodes=0;st=time.perf_counter()
    def norm_bounds(box):
        lo,hi=box
        low=0;up=0
        for a,b,c in zip(lo,hi,C):
            low+= (a-c)**2 if a>c else (b-c)**2 if b<c else 0
            up+=max((a-c)**2,(b-c)**2)
        return low,up
    znear=9*S*S//25;zinner=S*S//400
    # strict comparing via integer rounding of rational thresholds works if those thresholds have fractional remainder:
    # e.g. l >= 9/25 exact means 25*l >= 9*S*S.
    with tarfile.open(tar,'r:gz') as f:
        for entry in f:
            if not entry.isfile():continue
            assert entry.name.startswith('blocks/') and entry.name.endswith('.jsonl')
            name=entry.name.split('/')[-1][:-6]
            assert len(name)==6 and all(ch in '0123' for ch in name)
            assert name not in ids;ids.add(name)
            lines=f.extractfile(entry).read().decode().splitlines()
            h=json.loads(lines[0]);root=unit_box(h['lo'],h['hi']);expected=(tuple(root_lo[d]+int(name[d])*blockside for d in range(6)),tuple(root_lo[d]+(int(name[d])+1)*blockside for d in range(6)))
            if root != expected:errors.append((name,'block header differs from exact grid'))
            bxs=[];ct=collections.Counter()
            for i,line in enumerate(lines[1:]):
                a,b,label,N=json.loads(line);box=unit_box(a,b);bxs.append(box);ct[label]+=1;labels[label]+=1
                if label=='mirror':good=box[1][2]<=half
                elif label=='far':good=25*norm_bounds(box)[0]>=9*S*S
                elif label=='inner':good=400*norm_bounds(box)[1]<S*S
                elif label=='LG':good=True;types['LG not arithmetically replayed']+=1
                else:good=False
                if not good: errors.append((name,i,label,'invalid skip or unknown label'))
            if ct != collections.Counter({k:v for k,v in h['stats'].items() if k in ['LG','far','inner','mirror'] and v>0}):errors.append((name,'stats mismatch'))
            yes,n,why=cover(root,bxs);max_nodes=max(n,max_nodes)
            types['blocks partition PASS' if yes else 'blocks partition FAIL']+=1
            if not yes:errors.append((name,'partition',why))
            # A saved block cannot itself be safely skipped.
            low,up=norm_bounds(root)
            if root[1][2]<=half or 25*low>=9*S*S or 400*up<S*S:errors.append((name,'stored but skippable'))
    # all nonstored level2 cubes must pass one of the three skip tests, including the mirror boundary.
    needed=set()
    for digs in itertools.product(range(4),repeat=6):
        lo=tuple(root_lo[d]+v*blockside for d,v in enumerate(digs));hi=tuple(v+blockside for v in lo)
        low,up=norm_bounds((lo,hi))
        if hi[2]<=half or 25*low>=9*S*S or 400*up<S*S:types['skipped base4 roots']+=1
        else: needed.add(''.join(map(str,digs)))
    missing=sorted(needed-ids);extra=sorted(ids-needed)
    if missing: errors.append(('expected missing blocks',len(missing),missing[:10]))
    if extra:errors.append(('unexpected blocks',len(extra),extra[:10]))
    report={'task':'near','source':'blocks.tgz','blocks':len(ids),'expected_blocks':len(needed),'labels':dict(labels),'tests':dict(types),'max_recursive_nodes':max_nodes,'root_c':[float(v/S) for v in root_c],'C':[float(v/S) for v in C], 'errors':errors[:50], 'error_count':len(errors),'seconds':round(time.perf_counter()-st,3), 'lg_reproof':'NOT RUN'}
    return report

def far(dirname):
    base=pathlib.Path(dirname);errors=[];counts=collections.Counter();roots_tot={};rootcheck=collections.Counter();t=time.perf_counter();badgroups=0;minnodes=0
    for chart in ('std','E2','E3'):
        cdir=base/chart; roots=json.loads((cdir/'roots.json').read_text())['blocks']
        rootmap={}; chartct=collections.Counter()
        for b,entries in roots.items():
            for key,lo,hi,LB in entries:
                ky=tuple(key);assert ky not in rootmap
                rootmap[ky]=unit_box(lo,hi)
        roots_tot[chart]=len(rootmap)
        for blk in (cdir/'blocks').iterdir():
            if not blk.is_dir():continue
            d=json.loads((blk/'done.json').read_text())
            for file in ('leaves.jsonl','cert.jsonl'):
                if sha(blk/file)!=d['sha256'][file]:errors.append((chart,blk.name,file,'SHA mismatch'))
            leaves={};cats=collections.Counter()
            for x in jlines((blk/'leaves.jsonl').read_text()):
                key,j,a,b,label=x
                if label=='C':errors.append((chart,blk.name,'C erroneously in leaves'))
                leaves.setdefault((tuple(key),j),[]).append(unit_box(a,b));cats[label]+=1
            for x in jlines((blk/'cert.jsonl').read_text()):
                if x.get('status')!='certified' or x.get('how')!='LG':errors.append((chart,blk.name,'malformed C'))
                leaves.setdefault((tuple(x['key']),x['j']),[]).append(unit_box(x['lo'],x['hi']));cats['C']+=1
            expected={(k,j) for k in rootmap if any(k==tuple(x[0]) for x in roots.get(blk.name,[])) for j in (0,3)}
            got=set(leaves)
            if got!=expected:errors.append((chart,blk.name,'wrong key and j sets',len(got),len(expected)))
            for (k,j),boxes in leaves.items():
                if k not in rootmap:
                    errors.append((chart,blk.name,'unknown root',k));continue
                r=rootmap[k];R=(r[0]+(0,0),r[1]+(S,S));ok,n,why=cover(R,boxes);minnodes=max(minnodes,n)
                rootcheck['column PASS' if ok else 'column FAIL']+=1
                if not ok:errors.append((chart,blk.name,k,j,'partition',why))
            chartct.update(cats); counts.update(cats)
        rootcheck[chart+' columns']=sum(2*len(arr) for arr in roots.values())
    return {'task':'far','roots':roots_tot,'columns':dict(rootcheck),'labels':dict(counts),'error_count':len(errors),'errors':errors[:50],'seconds':round(time.perf_counter()-t,3),'lg_reproof':'NOT RUN','closed_form_reproof':'NOT RUN','full_roots_recheck':'SAMPLE ONLY'}

if __name__=='__main__':
    assert len(sys.argv)==3
    fn={'near':near,'far':far}[sys.argv[1]]
    v=fn(sys.argv[2]);print(json.dumps(v,ensure_ascii=False,indent=2))
    sys.exit(0 if not v['error_count'] else 1)
