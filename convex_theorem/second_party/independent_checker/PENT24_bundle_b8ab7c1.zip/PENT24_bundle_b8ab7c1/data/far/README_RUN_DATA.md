# The complete far cover `pent_far5` (user's machine, 2026-11-18/19) and its checks

Run: package `pent_far5` (T1-free), COMMIT f30df709be7ad03480fca3c6543760ca373693e9, eight processes on the author's
computer, started 11-18 10:44 CST, `ALL STAGES DONE` 11-19 01:57:46 CST; 1,260 / 1,260 blocks, no unresolved leaf.
Acceptance: `../local/accept/FAR5_USER_ACCEPT_20261119.md`.

| file | content | SHA256 |
|---|---|---|
| `pent_far5_cert.tar.xz` (13,749,176 bytes; 262 MB unpacked) | `out/`: `config.json`, `<chart>/roots.json`, every block's `leaves.jsonl`, `cert.jsonl`, `done.json`, `block.log`; `qtable/cells.jsonl`, `table_info.json` | 01cec8f9ddacf8fb39b6b188d75cb848c7d18ba2b37ba9b354d8577dd5fed174 |
| `far5_results.tgz` (1,860,051 bytes) | `run.log`, `status.txt`, `COMMIT`, `verify.txt` (empty: the self-check crashed, see below), per-block summaries | 4760db3ee7cf018700d2e177c9dc01ca5a4cc189f52bdc5b4bf617cf0ee3af4c |

**Unpacking.** Extract into an empty directory (`tar xJf pent_far5_cert.tar.xz --no-same-owner --no-same-permissions`).
The archive lacks the per-block `corners.jsonl` because the packing command omitted it (fixed in `../local/accept/README.md`).
Every `done.json` records the SHA256 of the empty file for it (eigen corners: 0 everywhere), so recreate them with
`for d in out/*/blocks/*/; do : > "$d/corners.jsonl"; done` before running `far_verify.py`.

## Checks (`sandbox_checks/`, all on these files, in the sandbox)
| log | program | result |
|---|---|---|
| `verify_edge.txt` | production `far_verify.py --replay 3 --relabel 300 --table 20 --strict-table --complete --chart E2,E3` | VERIFY OK |
| `verify_std.txt` | the same for std (before the `lg_check` fix) | everything OK except 10 table LG parts "not re-proved": the non-monotone test, see the acceptance note |
| `table_A.txt`, `table_B.txt` | the table check for std after the fix (two halves of the blocks) | VERIFY OK; 43,103 LG entries re-proved |
| `root_spot.txt` | `v2_run/tests/far_root_spot.py` (second implementation) | no missing root |
| `tiling_spot.txt` | `v2_run/tests/far_tiling_spot.py` (second implementation) | no failure |
| `label_*of8.txt` | `v2_run/tests/far_label_spot.py --sample 0 --part i/8` (second implementation) | 1,346,916 re-proved in one piece, 13 not |
| `../local/accept/tools/label_subdivide_far5_log.txt` | `local/accept/tools/label_subdivide.py` | the 13: every one re-proved after one halving into 64 pieces |
| `e2e_50000_final.txt`, `e2e_hard_30000_final.txt`, `e2e_shell_30000_final.txt` | `v2_run/tests/far_e2e_check.py` (floating point, no proof): random strictly convex pentagon → kept representation → leaf of this cover (through the hand-over) → the leaf's assertion from the vertices | 110,000 pentagons (random; adversarial: tiny / full cuts, flat vertices, ties, elongated; chart distance 0.5–0.8 around the hand-over sphere): **0 violations, 0 inconclusive** |

Not covered by a second implementation: the 377,515 certified boxes (C; 2,532 of them replayed from scratch by the
production self-check), the LG parts of the quadrilateral table
(re-proved by the production code only), the closed forms of the label code (re-derived by hand and by
`tests/far_formula_check.py`). These are the second party's items 3.4 and 3.5 in `handoffs/GPT-PENT-22-20261117.md`.
