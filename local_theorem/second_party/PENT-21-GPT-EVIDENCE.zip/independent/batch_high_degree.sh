#!/usr/bin/env bash
set -euo pipefail
P=/mnt/data/pent21_review/independent
for S in "$@"; do
  ((S>=180 && S<240)) || continue
  (OPENBLAS_NUM_THREADS=1 python "$P/fan_lg_checker.py" 5 "$S" > "$P/fan_chunk_${S}.log" 2>&1) &
done
wait
for S in "$@"; do tail -1 "$P/fan_chunk_${S}.log"; done
