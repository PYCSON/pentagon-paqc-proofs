#!/usr/bin/env python3
"""Independent fan Lehmann-Goerisch verification from LG_LEMMA.md specification.
NEVER imports/executes production Python. Optimises flux with floating linear algebra,
then CERTIFIES the resulting certificate using exact rational triangle integrals.
"""
from fractions import Fraction as F
import math,functools,sys,time,json
from pathlib import Path
import numpy as np
from numpy.polynomial.legendre import leggauss

P=Path('/mnt/data/pent21_review/input/lines/D-topics/probes/PENT/v2_run/tests/lg_samples/fan_samples.jsonl')
KS=F(3633682907,100000000)

def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def sub(a,b):return (a[0]-b[0],a[1]-b[1])
def integral_dict(a):return sum((v*integral_mon(*k) for k,v in a.items()),F(0))
@functools.lru_cache(None)
def integral_mon(i,j):return F(math.factorial(i)*math.factorial(j),math.factorial(i+j+2))

def poly_add(a,b,fac=1):
 z=dict(a)
 for k,v in b.items():z[k]=z.get(k,F(0))+fac*v
 return {k:v for k,v in z.items() if v}
def scale(a,f):return {k:f*v for k,v in a.items() if v}
def deriv(a,index):
 out={}
 for (i,j),v in a.items():
  k=i if index==0 else j
  if k: out[(i-1,j) if index==0 else (i,j-1)]=k*v
 return out
def multiply(a,b):
 z={}
 for (i,j),v in a.items():
  for (p,q),w in b.items():z[(i+p,j+q)]=z.get((i+p,j+q),F(0))+v*w
 return z
def inner(a,b):return integral_dict(multiply(a,b))
def xpoly(a,axis):return {(p+(axis==0),q+(axis==1)):v for (p,q),v in a.items()}
@functools.lru_cache(None)
def bern_abc(n,i,j,l):
 coeff=F(math.factorial(n),math.factorial(i)*math.factorial(j)*math.factorial(l))
 out={}
 for aa in range(i+1):
  for bb in range(i-aa+1):
   ff=coeff*math.factorial(i)/(math.factorial(aa)*math.factorial(bb)*math.factorial(i-aa-bb))*(-1)**(aa+bb)
   out[(j+aa,l+bb)]=ff
 return out

def free_u_indices(n,k):
 out=[];interior=n-1
 for i in range(n,-1,-1):
  for j in range(n-i,-1,-1):
   l=n-i-j
   if i==0:idx=None
   elif i==n:idx=0
   elif l==0:idx=1+k*(n-1)+(i-1)
   elif j==0:idx=1+((k+1)%5)*(n-1)+(i-1)
   else:
    offset=sum((n-ii-1 for ii in range(1,i)),0)+(j-1)
    idx=1+5*(n-1)+k*(n-1)*(n-2)//2+offset
   if idx is not None:out.append((i,j,l,idx))
 return out

def free_chi_indices(n,k):
 out=[];base=1+5*(n-1);vbase=base;ebase=vbase+5; ibase=ebase+5*(n-1)
 for i in range(n,-1,-1):
  for j in range(n-i,-1,-1):
   l=n-i-j
   if i==n:idx=0
   elif j==n:idx=vbase+k
   elif l==n:idx=vbase+(k+1)%5
   elif l==0 and i>0:idx=1+k*(n-1)+(i-1)
   elif j==0 and i>0:idx=1+((k+1)%5)*(n-1)+(i-1)
   elif i==0:idx=ebase+k*(n-1)+(j-1)
   else:
    offset=sum((n-ii-1 for ii in range(1,i)),0)+(j-1)
    idx=ibase+k*(n-1)*(n-2)//2+offset
   out.append((i,j,l,idx))
 return out

def convex(v):
 return all(cross(sub(v[(i+1)%len(v)],v[i]),sub(v[(i+2)%len(v)],v[(i+1)%len(v)]))>0 for i in range(len(v)))
def contains_polygon(vouter,vinner):
 return all(cross(sub(vouter[(i+1)%len(vouter)],vouter[i]),sub(p,vouter[i]))>=0 for p in vinner for i in range(len(vouter)))

def qdata(n):
 t,wt=leggauss(n);t=(t+1)/2;wt=wt/2
 aa,tt=np.meshgrid(t,t,indexing='ij');a=aa.ravel();b=((1-aa)*tt).ravel();q=(wt[:,None]*wt[None,:]*(1-aa)).ravel()
 return a,b,q

def polyval(p,a,b):
 z=np.zeros_like(a)
 for (i,j),v in p.items():z+=float(v)*a**i*b**j
 return z

def optimize_flux(uh,tri_geometries,n,ndim,precision=26):
 a,b,weight=qdata(max(11,n+2));N=len(a)
 G=np.zeros((ndim,ndim));rhs=np.zeros(ndim)
 for k,(det,M,Nmat) in enumerate(tri_geometries):
  d=np.zeros((N,ndim,2))
  for i,j,l,idx in free_chi_indices(n,k):
   B=bern_abc(n,i,j,l)
   d[:,idx,0]+=polyval(deriv(B,1),a,b)
   d[:,idx,1]-=polyval(deriv(B,0),a,b)
  rr=-float(det)*np.stack([a,b],axis=1)*polyval(uh[k],a,b)[:,None]
  rN=rr@np.array(Nmat,dtype=float)
  rhs+=np.einsum('ni,nki,n->k',rN,d,weight)
  G+=np.einsum('nki,ij,nlj,n->kl',d,np.array(Nmat,dtype=float),d,weight)
 # eliminate constant gauge at center
 sol=np.zeros(ndim)
 try:sol[1:]=np.linalg.solve(G[1:,1:],-rhs[1:])
 except np.linalg.LinAlgError as ex:
  print('bad chi solve',ex,flush=True);return None
 scale_int=2**precision
 return [F(int(round(x*scale_int)),scale_int) for x in sol]

def rectangle_nu(vertices):
  pi2=F(98696044,10000000)  # 9.8696044 < pi^2
  dirs=[(F(1),F(0)),(F(0),F(1))]
  for k in range(len(vertices)):
   e=sub(vertices[(k+1)%len(vertices)],vertices[k])
   dirs.append(e)
  best=F(0)
  for dx,dy in dirs:
   L2=dx*dx+dy*dy
   p=[x*dx+y*dy for x,y in vertices]
   q=[-x*dy+y*dx for x,y in vertices]
   a2=(max(p)-min(p))**2/L2
   b2=(max(q)-min(q))**2/L2
   if a2 and b2:best=max(best,pi2*min(4/a2+1/b2,1/a2+4/b2))
  return best

def check(record,do_optimise=True):
 v=record['lg'];N=int(v['N']);n=int(v['n'])
 coordc=tuple(F(x) for x in v['c']);s=F(v['s'])
 V=[tuple(F.from_float(float(t)) for t in row) for row in record['V']]
 Vf=[tuple((x-coordc[i])/s for i,x in enumerate(row)) for row in V]
 UP=[tuple(F(x) for x in row) for row in v['Uplus']];O=tuple(F(x) for x in v['O'])
 if not convex(Vf) or not convex(UP) or not contains_polygon(UP,Vf) or not contains_polygon(UP,[O]):return {'pass':False,'why':'geometry'}
 areaP=sum((cross(V[i],V[(i+1)%5]) for i in range(5)),F(0))/2
 areaf=sum((cross(UP[i],UP[(i+1)%5]) for i in range(5)),F(0))/2
 if areaP<=0 or areaf<=0: return {'pass':False,'why':'area'}
 ucoeff=v['u'];needed_u=1+5*(N-1)+5*(N-1)*(N-2)//2
 if len(ucoeff)!=needed_u:return {'pass':False,'why':'u length'}
 chiN=1+5*(n-1)+5+5*(n-1)+5*(n-1)*(n-2)//2
 un=[];hun=[];trip=[];Pmat=[]
 for k in range(5):
  e1=sub(UP[k],O);e2=sub(UP[(k+1)%5],O);det=cross(e1,e2)
  if det<=0:return {'pass':False,'why':'det'}
  n11=sum(x*x for x in e1);n12=sum(x*y for x,y in zip(e1,e2));n22=sum(x*x for x in e2)
  M=((n22/det,-n12/det),(-n12/det,n11/det)); Nt=((n11/det,n12/det),(n12/det,n22/det))
  pol={}
  for i,j,l,idx in free_u_indices(N,k):
   pol=poly_add(pol,bern_abc(N,i,j,l),F(ucoeff[idx],2**30))
  hp={q:vv/F(sum(q)+2) for q,vv in pol.items()}
  un.append(pol);hun.append(hp);trip.append((det,M,Nt));Pmat.append((det,n11,n12,n22))
 if do_optimise and not ('x' in v and 'xe' in v):
  cchi=optimize_flux(hun,trip,n,chiN)
  if cchi is None:return {'pass':False,'why':'chi optimization'}
 elif 'x' in v:
  cchi=[F(t)*F(2)**int(v['xe']) for t in v['x']]
 else:cchi=[F(0)]*chiN
 A0=A1=A2=F(0)
 for k,(det,M,Nt) in enumerate(trip):
  uu=un[k];hh=hun[k]
  chic={}
  for i,j,l,idx in free_chi_indices(n,k):
   if cchi[idx]:chic=poly_add(chic,bern_abc(n,i,j,l),cchi[idx])
  ua=deriv(uu,0);ub=deriv(uu,1)
  cha=deriv(chic,0);chb=deriv(chic,1)
  rr0=poly_add(scale(xpoly(hh,0),-det),chb)
  rr1=poly_add(scale(xpoly(hh,1),-det),cha,-1)
  A1+=det*inner(uu,uu)
  A0+=M[0][0]*inner(ua,ua)+2*M[0][1]*inner(ua,ub)+M[1][1]*inner(ub,ub)
  A2+=Nt[0][0]*inner(rr0,rr0)+2*Nt[0][1]*inner(rr0,rr1)+Nt[1][1]*inner(rr1,rr1)
 nu=max(KS/areaf,rectangle_nu(UP))
 D=A0-nu*A1
 if D>=0:return {'pass':False,'why':'LG hypothesis','D':float(D)}
 G=A0-2*nu*A1+nu*nu*A2
 Fnew=nu*(-D)/(G-D)*areaP/s**2
 claim=F.from_float(float(v['F_lo']))
 return {'pass':Fnew>=claim,'F_independent':float(Fnew),'claimed_F_lo':float(claim),'slack':float(Fnew-claim),'N':N,'n':n,'F0_Ritz':float(A0/A1*areaP/s**2),'D':float(D),'A0':float(A0),'A1':float(A1),'A2':float(A2),'flux_optimised':do_optimise and 'x' not in v}

if __name__=='__main__':
 t=time.monotonic();res=[]
 with open(P) as f:
  for j,line in enumerate(f):
   if not line.strip():continue
   if len(sys.argv)>2 and j<int(sys.argv[2]):continue
   ans=check(json.loads(line));ans['index']=j;ans['sec_since_start']=time.monotonic()-t
   res.append(ans)
   print(j,ans,flush=True)
   if len(sys.argv)>1 and len(res)>=int(sys.argv[1]):break
 print('total',len(res),'PASS',sum(x['pass'] for x in res),'elapsed',time.monotonic()-t)
 Path('/mnt/data/pent21_review/independent/fan_lg_result.json').write_text(json.dumps(res,indent=2))
