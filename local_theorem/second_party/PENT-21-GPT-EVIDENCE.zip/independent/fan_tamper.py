import copy,json
from fan_lg_checker import P,check
v=json.loads(open(P).readline());a=check(v)
assert a['pass']
w=copy.deepcopy(v);w['lg']['F_lo']+=.01;z=check(w);assert not z['pass']
print('TAMPERED_CLAIM',z['pass'],z['slack'])
w=copy.deepcopy(v);w['lg']['Uplus'][1]=w['lg']['Uplus'][0];z=check(w);assert not z['pass'];print('TAMPERED_GEOMETRY',z['pass'],z['why'])
w=copy.deepcopy(v);w['lg']['u'][0]=0;z=check(w);assert not z['pass'];print('TAMPERED_U',z['pass'],z.get('why'),z.get('slack'))
