#!/usr/bin/env python3
"""Independent piecewise-linear finite element eigenvalue probe for Theorem L.
Only a NONRIGOROUS numerical falsification test; never imports producer scripts.
Fixed fan topology, physical triangles obtained via mapping from chart pentagon.
"""
import math,time,json,sys
from pathlib import Path
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import eigsh

def regular():
 v=[np.array([0.,0.]),np.array([1.,0.])]
 for j in range(1,4):v.append(v[-1]+np.array([math.cos(2*math.pi*j/5),math.sin(2*math.pi*j/5)]))
 return np.array(v)
V0=regular(); c=V0[2:].ravel(); O=np.mean(V0,axis=0)

class FanFE:
 def __init__(self,N):
  self.N=N;nd={}; bary=[];tris=[]
  def node(k,i,j):
   if i+j==0:key=('o',)
   elif j==0:key=('r',k,i)
   elif i==0:key=('r',(k+1)%5,j)
   else:key=('t',k,i,j)
   if key not in nd:
    nd[key]=len(nd)
    q=np.zeros(5);q[k]+=i/N;q[(k+1)%5]+=j/N
    bary.append(q)
   return nd[key]
  for k in range(5):
   for i in range(N):
    for j in range(N-i):
     tris.append((node(k,i,j),node(k,i+1,j),node(k,i,j+1)))
     if i+j<N-1:tris.append((node(k,i+1,j),node(k,i+1,j+1),node(k,i,j+1)))
  self.tris=np.asarray(tris,dtype=np.int64)
  self.bary=np.asarray(bary)
  self.inner=np.where(np.max(self.bary,axis=1)<1-1e-12)[0]
  # some points with beta+gamma==1 should be boundary despite largest q<1, use sum q=1
  self.inner=np.where(np.sum(self.bary,axis=1)<1-1e-12)[0]
  self.ri=np.repeat(self.tris,3,axis=1).ravel()
  self.ci=np.tile(self.tris,(1,3)).ravel()
  self.size=len(self.bary)
  print('mesh N',N,'nodes',self.size,'free',len(self.inner),'elements',len(self.tris),flush=True)
 def eigen(self,z,return_vec=False):
  V=np.concatenate([V0[:2],np.array(z).reshape(3,2)])
  pts=self.bary@V+(1-np.sum(self.bary,axis=1))[:,None]*O
  t=pts[self.tris]
  x=t[:,:,0];y=t[:,:,1]
  det=(x[:,1]-x[:,0])*(y[:,2]-y[:,0])-(x[:,2]-x[:,0])*(y[:,1]-y[:,0])
  if np.min(det)<=0:raise ValueError(f'bad triangle det {np.min(det)}')
  bet=np.stack([y[:,1]-y[:,2],y[:,2]-y[:,0],y[:,0]-y[:,1]],axis=1)
  gam=np.stack([x[:,2]-x[:,1],x[:,0]-x[:,2],x[:,1]-x[:,0]],axis=1)
  K=(bet[:,:,None]*bet[:,None,:]+gam[:,:,None]*gam[:,None,:])/(2*det[:,None,None])
  Mass=((np.ones((3,3))+np.eye(3))[None,:,:]*det[:,None,None]/24)
  K=coo_matrix((K.ravel(),(self.ri,self.ci)),shape=(self.size,self.size)).tocsr()[self.inner,:][:,self.inner]
  Mass=coo_matrix((Mass.ravel(),(self.ri,self.ci)),shape=(self.size,self.size)).tocsr()[self.inner,:][:,self.inner]
  lam,vec=eigsh(K,k=1,M=Mass,sigma=0.,which='LM',tol=2e-11)
  area=.5*sum(np.cross(V[i],V[(i+1)%5]) for i in range(5))
  F=lam[0]*area
  return (F,vec[:,0]) if return_vec else F

def hessian(fe,h):
 zero=fe.eigen(c);n=6;g=np.zeros(n);H=np.zeros((n,n)); fs={}
 for i in range(6):
  v=np.eye(6)[i]*h; p=fe.eigen(c+v);m=fe.eigen(c-v);fs[(i,1)]=p;fs[(i,-1)]=m
  g[i]=(p-m)/(2*h);H[i,i]=(p+m-2*zero)/h**2
 for i in range(6):
  for j in range(i+1,6):
   vi=np.eye(6)[i]*h; vj=np.eye(6)[j]*h
   zz=(fe.eigen(c+vi+vj)-fe.eigen(c+vi-vj)-fe.eigen(c-vi+vj)+fe.eigen(c-vi-vj))/(4*h*h)
   H[i,j]=H[j,i]=zz
 w,vec=np.linalg.eigh(H)
 return zero,g,H,w,vec

def search(fe,w,vec,F0,nrandom=300,seed=20261117):
 rng=np.random.default_rng(seed)
 trials=[]
 for i in range(2):
  for radius in [0.001,0.003,0.005,0.01,0.025,0.049]:
   for sign in [-1,1]:trials.append((f'weak{i}_{radius}_{sign}',sign*radius*vec[:,i]))
 for j in range(nrandom):
  d=rng.standard_normal(6);d/=np.linalg.norm(d)
  radius=np.exp(rng.uniform(math.log(.001),math.log(.0495)))
  trials.append((f'random_{j}',d*radius))
 best=(1e50,None,None); bad=[]
 for name,d in trials:
  F=fe.eigen(c+d)
  r2=d@d;coef=(F-F0)/r2
  if coef<best[0]:best=(coef,name,float(np.sqrt(r2)))
  if coef<.2:bad.append((name,float(np.sqrt(r2)),F,coef))
 return best,bad,len(trials)

if __name__=='__main__':
 start=time.monotonic();data=[]
 for N,h in [(12,0.004),(20,.004),(28,.004)]:
  fe=FanFE(N)
  t=time.monotonic();F0,g,H,eigs,vec=hessian(fe,h)
  print('HESSIAN',N,'h',h,'F0',F0,'gradmax',np.max(abs(g)),'six eigs',eigs,'sec',time.monotonic()-t,flush=True)
  data.append({'N':N,'F0':float(F0),'gradmax':float(np.max(abs(g))),'H_eigs':eigs.tolist(),'H':H.tolist(),'sec':time.monotonic()-t})
  if N==28:
   best,bad,nt=search(fe,eigs,vec,F0,150)
   print('SEARCH',nt,'best curvature ratio',best,'bad count',len(bad),'bad examples',bad[:5],flush=True)
   data[-1].update({'search_trials':nt,'search_best':best,'search_bad':bad})
 print('total elapsed',time.monotonic()-start)
 Path('/mnt/data/pent21_review/independent/fe_results.json').write_text(json.dumps(data,indent=2))
