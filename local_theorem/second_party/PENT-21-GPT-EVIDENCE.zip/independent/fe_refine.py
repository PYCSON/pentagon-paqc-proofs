import json,time
import numpy as np
from pathlib import Path
from fe_hessian_counterexample import FanFE,hessian,search
s=[]
for n,h in ((44,.003),(72,.003)):
 st=time.perf_counter();fe=FanFE(n)
 f,g,H,ev,vec=hessian(fe,h)
 print('REFINED',n,'F0',f,'H eigenvalues',ev,'gradmax',np.max(abs(g)),'secs',time.perf_counter()-st,flush=True)
 s.append({'N':n,'F0':f,'eigenvalues':ev.tolist(),'gradmax':float(np.max(abs(g))),'H':H.tolist(),'sec':time.perf_counter()-st})
 if n==44:
  best,bad,ntrial=search(fe,ev,vec,f,800)
  print('PROBE',best,'N trials',ntrial,'bad',len(bad),flush=True)
  s[-1].update({'search_best':best,'search_trials':ntrial,'search_bad':bad})
Path('/mnt/data/pent21_review/independent/fe_refined.json').write_text(json.dumps(s,indent=2))
