import json
from pathlib import Path
import numpy as np
from fe_hessian_counterexample import FanFE,c
p=Path('/mnt/data/pent21_review/independent/fe_refined.json');z=json.loads(p.read_text())[-1]
H=np.array(z['H']);evals,ev=np.linalg.eigh(H)
fe=FanFE(72);F0=fe.eigen(c)
rows=[]
for k in (0,1):
 for rr in (0.001,0.003,0.005,0.01,0.025,0.049):
  for sign in (-1,1):
   F=fe.eigen(c+sign*rr*ev[:,k]);coef=(F-F0)/rr**2
   rows.append({'weak':k,'radius':rr,'sign':sign,'F_FE':F,'quotient':coef})
   print(k,rr,sign,'quotient',coef,flush=True)
print('min ratio',min(r['quotient'] for r in rows))
Path('/mnt/data/pent21_review/independent/fe_weak72.json').write_text(json.dumps(rows,indent=2))
