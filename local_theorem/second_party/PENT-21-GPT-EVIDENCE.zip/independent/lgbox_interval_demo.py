#!/usr/bin/env python3
"""Independent rigorous 6D box Lehmann-Goerisch example using exact rational intervals.
This is not a replay of producer's near-cover; it certifies one user-specified
sample box with a new fixed trial family, without polynomial-producer code.
"""
import json,sys,time
from fractions import Fraction as F
from pathlib import Path
from fan_lg_checker import *

class IV:
 def __init__(self,l,h=None):
  if isinstance(l,IV):self.lo=l.lo;self.hi=l.hi;return
  self.lo=F(l);self.hi=F(h) if h is not None else F(l)
  assert self.lo<=self.hi
 def __add__(self,b):
  b=IV(b);return IV(self.lo+b.lo,self.hi+b.hi)
 __radd__=__add__
 def __neg__(self):return IV(-self.hi,-self.lo)
 def __sub__(self,b):return self+-IV(b)
 def __rsub__(self,b):return IV(b)+-self
 def __mul__(self,b):
  b=IV(b); v=[a*c for a in [self.lo,self.hi] for c in [b.lo,b.hi]];return IV(min(v),max(v))
 __rmul__=__mul__
 def __truediv__(self,b):
  b=IV(b)
  if b.lo<=0<=b.hi:raise ZeroDivisionError('unproved positive denominator')
  return self*IV(1/b.hi,1/b.lo)
 def __repr__(self):return f'[{float(self.lo):.12g},{float(self.hi):.12g}]'

def loc_iu(p,q):return inner(p,q)

def run(k=0,rho=F(1,2**28)):
 raw=json.loads(open(P).readline())['lg']
 uN=int(raw['N']);n=int(raw['n']);nc=1+5*(n-1)+5+5*(n-1)+5*(n-1)*(n-2)//2
 UP=[tuple(F(x) for x in row) for row in raw['Uplus']]; O=tuple(F(x) for x in raw['O'])
 polys=[];hs=[];geo=[]
 for i in range(5):
  e1=sub(UP[i],O);e2=sub(UP[(i+1)%5],O);det=cross(e1,e2)
  n11=sum(x*x for x in e1);n12=sum(x*y for x,y in zip(e1,e2));n22=sum(x*x for x in e2)
  geo.append((det,((n22/det,-n12/det),(-n12/det,n11/det)),((n11/det,n12/det),(n12/det,n22/det))))
  u={}
  for a,b,c,idx in free_u_indices(uN,i):u=poly_add(u,bern_abc(uN,a,b,c),F(raw['u'][idx],2**30))
  h={key:v/F(sum(key)+2) for key,v in u.items()}
  polys.append(u);hs.append(h)
 cc=optimize_flux(hs,geo,n,nc)
 arrays=[]
 for i in range(5):
  chi={}
  for a,b,c,idx in free_chi_indices(n,i):
   if cc[idx]:chi=poly_add(chi,bern_abc(n,a,b,c),cc[idx])
  u=polys[i];h=hs[i];ua,ub=deriv(u,0),deriv(u,1);ca,cb=deriv(chi,0),deriv(chi,1)
  ah=xpoly(h,0);bh=xpoly(h,1)
  arrays.append(dict(Iuu=inner(u,u),Iaa=inner(ua,ua),Iab=inner(ua,ub),Ibb=inner(ub,ub),
     Saa=inner(ah,ah),Sab=inner(ah,bh),Sbb=inner(bh,bh),
     Scaa=inner(ah,ca),Scbb=inner(bh,cb),Scab=inner(ah,cb),Scba=inner(bh,ca),
     Raa=inner(ca,ca),Rab=inner(ca,cb),Rbb=inner(cb,cb)))
 def certify(boxrad):
  VV=[tuple(IV(x if i<2 else x-boxrad, x if i<2 else x+boxrad) for x in UP[i]) for i in range(5)]
  dA=IV(0);A0=A1=A2=IV(0)
  for i in range(5):
   e1=(VV[i][0]-O[0],VV[i][1]-O[1]);e2=(VV[(i+1)%5][0]-O[0],VV[(i+1)%5][1]-O[1])
   det=e1[0]*e2[1]-e1[1]*e2[0]
   if det.lo<=0:return {'pass':False,'reason':'det','det':str(det)}
   n11=e1[0]*e1[0]+e1[1]*e1[1];n12=e1[0]*e2[0]+e1[1]*e2[1];n22=e2[0]*e2[0]+e2[1]*e2[1]
   a=arrays[i]
   A1+=det*a['Iuu']
   A0+=(n22*a['Iaa']-2*n12*a['Iab']+n11*a['Ibb'])/det
   sa=det*det*a['Saa']-2*det*a['Scab']+a['Rbb']
   sb=det*det*a['Sab']+det*a['Scaa']-det*a['Scbb']-a['Rab']
   sc=det*det*a['Sbb']+2*det*a['Scba']+a['Raa']
   A2+=(n11*sa+2*n12*sb+n22*sc)/det
   dA+=det/2
  dc=KS*A1-dA*A0
  c=dA*dc-F.from_float(18.919134195733914)*(KS*A2-dA*A1)
  return {'pass':dc.lo>0 and c.lo>0,'rho':str(boxrad),'Dc':repr(dc),'C':repr(c),'F_margin_from_LG':float(c.lo/(KS*A2-dA*A1).hi) if (KS*A2-dA*A1).lo>0 else None}
 st=time.perf_counter()
 res=[]
 for r in [F(0),F(1,100),F(1,1000),F(1,10000),F(1,2**20),F(1,2**28)]:
  v=certify(r);res.append(v);print(v,flush=True)
 print('elapsed seconds',time.perf_counter()-st)
 Path('/mnt/data/pent21_review/independent/lgbox_result.json').write_text(json.dumps(res,indent=2))
if __name__=='__main__':run()
