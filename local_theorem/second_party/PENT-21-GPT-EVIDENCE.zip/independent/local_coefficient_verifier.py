#!/usr/bin/env python3
"""Independent exact rational checker for a FROZEN Theorem L polynomial witness.
Consumes monomial coefficient centers and nonnegative radii (degree >=2), never
producer source. This package does not supply the required arrays, so only
synthetic self-tests can run; NEVER reports real 0.3199 from missing inputs.

Expected witness JSON:
 {"Tm":{"0,0,2,0,0,0":"1/2",...},"Em":{same: "1/100"},
  "rho_in":"1/128"}
"""
import json,itertools,math,sys
from fractions import Fraction as F
from pathlib import Path
N=6

def parse_map(d):
 return {tuple(map(int,key.split(','))):F(v) for key,v in d.items()}

def trace(Tm,Em,rho):
 assert all(len(k)==N and sum(k)>=2 for k in Tm|Em)
 H=[[F(0)]*N for _ in range(N)]
 T=[[[F(0)]*N for _ in range(N)] for _ in range(N)]
 Err=[[F(0)]*N for _ in range(N)]
 for k,v in Tm.items():
  if sum(k)==2:
   ix=[i for i,p in enumerate(k) for j in range(p)]
   if ix[0]==ix[1]:H[ix[0]][ix[0]]+=2*v
   else:H[ix[0]][ix[1]]+=v;H[ix[1]][ix[0]]+=v
  if sum(k)==3:
   ix=[i for i,p in enumerate(k) for j in range(p)]
   cnt=len(set(itertools.permutations(ix)))
   for inds in set(itertools.permutations(ix)):
    T[inds[0]][inds[1]][inds[2]]+=v/cnt
 for k,v in Em.items():
  assert v>=0
  if sum(k)==2:
   ix=[i for i,p in enumerate(k) for j in range(p)]
   if ix[0]==ix[1]:Err[ix[0]][ix[0]]+=v
   else:Err[ix[0]][ix[1]]+=v/2;Err[ix[1]][ix[0]]+=v/2
 tau2=max(sum(Err[i]) for i in range(N))
 tau3=sum(v*rho*(F(1) if len([x for x in k if x])==1 else F(1,2)) for k,v in Em.items() if sum(k)==3)
 tau4=sum((abs(Tm.get(k,F(0)))+Em.get(k,F(0)))*rho**(sum(k)-2)*(F(1) if sum(bool(x) for x in k)==1 else F(1,2)) for k in (Tm|Em) if sum(k)>=4)
 tau=tau2+tau3+tau4
 minpivot=None
 for signs in itertools.product((-1,1),repeat=N):
  d=[s*rho for s in signs]
  Q=[[H[i][j]/2+sum(d[k]*T[k][i][j] for k in range(N))-(tau if i==j else 0) for j in range(N)] for i in range(N)]
  # exact fraction LDL pivots
  L=[[F(0)]*N for _ in range(N)];piv=[]
  for i in range(N):
   di=Q[i][i]-sum(L[i][k]**2*piv[k] for k in range(i))
   if di<=0:return {'passed':False,'failing_vertex':signs,'pivot_index':i,'pivot':str(di),'tau':str(tau)}
   piv.append(di);L[i][i]=1
   for j in range(i+1,N):L[j][i]=(Q[j][i]-sum(L[j][k]*L[i][k]*piv[k] for k in range(i)))/di
  vmin=min(piv)
  minpivot=vmin if minpivot is None else min(minpivot,vmin)
 return {'passed':True,'vertex_count':64,'tau2':str(tau2),'tau3':str(tau3),'tau_ge4':str(tau4),'tau':str(tau),'minimum_pivot':str(minpivot),'minimum_pivot_float':float(minpivot)}

def selftest():
 x={};e={}
 def key(*x):return ','.join(map(str,x))
 for i in range(6):
  v=[0]*6;v[i]=2;x[key(*v)]=str(F(i+1,2));e[key(*v)]=str(F(1,1000))
 v=[0]*6;v[0]=3;x[key(*v)]=str(F(1,10))
 v=[0]*6;v[0]=2;v[1]=2;x[key(*v)]=str(F(1,2**12))
 out=trace(parse_map(x),parse_map(e),F(1,128))
 print('POSITIVE WITNESS',out)
 assert out['passed']
 x[key(0,0,0,0,0,2)]='-2'
 out2=trace(parse_map(x),parse_map(e),F(1,128))
 print('TAMPERED WITNESS',out2)
 assert not out2['passed']
 return out
if __name__=='__main__':
 if len(sys.argv)>1:
  v=json.load(open(sys.argv[1]));print(trace(parse_map(v['Tm']),parse_map(v['Em']),F(v.get('rho_in','1/128'))))
 else: selftest()
