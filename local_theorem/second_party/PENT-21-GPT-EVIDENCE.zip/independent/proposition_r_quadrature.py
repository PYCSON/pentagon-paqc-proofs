#!/usr/bin/env python3
"""Independent quadrature validation of Proposition R on a manufactured triangle.
The exact true pair is zero, the computed pair is the polynomial error pair.
Hence this is a nontrivial check of both integration-by-parts cancellations and
of the signs/coefficient structure, without any producer Gram tables.
"""
import json
import numpy as np
from numpy.polynomial.legendre import leggauss
from pathlib import Path

def gauss_triangle(n):
 x,wx=leggauss(n);t=(x+1)/2;w=wx/2
 aa,tt=np.meshgrid(t,t,indexing='ij')
 a=aa.ravel();b=((1-aa)*tt).ravel()
 weight=(w[:,None]*w[None,:]*(1-aa)).ravel()
 return a,b,weight

def quantities(a,b,E1,E2):
 det=np.linalg.det(np.stack([E1,E2],axis=1))
 n11=E1@E1;n12=E1@E2;n22=E2@E2
 M=np.array([[n22,-n12],[-n12,n11]])/det
 N=np.array([[n11,n12],[n12,n22]])/det
 return det,M,N

def run(n=13):
 a,b,weight=gauss_triangle(n)
 ee=a*b*(1-a-b)
 eh=a*b/4-(a*a*b+a*b*b)/5
 grad=np.stack((b*(1-2*a-b),a*(1-a-2*b)),axis=1)
 # nontrivial curl from polynomial chi=a*b*(1-a-b)+0.07 a*b
 dchi_a=grad[:,0]+0.07*b
 dchi_b=grad[:,1]+0.07*a
 rot=np.stack((dchi_b,-dchi_a),axis=1)
 ab=np.stack((a,b),axis=1)
 print('test e not identically zero, ||grad e||^2',np.dot(weight,np.sum(grad*grad,axis=1)))
 d0,Mc,Nc=quantities(a,b,np.array([.7,.1]),np.array([-.1,1.0]))
 dz,Mz,Nz=quantities(a,b,np.array([.65,.15]),np.array([-.25,.9]))
 P0=d0/2;P=dz/2;F0=18.91910384;lam0=F0/P0;lamhat=F0/P;kappa=36.33682907
 sc=rot-d0*ab*eh[:,None]
 sz=rot-dz*ab*eh[:,None]
 rhoc=sc@Nc.T-grad/lam0
 rhoz=sz@Nz.T-grad/lamhat
 # tensors are row vectors: M*gradient etc.
 t0=(rhoc+grad/lam0)@Mc.T
 tz=t0-(dz-d0)*ab*eh[:,None]
 assert np.max(abs(tz-sz))<2e-15
 tp=grad@Mc.T/lam0-(dz-d0)*ab*eh[:,None]
 rconst=rhoc@Mc.T
 def dot(x,y):return np.dot(weight,np.sum(x*y,axis=1))
 def bform(f,g):return dz*np.dot(weight,f*g)
 def aform(f,g):return dot(f@Mz.T,g)
 def cform(f,g):return dot(f@Nz.T,g)
 def B(v,s):return P*(kappa+F0)*bform(v,v)-P**2*aform(grad,grad)-F0*kappa*cform(s,s)
 Psi_tilde=B(ee,sz)
 # true pair v=0, s=0, so Psi must vanish exactly
 Psi_true=0
 K=Psi_tilde+2*F0*kappa*dot(rhoz,rconst)-F0*kappa*cform(rconst,rconst)
 Lam=2*F0*((kappa/lam0)*(rhoz@Mc.T)-P*(rhoz@Mz.T)-(kappa/lam0)*(rconst@Nz.T@Mc.T))
 Theta=-2*F0*kappa*(dz-d0)*(rhoz-rconst@Nz.T)
 q=P*(kappa+F0)*bform(ee,ee)-P**2*aform(grad,grad)-F0*kappa*cform(tp,tp)
 sumrhs=K+dot(grad,Lam)+dot(eh[:,None]*ab,Theta)+q
 # inspect cancellation explicitly using two IP identities
 ip_s=dot(sz,grad); ip_t=dot(tz,grad)
 mass=bform(ee,ee)
 cross=P*(kappa+F0)*mass-P**2*aform(grad,grad)-F0*kappa*cform(sz,tz)
 simplified=F0*P*dot(rhoz,grad@Mz.T)-F0*kappa*dot(rhoz,tz)
 print('z det',dz,'c det',d0)
 print('IP(s), IP(t), mass',ip_s,ip_t,mass,'absolute errors',abs(ip_s-mass),abs(ip_t-mass))
 print('cross term',cross,'simplified',simplified,'diff',cross-simplified)
 print('K',K,'Lgrad',dot(grad,Lam),'Lray',dot(eh[:,None]*ab,Theta),'q',q)
 print('Psi true vs residual expression',Psi_true,sumrhs,'abs error',abs(sumrhs))
 result={'quad_n':n,'ip_s_error':float(abs(ip_s-mass)),'ip_t_error':float(abs(ip_t-mass)),'cross_error':float(abs(cross-simplified)),'residual_identity_error':float(abs(sumrhs)),'K':float(K),'linear_gradient':float(dot(grad,Lam)),'linear_ray':float(dot(eh[:,None]*ab,Theta)),'q':float(q)}
 return result
if __name__=='__main__':
 data=[run(n) for n in [10,15,23]]
 Path('/mnt/data/pent21_review/independent/prop_r_results.json').write_text(json.dumps(data,indent=2))
