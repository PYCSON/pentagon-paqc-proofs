#!/usr/bin/env python3
"""Independent symmetry differential and exact leaf geometry audit.
No imports or executions of producer code."""
import sys, json, hashlib, lzma, itertools, math, time
from pathlib import Path
from fractions import Fraction
import mpmath as mp
import numpy as np
mp.mp.dps=100
root=Path('/mnt/data/pent21_review/input/lines/D-topics/probes/PENT')
out=Path('/mnt/data/pent21_review/independent')
pi=mp.pi
# regular pentagon from unit edge, exterior turn 72 degrees
w=[mp.mpc(0),mp.mpc(1)]
for j in range(1,4): w.append(w[-1]+mp.e**(2*mp.pi*mp.j*j/5))
c=mp.matrix([a for k in (2,3,4) for a in (mp.re(w[k]),mp.im(w[k]))])
print('regular chart c=',[mp.nstr(x,30) for x in c]);print('closure residual',mp.nstr(abs(w[4]+mp.e**(8*mp.pi*mp.j/5)),15))
# exact derivative via quotient rule, with reversed orientation uses conjugation to preserve chirality
I=mp.j
b=[[] for j in range(5)]
for i in range(6):
  v=[mp.mpc(0)]*5
  v[2+i//2]=1 if i%2==0 else I
  b[0].append(v)

def phi_deriv(j,s):
  W=w
  den=W[(j+s)%5]-W[j]
  out=[]; cols=[]
  for k in [2,3,4]:
    num=W[(j+s*k)%5]-W[j]
    t=num/den
    if s==-1:t=mp.conj(t)
    out.extend([mp.re(t),mp.im(t)])
    cols.append(t)
  D=mp.matrix(6,6)
  for i in range(6):
    dw=[mp.mpc(0)]*5
    dw[2+i//2]=1 if i%2==0 else mp.j
    dden=dw[(j+s)%5]-dw[j]
    for idx,k in enumerate([2,3,4]):
      num=W[(j+s*k)%5]-W[j]
      dnum=dw[(j+s*k)%5]-dw[j]
      v=(dnum*den-num*dden)/(den*den)
      if s==-1:v=mp.conj(v)
      D[2*idx,i]=mp.re(v);D[2*idx+1,i]=mp.im(v)
  return out,D
M=mp.matrix(6,6); matrices={}
for s in (1,-1):
 for j in range(5):
  image,D=phi_deriv(j,s)
  diff=max(abs(image[i]-c[i]) for i in range(6))
  print('D5 g',j,s,'fixed-point diff',mp.nstr(diff,4),'trace',mp.nstr(sum(D[i,i] for i in range(6)),14))
  for i in range(6):
   for k in range(6):M[i,k]+=D[i,k]/10
  matrices[f'{j},{s}']=[[mp.nstr(D[i,k],65) for k in range(6)] for i in range(6)]
print('M abs max',mp.nstr(max(abs(M[i,j]) for i in range(6) for j in range(6)),20))
print('M Frobenius norm',mp.nstr(mp.sqrt(sum(M[i,j]**2 for i in range(6) for j in range(6))),20))
print('id matrix squared err',mp.nstr(max(abs((M*M)[i,j]-M[i,j]) for i in range(6) for j in range(6)),20))
# Verify D(g) group closure to numeric tolerance
Dlist=[mp.matrix([[mp.mpf(x) for x in r] for r in val]) for val in matrices.values()]
maxclosure=mp.mpf(0)
for a in Dlist:
 for b0 in Dlist:
  cand=a*b0
  d0=min(max(abs(cand[i,j]-D[i,j]) for i in range(6) for j in range(6)) for D in Dlist)
  maxclosure=max(maxclosure,d0)
print('max group matrix closure err=',mp.nstr(maxclosure,20))
# Fraction volume, bounds checks
p=root/'local_run_20261117/leaves.txt.xz'
actual_sha=hashlib.sha256(lzma.open(p,'rb').read()).hexdigest()
raw=lzma.open(p,'rt').read().splitlines()
leaves=[]
for line in raw:
 try:
  a=[Fraction.from_float(float.fromhex(v)) for v in line.split()]
  assert len(a)==12
  leaves.append(([a[i]-a[6+i] for i in range(6)],[a[i]+a[6+i] for i in range(6)]))
 except Exception as ex:print('BAD LEAF',line[:100],ex);sys.exit(3)
W=Fraction(13,256); rho=Fraction(1,128);R=Fraction(52429,2**20)
total=sum((math.prod(y-x for x,y in zip(lo,hi)) for lo,hi in leaves),Fraction(0))
root_volume=(2*W)**5*W
within=all(all(-W<=lo[i]<hi[i]<=W if i!=2 else 0<=lo[i]<hi[i]<=W for i in range(6)) for lo,hi in leaves)
print('leaf_sha',actual_sha,'nleaf',len(leaves),'within half cube',within,'volume ratio',total/root_volume,'L∞ outlier',min(x for L,H in leaves for x in L))
# pairwise positive overlap x0 swept without using any producer methods
order=sorted(range(len(leaves)),key=lambda j:leaves[j][0][0]); active=[];paircount=0;overlap=None
for t,idx in enumerate(order):
 lo,hi=leaves[idx]; active=[a for a in active if leaves[a][1][0]>lo[0]]
 for other in active:
  paircount+=1
  a,b=leaves[other]
  if all(min(hi[d],b[d])>max(lo[d],a[d]) for d in range(1,6)):
   overlap=(idx,other);break
 if overlap:break
 active.append(idx)
print('pair candidates',paircount,'interior overlap',overlap)
# check leaf categorisation from geometry: full inner, full outside ball, remaining polynomial-claimed
inner=sum(all(max(abs(lo[j]),abs(hi[j]))<=rho for j in range(6)) for lo,hi in leaves)
outside=sum(sum((Fraction(0) if lo[j]<=0<=hi[j] else min(lo[j]**2,hi[j]**2)) for j in range(6))>=R*R for lo,hi in leaves)
print('inner geometry',inner,'outside geometry',outside,'remaining',len(leaves)-inner-outside)
(out/'geometry_symmetry.json').write_text(json.dumps({'M_max':str(max(abs(M[i,j]) for i in range(6) for j in range(6))),'closure_err':str(maxclosure),'leaf_sha':actual_sha,'nleaves':len(leaves),'volume_ratio':str(total/root_volume),'within':within,'overlap':overlap,'inner':inner,'outside':outside,'pair_candidates':paircount,'c':[mp.nstr(x,60) for x in c]},indent=2))
