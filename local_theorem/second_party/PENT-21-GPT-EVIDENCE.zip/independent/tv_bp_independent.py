#!/usr/bin/env python3
"""Independent rational tests of the TV Loewner identity and 6D BP
Bernstein coefficients without reading or executing producer algorithms."""
from fractions import Fraction as F
import itertools,random,math,json
from pathlib import Path
rng=random.Random(20261117)

# TV: exact symmetric 2x2 matrices.
def det(M):return M[0][0]*M[1][1]-M[0][1]*M[1][0]
def diff(A,B):return [[A[i][j]-B[i][j] for j in range(2)] for i in range(2)]
def matdot(X,Y):return [[sum(X[i][k]*Y[k][j] for k in range(2)) for j in range(2)] for i in range(2)]
def transpose(X):return list(map(list,zip(*X)))
def outer(u,v):return [[u[i]*v[j] for j in range(2)] for i in range(2)]

def single(J,B,G,Y):
 # B = 2x2; J>0 scalar; L_Y = B Y^T+Y B^T-J Y Y^T
 L=[[sum(B[i][k]*Y[j][k]+Y[i][k]*B[j][k] for k in range(2))-J*sum(Y[i][k]*Y[j][k] for k in range(2)) for j in range(2)] for i in range(2)]
 G0=matdot(B,transpose(B))
 G=[[v/J for v in rr] for rr in G0] # exact matrix; PSD rank2
 D=diff(G,L)
 E=matdot(diff(B,[[J*x for x in row] for row in Y]),transpose(diff(B,[[J*x for x in row] for row in Y])))
 E=[[x/J for x in row] for row in E]
 assert D==E
 assert D[0][0]>=0 and D[1][1]>=0 and det(D)>=0
 return D

# BP: quadratic Bernstein coefficient for product of multiaffine f,g
# B^2_0=(1-t)^2, B^2_1=2t(1-t), B^2_2=t^2.
corners=list(itertools.product((0,1),repeat=6));ids={v:i for i,v in enumerate(corners)}
def bernstein_prod(f,g):
 out={}
 for a in itertools.product((0,1,2),repeat=6):
  pairs=[]
  for bits in corners:
   v=tuple(a[i]-bits[i] for i in range(6))
   if all(x in (0,1) for x in v):pairs.append((bits,v))
  denom=2**sum(x==1 for x in a)
  out[a]=sum((f[ids[u]]*g[ids[v]] for u,v in pairs),F(0))/denom
 return out

def multiaff_eval(f,t):
 return sum((f[j]*math.prod(t[i] if a else (1-t[i]) for i,a in enumerate(c)) for j,c in enumerate(corners)),0.0)

def b2_eval(b,t):
 def beta(a,x):return (1-x)**2 if a==0 else (2*x*(1-x) if a==1 else x*x)
 return sum(float(v)*math.prod(beta(a[i],t[i]) for i in range(6)) for a,v in b.items())

if __name__=='__main__':
 for k in range(100):
  J=F(rng.randint(1,100),rng.randint(1,30));B=[[F(rng.randint(-7,7),rng.randint(1,9)) for j in range(2)] for i in range(2)]
  Y=[[F(rng.randint(-6,6),rng.randint(1,11)) for j in range(2)] for i in range(2)]
  single(J,B,None,Y)
 print('TV exact identities + PSD: 100/100 PASS')
 for k in range(6):
  f=[F(rng.randint(-30,50),rng.randint(1,100)) for j in range(64)]
  g=[F(rng.randint(-25,40),rng.randint(1,100)) for j in range(64)]
  b=bernstein_prod(f,g)
  for v in range(60):
   t=[rng.random() for i in range(6)]
   y=multiaff_eval(f,t)*multiaff_eval(g,t)
   cert=b2_eval(b,t)
   assert abs(y-cert)<1e-11
   assert y>=min(float(x) for x in b.values())-1e-11
 print('BP 6D coefficient/evaluation checks: 6*60=360/360 PASS; 729 coefficients each')
 Path('/mnt/data/pent21_review/independent/tv_bp_results.json').write_text(json.dumps({'TV':100,'BP_polynomials':6,'BP_points':360,'BP_coefficients_per_product':729},indent=2))
