# PENT-21 — ALL INDEPENDENT CODE

This contains **10 new Python scripts**. All read producer files as data only; none imports or runs producer code.

## `fan_lg_checker.py`

```python
#!/usr/bin/env python3
"""Independent fan Lehmann-Goerisch verification from LG_LEMMA.md specification.
NEVER imports/executes production Python. Optimises flux with floating linear algebra,
then CERTIFIES the resulting certificate using exact rational triangle integrals.
"""
from fractions import Fraction as F
import math,functools,sys,time,json
from pathlib import Path
import numpy as np
from numpy.polynomial.legendre import leggauss

P=Path('/mnt/data/pent21_review/input/lines/D-topics/probes/PENT/v2_run/tests/lg_samples/fan_samples.jsonl')
KS=F(3633682907,100000000)

def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def sub(a,b):return (a[0]-b[0],a[1]-b[1])
def integral_dict(a):return sum((v*integral_mon(*k) for k,v in a.items()),F(0))
@functools.lru_cache(None)
def integral_mon(i,j):return F(math.factorial(i)*math.factorial(j),math.factorial(i+j+2))

def poly_add(a,b,fac=1):
 z=dict(a)
 for k,v in b.items():z[k]=z.get(k,F(0))+fac*v
 return {k:v for k,v in z.items() if v}
def scale(a,f):return {k:f*v for k,v in a.items() if v}
def deriv(a,index):
 out={}
 for (i,j),v in a.items():
  k=i if index==0 else j
  if k: out[(i-1,j) if index==0 else (i,j-1)]=k*v
 return out
def multiply(a,b):
 z={}
 for (i,j),v in a.items():
  for (p,q),w in b.items():z[(i+p,j+q)]=z.get((i+p,j+q),F(0))+v*w
 return z
def inner(a,b):return integral_dict(multiply(a,b))
def xpoly(a,axis):return {(p+(axis==0),q+(axis==1)):v for (p,q),v in a.items()}
@functools.lru_cache(None)
def bern_abc(n,i,j,l):
 coeff=F(math.factorial(n),math.factorial(i)*math.factorial(j)*math.factorial(l))
 out={}
 for aa in range(i+1):
  for bb in range(i-aa+1):
   ff=coeff*math.factorial(i)/(math.factorial(aa)*math.factorial(bb)*math.factorial(i-aa-bb))*(-1)**(aa+bb)
   out[(j+aa,l+bb)]=ff
 return out

def free_u_indices(n,k):
 out=[];interior=n-1
 for i in range(n,-1,-1):
  for j in range(n-i,-1,-1):
   l=n-i-j
   if i==0:idx=None
   elif i==n:idx=0
   elif l==0:idx=1+k*(n-1)+(i-1)
   elif j==0:idx=1+((k+1)%5)*(n-1)+(i-1)
   else:
    offset=sum((n-ii-1 for ii in range(1,i)),0)+(j-1)
    idx=1+5*(n-1)+k*(n-1)*(n-2)//2+offset
   if idx is not None:out.append((i,j,l,idx))
 return out

def free_chi_indices(n,k):
 out=[];base=1+5*(n-1);vbase=base;ebase=vbase+5; ibase=ebase+5*(n-1)
 for i in range(n,-1,-1):
  for j in range(n-i,-1,-1):
   l=n-i-j
   if i==n:idx=0
   elif j==n:idx=vbase+k
   elif l==n:idx=vbase+(k+1)%5
   elif l==0 and i>0:idx=1+k*(n-1)+(i-1)
   elif j==0 and i>0:idx=1+((k+1)%5)*(n-1)+(i-1)
   elif i==0:idx=ebase+k*(n-1)+(j-1)
   else:
    offset=sum((n-ii-1 for ii in range(1,i)),0)+(j-1)
    idx=ibase+k*(n-1)*(n-2)//2+offset
   out.append((i,j,l,idx))
 return out

def convex(v):
 return all(cross(sub(v[(i+1)%len(v)],v[i]),sub(v[(i+2)%len(v)],v[(i+1)%len(v)]))>0 for i in range(len(v)))
def contains_polygon(vouter,vinner):
 return all(cross(sub(vouter[(i+1)%len(vouter)],vouter[i]),sub(p,vouter[i]))>=0 for p in vinner for i in range(len(vouter)))

def qdata(n):
 t,wt=leggauss(n);t=(t+1)/2;wt=wt/2
 aa,tt=np.meshgrid(t,t,indexing='ij');a=aa.ravel();b=((1-aa)*tt).ravel();q=(wt[:,None]*wt[None,:]*(1-aa)).ravel()
 return a,b,q

def polyval(p,a,b):
 z=np.zeros_like(a)
 for (i,j),v in p.items():z+=float(v)*a**i*b**j
 return z

def optimize_flux(uh,tri_geometries,n,ndim,precision=26):
 a,b,weight=qdata(max(11,n+2));N=len(a)
 G=np.zeros((ndim,ndim));rhs=np.zeros(ndim)
 for k,(det,M,Nmat) in enumerate(tri_geometries):
  d=np.zeros((N,ndim,2))
  for i,j,l,idx in free_chi_indices(n,k):
   B=bern_abc(n,i,j,l)
   d[:,idx,0]+=polyval(deriv(B,1),a,b)
   d[:,idx,1]-=polyval(deriv(B,0),a,b)
  rr=-float(det)*np.stack([a,b],axis=1)*polyval(uh[k],a,b)[:,None]
  rN=rr@np.array(Nmat,dtype=float)
  rhs+=np.einsum('ni,nki,n->k',rN,d,weight)
  G+=np.einsum('nki,ij,nlj,n->kl',d,np.array(Nmat,dtype=float),d,weight)
 # eliminate constant gauge at center
 sol=np.zeros(ndim)
 try:sol[1:]=np.linalg.solve(G[1:,1:],-rhs[1:])
 except np.linalg.LinAlgError as ex:
  print('bad chi solve',ex,flush=True);return None
 scale_int=2**precision
 return [F(int(round(x*scale_int)),scale_int) for x in sol]

def rectangle_nu(vertices):
  pi2=F(98696044,10000000)  # 9.8696044 < pi^2
  dirs=[(F(1),F(0)),(F(0),F(1))]
  for k in range(len(vertices)):
   e=sub(vertices[(k+1)%len(vertices)],vertices[k])
   dirs.append(e)
  best=F(0)
  for dx,dy in dirs:
   L2=dx*dx+dy*dy
   p=[x*dx+y*dy for x,y in vertices]
   q=[-x*dy+y*dx for x,y in vertices]
   a2=(max(p)-min(p))**2/L2
   b2=(max(q)-min(q))**2/L2
   if a2 and b2:best=max(best,pi2*min(4/a2+1/b2,1/a2+4/b2))
  return best

def check(record,do_optimise=True):
 v=record['lg'];N=int(v['N']);n=int(v['n'])
 coordc=tuple(F(x) for x in v['c']);s=F(v['s'])
 V=[tuple(F.from_float(float(t)) for t in row) for row in record['V']]
 Vf=[tuple((x-coordc[i])/s for i,x in enumerate(row)) for row in V]
 UP=[tuple(F(x) for x in row) for row in v['Uplus']];O=tuple(F(x) for x in v['O'])
 if not convex(Vf) or not convex(UP) or not contains_polygon(UP,Vf) or not contains_polygon(UP,[O]):return {'pass':False,'why':'geometry'}
 areaP=sum((cross(V[i],V[(i+1)%5]) for i in range(5)),F(0))/2
 areaf=sum((cross(UP[i],UP[(i+1)%5]) for i in range(5)),F(0))/2
 if areaP<=0 or areaf<=0: return {'pass':False,'why':'area'}
 ucoeff=v['u'];needed_u=1+5*(N-1)+5*(N-1)*(N-2)//2
 if len(ucoeff)!=needed_u:return {'pass':False,'why':'u length'}
 chiN=1+5*(n-1)+5+5*(n-1)+5*(n-1)*(n-2)//2
 un=[];hun=[];trip=[];Pmat=[]
 for k in range(5):
  e1=sub(UP[k],O);e2=sub(UP[(k+1)%5],O);det=cross(e1,e2)
  if det<=0:return {'pass':False,'why':'det'}
  n11=sum(x*x for x in e1);n12=sum(x*y for x,y in zip(e1,e2));n22=sum(x*x for x in e2)
  M=((n22/det,-n12/det),(-n12/det,n11/det)); Nt=((n11/det,n12/det),(n12/det,n22/det))
  pol={}
  for i,j,l,idx in free_u_indices(N,k):
   pol=poly_add(pol,bern_abc(N,i,j,l),F(ucoeff[idx],2**30))
  hp={q:vv/F(sum(q)+2) for q,vv in pol.items()}
  un.append(pol);hun.append(hp);trip.append((det,M,Nt));Pmat.append((det,n11,n12,n22))
 if do_optimise and not ('x' in v and 'xe' in v):
  cchi=optimize_flux(hun,trip,n,chiN)
  if cchi is None:return {'pass':False,'why':'chi optimization'}
 elif 'x' in v:
  cchi=[F(t)*F(2)**int(v['xe']) for t in v['x']]
 else:cchi=[F(0)]*chiN
 A0=A1=A2=F(0)
 for k,(det,M,Nt) in enumerate(trip):
  uu=un[k];hh=hun[k]
  chic={}
  for i,j,l,idx in free_chi_indices(n,k):
   if cchi[idx]:chic=poly_add(chic,bern_abc(n,i,j,l),cchi[idx])
  ua=deriv(uu,0);ub=deriv(uu,1)
  cha=deriv(chic,0);chb=deriv(chic,1)
  rr0=poly_add(scale(xpoly(hh,0),-det),chb)
  rr1=poly_add(scale(xpoly(hh,1),-det),cha,-1)
  A1+=det*inner(uu,uu)
  A0+=M[0][0]*inner(ua,ua)+2*M[0][1]*inner(ua,ub)+M[1][1]*inner(ub,ub)
  A2+=Nt[0][0]*inner(rr0,rr0)+2*Nt[0][1]*inner(rr0,rr1)+Nt[1][1]*inner(rr1,rr1)
 nu=max(KS/areaf,rectangle_nu(UP))
 D=A0-nu*A1
 if D>=0:return {'pass':False,'why':'LG hypothesis','D':float(D)}
 G=A0-2*nu*A1+nu*nu*A2
 Fnew=nu*(-D)/(G-D)*areaP/s**2
 claim=F.from_float(float(v['F_lo']))
 return {'pass':Fnew>=claim,'F_independent':float(Fnew),'claimed_F_lo':float(claim),'slack':float(Fnew-claim),'N':N,'n':n,'F0_Ritz':float(A0/A1*areaP/s**2),'D':float(D),'A0':float(A0),'A1':float(A1),'A2':float(A2),'flux_optimised':do_optimise and 'x' not in v}

if __name__=='__main__':
 t=time.monotonic();res=[]
 with open(P) as f:
  for j,line in enumerate(f):
   if not line.strip():continue
   if len(sys.argv)>2 and j<int(sys.argv[2]):continue
   ans=check(json.loads(line));ans['index']=j;ans['sec_since_start']=time.monotonic()-t
   res.append(ans)
   print(j,ans,flush=True)
   if len(sys.argv)>1 and len(res)>=int(sys.argv[1]):break
 print('total',len(res),'PASS',sum(x['pass'] for x in res),'elapsed',time.monotonic()-t)
 Path('/mnt/data/pent21_review/independent/fan_lg_result.json').write_text(json.dumps(res,indent=2))

```

## `fan_tamper.py`

```python
import copy,json
from fan_lg_checker import P,check
v=json.loads(open(P).readline());a=check(v)
assert a['pass']
w=copy.deepcopy(v);w['lg']['F_lo']+=.01;z=check(w);assert not z['pass']
print('TAMPERED_CLAIM',z['pass'],z['slack'])
w=copy.deepcopy(v);w['lg']['Uplus'][1]=w['lg']['Uplus'][0];z=check(w);assert not z['pass'];print('TAMPERED_GEOMETRY',z['pass'],z['why'])
w=copy.deepcopy(v);w['lg']['u'][0]=0;z=check(w);assert not z['pass'];print('TAMPERED_U',z['pass'],z.get('why'),z.get('slack'))

```

## `fe_hessian_counterexample.py`

```python
#!/usr/bin/env python3
"""Independent piecewise-linear finite element eigenvalue probe for Theorem L.
Only a NONRIGOROUS numerical falsification test; never imports producer scripts.
Fixed fan topology, physical triangles obtained via mapping from chart pentagon.
"""
import math,time,json,sys
from pathlib import Path
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import eigsh

def regular():
 v=[np.array([0.,0.]),np.array([1.,0.])]
 for j in range(1,4):v.append(v[-1]+np.array([math.cos(2*math.pi*j/5),math.sin(2*math.pi*j/5)]))
 return np.array(v)
V0=regular(); c=V0[2:].ravel(); O=np.mean(V0,axis=0)

class FanFE:
 def __init__(self,N):
  self.N=N;nd={}; bary=[];tris=[]
  def node(k,i,j):
   if i+j==0:key=('o',)
   elif j==0:key=('r',k,i)
   elif i==0:key=('r',(k+1)%5,j)
   else:key=('t',k,i,j)
   if key not in nd:
    nd[key]=len(nd)
    q=np.zeros(5);q[k]+=i/N;q[(k+1)%5]+=j/N
    bary.append(q)
   return nd[key]
  for k in range(5):
   for i in range(N):
    for j in range(N-i):
     tris.append((node(k,i,j),node(k,i+1,j),node(k,i,j+1)))
     if i+j<N-1:tris.append((node(k,i+1,j),node(k,i+1,j+1),node(k,i,j+1)))
  self.tris=np.asarray(tris,dtype=np.int64)
  self.bary=np.asarray(bary)
  self.inner=np.where(np.max(self.bary,axis=1)<1-1e-12)[0]
  # some points with beta+gamma==1 should be boundary despite largest q<1, use sum q=1
  self.inner=np.where(np.sum(self.bary,axis=1)<1-1e-12)[0]
  self.ri=np.repeat(self.tris,3,axis=1).ravel()
  self.ci=np.tile(self.tris,(1,3)).ravel()
  self.size=len(self.bary)
  print('mesh N',N,'nodes',self.size,'free',len(self.inner),'elements',len(self.tris),flush=True)
 def eigen(self,z,return_vec=False):
  V=np.concatenate([V0[:2],np.array(z).reshape(3,2)])
  pts=self.bary@V+(1-np.sum(self.bary,axis=1))[:,None]*O
  t=pts[self.tris]
  x=t[:,:,0];y=t[:,:,1]
  det=(x[:,1]-x[:,0])*(y[:,2]-y[:,0])-(x[:,2]-x[:,0])*(y[:,1]-y[:,0])
  if np.min(det)<=0:raise ValueError(f'bad triangle det {np.min(det)}')
  bet=np.stack([y[:,1]-y[:,2],y[:,2]-y[:,0],y[:,0]-y[:,1]],axis=1)
  gam=np.stack([x[:,2]-x[:,1],x[:,0]-x[:,2],x[:,1]-x[:,0]],axis=1)
  K=(bet[:,:,None]*bet[:,None,:]+gam[:,:,None]*gam[:,None,:])/(2*det[:,None,None])
  Mass=((np.ones((3,3))+np.eye(3))[None,:,:]*det[:,None,None]/24)
  K=coo_matrix((K.ravel(),(self.ri,self.ci)),shape=(self.size,self.size)).tocsr()[self.inner,:][:,self.inner]
  Mass=coo_matrix((Mass.ravel(),(self.ri,self.ci)),shape=(self.size,self.size)).tocsr()[self.inner,:][:,self.inner]
  lam,vec=eigsh(K,k=1,M=Mass,sigma=0.,which='LM',tol=2e-11)
  area=.5*sum(np.cross(V[i],V[(i+1)%5]) for i in range(5))
  F=lam[0]*area
  return (F,vec[:,0]) if return_vec else F

def hessian(fe,h):
 zero=fe.eigen(c);n=6;g=np.zeros(n);H=np.zeros((n,n)); fs={}
 for i in range(6):
  v=np.eye(6)[i]*h; p=fe.eigen(c+v);m=fe.eigen(c-v);fs[(i,1)]=p;fs[(i,-1)]=m
  g[i]=(p-m)/(2*h);H[i,i]=(p+m-2*zero)/h**2
 for i in range(6):
  for j in range(i+1,6):
   vi=np.eye(6)[i]*h; vj=np.eye(6)[j]*h
   zz=(fe.eigen(c+vi+vj)-fe.eigen(c+vi-vj)-fe.eigen(c-vi+vj)+fe.eigen(c-vi-vj))/(4*h*h)
   H[i,j]=H[j,i]=zz
 w,vec=np.linalg.eigh(H)
 return zero,g,H,w,vec

def search(fe,w,vec,F0,nrandom=300,seed=20261117):
 rng=np.random.default_rng(seed)
 trials=[]
 for i in range(2):
  for radius in [0.001,0.003,0.005,0.01,0.025,0.049]:
   for sign in [-1,1]:trials.append((f'weak{i}_{radius}_{sign}',sign*radius*vec[:,i]))
 for j in range(nrandom):
  d=rng.standard_normal(6);d/=np.linalg.norm(d)
  radius=np.exp(rng.uniform(math.log(.001),math.log(.0495)))
  trials.append((f'random_{j}',d*radius))
 best=(1e50,None,None); bad=[]
 for name,d in trials:
  F=fe.eigen(c+d)
  r2=d@d;coef=(F-F0)/r2
  if coef<best[0]:best=(coef,name,float(np.sqrt(r2)))
  if coef<.2:bad.append((name,float(np.sqrt(r2)),F,coef))
 return best,bad,len(trials)

if __name__=='__main__':
 start=time.monotonic();data=[]
 for N,h in [(12,0.004),(20,.004),(28,.004)]:
  fe=FanFE(N)
  t=time.monotonic();F0,g,H,eigs,vec=hessian(fe,h)
  print('HESSIAN',N,'h',h,'F0',F0,'gradmax',np.max(abs(g)),'six eigs',eigs,'sec',time.monotonic()-t,flush=True)
  data.append({'N':N,'F0':float(F0),'gradmax':float(np.max(abs(g))),'H_eigs':eigs.tolist(),'H':H.tolist(),'sec':time.monotonic()-t})
  if N==28:
   best,bad,nt=search(fe,eigs,vec,F0,150)
   print('SEARCH',nt,'best curvature ratio',best,'bad count',len(bad),'bad examples',bad[:5],flush=True)
   data[-1].update({'search_trials':nt,'search_best':best,'search_bad':bad})
 print('total elapsed',time.monotonic()-start)
 Path('/mnt/data/pent21_review/independent/fe_results.json').write_text(json.dumps(data,indent=2))

```

## `fe_refine.py`

```python
import json,time
import numpy as np
from pathlib import Path
from fe_hessian_counterexample import FanFE,hessian,search
s=[]
for n,h in ((44,.003),(72,.003)):
 st=time.perf_counter();fe=FanFE(n)
 f,g,H,ev,vec=hessian(fe,h)
 print('REFINED',n,'F0',f,'H eigenvalues',ev,'gradmax',np.max(abs(g)),'secs',time.perf_counter()-st,flush=True)
 s.append({'N':n,'F0':f,'eigenvalues':ev.tolist(),'gradmax':float(np.max(abs(g))),'H':H.tolist(),'sec':time.perf_counter()-st})
 if n==44:
  best,bad,ntrial=search(fe,ev,vec,f,800)
  print('PROBE',best,'N trials',ntrial,'bad',len(bad),flush=True)
  s[-1].update({'search_best':best,'search_trials':ntrial,'search_bad':bad})
Path('/mnt/data/pent21_review/independent/fe_refined.json').write_text(json.dumps(s,indent=2))

```

## `fe_weak72.py`

```python
import json
from pathlib import Path
import numpy as np
from fe_hessian_counterexample import FanFE,c
p=Path('/mnt/data/pent21_review/independent/fe_refined.json');z=json.loads(p.read_text())[-1]
H=np.array(z['H']);evals,ev=np.linalg.eigh(H)
fe=FanFE(72);F0=fe.eigen(c)
rows=[]
for k in (0,1):
 for rr in (0.001,0.003,0.005,0.01,0.025,0.049):
  for sign in (-1,1):
   F=fe.eigen(c+sign*rr*ev[:,k]);coef=(F-F0)/rr**2
   rows.append({'weak':k,'radius':rr,'sign':sign,'F_FE':F,'quotient':coef})
   print(k,rr,sign,'quotient',coef,flush=True)
print('min ratio',min(r['quotient'] for r in rows))
Path('/mnt/data/pent21_review/independent/fe_weak72.json').write_text(json.dumps(rows,indent=2))

```

## `lgbox_interval_demo.py`

```python
#!/usr/bin/env python3
"""Independent rigorous 6D box Lehmann-Goerisch example using exact rational intervals.
This is not a replay of producer's near-cover; it certifies one user-specified
sample box with a new fixed trial family, without polynomial-producer code.
"""
import json,sys,time
from fractions import Fraction as F
from pathlib import Path
from fan_lg_checker import *

class IV:
 def __init__(self,l,h=None):
  if isinstance(l,IV):self.lo=l.lo;self.hi=l.hi;return
  self.lo=F(l);self.hi=F(h) if h is not None else F(l)
  assert self.lo<=self.hi
 def __add__(self,b):
  b=IV(b);return IV(self.lo+b.lo,self.hi+b.hi)
 __radd__=__add__
 def __neg__(self):return IV(-self.hi,-self.lo)
 def __sub__(self,b):return self+-IV(b)
 def __rsub__(self,b):return IV(b)+-self
 def __mul__(self,b):
  b=IV(b); v=[a*c for a in [self.lo,self.hi] for c in [b.lo,b.hi]];return IV(min(v),max(v))
 __rmul__=__mul__
 def __truediv__(self,b):
  b=IV(b)
  if b.lo<=0<=b.hi:raise ZeroDivisionError('unproved positive denominator')
  return self*IV(1/b.hi,1/b.lo)
 def __repr__(self):return f'[{float(self.lo):.12g},{float(self.hi):.12g}]'

def loc_iu(p,q):return inner(p,q)

def run(k=0,rho=F(1,2**28)):
 raw=json.loads(open(P).readline())['lg']
 uN=int(raw['N']);n=int(raw['n']);nc=1+5*(n-1)+5+5*(n-1)+5*(n-1)*(n-2)//2
 UP=[tuple(F(x) for x in row) for row in raw['Uplus']]; O=tuple(F(x) for x in raw['O'])
 polys=[];hs=[];geo=[]
 for i in range(5):
  e1=sub(UP[i],O);e2=sub(UP[(i+1)%5],O);det=cross(e1,e2)
  n11=sum(x*x for x in e1);n12=sum(x*y for x,y in zip(e1,e2));n22=sum(x*x for x in e2)
  geo.append((det,((n22/det,-n12/det),(-n12/det,n11/det)),((n11/det,n12/det),(n12/det,n22/det))))
  u={}
  for a,b,c,idx in free_u_indices(uN,i):u=poly_add(u,bern_abc(uN,a,b,c),F(raw['u'][idx],2**30))
  h={key:v/F(sum(key)+2) for key,v in u.items()}
  polys.append(u);hs.append(h)
 cc=optimize_flux(hs,geo,n,nc)
 arrays=[]
 for i in range(5):
  chi={}
  for a,b,c,idx in free_chi_indices(n,i):
   if cc[idx]:chi=poly_add(chi,bern_abc(n,a,b,c),cc[idx])
  u=polys[i];h=hs[i];ua,ub=deriv(u,0),deriv(u,1);ca,cb=deriv(chi,0),deriv(chi,1)
  ah=xpoly(h,0);bh=xpoly(h,1)
  arrays.append(dict(Iuu=inner(u,u),Iaa=inner(ua,ua),Iab=inner(ua,ub),Ibb=inner(ub,ub),
     Saa=inner(ah,ah),Sab=inner(ah,bh),Sbb=inner(bh,bh),
     Scaa=inner(ah,ca),Scbb=inner(bh,cb),Scab=inner(ah,cb),Scba=inner(bh,ca),
     Raa=inner(ca,ca),Rab=inner(ca,cb),Rbb=inner(cb,cb)))
 def certify(boxrad):
  VV=[tuple(IV(x if i<2 else x-boxrad, x if i<2 else x+boxrad) for x in UP[i]) for i in range(5)]
  dA=IV(0);A0=A1=A2=IV(0)
  for i in range(5):
   e1=(VV[i][0]-O[0],VV[i][1]-O[1]);e2=(VV[(i+1)%5][0]-O[0],VV[(i+1)%5][1]-O[1])
   det=e1[0]*e2[1]-e1[1]*e2[0]
   if det.lo<=0:return {'pass':False,'reason':'det','det':str(det)}
   n11=e1[0]*e1[0]+e1[1]*e1[1];n12=e1[0]*e2[0]+e1[1]*e2[1];n22=e2[0]*e2[0]+e2[1]*e2[1]
   a=arrays[i]
   A1+=det*a['Iuu']
   A0+=(n22*a['Iaa']-2*n12*a['Iab']+n11*a['Ibb'])/det
   sa=det*det*a['Saa']-2*det*a['Scab']+a['Rbb']
   sb=det*det*a['Sab']+det*a['Scaa']-det*a['Scbb']-a['Rab']
   sc=det*det*a['Sbb']+2*det*a['Scba']+a['Raa']
   A2+=(n11*sa+2*n12*sb+n22*sc)/det
   dA+=det/2
  dc=KS*A1-dA*A0
  c=dA*dc-F.from_float(18.919134195733914)*(KS*A2-dA*A1)
  return {'pass':dc.lo>0 and c.lo>0,'rho':str(boxrad),'Dc':repr(dc),'C':repr(c),'F_margin_from_LG':float(c.lo/(KS*A2-dA*A1).hi) if (KS*A2-dA*A1).lo>0 else None}
 st=time.perf_counter()
 res=[]
 for r in [F(0),F(1,100),F(1,1000),F(1,10000),F(1,2**20),F(1,2**28)]:
  v=certify(r);res.append(v);print(v,flush=True)
 print('elapsed seconds',time.perf_counter()-st)
 Path('/mnt/data/pent21_review/independent/lgbox_result.json').write_text(json.dumps(res,indent=2))
if __name__=='__main__':run()

```

## `local_coefficient_verifier.py`

```python
#!/usr/bin/env python3
"""Independent exact rational checker for a FROZEN Theorem L polynomial witness.
Consumes monomial coefficient centers and nonnegative radii (degree >=2), never
producer source. This package does not supply the required arrays, so only
synthetic self-tests can run; NEVER reports real 0.3199 from missing inputs.

Expected witness JSON:
 {"Tm":{"0,0,2,0,0,0":"1/2",...},"Em":{same: "1/100"},
  "rho_in":"1/128"}
"""
import json,itertools,math,sys
from fractions import Fraction as F
from pathlib import Path
N=6

def parse_map(d):
 return {tuple(map(int,key.split(','))):F(v) for key,v in d.items()}

def trace(Tm,Em,rho):
 assert all(len(k)==N and sum(k)>=2 for k in Tm|Em)
 H=[[F(0)]*N for _ in range(N)]
 T=[[[F(0)]*N for _ in range(N)] for _ in range(N)]
 Err=[[F(0)]*N for _ in range(N)]
 for k,v in Tm.items():
  if sum(k)==2:
   ix=[i for i,p in enumerate(k) for j in range(p)]
   if ix[0]==ix[1]:H[ix[0]][ix[0]]+=2*v
   else:H[ix[0]][ix[1]]+=v;H[ix[1]][ix[0]]+=v
  if sum(k)==3:
   ix=[i for i,p in enumerate(k) for j in range(p)]
   cnt=len(set(itertools.permutations(ix)))
   for inds in set(itertools.permutations(ix)):
    T[inds[0]][inds[1]][inds[2]]+=v/cnt
 for k,v in Em.items():
  assert v>=0
  if sum(k)==2:
   ix=[i for i,p in enumerate(k) for j in range(p)]
   if ix[0]==ix[1]:Err[ix[0]][ix[0]]+=v
   else:Err[ix[0]][ix[1]]+=v/2;Err[ix[1]][ix[0]]+=v/2
 tau2=max(sum(Err[i]) for i in range(N))
 tau3=sum(v*rho*(F(1) if len([x for x in k if x])==1 else F(1,2)) for k,v in Em.items() if sum(k)==3)
 tau4=sum((abs(Tm.get(k,F(0)))+Em.get(k,F(0)))*rho**(sum(k)-2)*(F(1) if sum(bool(x) for x in k)==1 else F(1,2)) for k in (Tm|Em) if sum(k)>=4)
 tau=tau2+tau3+tau4
 minpivot=None
 for signs in itertools.product((-1,1),repeat=N):
  d=[s*rho for s in signs]
  Q=[[H[i][j]/2+sum(d[k]*T[k][i][j] for k in range(N))-(tau if i==j else 0) for j in range(N)] for i in range(N)]
  # exact fraction LDL pivots
  L=[[F(0)]*N for _ in range(N)];piv=[]
  for i in range(N):
   di=Q[i][i]-sum(L[i][k]**2*piv[k] for k in range(i))
   if di<=0:return {'passed':False,'failing_vertex':signs,'pivot_index':i,'pivot':str(di),'tau':str(tau)}
   piv.append(di);L[i][i]=1
   for j in range(i+1,N):L[j][i]=(Q[j][i]-sum(L[j][k]*L[i][k]*piv[k] for k in range(i)))/di
  vmin=min(piv)
  minpivot=vmin if minpivot is None else min(minpivot,vmin)
 return {'passed':True,'vertex_count':64,'tau2':str(tau2),'tau3':str(tau3),'tau_ge4':str(tau4),'tau':str(tau),'minimum_pivot':str(minpivot),'minimum_pivot_float':float(minpivot)}

def selftest():
 x={};e={}
 def key(*x):return ','.join(map(str,x))
 for i in range(6):
  v=[0]*6;v[i]=2;x[key(*v)]=str(F(i+1,2));e[key(*v)]=str(F(1,1000))
 v=[0]*6;v[0]=3;x[key(*v)]=str(F(1,10))
 v=[0]*6;v[0]=2;v[1]=2;x[key(*v)]=str(F(1,2**12))
 out=trace(parse_map(x),parse_map(e),F(1,128))
 print('POSITIVE WITNESS',out)
 assert out['passed']
 x[key(0,0,0,0,0,2)]='-2'
 out2=trace(parse_map(x),parse_map(e),F(1,128))
 print('TAMPERED WITNESS',out2)
 assert not out2['passed']
 return out
if __name__=='__main__':
 if len(sys.argv)>1:
  v=json.load(open(sys.argv[1]));print(trace(parse_map(v['Tm']),parse_map(v['Em']),F(v.get('rho_in','1/128'))))
 else: selftest()

```

## `proposition_r_quadrature.py`

```python
#!/usr/bin/env python3
"""Independent quadrature validation of Proposition R on a manufactured triangle.
The exact true pair is zero, the computed pair is the polynomial error pair.
Hence this is a nontrivial check of both integration-by-parts cancellations and
of the signs/coefficient structure, without any producer Gram tables.
"""
import json
import numpy as np
from numpy.polynomial.legendre import leggauss
from pathlib import Path

def gauss_triangle(n):
 x,wx=leggauss(n);t=(x+1)/2;w=wx/2
 aa,tt=np.meshgrid(t,t,indexing='ij')
 a=aa.ravel();b=((1-aa)*tt).ravel()
 weight=(w[:,None]*w[None,:]*(1-aa)).ravel()
 return a,b,weight

def quantities(a,b,E1,E2):
 det=np.linalg.det(np.stack([E1,E2],axis=1))
 n11=E1@E1;n12=E1@E2;n22=E2@E2
 M=np.array([[n22,-n12],[-n12,n11]])/det
 N=np.array([[n11,n12],[n12,n22]])/det
 return det,M,N

def run(n=13):
 a,b,weight=gauss_triangle(n)
 ee=a*b*(1-a-b)
 eh=a*b/4-(a*a*b+a*b*b)/5
 grad=np.stack((b*(1-2*a-b),a*(1-a-2*b)),axis=1)
 # nontrivial curl from polynomial chi=a*b*(1-a-b)+0.07 a*b
 dchi_a=grad[:,0]+0.07*b
 dchi_b=grad[:,1]+0.07*a
 rot=np.stack((dchi_b,-dchi_a),axis=1)
 ab=np.stack((a,b),axis=1)
 print('test e not identically zero, ||grad e||^2',np.dot(weight,np.sum(grad*grad,axis=1)))
 d0,Mc,Nc=quantities(a,b,np.array([.7,.1]),np.array([-.1,1.0]))
 dz,Mz,Nz=quantities(a,b,np.array([.65,.15]),np.array([-.25,.9]))
 P0=d0/2;P=dz/2;F0=18.91910384;lam0=F0/P0;lamhat=F0/P;kappa=36.33682907
 sc=rot-d0*ab*eh[:,None]
 sz=rot-dz*ab*eh[:,None]
 rhoc=sc@Nc.T-grad/lam0
 rhoz=sz@Nz.T-grad/lamhat
 # tensors are row vectors: M*gradient etc.
 t0=(rhoc+grad/lam0)@Mc.T
 tz=t0-(dz-d0)*ab*eh[:,None]
 assert np.max(abs(tz-sz))<2e-15
 tp=grad@Mc.T/lam0-(dz-d0)*ab*eh[:,None]
 rconst=rhoc@Mc.T
 def dot(x,y):return np.dot(weight,np.sum(x*y,axis=1))
 def bform(f,g):return dz*np.dot(weight,f*g)
 def aform(f,g):return dot(f@Mz.T,g)
 def cform(f,g):return dot(f@Nz.T,g)
 def B(v,s):return P*(kappa+F0)*bform(v,v)-P**2*aform(grad,grad)-F0*kappa*cform(s,s)
 Psi_tilde=B(ee,sz)
 # true pair v=0, s=0, so Psi must vanish exactly
 Psi_true=0
 K=Psi_tilde+2*F0*kappa*dot(rhoz,rconst)-F0*kappa*cform(rconst,rconst)
 Lam=2*F0*((kappa/lam0)*(rhoz@Mc.T)-P*(rhoz@Mz.T)-(kappa/lam0)*(rconst@Nz.T@Mc.T))
 Theta=-2*F0*kappa*(dz-d0)*(rhoz-rconst@Nz.T)
 q=P*(kappa+F0)*bform(ee,ee)-P**2*aform(grad,grad)-F0*kappa*cform(tp,tp)
 sumrhs=K+dot(grad,Lam)+dot(eh[:,None]*ab,Theta)+q
 # inspect cancellation explicitly using two IP identities
 ip_s=dot(sz,grad); ip_t=dot(tz,grad)
 mass=bform(ee,ee)
 cross=P*(kappa+F0)*mass-P**2*aform(grad,grad)-F0*kappa*cform(sz,tz)
 simplified=F0*P*dot(rhoz,grad@Mz.T)-F0*kappa*dot(rhoz,tz)
 print('z det',dz,'c det',d0)
 print('IP(s), IP(t), mass',ip_s,ip_t,mass,'absolute errors',abs(ip_s-mass),abs(ip_t-mass))
 print('cross term',cross,'simplified',simplified,'diff',cross-simplified)
 print('K',K,'Lgrad',dot(grad,Lam),'Lray',dot(eh[:,None]*ab,Theta),'q',q)
 print('Psi true vs residual expression',Psi_true,sumrhs,'abs error',abs(sumrhs))
 result={'quad_n':n,'ip_s_error':float(abs(ip_s-mass)),'ip_t_error':float(abs(ip_t-mass)),'cross_error':float(abs(cross-simplified)),'residual_identity_error':float(abs(sumrhs)),'K':float(K),'linear_gradient':float(dot(grad,Lam)),'linear_ray':float(dot(eh[:,None]*ab,Theta)),'q':float(q)}
 return result
if __name__=='__main__':
 data=[run(n) for n in [10,15,23]]
 Path('/mnt/data/pent21_review/independent/prop_r_results.json').write_text(json.dumps(data,indent=2))

```

## `symmetry_and_leaves.py`

```python
#!/usr/bin/env python3
"""Independent symmetry differential and exact leaf geometry audit.
No imports or executions of producer code."""
import sys, json, hashlib, lzma, itertools, math, time
from pathlib import Path
from fractions import Fraction
import mpmath as mp
import numpy as np
mp.mp.dps=100
root=Path('/mnt/data/pent21_review/input/lines/D-topics/probes/PENT')
out=Path('/mnt/data/pent21_review/independent')
pi=mp.pi
# regular pentagon from unit edge, exterior turn 72 degrees
w=[mp.mpc(0),mp.mpc(1)]
for j in range(1,4): w.append(w[-1]+mp.e**(2*mp.pi*mp.j*j/5))
c=mp.matrix([a for k in (2,3,4) for a in (mp.re(w[k]),mp.im(w[k]))])
print('regular chart c=',[mp.nstr(x,30) for x in c]);print('closure residual',mp.nstr(abs(w[4]+mp.e**(8*mp.pi*mp.j/5)),15))
# exact derivative via quotient rule, with reversed orientation uses conjugation to preserve chirality
I=mp.j
b=[[] for j in range(5)]
for i in range(6):
  v=[mp.mpc(0)]*5
  v[2+i//2]=1 if i%2==0 else I
  b[0].append(v)

def phi_deriv(j,s):
  W=w
  den=W[(j+s)%5]-W[j]
  out=[]; cols=[]
  for k in [2,3,4]:
    num=W[(j+s*k)%5]-W[j]
    t=num/den
    if s==-1:t=mp.conj(t)
    out.extend([mp.re(t),mp.im(t)])
    cols.append(t)
  D=mp.matrix(6,6)
  for i in range(6):
    dw=[mp.mpc(0)]*5
    dw[2+i//2]=1 if i%2==0 else mp.j
    dden=dw[(j+s)%5]-dw[j]
    for idx,k in enumerate([2,3,4]):
      num=W[(j+s*k)%5]-W[j]
      dnum=dw[(j+s*k)%5]-dw[j]
      v=(dnum*den-num*dden)/(den*den)
      if s==-1:v=mp.conj(v)
      D[2*idx,i]=mp.re(v);D[2*idx+1,i]=mp.im(v)
  return out,D
M=mp.matrix(6,6); matrices={}
for s in (1,-1):
 for j in range(5):
  image,D=phi_deriv(j,s)
  diff=max(abs(image[i]-c[i]) for i in range(6))
  print('D5 g',j,s,'fixed-point diff',mp.nstr(diff,4),'trace',mp.nstr(sum(D[i,i] for i in range(6)),14))
  for i in range(6):
   for k in range(6):M[i,k]+=D[i,k]/10
  matrices[f'{j},{s}']=[[mp.nstr(D[i,k],65) for k in range(6)] for i in range(6)]
print('M abs max',mp.nstr(max(abs(M[i,j]) for i in range(6) for j in range(6)),20))
print('M Frobenius norm',mp.nstr(mp.sqrt(sum(M[i,j]**2 for i in range(6) for j in range(6))),20))
print('id matrix squared err',mp.nstr(max(abs((M*M)[i,j]-M[i,j]) for i in range(6) for j in range(6)),20))
# Verify D(g) group closure to numeric tolerance
Dlist=[mp.matrix([[mp.mpf(x) for x in r] for r in val]) for val in matrices.values()]
maxclosure=mp.mpf(0)
for a in Dlist:
 for b0 in Dlist:
  cand=a*b0
  d0=min(max(abs(cand[i,j]-D[i,j]) for i in range(6) for j in range(6)) for D in Dlist)
  maxclosure=max(maxclosure,d0)
print('max group matrix closure err=',mp.nstr(maxclosure,20))
# Fraction volume, bounds checks
p=root/'local_run_20261117/leaves.txt.xz'
actual_sha=hashlib.sha256(lzma.open(p,'rb').read()).hexdigest()
raw=lzma.open(p,'rt').read().splitlines()
leaves=[]
for line in raw:
 try:
  a=[Fraction.from_float(float.fromhex(v)) for v in line.split()]
  assert len(a)==12
  leaves.append(([a[i]-a[6+i] for i in range(6)],[a[i]+a[6+i] for i in range(6)]))
 except Exception as ex:print('BAD LEAF',line[:100],ex);sys.exit(3)
W=Fraction(13,256); rho=Fraction(1,128);R=Fraction(52429,2**20)
total=sum((math.prod(y-x for x,y in zip(lo,hi)) for lo,hi in leaves),Fraction(0))
root_volume=(2*W)**5*W
within=all(all(-W<=lo[i]<hi[i]<=W if i!=2 else 0<=lo[i]<hi[i]<=W for i in range(6)) for lo,hi in leaves)
print('leaf_sha',actual_sha,'nleaf',len(leaves),'within half cube',within,'volume ratio',total/root_volume,'L∞ outlier',min(x for L,H in leaves for x in L))
# pairwise positive overlap x0 swept without using any producer methods
order=sorted(range(len(leaves)),key=lambda j:leaves[j][0][0]); active=[];paircount=0;overlap=None
for t,idx in enumerate(order):
 lo,hi=leaves[idx]; active=[a for a in active if leaves[a][1][0]>lo[0]]
 for other in active:
  paircount+=1
  a,b=leaves[other]
  if all(min(hi[d],b[d])>max(lo[d],a[d]) for d in range(1,6)):
   overlap=(idx,other);break
 if overlap:break
 active.append(idx)
print('pair candidates',paircount,'interior overlap',overlap)
# check leaf categorisation from geometry: full inner, full outside ball, remaining polynomial-claimed
inner=sum(all(max(abs(lo[j]),abs(hi[j]))<=rho for j in range(6)) for lo,hi in leaves)
outside=sum(sum((Fraction(0) if lo[j]<=0<=hi[j] else min(lo[j]**2,hi[j]**2)) for j in range(6))>=R*R for lo,hi in leaves)
print('inner geometry',inner,'outside geometry',outside,'remaining',len(leaves)-inner-outside)
(out/'geometry_symmetry.json').write_text(json.dumps({'M_max':str(max(abs(M[i,j]) for i in range(6) for j in range(6))),'closure_err':str(maxclosure),'leaf_sha':actual_sha,'nleaves':len(leaves),'volume_ratio':str(total/root_volume),'within':within,'overlap':overlap,'inner':inner,'outside':outside,'pair_candidates':paircount,'c':[mp.nstr(x,60) for x in c]},indent=2))

```

## `tv_bp_independent.py`

```python
#!/usr/bin/env python3
"""Independent rational tests of the TV Loewner identity and 6D BP
Bernstein coefficients without reading or executing producer algorithms."""
from fractions import Fraction as F
import itertools,random,math,json
from pathlib import Path
rng=random.Random(20261117)

# TV: exact symmetric 2x2 matrices.
def det(M):return M[0][0]*M[1][1]-M[0][1]*M[1][0]
def diff(A,B):return [[A[i][j]-B[i][j] for j in range(2)] for i in range(2)]
def matdot(X,Y):return [[sum(X[i][k]*Y[k][j] for k in range(2)) for j in range(2)] for i in range(2)]
def transpose(X):return list(map(list,zip(*X)))
def outer(u,v):return [[u[i]*v[j] for j in range(2)] for i in range(2)]

def single(J,B,G,Y):
 # B = 2x2; J>0 scalar; L_Y = B Y^T+Y B^T-J Y Y^T
 L=[[sum(B[i][k]*Y[j][k]+Y[i][k]*B[j][k] for k in range(2))-J*sum(Y[i][k]*Y[j][k] for k in range(2)) for j in range(2)] for i in range(2)]
 G0=matdot(B,transpose(B))
 G=[[v/J for v in rr] for rr in G0] # exact matrix; PSD rank2
 D=diff(G,L)
 E=matdot(diff(B,[[J*x for x in row] for row in Y]),transpose(diff(B,[[J*x for x in row] for row in Y])))
 E=[[x/J for x in row] for row in E]
 assert D==E
 assert D[0][0]>=0 and D[1][1]>=0 and det(D)>=0
 return D

# BP: quadratic Bernstein coefficient for product of multiaffine f,g
# B^2_0=(1-t)^2, B^2_1=2t(1-t), B^2_2=t^2.
corners=list(itertools.product((0,1),repeat=6));ids={v:i for i,v in enumerate(corners)}
def bernstein_prod(f,g):
 out={}
 for a in itertools.product((0,1,2),repeat=6):
  pairs=[]
  for bits in corners:
   v=tuple(a[i]-bits[i] for i in range(6))
   if all(x in (0,1) for x in v):pairs.append((bits,v))
  denom=2**sum(x==1 for x in a)
  out[a]=sum((f[ids[u]]*g[ids[v]] for u,v in pairs),F(0))/denom
 return out

def multiaff_eval(f,t):
 return sum((f[j]*math.prod(t[i] if a else (1-t[i]) for i,a in enumerate(c)) for j,c in enumerate(corners)),0.0)

def b2_eval(b,t):
 def beta(a,x):return (1-x)**2 if a==0 else (2*x*(1-x) if a==1 else x*x)
 return sum(float(v)*math.prod(beta(a[i],t[i]) for i in range(6)) for a,v in b.items())

if __name__=='__main__':
 for k in range(100):
  J=F(rng.randint(1,100),rng.randint(1,30));B=[[F(rng.randint(-7,7),rng.randint(1,9)) for j in range(2)] for i in range(2)]
  Y=[[F(rng.randint(-6,6),rng.randint(1,11)) for j in range(2)] for i in range(2)]
  single(J,B,None,Y)
 print('TV exact identities + PSD: 100/100 PASS')
 for k in range(6):
  f=[F(rng.randint(-30,50),rng.randint(1,100)) for j in range(64)]
  g=[F(rng.randint(-25,40),rng.randint(1,100)) for j in range(64)]
  b=bernstein_prod(f,g)
  for v in range(60):
   t=[rng.random() for i in range(6)]
   y=multiaff_eval(f,t)*multiaff_eval(g,t)
   cert=b2_eval(b,t)
   assert abs(y-cert)<1e-11
   assert y>=min(float(x) for x in b.values())-1e-11
 print('BP 6D coefficient/evaluation checks: 6*60=360/360 PASS; 729 coefficients each')
 Path('/mnt/data/pent21_review/independent/tv_bp_results.json').write_text(json.dumps({'TV':100,'BP_polynomials':6,'BP_points':360,'BP_coefficients_per_product':729},indent=2))

```

## `batch_high_degree.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail
P=/mnt/data/pent21_review/independent
for S in "$@"; do
  ((S>=180 && S<240)) || continue
  (OPENBLAS_NUM_THREADS=1 python "$P/fan_lg_checker.py" 5 "$S" > "$P/fan_chunk_${S}.log" 2>&1) &
done
wait
for S in "$@"; do tail -1 "$P/fan_chunk_${S}.log"; done

```
