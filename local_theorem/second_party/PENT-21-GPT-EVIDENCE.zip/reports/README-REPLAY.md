# PENT-21 independent evidence replay

Input ZIP SHA256: `14ed1545003b89b8bd4e6a8c014c54dcb6648fe485ec51e94ec9c2ffa27821ac` (131 entries). No root SHA256SUMS exists in the input.

**Trust boundary:** `independent/*.py` is original; no producer module is imported or run. All sources read from `../input/` are immutable, except downloaded source archives are not included in delivery. Python 3.11+, numpy, scipy, mpmath; standard library fractions. Use `OPENBLAS_NUM_THREADS=1` for numerical reproducibility.

The Python files have the original frozen paths under `/mnt/data/pent21_review/` encoded for this session; relocate the folder or edit the hardcoded `root` paths before replay on another machine.

Run from the review directory, in this order:

```
python independent/symmetry_and_leaves.py > independent/symmetry_and_leaves.log
python independent/proposition_r_quadrature.py > independent/proposition_r.log
OPENBLAS_NUM_THREADS=1 python independent/fe_hessian_counterexample.py > independent/fe.log
OPENBLAS_NUM_THREADS=1 PYTHONPATH=independent python independent/fe_refine.py > independent/fe_refine.log
OPENBLAS_NUM_THREADS=1 PYTHONPATH=independent python independent/fe_weak72.py > independent/fe_weak72.log
python independent/local_coefficient_verifier.py > independent/local_coefficient_verifier.log
python independent/tv_bp_independent.py > independent/tv_bp.log
OPENBLAS_NUM_THREADS=1 PYTHONPATH=independent python independent/fan_tamper.py > independent/fan_tamper.log
OPENBLAS_NUM_THREADS=1 PYTHONPATH=independent python independent/lgbox_interval_demo.py > independent/lgbox.log
# 240 fan LG records: for N=5 first 180, and N=12 in groups:
OPENBLAS_NUM_THREADS=1 python independent/fan_lg_checker.py 180 0 > fan_n5.log
OPENBLAS_NUM_THREADS=1 python independent/fan_lg_checker.py 60 180 > fan_n12.log
```

Full records of the 240 sample outcomes are in `independent/fan_results_full.json` and all original logs `fan_lg_first180.log`, `fan_lg_N12_5.log`, and `fan_chunk_*.log`.

Caveats: Hessian and counterexample search are **not rigorous numerical proofs**; `local_coefficient_verifier.py` tests a synthetic polynomial because `Tm/Em` are absent. `lgbox_interval_demo.py` proves a small box on an independently chosen sample but **not** production near coverage. No production `.py` has been executed.
