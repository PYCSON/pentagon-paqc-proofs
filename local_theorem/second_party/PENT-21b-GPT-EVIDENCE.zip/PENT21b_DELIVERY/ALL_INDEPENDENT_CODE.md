# PENT21b — All Independent Source Code

## independent_k_jax.py

```python
#!/usr/bin/env python3
"""Independent derivative reconstruction of D*K and D*Lambda/Theta using JAX autodiff.
Production .py files are NOT imported nor executed. Gram inputs are sampled independently elsewhere.
"""
import os,json,lzma,time
from fractions import Fraction as F
os.environ['JAX_ENABLE_X64']='True'
import jax
jax.config.update('jax_enable_x64',True)
import jax.numpy as np
P='/mnt/data/pent21b_audit/lines/D-topics/probes/PENT/local_run_20261117/cert/'
I=json.load(open(P+'inputs.json'));C=json.load(open(P+'constants.json'));L=json.load(open(P+'lowdeg.json'));R=json.load(open(P+'rho_c.json'))
G=json.loads(lzma.open(P+'gram.json.xz').read())
mat=np.array([[[float(F(q)) for q in row]for row in Gk]for Gk in G['gram']]);mass=np.array([[[float(F(q)) for q in row]for row in Gk]for Gk in G['mass']]);
mid=lambda o: float(F(o['mid']))
c=np.array([mid(t) for t in C['c']]);cq=np.array([float(F(x)) for x in I['Cq']]);origin=np.array([float(F(x)) for x in I['O']]);
kappa=float(F(C['KS']));f0=float((F(C['F_lo'])+F(C['F_up']))/2);area_c=float(F(C['forms_at_c']['area_c']['mid']));l0=f0/area_c
mrho=np.zeros((5,2,42));
for k in range(5):
 for j,field in enumerate(['M_rho_a','M_rho_b']):
  mrho=mrho.at[k,j,np.arange(0,42,7)].set(np.array([mid(v) for v in R[k][field]]))

def gram(k,u,v):return np.dot(u,np.dot(mat[k],v))
def geometry(z):
 verts=np.array([[0.,0.],[1.,0.],[z[0],z[1]],[z[2],z[3]],[z[4],z[5]]]);
 ex=verts-origin[None,:];ey=np.roll(ex,-1,axis=0)
 n11=np.sum(ex*ex,axis=1);n12=np.sum(ex*ey,axis=1);n22=np.sum(ey*ey,axis=1)
 det=ex[:,0]*ey[:,1]-ex[:,1]*ey[:,0];area=np.sum(det)/2
 return n11,n12,n22,det,area

def fill(component,w):
 out=np.zeros(42)
 return out.at[np.arange(component*7,(component+1)*7)].set(w)

def calc(z, needfields=False):
 n11,n12,n22,det,area=geometry(z)
 w=np.concatenate((np.array([1.]),z-c));
 b=0.;a=0.;cflux=0.;cross1=0.;cross2=0.
 Lfields=[];Tfields=[]
 for k in range(5):
  b=b+det[k]*np.dot(w,mass[k]@w)
  ha=fill(0,w);hb=fill(1,w);ch_a=fill(2,w);ch_b=fill(3,w)
  da=fill(4,w);db=fill(5,w)
  s1=-det[k]*ha+ch_b;s2=-det[k]*hb-ch_a
  A=np.array([[n22[k],-n12[k]],[-n12[k],n11[k]]])/det[k]
  N=np.array([[n11[k],n12[k]],[n12[k],n22[k]]])/det[k]
  Ac=np.array([[mid(C['geometry_at_c'][k]['n22']),-mid(C['geometry_at_c'][k]['n12'])],[-mid(C['geometry_at_c'][k]['n12']),mid(C['geometry_at_c'][k]['n11'])]])/mid(C['geometry_at_c'][k]['det'])
  Nc=np.linalg.inv(Ac)
  a=a+(n22[k]*gram(k,da,da)-2*n12[k]*gram(k,da,db)+n11[k]*gram(k,db,db))/det[k]
  cflux=cflux+(n11[k]*gram(k,s1,s1)+2*n12[k]*gram(k,s1,s2)+n22[k]*gram(k,s2,s2))/det[k]
  rho1=N[0,0]*s1+N[0,1]*s2-(area/f0)*da
  rho2=N[1,0]*s1+N[1,1]*s2-(area/f0)*db
  x,y=mrho[k,0],mrho[k,1]
  cross1=cross1+gram(k,rho1,x)+gram(k,rho2,y)
  cross2=cross2+N[0,0]*gram(k,x,x)+2*N[0,1]*gram(k,x,y)+N[1,1]*gram(k,y,y)
  if needfields:
   Rmat=np.stack((rho1,rho2));Wmat=np.stack((x,y))
   tLm=(2*f0)*((kappa/l0)*(Ac@Rmat)-area*(A@Rmat)-(kappa/l0)*(Ac@N@Wmat))
   tTh=(-2*f0*kappa)*(det[k]-mid(C['geometry_at_c'][k]['det']))*(Rmat-N@Wmat)
   Lfields.append(tLm);Tfields.append(tTh)
 D=np.prod(det)
 Psi=area*(kappa+f0)*b-area*area*a-f0*kappa*cflux
 K=Psi+2*f0*kappa*cross1-f0*kappa*cross2
 if needfields:
  return D*K,np.stack(Lfields)*D,np.stack(Tfields)*D
 return D*K

def doit():
 t=time.time();j2=jax.jacfwd(jax.jacfwd(calc))(cq)
 def kval(a):
  inds=[i for i,v in enumerate(a) for _ in range(v)]
  return float(j2[inds[0],inds[1]]/(2 if inds[0]==inds[1] else 1))
 total=0;fail=[]
 for a in L:
  ax=tuple(map(int,a.split(',')))
  if sum(ax)!=2:continue
  x=kval(ax); ref=L[a]
  y=float(F(ref['K_mid']));rad=float(F(ref['K_rad']))
  inside=abs(x-y)<=rad;total+=inside
  if not inside:fail.append((a,x,y,rad))
  print('K',a,'ind=',format(x,'.12g'),'archive=',format(y,'.12g'),'rad=',format(rad,'.3g'),'PASS' if inside else 'FAIL',flush=True)
 print('K total',total,'/',21,'failure',fail,'elapsed',time.time()-t,flush=True)
 print('K constant',float(calc(cq)),'archive',float(F(L['0,0,0,0,0,0']['K_mid'])),flush=True)
 # Analytic first and second derivatives for the dual norms, using exactly the
 # same coefficient basis and bilinear Gram as in the archive.
 q,jl,jt=calc(cq,True)
 hL=jax.jacfwd(jax.jacfwd(lambda z:calc(z,True)[1]))(cq)
 hT=jax.jacfwd(jax.jacfwd(lambda z:calc(z,True)[2]))(cq)
 checked=[]
 for a in L:
  ax=tuple(map(int,a.split(',')))
  if sum(ax)!=2:continue
  ids=[i for i,v in enumerate(ax) for _ in range(v)]
  ll=np.array(hL[:,:,:,ids[0],ids[1]])/(2 if ids[0]==ids[1] else 1)
  tt=np.array(hT[:,:,:,ids[0],ids[1]])/(2 if ids[0]==ids[1] else 1)
  norml=normt=0.
  for k in range(5):
   n11=mid(C['geometry_at_c'][k]['n11']);n12=mid(C['geometry_at_c'][k]['n12']);n22=mid(C['geometry_at_c'][k]['n22']);det=mid(C['geometry_at_c'][k]['det'])
   mm=np.array([[n11,n12],[n12,n22]])/det
   norml+=sum(float(mm[i,j]*gram(k,ll[k,i],ll[k,j])) for i in range(2) for j in range(2))
   normt+=sum(float(gram(k,tt[k,i],tt[k,i])/det) for i in range(2))
  nl=float(np.sqrt(max(0,norml)));nt=float(np.sqrt(max(0,normt)))
  el=L[a]; nlr=float(F(el['NL']['mid']));ntr=float(F(el['NT']['mid']))
  print('NORM',a,'NL',nl,'archive',nlr,'NT',nt,'archive',ntr,'diff',nl-nlr,nt-ntr,flush=True)
  checked.append((nl,nlr,nt,ntr))
 print('NORM total',len(checked),'maxdifferences',max(abs(q[0]-q[1]) for q in checked),max(abs(q[2]-q[3]) for q in checked),'elapsed',time.time()-t,flush=True)

if __name__=='__main__':doit()

```

## check_p2.cpp

```cpp
// Standalone strict integer/rational checker for P leaves. No external producer code.
#include <gmpxx.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <array>
#include <algorithm>
#include <chrono>
#include <map>
#include <memory>
using namespace std;
using E=array<int,6>;
static constexpr int BASE=7;
struct Index { E a; int d; int p; };
int code(const E&a){int v=0;for(int i=0;i<6;i++)v=v*BASE+a[i];return v;}
mpq_class parse(string s){mpq_class r(s);r.canonicalize();return r;}
int binom(int n,int k){int b=1;for(int i=1;i<=k;i++)b=b*(n-i+1)/i;return b;}
struct Power { mpz_class n;int e; };
struct Node { std::map<int, std::unique_ptr<Node>> child; mpz_class coeff=0; };
void put(Node &root,const E &a,const mpz_class &v) {
 Node *p=&root;
 for(int i=0;i<6;i++) {auto &q=p->child[a[i]];if(!q)q=std::make_unique<Node>();p=q.get();}
 p->coeff+=v;
}
mpz_class eval(Node &node,int dim,const Power c[6]){
 if(dim==6)return node.coeff;
 auto it=node.child.rbegin();if(it==node.child.rend())return 0;
 int last=it->first;mpz_class res=eval(*it->second,dim+1,c);++it;
 for(int k=last-1;k>=0;k--){
  mpz_class v=res*c[dim].n;
  if(c[dim].e){int shift=c[dim].e;res=v>>shift;}else res=v;
  if(it!=node.child.rend() && it->first==k){res+=eval(*it->second,dim+1,c);++it;}
 }
 return res;
}

Power dyad(string s){ mpq_class q=parse(s);mpz_class n=q.get_num();mpz_class d=q.get_den();int e=0;while(d>1){if(mpz_odd_p(d.get_mpz_t()))throw runtime_error("nondyadic");d>>=1;e++;}return {n,e};}
mpz_class zabs(mpz_class n){return n>=0?n:-n;}
// Ordinary exact rational LDL positivity test (7x7 Schur complement test).
bool pd7(vector<vector<mpq_class>> A){
 int n=A.size();
 for(int j=0;j<n;j++){
  if(A[j][j]<=0)return false;
  for(int i=j+1;i<n;i++)for(int k=j+1;k<=i;k++){
    A[i][k]-=A[i][j]*A[k][j]/A[j][j];if(i!=k)A[k][i]=A[i][k];
  }
 }
 return true;
}
int main(int argc,char**argv){
 auto start=chrono::steady_clock::now();ifstream in(argv[1]);if(!in)throw runtime_error("missing file");
 const int SHIFT=320;mpz_class S=mpz_class(1)<<SHIFT;mpq_class SQ(S);
 vector<Index> ids;map<int,int> where;
 for(int a0=0;a0<=6;a0++)for(int a1=0;a1<=6-a0;a1++)for(int a2=0;a2<=6-a0-a1;a2++)for(int a3=0;a3<=6-a0-a1-a2;a3++)for(int a4=0;a4<=6-a0-a1-a2-a3;a4++)for(int a5=0;a5<=6-a0-a1-a2-a3-a4;a5++){
  E a={a0,a1,a2,a3,a4,a5};int d=a0+a1+a2+a3+a4+a5;where[code(a)]=ids.size();ids.push_back({a,d,code(a)});
 }
 int M;in>>M;vector<mpz_class> init(ids.size());for(int n=0;n<M;n++){
  E a;for(int &v:a)in>>v;mpz_class c;in>>c;init[where.at(code(a))]=c<<160;
 }
 int numerr;in>>numerr;Node eroot;
 for(int i=0;i<numerr;i++){E a;for(int &x:a)in>>x;mpz_class v;in>>v;put(eroot,a,v<<(SHIFT-160));}
 int leafN;in>>leafN;int count=0,crudes=0,duals=0;int fails=0;long double minbound=1e100;vector<int>failed;
 for(int li=0;li<leafN;li++){
  array<string,18> str;for(auto &v:str)in>>v;
  Power m[6],r[6],c[6];mpq_class muv[6];
  for(int j=0;j<6;j++){
   m[j]=dyad(str[j]);r[j]=dyad(str[j+6]);muv[j]=parse(str[j+12]);
   mpq_class q=zabs(m[j].n); q/=mpz_class(1)<<m[j].e; q+=parse(str[j+6]);
   c[j]=dyad(q.get_str());
  }
  // Polynomial substitution, dimension by dimension: p(m+r t). Exact dyadic integers scaled by 2^320.
  vector<mpz_class> cur=init, nxt(ids.size());
  for(int i=0;i<6;i++){
   fill(nxt.begin(),nxt.end(),mpz_class(0));
   mpz_class pm[7],pr[7];pm[0]=1;pr[0]=1;
   for(int k=1;k<=6;k++){pm[k]=pm[k-1]*m[i].n;pr[k]=pr[k-1]*r[i].n;}
   for(size_t j=0;j<ids.size();j++){
    if(cur[j]==0)continue;
    auto a=ids[j].a;int deg=a[i];
    for(int k=0;k<=deg;k++){
     a[i]=k;mpz_class num=cur[j]*binom(deg,k)*pm[deg-k]*pr[k];
     int shift=(deg-k)*m[i].e+k*r[i].e;
     if(shift) { mpz_class check = num%(mpz_class(1)<<shift); if(check!=0)throw runtime_error("bad exact shift");num >>= shift; }
     nxt[where.at(code(a))]+=num;
    }
   }
   cur.swap(nxt);
  }
  mpz_class constant=cur[where.at(code(E{}))];mpz_class g[6],H[6][6],tail=0;
  for(int i=0;i<6;i++){
   E a={};a[i]=1;g[i]=cur[where.at(code(a))];
   for(int j=0;j<6;j++){
    E b={};b[i]++;b[j]++;H[i][j]=cur[where.at(code(b))]*(i==j?2:1);
   }
  }
  for(size_t i=0;i<ids.size();i++) if(ids[i].d>=3)tail+=zabs(cur[i]);
  // Evaluate the nonnegative error polynomial at the six true far corners.
  // Fixed-point values use 2^320 as denominator; each Horner shift is exact
  // because the total polynomial degree is at most 13 and inputs are dyadic.
  mpz_class en=eval(eroot,0,c);mpq_class err(en,S);
  mpq_class excess=mpq_class(constant-tail,S)-err;
  mpq_class crude=excess;
  for(int i=0;i<6;i++)crude-=mpq_class(zabs(g[i]),S);
  for(int i=0;i<6;i++)for(int j=0;j<6;j++)crude-=mpq_class(zabs(H[i][j]),S)/2;
  if(crude>0){crudes++;count++;minbound=min(minbound,(long double)crude.get_d());continue;}
  // Dual quadratic lower bound via exact 7x7 Schur positive definiteness.
  mpq_class b=2*excess;
  mpq_class am[6][6];
  for(int i=0;i<6;i++){
   mpq_class rr=parse(str[i+6]);b-=2*muv[i]*rr*rr;
   for(int j=0;j<6;j++)am[i][j]=mpq_class(H[i][j],S)+(i==j?2*muv[i]*rr*rr:mpq_class(0));
  }
  vector<vector<mpq_class>> B(7,vector<mpq_class>(7));B[0][0]=b;
  for(int i=0;i<6;i++){B[0][i+1]=B[i+1][0]=mpq_class(g[i],S);for(int j=0;j<6;j++)B[i+1][j+1]=am[i][j];}
  if(pd7(B)){duals++;count++;}
  else{failed.push_back(li);fails++;if(failed.size()<15)cerr<<"P leaf failed conservative bound "<<li<<" cmax="<<" crude="<<crude.get_d()<<"\n";}
  if(li%500==0)cerr<<"progress "<<li<<"/"<<leafN<<" pass="<<count<<" failed="<<fails<<" elapsed="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"s\n";
 }
 cout<<"P leaves="<<leafN<<" PASS="<<count<<" FAIL_TO_CLOSE="<<fails<<" crude="<<crudes<<" dual="<<duals<<" elapsed="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<" s\n";
 cout<<"failed_indices=";for(auto x:failed)cout<<x<<",";cout<<"\n";
}

```

## prep_level_a.py

```python
import json
from fractions import Fraction as F
from collections import defaultdict
p='/mnt/data/pent21b_audit/lines/D-topics/probes/PENT/local_run_20261117/cert/'
w=json.load(open(p+'witness.json')); ls=[json.loads(s) for s in open(p+'leaves.jsonl')][1:]
scale=1<<160
with open('/mnt/data/pent21b_audit/levela_data.txt','w') as out:
 tm=[(tuple(map(int,k.split(','))),F(v)) for k,v in w['Tm'].items() if sum(map(int,k.split(',')))<=6]
 out.write(f'{len(tm)}\n')
 for a,v in tm:
  n=v*scale; assert n.denominator==1
  out.write(' '.join(map(str,a))+' '+str(n.numerator)+'\n')
 es=defaultdict(F)
 for k,v in w['Em'].items():es[sum(map(int,k.split(',')))]+=F(v)
 for k,v in w['Tm'].items():
  if sum(map(int,k.split(',')))>6:es[sum(map(int,k.split(',')))]+=abs(F(v))
 out.write(str(len(es))+'\n')
 for d,v in sorted(es.items()):
  n=v*scale; assert n.denominator==1
  out.write(f'{d} {n.numerator}\n')
 pl=[L for L in ls if L['t']=='P'];out.write(str(len(pl))+'\n')
 for L in pl:
  out.write(' '.join(L['m']+L['r']+L.get('mu',['0']*6))+'\n')
print('P',len(pl),'Tm',len(tm),'Es',len(es))

```

## independent_near_poly.py

```python
"""Minimal *strict* rational near-region polynomial positivity kernel.
No production imports. Conservative, for a record containing an exponent->rational
polynomial and a six-dimensional axis-aligned rational box. A failure means
UNVERIFIED, never disproved.
"""
import json,math,itertools,sys
from fractions import Fraction as F

def strict_positive(coeffs,lo,hi):
 assert len(lo)==6==len(hi)
 m=[(F(lo[i])+F(hi[i]))/2 for i in range(6)]
 r=[(F(hi[i])-F(lo[i]))/2 for i in range(6)]
 if any(v<=0 for v in r):return False,{'reason':'invalid or degenerate box'}
 # p(m+x) via exact binomial expansion, then a safe absolute coefficient bound.
 shifted={}
 for key,cv in coeffs.items():
  a=tuple(map(int,key.split(',')));v=F(cv)
  if len(a)!=6 or any(t<0 for t in a):return False,{'reason':'invalid exponent'}
  choices=[range(t+1) for t in a]
  for b in itertools.product(*choices):
   t=v
   for i in range(6):t*=math.comb(a[i],b[i])*m[i]**(a[i]-b[i])
   shifted[b]=shifted.get(b,F(0))+t
 z=(0,)*6
 lower=shifted.get(z,F(0))-sum(abs(v)*math.prod(r[i]**a[i] for i in range(6)) for a,v in shifted.items() if a!=z)
 return lower>0,{'lower':str(lower),'bound_float':float(lower)}

def main():
 a={','.join(map(str,[0]*6)):'1'}
 for i in range(6):
  ex=[0]*6;ex[i]=2;a[','.join(map(str,ex))]='1'
 lo=['-1/10']*6;hi=['1/10']*6
 p,d=strict_positive(a,lo,hi);print('positive test',p,d);assert p
 aa=a.copy();aa[','.join(['0']*6)]='-1';p,d=strict_positive(aa,lo,hi);print('tamper test',p,d);assert not p
 lo2=lo.copy();lo2[1]='1/5';p,d=strict_positive(a,lo2,hi);print('invalid box rejected',not p,d);assert not p
if __name__=='__main__':main()

```

## float_tail_audit.py

```python
"""Own independent test of binary64 nonnegative tail scaling (empirical check)."""
import math,random
from fractions import Fraction as F
rnd=random.Random(20261117)
fail=[];worst=0.
for case in range(100):
 radius=[F(rnd.randrange(1,50),1024) for _ in range(6)]
 poly=[];truth=F(0);total=0.
 for _ in range(250):
  e=[0]*6
  for _ in range(rnd.randrange(3,14)):e[rnd.randrange(6)]+=1
  c=F(rnd.randrange(1,1024),2**rnd.randrange(25,1050))
  exact=c
  for k,ei in enumerate(e):exact*=radius[k]**ei
  truth+=exact
  a=float(c)*(1+2.0**-52)
  w=1.
  for k,ei in enumerate(e):
   for j in range(ei):w*=float(radius[k])
  total+=a*w
 estimate=math.nextafter(total*(1+1e-9)+1e-290,math.inf)
 if F(estimate)<truth:fail.append(case)
 worst=max(worst,float(truth)/estimate)
print('random nonnegative tails',100,'pass',100-len(fail),'worst actual/upper ratio',worst,'failures',fail)
assert not fail

```

## test_b_direct.py

```python
import independent_b as B
from fractions import Fraction as F
from math import factorial as fact
from collections import Counter
k=0; coeff=B.XI[0];n=B.n
terms=[]
for (i,j,l),idx in B.dofs(k,n,True):
 if idx<0 or not coeff[idx]:continue
 C=F(coeff[idx],2**(-B.xe))*B.multinomial(i,j,l)
 if j:terms.append((C*j,(i,j-1,l)))
 if i:terms.append((-C*i,(i-1,j,l)))
print('terms',len(terms))
S=F(0)
for v,a in terms:
 for w,b in terms:
  S+=v*w*F(fact(a[0]+b[0])*fact(a[1]+b[1])*fact(a[2]+b[2]),fact(sum(a)+sum(b)+2))
print('direct',str(S),float(S))
print('my',str(B.integral(B.bases(0,0)[0][2], B.bases(0,0)[0][2])))
print('gram',str(B.G['gram'][0][14][14]))

```

## independent_b.py

```python
#!/usr/bin/env python3
"""Independent Bernstein polynomial -> monomial integration, no producer imports."""
import json,lzma,itertools,math,time,random
from collections import defaultdict
from fractions import Fraction as F
P='/mnt/data/pent21b_audit/lines/D-topics/probes/PENT/local_run_20261117/cert/'
I=json.load(open(P+'inputs.json'));G=json.loads(lzma.open(P+'gram.json.xz').read());C=json.load(open(P+'constants.json'))
N=I['N'];n=I['n'];CB=I['CB'];xe=I['xe'];CI=I['CI'];XI=I['XI'];

def dofs(k,deg,boundary):
 offset=1+5*(deg-1)
 local=[]
 # local (i,j,l), i is lambda power, j=a, l=b
 for i in range(deg+1):
  for j in range(deg-i+1):
   l=deg-i-j
   if i==deg:g=0
   elif i==0 and l==0:g=(offset+k) if boundary else -1
   elif i==0 and j==0:g=(offset+(k+1)%5) if boundary else -1
   elif i==0:g=offset+5+k*(deg-1)+j-1 if boundary else -1
   elif l==0:g=1+k*(deg-1)+(i-1)
   elif j==0:g=1+((k+1)%5)*(deg-1)+(i-1)
   else:
    # count interior from previous triangles and prior terms with i,j,l all positive
    inner_count=(deg-1)*(deg-2)//2
    pidx=0
    for i2 in range(1,i):pidx+=max(deg-i2-1,0)
    pidx+=j-1
    st=offset+(5+5*(deg-1) if boundary else 0)
    g=st+k*inner_count+pidx
   local.append(((i,j,l),g))
 return local

def check_map():
 for deg,bdy,coeff in [(N,False,CI),(n,True,XI)]:
  maximum=max(g for k in range(5) for _,g in dofs(k,deg,bdy)); assert maximum+1==len(coeff[0]),(maximum,len(coeff[0]),deg)
check_map()

from math import factorial as fact
@__import__('functools').lru_cache(None)
def tri_moment(a,b):return F(fact(a)*fact(b),fact(a+b+2))
@__import__('functools').lru_cache(None)
def multinomial(i,j,l):return fact(i+j+l)//(fact(i)*fact(j)*fact(l))

def local_poly(k,b,typ):
 deg=N if typ=='u' else n
 co=CI[b] if typ=='u' else XI[b]
 scale=F(1,2**CB) if typ=='u' else F(1,2**(-xe))
 acc=defaultdict(int)
 for (i,j,l),idx in dofs(k,deg,typ=='chi'):
  if idx<0 or co[idx]==0:continue
  q=co[idx]*multinomial(i,j,l)
  for s in range(i+1):
   for t in range(i-s+1):
    sign=-1 if (s+t)%2 else 1
    v=q*sign*fact(i)//(fact(s)*fact(t)*fact(i-s-t))
    acc[(j+s,l+t)]+=v
 return {a:scale*v for a,v in acc.items() if v}

def deriv(poly,i):return {(a[0]-(i==0),a[1]-(i==1)):v*a[i] for a,v in poly.items() if a[i]}
def hpoly(poly):return {a:v/(sum(a)+2) for a,v in poly.items()}
def mul_ab(poly,i):return {(a[0]+(i==0),a[1]+(i==1)):v for a,v in poly.items()}

def bases(k,b):
 u=local_poly(k,b,'u'); ch=local_poly(k,b,'chi');h=hpoly(u)
 return [mul_ab(h,0),mul_ab(h,1),deriv(ch,0),deriv(ch,1),deriv(u,0),deriv(u,1)],u

def integral(a,b):
 # exact triangular monomial integration, sparse 2d convolution
 z=F(0)
 for (i,j),v in a.items():
  for (k,l),w in b.items():z+=v*w*tri_moment(i+k,j+l)
 return z

def bounds(v):return F(v['mid'])-F(v['rad']),F(v['mid'])+F(v['rad'])

def run():
 start=time.time();gram=G['gram'];mass=G['mass'];correct=0;bad=[];A=[]
 idx=[(i*7,i*7) for i in range(6)]+[(0,j*7) for j in range(1,6)]+[(2*7,j*7) for j in range(3,6)]+[(i*7+1,i*7) for i in range(6)]
 print('requested gram entries per triangle',len(idx),flush=True)
 for k in range(5):
  B=[];U=[]
  for b in range(7):
   b6,u=bases(k,b);B.append(b6);U.append(u)
  err=[]
  for i,j in idx:
   ai,bi=divmod(i,7);aj,bj=divmod(j,7)
   val=integral(B[bi][ai],B[bj][aj]); ref=F(gram[k][i][j]);
   if val!=ref:err.append((i,j,str(val),str(ref)))
  for b in range(7):
   val=integral(U[0],U[b]);ref=F(mass[k][0][b]);
   if val!=ref:err.append(('mass',b,str(val),str(ref)))
  print('triangle',k,'gram matches',len(idx)-sum(isinstance(e[0],int) for e in err),'mass matches',7-sum(e[0]=='mass' for e in err),'time',round(time.time()-start,2),flush=True)
  bad+=[(k,*x) for x in err]
  # Independent A0,A1,A2 forms using exact Bernstein-to-monomial integration.
  bb=B[0];u=U[0]
  # Reconstruct geometry from reference vertices, instead of treating linked
  # geometric interval midpoints as if they were independent exact variables.
  cv=[F(q['mid']) for q in C['c']];verts=[(F(0),F(0)),(F(1),F(0)),(cv[0],cv[1]),(cv[2],cv[3]),(cv[4],cv[5])];O=[F(t) for t in I['O']]
  e1=[verts[k][i]-O[i] for i in range(2)];e2=[verts[(k+1)%5][i]-O[i] for i in range(2)]
  n11=sum(u*u for u in e1);n12=sum(e1[i]*e2[i] for i in range(2));n22=sum(u*u for u in e2);det=e1[0]*e2[1]-e1[1]*e2[0]
  a1=det*integral(u,u)
  a0=(n22*integral(bb[4],bb[4])-2*n12*integral(bb[4],bb[5])+n11*integral(bb[5],bb[5]))/det
  # physical flux s=( -det*a*h + d_b chi, -det*b*h - d_a chi)
  s1={k:-det*v for k,v in bb[0].items()}
  for key,v in bb[3].items():s1[key]=s1.get(key,F(0))+v
  s2={k:-det*v for k,v in bb[1].items()}
  for key,v in bb[2].items():s2[key]=s2.get(key,F(0))-v
  a2=(n11*integral(s1,s1)+2*n12*integral(s1,s2)+n22*integral(s2,s2))/det
  A.append((a0,a1,a2))
 print('Total mismatches',len(bad),'examples',bad[:5],flush=True)
 total=[sum(a[t] for a in A) for t in range(3)]
 for t,name in enumerate(['A0','A1','A2']):
  lo,hi=bounds(C['forms_at_c'][name]);print(name,'computed-mid',float(total[t]),'enclosed?',lo<=total[t]<=hi,'delta',float(total[t]-F(C['forms_at_c'][name]['mid'])),flush=True)
 area=sum(F(g['det']['mid']) for g in C['geometry_at_c'])/2
 nu=F(C['KS'])/area
 lamup=total[0]/total[1]
 lamlo=(nu*total[1]-total[0])/(nu*total[2]-total[1])
 eps1sq=(total[0]-lamlo*total[1])/(1-lamup/nu)
 eps0sq=eps1sq/nu
 for nm,value in [('area_c',area),('nu',nu),('lam_up',lamup),('lam_lo',lamlo),('eps1_sq',eps1sq),('eps0_sq',eps0sq)]:
  lo,hi=bounds(C['forms_at_c'][nm]);print(nm,'value_mid_recon',float(value),'inside supplied ball?',lo<=value<=hi,'reference',C['forms_at_c'][nm]['approx'],flush=True)
 print('complete seconds',time.time()-start,flush=True)

if __name__=='__main__':run()

```

## check_p.cpp

```cpp
// Standalone strict integer/rational checker for P leaves. No external producer code.
#include <gmpxx.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <array>
#include <algorithm>
#include <chrono>
#include <map>
using namespace std;
using E=array<int,6>;
static constexpr int BASE=7;
struct Index { E a; int d; int p; };
int code(const E&a){int v=0;for(int i=0;i<6;i++)v=v*BASE+a[i];return v;}
mpq_class parse(string s){mpq_class r(s);r.canonicalize();return r;}
int binom(int n,int k){int b=1;for(int i=1;i<=k;i++)b=b*(n-i+1)/i;return b;}
struct Power { mpz_class n;int e; };
Power dyad(string s){ mpq_class q=parse(s);mpz_class n=q.get_num();mpz_class d=q.get_den();int e=0;while(d>1){if(mpz_odd_p(d.get_mpz_t()))throw runtime_error("nondyadic");d>>=1;e++;}return {n,e};}
mpz_class zabs(mpz_class n){return n>=0?n:-n;}
// Ordinary exact rational LDL positivity test (7x7 Schur complement test).
bool pd7(vector<vector<mpq_class>> A){
 int n=A.size();
 for(int j=0;j<n;j++){
  if(A[j][j]<=0)return false;
  for(int i=j+1;i<n;i++)for(int k=j+1;k<=i;k++){
    A[i][k]-=A[i][j]*A[k][j]/A[j][j];if(i!=k)A[k][i]=A[i][k];
  }
 }
 return true;
}
int main(int argc,char**argv){
 auto start=chrono::steady_clock::now();ifstream in(argv[1]);if(!in)throw runtime_error("missing file");
 const int SHIFT=320;mpz_class S=mpz_class(1)<<SHIFT;mpq_class SQ(S);
 vector<Index> ids;map<int,int> where;
 for(int a0=0;a0<=6;a0++)for(int a1=0;a1<=6-a0;a1++)for(int a2=0;a2<=6-a0-a1;a2++)for(int a3=0;a3<=6-a0-a1-a2;a3++)for(int a4=0;a4<=6-a0-a1-a2-a3;a4++)for(int a5=0;a5<=6-a0-a1-a2-a3-a4;a5++){
  E a={a0,a1,a2,a3,a4,a5};int d=a0+a1+a2+a3+a4+a5;where[code(a)]=ids.size();ids.push_back({a,d,code(a)});
 }
 int M;in>>M;vector<mpz_class> init(ids.size());for(int n=0;n<M;n++){
  E a;for(int &v:a)in>>v;mpz_class c;in>>c;init[where.at(code(a))]=c<<160;
 }
 int numerr;in>>numerr;vector<pair<int,mpz_class>> es;
 for(int i=0;i<numerr;i++){int d;mpz_class v;in>>d>>v;es.push_back({d,v});}
 int leafN;in>>leafN;int count=0,crudes=0,duals=0;int fails=0;long double minbound=1e100;vector<int>failed;
 for(int li=0;li<leafN;li++){
  array<string,18> str;for(auto &v:str)in>>v;
  Power m[6],r[6],c[6];mpq_class muv[6];
  for(int j=0;j<6;j++){
   m[j]=dyad(str[j]);r[j]=dyad(str[j+6]);muv[j]=parse(str[j+12]);
   mpq_class q=zabs(m[j].n); q/=mpz_class(1)<<m[j].e; q+=parse(str[j+6]);
   c[j]=dyad(q.get_str());
  }
  // Polynomial substitution, dimension by dimension: p(m+r t). Exact dyadic integers scaled by 2^320.
  vector<mpz_class> cur=init, nxt(ids.size());
  for(int i=0;i<6;i++){
   fill(nxt.begin(),nxt.end(),mpz_class(0));
   mpz_class pm[7],pr[7];pm[0]=1;pr[0]=1;
   for(int k=1;k<=6;k++){pm[k]=pm[k-1]*m[i].n;pr[k]=pr[k-1]*r[i].n;}
   for(size_t j=0;j<ids.size();j++){
    if(cur[j]==0)continue;
    auto a=ids[j].a;int deg=a[i];
    for(int k=0;k<=deg;k++){
     a[i]=k;mpz_class num=cur[j]*binom(deg,k)*pm[deg-k]*pr[k];
     int shift=(deg-k)*m[i].e+k*r[i].e;
     if(shift) { mpz_class check = num%(mpz_class(1)<<shift); if(check!=0)throw runtime_error("bad exact shift");num >>= shift; }
     nxt[where.at(code(a))]+=num;
    }
   }
   cur.swap(nxt);
  }
  mpz_class constant=cur[where.at(code(E{}))];mpz_class g[6],H[6][6],tail=0;
  for(int i=0;i<6;i++){
   E a={};a[i]=1;g[i]=cur[where.at(code(a))];
   for(int j=0;j<6;j++){
    E b={};b[i]++;b[j]++;H[i][j]=cur[where.at(code(b))]*(i==j?2:1);
   }
  }
  for(size_t i=0;i<ids.size();i++) if(ids[i].d>=3)tail+=zabs(cur[i]);
  // Crude safe upper bound for E: replace all six nonnegative coordinates with max(c_i).
  mpq_class C(0);
  for(int i=0;i<6;i++){
   mpq_class q(c[i].n,mpz_class(1)<<c[i].e);if(q>C)C=q;
  }
  mpq_class cp(1),err(0);int last=0;
  for(const auto &ev:es){while(last<ev.first){cp*=C;last++;}err+=mpq_class(ev.second,mpz_class(1)<<160)*cp;}
  mpq_class excess=mpq_class(constant-tail,S)-err;
  mpq_class crude=excess;
  for(int i=0;i<6;i++)crude-=mpq_class(zabs(g[i]),S);
  for(int i=0;i<6;i++)for(int j=0;j<6;j++)crude-=mpq_class(zabs(H[i][j]),S)/2;
  if(crude>0){crudes++;count++;minbound=min(minbound,(long double)crude.get_d());continue;}
  // Dual quadratic lower bound via exact 7x7 Schur positive definiteness.
  mpq_class b=2*excess;
  mpq_class am[6][6];
  for(int i=0;i<6;i++){
   mpq_class rr=parse(str[i+6]);b-=2*muv[i]*rr*rr;
   for(int j=0;j<6;j++)am[i][j]=mpq_class(H[i][j],S)+(i==j?2*muv[i]*rr*rr:mpq_class(0));
  }
  vector<vector<mpq_class>> B(7,vector<mpq_class>(7));B[0][0]=b;
  for(int i=0;i<6;i++){B[0][i+1]=B[i+1][0]=mpq_class(g[i],S);for(int j=0;j<6;j++)B[i+1][j+1]=am[i][j];}
  if(pd7(B)){duals++;count++;}
  else{failed.push_back(li);fails++;if(failed.size()<15)cerr<<"P leaf failed conservative bound "<<li<<" cmax="<<C.get_d()<<" crude="<<crude.get_d()<<"\n";}
  if(li%500==0)cerr<<"progress "<<li<<"/"<<leafN<<" pass="<<count<<" failed="<<fails<<" elapsed="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"s\n";
 }
 cout<<"P leaves="<<leafN<<" PASS="<<count<<" FAIL_TO_CLOSE="<<fails<<" crude="<<crudes<<" dual="<<duals<<" elapsed="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<" s\n";
 cout<<"failed_indices=";for(auto x:failed)cout<<x<<",";cout<<"\n";
}

```

## independent_b_interval.py

```python
"""Exact rational interval propagation of reference coordinate uncertainty."""
from fractions import Fraction as F
import independent_b as B
import json,time
P=B.P;C=B.C;I=B.I
class IV:
 def __init__(self,a,b=None):
  if isinstance(a,IV):self.lo,self.hi=a.lo,a.hi
  else:self.lo=F(a);self.hi=F(a if b is None else b)
 def __add__(x,y):
  y=IV(y);return IV(x.lo+y.lo,x.hi+y.hi)
 __radd__=__add__
 def __neg__(x):return IV(-x.hi,-x.lo)
 def __sub__(x,y):return x+-IV(y)
 def __rsub__(x,y):return IV(y)+-x
 def __mul__(x,y):
  y=IV(y);v=[a*b for a in (x.lo,x.hi) for b in (y.lo,y.hi)];return IV(min(v),max(v))
 __rmul__=__mul__
 def __truediv__(x,y):
  y=IV(y);assert y.lo*y.hi>0;return x*IV(1/y.hi,1/y.lo)
 def __rtruediv__(x,y):return IV(y)/x
 def intersect(y,rec):
  a=F(rec['mid']);r=F(rec['rad']);return not (y.hi<a-r or y.lo>a+r)
 def inside(y,rec):
  a=F(rec['mid']);r=F(rec['rad']);return a-r<=y.lo<=y.hi<=a+r
 def show(x):return (float(x.lo),float(x.hi))

def run():
 t0=time.time();c=[IV(F(v['mid'])-F(v['rad']),F(v['mid'])+F(v['rad'])) for v in C['c']];v=[(IV(0),IV(0)),(IV(1),IV(0)),(c[0],c[1]),(c[2],c[3]),(c[4],c[5])];o=[IV(x) for x in I['O']]
 allA=[IV(0),IV(0),IV(0)];area=IV(0)
 for k in range(5):
  a=[v[k][i]-o[i] for i in range(2)];b=[v[(k+1)%5][i]-o[i] for i in range(2)]
  n11=a[0]*a[0]+a[1]*a[1];n12=a[0]*b[0]+a[1]*b[1];n22=b[0]*b[0]+b[1]*b[1];det=a[0]*b[1]-a[1]*b[0]
  assert det.lo>0;area+=det/IV(2)
  Bs,u=B.bases(k,0)
  U=[B.integral(Bs[i],Bs[i]) for i in range(6)]
  A0=(n22*U[4]-2*n12*B.integral(Bs[4],Bs[5])+n11*U[5])/det
  A1=det*B.integral(u,u)
  # Flux s = -det*[a h,b h]+curl chi
  A=Bs[0];D=Bs[1];ch_a=Bs[2];ch_b=Bs[3]
  # Assemble invariant quadratic coefficients instead of dynamic field intervals
  s1d=B.integral(A,A);s2d=B.integral(D,D);s12d=B.integral(A,D)
  u13=B.integral(A,ch_b);u12=B.integral(A,ch_a);u23=B.integral(D,ch_b);u22=B.integral(D,ch_a)
  ch33=B.integral(ch_b,ch_b);ch22=B.integral(ch_a,ch_a);ch23=B.integral(ch_a,ch_b)
  s11=det*det*s1d-2*det*u13+ch33
  s22=det*det*s2d+2*det*u22+ch22
  s12=det*det*s12d+det*u12-det*u23-ch23
  A2=(n11*s11+2*n12*s12+n22*s22)/det
  allA[0]+=A0;allA[1]+=A1;allA[2]+=A2
 ks=IV(C['KS']);nu=ks/area;lamup=allA[0]/allA[1];lamlo=(nu*allA[1]-allA[0])/(nu*allA[2]-allA[1]);eps1=(allA[0]-lamlo*allA[1])/(1-lamup/nu);eps0=eps1/nu
 for name,x in [('A0',allA[0]),('A1',allA[1]),('A2',allA[2]),('area_c',area),('nu',nu),('lam_up',lamup),('lam_lo',lamlo),('eps1_sq',eps1),('eps0_sq',eps0)]:
  ref=C['forms_at_c'][name]
  print(name,'lo',format(float(x.lo),'.15g'),'hi',format(float(x.hi),'.15g'),'width',format(float(x.hi-x.lo),'.3g'),'archive_overlap',x.intersect(ref),'inside_archive',x.inside(ref),flush=True)
 print('elapsed',time.time()-t0)
if __name__=='__main__':run()

```

## independent_a.py

```python
#!/usr/bin/env python3
"""Independent strict-rational Level A audit: no producer imports."""
import os,json,sys,math,itertools,time,collections,random
from fractions import Fraction as Q
from functools import lru_cache
DIR='/mnt/data/pent21b_audit/lines/D-topics/probes/PENT/local_run_20261117/cert'
ZERO=(0,)*6

def load():
 w=json.load(open(f'{DIR}/witness.json'))
 conv=lambda m:{tuple(map(int,k.split(','))):Q(v) for k,v in m.items()}
 return conv(w['Tm']),conv(w['Em'])

def pd(A):
 n=len(A); L=[[Q(0)]*n for i in range(n)];D=[]
 for j in range(n):
  d=A[j][j]-sum((L[j][k]**2)*D[k] for k in range(j))
  if d<=0:return None
  D.append(d)
  for i in range(j+1,n):
   L[i][j]=(A[i][j]-sum(L[i][k]*L[j][k]*D[k] for k in range(j)))/d
 return D

def inner(tm,em,r=Q(1,128)):
 h=[[Q(0)]*6 for _ in range(6)]; t=[[[Q(0)]*6 for _ in range(6)] for _ in range(6)]
 for a,v in tm.items():
  d=sum(a)
  if d==2:
   ix=[j for j in range(6) for _ in range(a[j])]
   if ix[0]==ix[1]:h[ix[0]][ix[1]]+=2*v
   else:h[ix[0]][ix[1]]+=v;h[ix[1]][ix[0]]+=v
  if d==3:
   ix=[j for j in range(6) for _ in range(a[j])]; perms=set(itertools.permutations(ix))
   for i,j,k in perms:t[i][j][k]+=v/len(perms)
 def ee(i,j):
  k=[0]*6;k[i]+=1;k[j]+=1;return em.get(tuple(k),Q(0))
 def wt(a):return Q(1) if max(a)==sum(a) else Q(1,2)
 tau2=max(ee(i,i)+sum(ee(i,j) for j in range(6) if j!=i)/2 for i in range(6))
 tau3=r*sum(v*wt(a) for a,v in em.items() if sum(a)==3)
 tau4=sum(r**(sum(a)-2)*(abs(tm.get(a,Q(0)))+em.get(a,Q(0)))*wt(a) for a in set(tm)|set(em) if sum(a)>=4)
 tau=tau2+tau3+tau4
 piv=[]
 for s in itertools.product([-1,1],repeat=6):
  A=[[h[i][j]/2 + r*sum(s[k]*t[k][i][j] for k in range(6))-(tau if i==j else 0) for j in range(6)]for i in range(6)]
  ds=pd(A)
  if ds is None:return False,{'tau2':tau2,'tau3':tau3,'tau4':tau4,'tau':tau,'failure_sign':s}
  piv.extend(ds)
 return True,{'tau2':tau2,'tau3':tau3,'tau4':tau4,'tau':tau,'min_pivot':min(piv),'H':h,'T':t}

def geometry(lines):
 root=lines[0];W=Q(root['W']);R=Q(root['R']);r=Q(root['rho_in'])
 assert root['t']=='root' and W>R>r>0
 b=[];volume=Q(0);types=collections.Counter()
 lb=[-W,-W,Q(0),-W,-W,-W];ub=[W]*6
 for idx,L in enumerate(lines[1:]):
  typ=L['t'];m=[Q(x) for x in L['m']];h=[Q(x) for x in L['r']]
  if typ not in ['I','O','P'] or len(h)!=6 or min(h)<=0:return False,idx
  lo=[m[i]-h[i] for i in range(6)];hi=[m[i]+h[i] for i in range(6)]
  if any(lo[i]<lb[i] or hi[i]>ub[i] for i in range(6)):return False,('out_of_root',idx)
  if typ=='I' and not all(abs(m[i])+h[i]<=r for i in range(6)):return False,('I',idx)
  if typ=='O' and sum(max(abs(m[i])-h[i],Q(0))**2 for i in range(6))<R*R:return False,('O',idx)
  v=math.prod(hi[i]-lo[i] for i in range(6));volume+=v; b.append((lo,hi,idx));types[typ]+=1
 if volume != (2*W)**5*W:return False,('volume',str(volume/((2*W)**5*W)))
 # Detect overlaps with sweep line along the first dimension.
 active=[]
 for lo,hi,i in sorted(b,key=lambda x:x[0][0]):
  active=[(x,y,j) for (x,y,j) in active if y[0]>lo[0]]
  for x,y,j in active:
   if all(lo[k]<y[k] and x[k]<hi[k] for k in range(6)):
    return False,('overlap',i,j)
  active.append((lo,hi,i))
 return True,dict(types=types,volume=str(volume),n=len(b))

if __name__=='__main__':
 t0=time.time();tm,em=load();print('coefficients',len(tm),len(em),flush=True)
 good,inf=inner(tm,em);print('inner',good,{k:float(v) for k,v in inf.items() if isinstance(v,Q)},'elapsed',time.time()-t0,flush=True)
 ref=json.load(open(f'{DIR}/inner.json'))
 if good:print('inner difference to reference', {k:float(inf[k]-Q(ref['tau_ge4' if k=='tau4' else k])) for k in ['tau2','tau3','tau4','tau','min_pivot']},flush=True)
 lines=[json.loads(s) for s in open(f'{DIR}/leaves.jsonl')];okay,info=geometry(lines);print('geometry',okay,info,'elapsed',time.time()-t0,flush=True)
 if good and okay:
  key=max((k for k in tm if sum(k)==2),key=lambda k:tm[k]);tm2=tm.copy();tm2[key]=-abs(tm[key]);print('tamper: flip diagonal',key,inner(tm2,em)[0],flush=True)
  altered=[x.copy() for x in lines];altered[100]=dict(lines[100]);altered[100]['m']=lines[100]['m'].copy();altered[100]['m'][0]='100';print('tamper: move leaf',geometry(altered)[0],flush=True)
  em2={k:v*100 for k,v in em.items()};print('tamper: inflate Em x100',inner(tm,em2)[0],flush=True)

```

## prep_a2.py

```python
import json
from fractions import Fraction as F
p='/mnt/data/pent21b_audit/lines/D-topics/probes/PENT/local_run_20261117/cert/'
w=json.load(open(p+'witness.json'));lines=[json.loads(s) for s in open(p+'leaves.jsonl')][1:]
S=1<<160
with open('/mnt/data/pent21b_audit/levela_data2.txt','w') as out:
 tm=[(tuple(map(int,k.split(','))),F(v)) for k,v in w['Tm'].items() if sum(map(int,k.split(',')))<=6]
 out.write(f'{len(tm)}\n')
 for a,v in tm:
  n=v*S;assert n.denominator==1
  out.write(' '.join(map(str,a))+' '+str(n.numerator)+'\n')
 E={tuple(map(int,k.split(','))):F(v) for k,v in w['Em'].items()}
 for k,v in w['Tm'].items():
  a=tuple(map(int,k.split(',')))
  if sum(a)>6:E[a]=E.get(a,F(0))+abs(F(v))
 out.write(str(len(E))+'\n')
 for a,v in sorted(E.items()):
  n=v*S;assert n.denominator==1
  out.write(' '.join(map(str,a))+' '+str(n.numerator)+'\n')
 pl=[L for L in lines if L['t']=='P'];out.write(str(len(pl))+'\n')
 for L in pl:out.write(' '.join(L['m']+L['r']+L.get('mu',['0']*6))+'\n')
print('E',len(E))

```

## independent_far_structure.py

```python
"""Independent exact tiling audit for frozen far pilot sample, no producer modules."""
import json,glob,collections,time
from fractions import Fraction as F
from pathlib import Path
B=Path('/mnt/data/pent21b_audit/oldfar/lines/D-topics/probes/PENT/v2_run/tests/far_20261116b/sample_out')

def box(a,b):return (tuple(F(x) for x in a),tuple(F(x) for x in b))
def vol(b):return __import__('math').prod(b[1][i]-b[0][i] for i in range(len(b[0])))
def intersects(a,b):return all(max(a[0][i],b[0][i])<min(a[1][i],b[1][i]) for i in range(6))

def main():
 start=time.time();results=[]
 for chart in ['std','E2','E3']:
  rootall=json.load(open(B/chart/'roots.json'))['blocks']
  for fld in sorted((B/chart/'blocks').iterdir()):
   roots={tuple(x[0]):box(x[1]+[0,0],x[2]+[1,1]) for x in rootall[fld.name]}
   groups=collections.defaultdict(list);labels=collections.Counter();faults=[]
   for line in open(fld/'leaves.jsonl'):
    rec=json.loads(line);key=tuple(rec[0]);labels[rec[4]]+=1
    if key not in roots:faults.append(('unknown_root',key));continue
    b=box(rec[2],rec[3]);r=roots[key]
    if not all(r[0][i]<=b[0][i]<b[1][i]<=r[1][i] for i in range(6)):faults.append(('out_root',key))
    groups[(key,rec[1])].append(b)
   for (key,j),boxes in groups.items():
    r=roots[key]
    if sum(map(vol,boxes),F(0))!=vol(r):faults.append(('volume',key))
    order=sorted(boxes,key=lambda a:a[0][0]);active=[]
    for b in order:
     active=[a for a in active if a[1][0]>b[0][0]]
     if any(intersects(a,b) for a in active):faults.append(('overlap',key));break
     active.append(b)
   result=dict(chart=chart,block=fld.name,roots=len(roots),leaves=sum(len(x) for x in groups.values()),labels=dict(labels),pass_struct=(len(faults)==0),failures=faults[:5]);results.append(result)
   print(result,flush=True)
 print('TOTAL',len(results),'pass',sum(x['pass_struct'] for x in results),'leaf',sum(x['leaves'] for x in results),'time',time.time()-start,flush=True)
if __name__=='__main__':main()

```

