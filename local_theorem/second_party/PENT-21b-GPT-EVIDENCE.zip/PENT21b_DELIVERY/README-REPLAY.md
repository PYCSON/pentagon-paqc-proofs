# PENT-21b Independent Replay

Never run production `lglocal.py`, `lgpoly.py`, or `tests/lglocal_cert_check.py` for this independent audit.

## Input

Extract the user-provided `PENT21b_cert_58e40e0.zip` to `/mnt/data/pent21b_audit`. `SHA256SUMS` contains an erroneous self-hash and passes **23/24**, not 24/24; the complete ZIP SHA is `9912990ef814123230862de7e7181188850def639f1ba7d3e2c5dc3cb74a8577`.

## Exact Level A

```bash
python3 source/independent_a.py
python3 source/prep_a2.py
c++ -O3 -std=c++17 source/check_p2.cpp -lgmpxx -lgmp -o check_p2
./check_p2 /mnt/data/pent21b_audit/levela_data2.txt
```

`independent_a.py` recomputes tau, 64 pivots, exact leaf tiling, I/O predicates and three mutations. `prep_a2.py` converts input fractions to an integer stream. The C++ code is a separate GMP checker for **all 6,942 P leaves**, with exact fixed-point shifts and positive Schur complements.

## Level B

```bash
python3 source/independent_b.py
python3 source/independent_b_interval.py
OPENBLAS_NUM_THREADS=1 XLA_PYTHON_CLIENT_PREALLOCATE=false python3 source/independent_k_jax.py
python3 source/float_tail_audit.py
python3 source/independent_near_poly.py
```

Requires Python 3, numpy, scipy (if installed), JAX for derivative samples, GMP/GMPXX headers/compiler for C++ Level A. Level B uses the supplied Gram table beyond the sampled 135 exact checked entries; this does **not** make it a full strict independent coefficient generator.

## Far pilot

`independent_far_structure.py` expects the `far_20261116b/sample_out` files from the earlier PENT-21 research bundle, not from PENT-21b. Its result is a limited geometry probe only, without domain exclusions / chart hand-off semantics.

## Audit evidence

`logs/` contains authentic raw stdout/stderr, including failed first attempts; these must not be reclassified as proof failure. `source/` contains full authored code. `SHA256SUMS` covers evidence files (excluding itself); check it by running `sha256sum -c SHA256SUMS` inside this delivery directory.
