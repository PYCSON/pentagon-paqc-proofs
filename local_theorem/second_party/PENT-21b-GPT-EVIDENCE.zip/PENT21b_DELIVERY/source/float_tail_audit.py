"""Own independent test of binary64 nonnegative tail scaling (empirical check)."""
import math,random
from fractions import Fraction as F
rnd=random.Random(20261117)
fail=[];worst=0.
for case in range(100):
 radius=[F(rnd.randrange(1,50),1024) for _ in range(6)]
 poly=[];truth=F(0);total=0.
 for _ in range(250):
  e=[0]*6
  for _ in range(rnd.randrange(3,14)):e[rnd.randrange(6)]+=1
  c=F(rnd.randrange(1,1024),2**rnd.randrange(25,1050))
  exact=c
  for k,ei in enumerate(e):exact*=radius[k]**ei
  truth+=exact
  a=float(c)*(1+2.0**-52)
  w=1.
  for k,ei in enumerate(e):
   for j in range(ei):w*=float(radius[k])
  total+=a*w
 estimate=math.nextafter(total*(1+1e-9)+1e-290,math.inf)
 if F(estimate)<truth:fail.append(case)
 worst=max(worst,float(truth)/estimate)
print('random nonnegative tails',100,'pass',100-len(fail),'worst actual/upper ratio',worst,'failures',fail)
assert not fail
