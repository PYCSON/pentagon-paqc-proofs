#!/usr/bin/env python3
"""Independent Bernstein polynomial -> monomial integration, no producer imports."""
import json,lzma,itertools,math,time,random
from collections import defaultdict
from fractions import Fraction as F
P='/mnt/data/pent21b_audit/lines/D-topics/probes/PENT/local_run_20261117/cert/'
I=json.load(open(P+'inputs.json'));G=json.loads(lzma.open(P+'gram.json.xz').read());C=json.load(open(P+'constants.json'))
N=I['N'];n=I['n'];CB=I['CB'];xe=I['xe'];CI=I['CI'];XI=I['XI'];

def dofs(k,deg,boundary):
 offset=1+5*(deg-1)
 local=[]
 # local (i,j,l), i is lambda power, j=a, l=b
 for i in range(deg+1):
  for j in range(deg-i+1):
   l=deg-i-j
   if i==deg:g=0
   elif i==0 and l==0:g=(offset+k) if boundary else -1
   elif i==0 and j==0:g=(offset+(k+1)%5) if boundary else -1
   elif i==0:g=offset+5+k*(deg-1)+j-1 if boundary else -1
   elif l==0:g=1+k*(deg-1)+(i-1)
   elif j==0:g=1+((k+1)%5)*(deg-1)+(i-1)
   else:
    # count interior from previous triangles and prior terms with i,j,l all positive
    inner_count=(deg-1)*(deg-2)//2
    pidx=0
    for i2 in range(1,i):pidx+=max(deg-i2-1,0)
    pidx+=j-1
    st=offset+(5+5*(deg-1) if boundary else 0)
    g=st+k*inner_count+pidx
   local.append(((i,j,l),g))
 return local

def check_map():
 for deg,bdy,coeff in [(N,False,CI),(n,True,XI)]:
  maximum=max(g for k in range(5) for _,g in dofs(k,deg,bdy)); assert maximum+1==len(coeff[0]),(maximum,len(coeff[0]),deg)
check_map()

from math import factorial as fact
@__import__('functools').lru_cache(None)
def tri_moment(a,b):return F(fact(a)*fact(b),fact(a+b+2))
@__import__('functools').lru_cache(None)
def multinomial(i,j,l):return fact(i+j+l)//(fact(i)*fact(j)*fact(l))

def local_poly(k,b,typ):
 deg=N if typ=='u' else n
 co=CI[b] if typ=='u' else XI[b]
 scale=F(1,2**CB) if typ=='u' else F(1,2**(-xe))
 acc=defaultdict(int)
 for (i,j,l),idx in dofs(k,deg,typ=='chi'):
  if idx<0 or co[idx]==0:continue
  q=co[idx]*multinomial(i,j,l)
  for s in range(i+1):
   for t in range(i-s+1):
    sign=-1 if (s+t)%2 else 1
    v=q*sign*fact(i)//(fact(s)*fact(t)*fact(i-s-t))
    acc[(j+s,l+t)]+=v
 return {a:scale*v for a,v in acc.items() if v}

def deriv(poly,i):return {(a[0]-(i==0),a[1]-(i==1)):v*a[i] for a,v in poly.items() if a[i]}
def hpoly(poly):return {a:v/(sum(a)+2) for a,v in poly.items()}
def mul_ab(poly,i):return {(a[0]+(i==0),a[1]+(i==1)):v for a,v in poly.items()}

def bases(k,b):
 u=local_poly(k,b,'u'); ch=local_poly(k,b,'chi');h=hpoly(u)
 return [mul_ab(h,0),mul_ab(h,1),deriv(ch,0),deriv(ch,1),deriv(u,0),deriv(u,1)],u

def integral(a,b):
 # exact triangular monomial integration, sparse 2d convolution
 z=F(0)
 for (i,j),v in a.items():
  for (k,l),w in b.items():z+=v*w*tri_moment(i+k,j+l)
 return z

def bounds(v):return F(v['mid'])-F(v['rad']),F(v['mid'])+F(v['rad'])

def run():
 start=time.time();gram=G['gram'];mass=G['mass'];correct=0;bad=[];A=[]
 idx=[(i*7,i*7) for i in range(6)]+[(0,j*7) for j in range(1,6)]+[(2*7,j*7) for j in range(3,6)]+[(i*7+1,i*7) for i in range(6)]
 print('requested gram entries per triangle',len(idx),flush=True)
 for k in range(5):
  B=[];U=[]
  for b in range(7):
   b6,u=bases(k,b);B.append(b6);U.append(u)
  err=[]
  for i,j in idx:
   ai,bi=divmod(i,7);aj,bj=divmod(j,7)
   val=integral(B[bi][ai],B[bj][aj]); ref=F(gram[k][i][j]);
   if val!=ref:err.append((i,j,str(val),str(ref)))
  for b in range(7):
   val=integral(U[0],U[b]);ref=F(mass[k][0][b]);
   if val!=ref:err.append(('mass',b,str(val),str(ref)))
  print('triangle',k,'gram matches',len(idx)-sum(isinstance(e[0],int) for e in err),'mass matches',7-sum(e[0]=='mass' for e in err),'time',round(time.time()-start,2),flush=True)
  bad+=[(k,*x) for x in err]
  # Independent A0,A1,A2 forms using exact Bernstein-to-monomial integration.
  bb=B[0];u=U[0]
  # Reconstruct geometry from reference vertices, instead of treating linked
  # geometric interval midpoints as if they were independent exact variables.
  cv=[F(q['mid']) for q in C['c']];verts=[(F(0),F(0)),(F(1),F(0)),(cv[0],cv[1]),(cv[2],cv[3]),(cv[4],cv[5])];O=[F(t) for t in I['O']]
  e1=[verts[k][i]-O[i] for i in range(2)];e2=[verts[(k+1)%5][i]-O[i] for i in range(2)]
  n11=sum(u*u for u in e1);n12=sum(e1[i]*e2[i] for i in range(2));n22=sum(u*u for u in e2);det=e1[0]*e2[1]-e1[1]*e2[0]
  a1=det*integral(u,u)
  a0=(n22*integral(bb[4],bb[4])-2*n12*integral(bb[4],bb[5])+n11*integral(bb[5],bb[5]))/det
  # physical flux s=( -det*a*h + d_b chi, -det*b*h - d_a chi)
  s1={k:-det*v for k,v in bb[0].items()}
  for key,v in bb[3].items():s1[key]=s1.get(key,F(0))+v
  s2={k:-det*v for k,v in bb[1].items()}
  for key,v in bb[2].items():s2[key]=s2.get(key,F(0))-v
  a2=(n11*integral(s1,s1)+2*n12*integral(s1,s2)+n22*integral(s2,s2))/det
  A.append((a0,a1,a2))
 print('Total mismatches',len(bad),'examples',bad[:5],flush=True)
 total=[sum(a[t] for a in A) for t in range(3)]
 for t,name in enumerate(['A0','A1','A2']):
  lo,hi=bounds(C['forms_at_c'][name]);print(name,'computed-mid',float(total[t]),'enclosed?',lo<=total[t]<=hi,'delta',float(total[t]-F(C['forms_at_c'][name]['mid'])),flush=True)
 area=sum(F(g['det']['mid']) for g in C['geometry_at_c'])/2
 nu=F(C['KS'])/area
 lamup=total[0]/total[1]
 lamlo=(nu*total[1]-total[0])/(nu*total[2]-total[1])
 eps1sq=(total[0]-lamlo*total[1])/(1-lamup/nu)
 eps0sq=eps1sq/nu
 for nm,value in [('area_c',area),('nu',nu),('lam_up',lamup),('lam_lo',lamlo),('eps1_sq',eps1sq),('eps0_sq',eps0sq)]:
  lo,hi=bounds(C['forms_at_c'][nm]);print(nm,'value_mid_recon',float(value),'inside supplied ball?',lo<=value<=hi,'reference',C['forms_at_c'][nm]['approx'],flush=True)
 print('complete seconds',time.time()-start,flush=True)

if __name__=='__main__':run()
