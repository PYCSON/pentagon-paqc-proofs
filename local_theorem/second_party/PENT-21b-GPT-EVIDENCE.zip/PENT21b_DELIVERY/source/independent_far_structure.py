"""Independent exact tiling audit for frozen far pilot sample, no producer modules."""
import json,glob,collections,time
from fractions import Fraction as F
from pathlib import Path
B=Path('/mnt/data/pent21b_audit/oldfar/lines/D-topics/probes/PENT/v2_run/tests/far_20261116b/sample_out')

def box(a,b):return (tuple(F(x) for x in a),tuple(F(x) for x in b))
def vol(b):return __import__('math').prod(b[1][i]-b[0][i] for i in range(len(b[0])))
def intersects(a,b):return all(max(a[0][i],b[0][i])<min(a[1][i],b[1][i]) for i in range(6))

def main():
 start=time.time();results=[]
 for chart in ['std','E2','E3']:
  rootall=json.load(open(B/chart/'roots.json'))['blocks']
  for fld in sorted((B/chart/'blocks').iterdir()):
   roots={tuple(x[0]):box(x[1]+[0,0],x[2]+[1,1]) for x in rootall[fld.name]}
   groups=collections.defaultdict(list);labels=collections.Counter();faults=[]
   for line in open(fld/'leaves.jsonl'):
    rec=json.loads(line);key=tuple(rec[0]);labels[rec[4]]+=1
    if key not in roots:faults.append(('unknown_root',key));continue
    b=box(rec[2],rec[3]);r=roots[key]
    if not all(r[0][i]<=b[0][i]<b[1][i]<=r[1][i] for i in range(6)):faults.append(('out_root',key))
    groups[(key,rec[1])].append(b)
   for (key,j),boxes in groups.items():
    r=roots[key]
    if sum(map(vol,boxes),F(0))!=vol(r):faults.append(('volume',key))
    order=sorted(boxes,key=lambda a:a[0][0]);active=[]
    for b in order:
     active=[a for a in active if a[1][0]>b[0][0]]
     if any(intersects(a,b) for a in active):faults.append(('overlap',key));break
     active.append(b)
   result=dict(chart=chart,block=fld.name,roots=len(roots),leaves=sum(len(x) for x in groups.values()),labels=dict(labels),pass_struct=(len(faults)==0),failures=faults[:5]);results.append(result)
   print(result,flush=True)
 print('TOTAL',len(results),'pass',sum(x['pass_struct'] for x in results),'leaf',sum(x['leaves'] for x in results),'time',time.time()-start,flush=True)
if __name__=='__main__':main()
