#!/usr/bin/env python3
"""Independent derivative reconstruction of D*K and D*Lambda/Theta using JAX autodiff.
Production .py files are NOT imported nor executed. Gram inputs are sampled independently elsewhere.
"""
import os,json,lzma,time
from fractions import Fraction as F
os.environ['JAX_ENABLE_X64']='True'
import jax
jax.config.update('jax_enable_x64',True)
import jax.numpy as np
P='/mnt/data/pent21b_audit/lines/D-topics/probes/PENT/local_run_20261117/cert/'
I=json.load(open(P+'inputs.json'));C=json.load(open(P+'constants.json'));L=json.load(open(P+'lowdeg.json'));R=json.load(open(P+'rho_c.json'))
G=json.loads(lzma.open(P+'gram.json.xz').read())
mat=np.array([[[float(F(q)) for q in row]for row in Gk]for Gk in G['gram']]);mass=np.array([[[float(F(q)) for q in row]for row in Gk]for Gk in G['mass']]);
mid=lambda o: float(F(o['mid']))
c=np.array([mid(t) for t in C['c']]);cq=np.array([float(F(x)) for x in I['Cq']]);origin=np.array([float(F(x)) for x in I['O']]);
kappa=float(F(C['KS']));f0=float((F(C['F_lo'])+F(C['F_up']))/2);area_c=float(F(C['forms_at_c']['area_c']['mid']));l0=f0/area_c
mrho=np.zeros((5,2,42));
for k in range(5):
 for j,field in enumerate(['M_rho_a','M_rho_b']):
  mrho=mrho.at[k,j,np.arange(0,42,7)].set(np.array([mid(v) for v in R[k][field]]))

def gram(k,u,v):return np.dot(u,np.dot(mat[k],v))
def geometry(z):
 verts=np.array([[0.,0.],[1.,0.],[z[0],z[1]],[z[2],z[3]],[z[4],z[5]]]);
 ex=verts-origin[None,:];ey=np.roll(ex,-1,axis=0)
 n11=np.sum(ex*ex,axis=1);n12=np.sum(ex*ey,axis=1);n22=np.sum(ey*ey,axis=1)
 det=ex[:,0]*ey[:,1]-ex[:,1]*ey[:,0];area=np.sum(det)/2
 return n11,n12,n22,det,area

def fill(component,w):
 out=np.zeros(42)
 return out.at[np.arange(component*7,(component+1)*7)].set(w)

def calc(z, needfields=False):
 n11,n12,n22,det,area=geometry(z)
 w=np.concatenate((np.array([1.]),z-c));
 b=0.;a=0.;cflux=0.;cross1=0.;cross2=0.
 Lfields=[];Tfields=[]
 for k in range(5):
  b=b+det[k]*np.dot(w,mass[k]@w)
  ha=fill(0,w);hb=fill(1,w);ch_a=fill(2,w);ch_b=fill(3,w)
  da=fill(4,w);db=fill(5,w)
  s1=-det[k]*ha+ch_b;s2=-det[k]*hb-ch_a
  A=np.array([[n22[k],-n12[k]],[-n12[k],n11[k]]])/det[k]
  N=np.array([[n11[k],n12[k]],[n12[k],n22[k]]])/det[k]
  Ac=np.array([[mid(C['geometry_at_c'][k]['n22']),-mid(C['geometry_at_c'][k]['n12'])],[-mid(C['geometry_at_c'][k]['n12']),mid(C['geometry_at_c'][k]['n11'])]])/mid(C['geometry_at_c'][k]['det'])
  Nc=np.linalg.inv(Ac)
  a=a+(n22[k]*gram(k,da,da)-2*n12[k]*gram(k,da,db)+n11[k]*gram(k,db,db))/det[k]
  cflux=cflux+(n11[k]*gram(k,s1,s1)+2*n12[k]*gram(k,s1,s2)+n22[k]*gram(k,s2,s2))/det[k]
  rho1=N[0,0]*s1+N[0,1]*s2-(area/f0)*da
  rho2=N[1,0]*s1+N[1,1]*s2-(area/f0)*db
  x,y=mrho[k,0],mrho[k,1]
  cross1=cross1+gram(k,rho1,x)+gram(k,rho2,y)
  cross2=cross2+N[0,0]*gram(k,x,x)+2*N[0,1]*gram(k,x,y)+N[1,1]*gram(k,y,y)
  if needfields:
   Rmat=np.stack((rho1,rho2));Wmat=np.stack((x,y))
   tLm=(2*f0)*((kappa/l0)*(Ac@Rmat)-area*(A@Rmat)-(kappa/l0)*(Ac@N@Wmat))
   tTh=(-2*f0*kappa)*(det[k]-mid(C['geometry_at_c'][k]['det']))*(Rmat-N@Wmat)
   Lfields.append(tLm);Tfields.append(tTh)
 D=np.prod(det)
 Psi=area*(kappa+f0)*b-area*area*a-f0*kappa*cflux
 K=Psi+2*f0*kappa*cross1-f0*kappa*cross2
 if needfields:
  return D*K,np.stack(Lfields)*D,np.stack(Tfields)*D
 return D*K

def doit():
 t=time.time();j2=jax.jacfwd(jax.jacfwd(calc))(cq)
 def kval(a):
  inds=[i for i,v in enumerate(a) for _ in range(v)]
  return float(j2[inds[0],inds[1]]/(2 if inds[0]==inds[1] else 1))
 total=0;fail=[]
 for a in L:
  ax=tuple(map(int,a.split(',')))
  if sum(ax)!=2:continue
  x=kval(ax); ref=L[a]
  y=float(F(ref['K_mid']));rad=float(F(ref['K_rad']))
  inside=abs(x-y)<=rad;total+=inside
  if not inside:fail.append((a,x,y,rad))
  print('K',a,'ind=',format(x,'.12g'),'archive=',format(y,'.12g'),'rad=',format(rad,'.3g'),'PASS' if inside else 'FAIL',flush=True)
 print('K total',total,'/',21,'failure',fail,'elapsed',time.time()-t,flush=True)
 print('K constant',float(calc(cq)),'archive',float(F(L['0,0,0,0,0,0']['K_mid'])),flush=True)
 # Analytic first and second derivatives for the dual norms, using exactly the
 # same coefficient basis and bilinear Gram as in the archive.
 q,jl,jt=calc(cq,True)
 hL=jax.jacfwd(jax.jacfwd(lambda z:calc(z,True)[1]))(cq)
 hT=jax.jacfwd(jax.jacfwd(lambda z:calc(z,True)[2]))(cq)
 checked=[]
 for a in L:
  ax=tuple(map(int,a.split(',')))
  if sum(ax)!=2:continue
  ids=[i for i,v in enumerate(ax) for _ in range(v)]
  ll=np.array(hL[:,:,:,ids[0],ids[1]])/(2 if ids[0]==ids[1] else 1)
  tt=np.array(hT[:,:,:,ids[0],ids[1]])/(2 if ids[0]==ids[1] else 1)
  norml=normt=0.
  for k in range(5):
   n11=mid(C['geometry_at_c'][k]['n11']);n12=mid(C['geometry_at_c'][k]['n12']);n22=mid(C['geometry_at_c'][k]['n22']);det=mid(C['geometry_at_c'][k]['det'])
   mm=np.array([[n11,n12],[n12,n22]])/det
   norml+=sum(float(mm[i,j]*gram(k,ll[k,i],ll[k,j])) for i in range(2) for j in range(2))
   normt+=sum(float(gram(k,tt[k,i],tt[k,i])/det) for i in range(2))
  nl=float(np.sqrt(max(0,norml)));nt=float(np.sqrt(max(0,normt)))
  el=L[a]; nlr=float(F(el['NL']['mid']));ntr=float(F(el['NT']['mid']))
  print('NORM',a,'NL',nl,'archive',nlr,'NT',nt,'archive',ntr,'diff',nl-nlr,nt-ntr,flush=True)
  checked.append((nl,nlr,nt,ntr))
 print('NORM total',len(checked),'maxdifferences',max(abs(q[0]-q[1]) for q in checked),max(abs(q[2]-q[3]) for q in checked),'elapsed',time.time()-t,flush=True)

if __name__=='__main__':doit()
