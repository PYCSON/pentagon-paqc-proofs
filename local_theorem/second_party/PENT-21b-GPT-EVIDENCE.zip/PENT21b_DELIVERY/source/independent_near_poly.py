"""Minimal *strict* rational near-region polynomial positivity kernel.
No production imports. Conservative, for a record containing an exponent->rational
polynomial and a six-dimensional axis-aligned rational box. A failure means
UNVERIFIED, never disproved.
"""
import json,math,itertools,sys
from fractions import Fraction as F

def strict_positive(coeffs,lo,hi):
 assert len(lo)==6==len(hi)
 m=[(F(lo[i])+F(hi[i]))/2 for i in range(6)]
 r=[(F(hi[i])-F(lo[i]))/2 for i in range(6)]
 if any(v<=0 for v in r):return False,{'reason':'invalid or degenerate box'}
 # p(m+x) via exact binomial expansion, then a safe absolute coefficient bound.
 shifted={}
 for key,cv in coeffs.items():
  a=tuple(map(int,key.split(',')));v=F(cv)
  if len(a)!=6 or any(t<0 for t in a):return False,{'reason':'invalid exponent'}
  choices=[range(t+1) for t in a]
  for b in itertools.product(*choices):
   t=v
   for i in range(6):t*=math.comb(a[i],b[i])*m[i]**(a[i]-b[i])
   shifted[b]=shifted.get(b,F(0))+t
 z=(0,)*6
 lower=shifted.get(z,F(0))-sum(abs(v)*math.prod(r[i]**a[i] for i in range(6)) for a,v in shifted.items() if a!=z)
 return lower>0,{'lower':str(lower),'bound_float':float(lower)}

def main():
 a={','.join(map(str,[0]*6)):'1'}
 for i in range(6):
  ex=[0]*6;ex[i]=2;a[','.join(map(str,ex))]='1'
 lo=['-1/10']*6;hi=['1/10']*6
 p,d=strict_positive(a,lo,hi);print('positive test',p,d);assert p
 aa=a.copy();aa[','.join(['0']*6)]='-1';p,d=strict_positive(aa,lo,hi);print('tamper test',p,d);assert not p
 lo2=lo.copy();lo2[1]='1/5';p,d=strict_positive(a,lo2,hi);print('invalid box rejected',not p,d);assert not p
if __name__=='__main__':main()
