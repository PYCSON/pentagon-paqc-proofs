import json
from fractions import Fraction as F
from collections import defaultdict
p='/mnt/data/pent21b_audit/lines/D-topics/probes/PENT/local_run_20261117/cert/'
w=json.load(open(p+'witness.json')); ls=[json.loads(s) for s in open(p+'leaves.jsonl')][1:]
scale=1<<160
with open('/mnt/data/pent21b_audit/levela_data.txt','w') as out:
 tm=[(tuple(map(int,k.split(','))),F(v)) for k,v in w['Tm'].items() if sum(map(int,k.split(',')))<=6]
 out.write(f'{len(tm)}\n')
 for a,v in tm:
  n=v*scale; assert n.denominator==1
  out.write(' '.join(map(str,a))+' '+str(n.numerator)+'\n')
 es=defaultdict(F)
 for k,v in w['Em'].items():es[sum(map(int,k.split(',')))]+=F(v)
 for k,v in w['Tm'].items():
  if sum(map(int,k.split(',')))>6:es[sum(map(int,k.split(',')))]+=abs(F(v))
 out.write(str(len(es))+'\n')
 for d,v in sorted(es.items()):
  n=v*scale; assert n.denominator==1
  out.write(f'{d} {n.numerator}\n')
 pl=[L for L in ls if L['t']=='P'];out.write(str(len(pl))+'\n')
 for L in pl:
  out.write(' '.join(L['m']+L['r']+L.get('mu',['0']*6))+'\n')
print('P',len(pl),'Tm',len(tm),'Es',len(es))
