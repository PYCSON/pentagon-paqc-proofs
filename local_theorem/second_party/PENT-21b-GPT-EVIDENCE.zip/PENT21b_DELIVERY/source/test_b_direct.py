import independent_b as B
from fractions import Fraction as F
from math import factorial as fact
from collections import Counter
k=0; coeff=B.XI[0];n=B.n
terms=[]
for (i,j,l),idx in B.dofs(k,n,True):
 if idx<0 or not coeff[idx]:continue
 C=F(coeff[idx],2**(-B.xe))*B.multinomial(i,j,l)
 if j:terms.append((C*j,(i,j-1,l)))
 if i:terms.append((-C*i,(i-1,j,l)))
print('terms',len(terms))
S=F(0)
for v,a in terms:
 for w,b in terms:
  S+=v*w*F(fact(a[0]+b[0])*fact(a[1]+b[1])*fact(a[2]+b[2]),fact(sum(a)+sum(b)+2))
print('direct',str(S),float(S))
print('my',str(B.integral(B.bases(0,0)[0][2], B.bases(0,0)[0][2])))
print('gram',str(B.G['gram'][0][14][14]))
