# PENT-21c 独立检查器完整源码

本文件含本轮核心和辅助独立程序；所有生产方 Python 程序均未包含或执行。

## independent_b.py

```python
#!/usr/bin/env python3
"""Independent Bernstein polynomial -> monomial integration, no producer imports."""
import json,lzma,itertools,math,time,random
from collections import defaultdict
from fractions import Fraction as F
P='/mnt/data/pent21c_audit/PENT21c_cert_3055e81/lines/D-topics/probes/PENT/local_run_20261117/cert/'
I=json.load(open(P+'inputs.json'));G=json.loads(lzma.open(P+'gram.json.xz').read());C=json.load(open(P+'constants.json'))
N=I['N'];n=I['n'];CB=I['CB'];xe=I['xe'];CI=I['CI'];XI=I['XI'];

def dofs(k,deg,boundary):
 offset=1+5*(deg-1)
 local=[]
 # local (i,j,l), i is lambda power, j=a, l=b
 for i in range(deg+1):
  for j in range(deg-i+1):
   l=deg-i-j
   if i==deg:g=0
   elif i==0 and l==0:g=(offset+k) if boundary else -1
   elif i==0 and j==0:g=(offset+(k+1)%5) if boundary else -1
   elif i==0:g=offset+5+k*(deg-1)+j-1 if boundary else -1
   elif l==0:g=1+k*(deg-1)+(i-1)
   elif j==0:g=1+((k+1)%5)*(deg-1)+(i-1)
   else:
    # count interior from previous triangles and prior terms with i,j,l all positive
    inner_count=(deg-1)*(deg-2)//2
    pidx=0
    for i2 in range(1,i):pidx+=max(deg-i2-1,0)
    pidx+=j-1
    st=offset+(5+5*(deg-1) if boundary else 0)
    g=st+k*inner_count+pidx
   local.append(((i,j,l),g))
 return local

def check_map():
 for deg,bdy,coeff in [(N,False,CI),(n,True,XI)]:
  maximum=max(g for k in range(5) for _,g in dofs(k,deg,bdy)); assert maximum+1==len(coeff[0]),(maximum,len(coeff[0]),deg)
check_map()

from math import factorial as fact
@__import__('functools').lru_cache(None)
def tri_moment(a,b):return F(fact(a)*fact(b),fact(a+b+2))
@__import__('functools').lru_cache(None)
def multinomial(i,j,l):return fact(i+j+l)//(fact(i)*fact(j)*fact(l))

def local_poly(k,b,typ):
 deg=N if typ=='u' else n
 co=CI[b] if typ=='u' else XI[b]
 scale=F(1,2**CB) if typ=='u' else F(1,2**(-xe))
 acc=defaultdict(int)
 for (i,j,l),idx in dofs(k,deg,typ=='chi'):
  if idx<0 or co[idx]==0:continue
  q=co[idx]*multinomial(i,j,l)
  for s in range(i+1):
   for t in range(i-s+1):
    sign=-1 if (s+t)%2 else 1
    v=q*sign*fact(i)//(fact(s)*fact(t)*fact(i-s-t))
    acc[(j+s,l+t)]+=v
 return {a:scale*v for a,v in acc.items() if v}

def deriv(poly,i):return {(a[0]-(i==0),a[1]-(i==1)):v*a[i] for a,v in poly.items() if a[i]}
def hpoly(poly):return {a:v/(sum(a)+2) for a,v in poly.items()}
def mul_ab(poly,i):return {(a[0]+(i==0),a[1]+(i==1)):v for a,v in poly.items()}

def bases(k,b):
 u=local_poly(k,b,'u'); ch=local_poly(k,b,'chi');h=hpoly(u)
 return [mul_ab(h,0),mul_ab(h,1),deriv(ch,0),deriv(ch,1),deriv(u,0),deriv(u,1)],u

def integral(a,b):
 # exact triangular monomial integration, sparse 2d convolution
 z=F(0)
 for (i,j),v in a.items():
  for (k,l),w in b.items():z+=v*w*tri_moment(i+k,j+l)
 return z

def bounds(v):return F(v['mid'])-F(v['rad']),F(v['mid'])+F(v['rad'])

def run():
 start=time.time();gram=G['gram'];mass=G['mass'];correct=0;bad=[];A=[]
 idx=[(i*7,i*7) for i in range(6)]+[(0,j*7) for j in range(1,6)]+[(2*7,j*7) for j in range(3,6)]+[(i*7+1,i*7) for i in range(6)]
 print('requested gram entries per triangle',len(idx),flush=True)
 for k in range(5):
  B=[];U=[]
  for b in range(7):
   b6,u=bases(k,b);B.append(b6);U.append(u)
  err=[]
  for i,j in idx:
   ai,bi=divmod(i,7);aj,bj=divmod(j,7)
   val=integral(B[bi][ai],B[bj][aj]); ref=F(gram[k][i][j]);
   if val!=ref:err.append((i,j,str(val),str(ref)))
  for b in range(7):
   val=integral(U[0],U[b]);ref=F(mass[k][0][b]);
   if val!=ref:err.append(('mass',b,str(val),str(ref)))
  print('triangle',k,'gram matches',len(idx)-sum(isinstance(e[0],int) for e in err),'mass matches',7-sum(e[0]=='mass' for e in err),'time',round(time.time()-start,2),flush=True)
  bad+=[(k,*x) for x in err]
  # Independent A0,A1,A2 forms using exact Bernstein-to-monomial integration.
  bb=B[0];u=U[0]
  # Reconstruct geometry from reference vertices, instead of treating linked
  # geometric interval midpoints as if they were independent exact variables.
  cv=[F(q['mid']) for q in C['c']];verts=[(F(0),F(0)),(F(1),F(0)),(cv[0],cv[1]),(cv[2],cv[3]),(cv[4],cv[5])];O=[F(t) for t in I['O']]
  e1=[verts[k][i]-O[i] for i in range(2)];e2=[verts[(k+1)%5][i]-O[i] for i in range(2)]
  n11=sum(u*u for u in e1);n12=sum(e1[i]*e2[i] for i in range(2));n22=sum(u*u for u in e2);det=e1[0]*e2[1]-e1[1]*e2[0]
  a1=det*integral(u,u)
  a0=(n22*integral(bb[4],bb[4])-2*n12*integral(bb[4],bb[5])+n11*integral(bb[5],bb[5]))/det
  # physical flux s=( -det*a*h + d_b chi, -det*b*h - d_a chi)
  s1={k:-det*v for k,v in bb[0].items()}
  for key,v in bb[3].items():s1[key]=s1.get(key,F(0))+v
  s2={k:-det*v for k,v in bb[1].items()}
  for key,v in bb[2].items():s2[key]=s2.get(key,F(0))-v
  a2=(n11*integral(s1,s1)+2*n12*integral(s1,s2)+n22*integral(s2,s2))/det
  A.append((a0,a1,a2))
 print('Total mismatches',len(bad),'examples',bad[:5],flush=True)
 total=[sum(a[t] for a in A) for t in range(3)]
 for t,name in enumerate(['A0','A1','A2']):
  lo,hi=bounds(C['forms_at_c'][name]);print(name,'computed-mid',float(total[t]),'enclosed?',lo<=total[t]<=hi,'delta',float(total[t]-F(C['forms_at_c'][name]['mid'])),flush=True)
 area=sum(F(g['det']['mid']) for g in C['geometry_at_c'])/2
 nu=F(C['KS'])/area
 lamup=total[0]/total[1]
 lamlo=(nu*total[1]-total[0])/(nu*total[2]-total[1])
 eps1sq=(total[0]-lamlo*total[1])/(1-lamup/nu)
 eps0sq=eps1sq/nu
 for nm,value in [('area_c',area),('nu',nu),('lam_up',lamup),('lam_lo',lamlo),('eps1_sq',eps1sq),('eps0_sq',eps0sq)]:
  lo,hi=bounds(C['forms_at_c'][nm]);print(nm,'value_mid_recon',float(value),'inside supplied ball?',lo<=value<=hi,'reference',C['forms_at_c'][nm]['approx'],flush=True)
 print('complete seconds',time.time()-start,flush=True)

if __name__=='__main__':run()

```

## gram_full_modular.py

```python
#!/usr/bin/env python3
"""Independent exact full Gram via modular integer matrix identities and a proven CRT size bound.
Never executes production code. Monomial re-expansion is independently written in independent_b.py.
"""
import sys,time,json,math,functools,lzma
from fractions import Fraction as F
from pathlib import Path
import numpy as np
from sympy import nextprime
sys.path.insert(0,str(Path(__file__).parent))
import independent_b as B

def run():
 t=time.perf_counter();D=(1<<max(B.CB,-B.xe))*math.lcm(*range(2,max(B.N,B.n)+3))
 # largest monomial degree among all basis polynomials; exact 2D monomial representation
 poly=[];poly_mass=[];maxdeg=0
 for k in range(5):
  rows=[];urs=[];per_b=[]
  for b in range(7):
   f,u=B.bases(k,b);per_b.append(f);urs.append(u)
   for x in f+[u]:
    if x:maxdeg=max(maxdeg,max(sum(a) for a in x))
  rows=[per_b[b][i] for i in range(6) for b in range(7)]
  poly.append(rows);poly_mass.append(urs)
 M=(maxdeg*2+2)
 T=math.factorial(M)
 keys=[(i,j) for i in range(maxdeg+1) for j in range(maxdeg+1-i)]
 N=len(keys)
 H=np.empty((N,N),dtype=object)
 for q,(i,j) in enumerate(keys):
  for r,(k,l) in enumerate(keys):
   tot=i+j+k+l+2
   H[q,r]=T//math.factorial(tot)*math.factorial(i+k)*math.factorial(j+l)
 def makevec(polys):
  out=np.zeros((len(polys),N),dtype=object)
  for q,x in enumerate(polys):
   for a,v in x.items():
    vv=v*D
    if vv.denominator!=1:raise ValueError(('not-integer-coef',q,a,vv))
    out[q,keys.index(a)]=int(vv)
  return out
 Ps=[makevec(v) for v in poly]
 Us=[makevec(v) for v in poly_mass]
 common=D*D*T
 refG=B.G['gram'];refM=B.G['mass']
 for k in range(5):
  assert len(Ps[k])==42 and len(Us[k])==7
  for Z,ref in [(Ps[k],refG[k]),(Us[k],refM[k])]:
   rowabs=[sum(abs(int(x)) for x in row) for row in Z]
   Hmax=max(int(x) for row in H for x in row)
   bound=max(rowabs)**2*Hmax
   targetmax=int(max(abs(F(x)*common) for row in ref for x in row))
   assert all((F(x)*common).denominator==1 for row in ref for x in row)
   nbound=(bound+targetmax)*2+1
   print('block',k,'rows',len(Z),'max difference bound bits',nbound.bit_length(),flush=True)
   # Prime product >2 * absolute upper bound on every independent difference.
   modprod=1;primes=[];q=2**22+int(k)*10000+len(Z)*31
   while modprod<=nbound:
    q=int(nextprime(q+1));primes.append(q);modprod*=q
   for prime in primes:
    hmod=np.asarray(H % prime,dtype=np.int64)
    zmod=np.asarray(Z % prime,dtype=np.int64)
    # dimensions <= 171 and primes <2^23 => int64 matmul cannot overflow
    assert prime<(1<<23) and 2*len(keys)*(prime-1)**2<2**63
    left=(zmod @ hmod)%prime
    got=(left @ zmod.T)%prime
    want=np.array([[int((F(x)*common).numerator%prime) for x in row] for row in ref],dtype=np.int64)
    hit=np.argwhere(got!=want)
    if len(hit):
     a,b=map(int,hit[0]);raise AssertionError(('mod-mismatch',k,len(Z),prime,a,b,int(got[a,b]),int(want[a,b])))
   print('PASS',k,'size',len(Z),'primes',len(primes),'CRT_bits',modprod.bit_length(),'checkable entries',len(Z)*(len(Z)+1)//2,'time_sec',round(time.perf_counter()-t,3),flush=True)
 print('FULL_GRAM_PASS',time.perf_counter()-t)
if __name__=='__main__':run()

```

## constants_exact.py

```python
#!/usr/bin/env python3
"""Fully independent algebraic regular-pentagon geometry and LG norm constants, exact Fraction intervals.
Verified Gram entries are consumed as trusted inputs; their independent recomputation is in gram_full_modular.py.
"""
from fractions import Fraction as Q
from math import isqrt
import json,lzma,time
from pathlib import Path
P=Path('/mnt/data/pent21c_audit/PENT21c_cert_3055e81/lines/D-topics/probes/PENT/local_run_20261117/cert')
C=json.load(open(P/'constants.json'));I=json.load(open(P/'inputs.json'))
G=json.load(lzma.open(P/'gram.json.xz','rt'))

class IV:
 def __init__(self,low,hi=None):
  if isinstance(low,IV):self.a,self.b=low.a,low.b
  else:self.a,self.b=Q(low),Q(low if hi is None else hi)
  if self.a>self.b:raise ValueError('reversed')
 def __add__(x,y):
  y=IV(y);return IV(x.a+y.a,x.b+y.b)
 __radd__=__add__
 def __neg__(x):return IV(-x.b,-x.a)
 def __sub__(x,y):return x+(-IV(y))
 def __rsub__(x,y):return IV(y)-x
 def __mul__(x,y):
  y=IV(y);s=[a*b for a in (x.a,x.b) for b in (y.a,y.b)];return IV(min(s),max(s))
 __rmul__=__mul__
 def __truediv__(x,y):
  y=IV(y)
  if y.a*y.b<=0: raise ZeroDivisionError((str(y.a),str(y.b)))
  return x*IV(1/y.b,1/y.a)
 def __rtruediv__(x,y):return IV(y)/x
 def __pow__(x,n):
  assert n>=0 and int(n)==n
  if n==0:return IV(1)
  if n==1:return IV(x)
  if n%2==1:return x*(x**(n-1))
  # for squares nonnegative; higher even exponents repeated via nonnegative enclosure
  if x.a<=0<=x.b: return IV(0,max(abs(x.a),abs(x.b))**n)
  return IV(min(x.a**n,x.b**n),max(x.a**n,x.b**n))
 def mid(x):return (x.a+x.b)/2
 def intersects(x,y):
  y=IV(y);return max(x.a,y.a)<=min(x.b,y.b)
 def included(x,y):
  y=IV(y);return y.a<=x.a<=x.b<=y.b
 def approx(x):return [format(float(x.a),'.17g'),format(float(x.b),'.17g')]

def sqrt_q(q,bits=256):
 q=Q(q); assert q>=0
 top=(q.numerator<<(2*bits))//q.denominator
 n=isqrt(top)
 assert Q(n*n,1<<(2*bits))<=q and Q((n+1)**2,1<<(2*bits))>q
 return IV(Q(n,1<<bits),Q(n+1,1<<bits))
def sqrt_iv(x,bits=256):
 x=IV(x);return IV(sqrt_q(x.a,bits).a,sqrt_q(x.b,bits).b)
def arcv(v):return IV(Q(v['mid'])-Q(v['rad']),Q(v['mid'])+Q(v['rad']))
def rect(k,a,b):return Q(G['gram'][k][a][b])

def run():
 t=time.perf_counter();bits=512
 root5=sqrt_q(5,bits)
 cos=(root5-1)/4
 sin=sqrt_iv(10+2*root5,bits)/4
 c=[1+cos,sin,IV(Q(1,2)),sin/(2*cos),-cos,sin]
 assert len(c)==6
 chk=[]
 for j,x in enumerate(c):
  arch=arcv(C['c'][j]);inside=x.included(arch)
  chk.append(inside)
  print('C',j,'inside_archive',inside,'width_approx',f'{float(x.b-x.a):.3e}','archive_width',f'{float(arch.b-arch.a):.3e}',flush=True)
 assert all(chk)
 vert=[(IV(0),IV(0)),(IV(1),IV(0)),(c[0],c[1]),(c[2],c[3]),(c[4],c[5])]
 orig=[IV(v) for v in I['O']]
 a0=IV(0);a1=IV(0);a2=IV(0);area=IV(0)
 for k in range(5):
  e1=[vert[k][i]-orig[i] for i in range(2)]
  e2=[vert[(k+1)%5][i]-orig[i] for i in range(2)]
  n11=e1[0]*e1[0]+e1[1]*e1[1]
  n12=e1[0]*e2[0]+e1[1]*e2[1]
  n22=e2[0]*e2[0]+e2[1]*e2[1]
  det=e1[0]*e2[1]-e1[1]*e2[0]
  assert det.a>0
  area+=det/2
  gr=lambda u,v:IV(rect(k,u,v))
  ugrad=(n22*gr(28,28)-2*n12*gr(28,35)+n11*gr(35,35))/det
  a0+=ugrad
  a1+=det*Q(G['mass'][k][0][0])
  s11=det*det*gr(0,0)-2*det*gr(0,21)+gr(21,21)
  s22=det*det*gr(7,7)+2*det*gr(7,14)+gr(14,14)
  s12=det*det*gr(0,7)+det*gr(0,14)-det*gr(21,7)-gr(21,14)
  a2+=(n11*s11+2*n12*s12+n22*s22)/det
 ks=IV(C['KS']);nu=ks/area;lamup=a0/a1;lamlo=(nu*a1-a0)/(nu*a2-a1)
 eps1_sq=(a0-lamlo*a1)/(1-lamup/nu)
 eps0_sq=eps1_sq/nu
 vals={'A0':a0,'A1':a1,'A2':a2,'area_c':area,'nu':nu,'lam_up':lamup,'lam_lo':lamlo,'eps1_sq':eps1_sq,'eps0_sq':eps0_sq}
 for k,x in vals.items():
  archive=arcv(C['forms_at_c'][k]);inside=x.included(archive)
  print('FORM',k,'independent',x.approx(),'width',f'{float(x.b-x.a):.4g}','archive_intersects',x.intersects(archive),'in_archive',inside,'delta_mid',float(x.mid()-archive.mid()),'rad',float((archive.b-archive.a)/2),'lo_minus_hi',float(x.a-archive.b),'hi_minus_archlo',float(x.b-archive.a),flush=True)
  if not x.intersects(archive): print('FAIL mismatched archive',k)
 # One-sided tests use the exact rational limits included in constants.json.
 tests={'F_lo':IV(C['F_lo']).a<=lamlo.a*area.a,
        'F_up':IV(C['F_up']).b>=lamup.b*area.b,
        'eps1':IV(C['eps1']).b**2>=eps1_sq.b,
        'eps0':IV(C['eps0']).b**2>=eps0_sq.b}
 for k,ok in tests.items():
  print('ONE_SIDED',k,'PASS' if ok else 'FAIL',flush=True)
  if not ok:
   if k=='F_lo': delta=Q(C['F_lo'])-lamlo.a*area.a
   elif k=='F_up':delta=lamup.b*area.b-Q(C['F_up'])
   elif k=='eps1':delta=eps1_sq.b-Q(C['eps1'])**2
   else:delta=eps0_sq.b-Q(C['eps0'])**2
   print('FAIL delta',float(delta),flush=True)
 print('ELAPSED',time.perf_counter()-t,flush=True)
 print('STATUS', 'PASS' if all(tests.values()) else 'CHANGES',flush=True)
 return tests
if __name__=='__main__':run()

```

## parts_audit.py

```python
#!/usr/bin/env python3
"""Exact integer provenance consistency; not an independent PDE coefficient enclosure."""
from pathlib import Path
from fractions import Fraction as Q
import json,lzma,collections,copy,time
ROOT=Path('/mnt/data/pent21c_audit/PENT21c_cert_3055e81/lines/D-topics/probes/PENT/local_run_20261117/cert')
def load():
 w=json.load(open(ROOT/'witness.json'))
 z=json.load(lzma.open(ROOT/'parts.json.xz','rt'))
 return w,z

def check(w,z):
 p=z['parts']; tm=w['Tm']; em=w['Em']; scale=1<<w['gbits']
 assert w['gbits']==z['gbits'] and set(p)==set(em)
 ok=0;err=[];degrees=collections.Counter();tight=collections.Counter();breakpoints=collections.Counter()
 for a, (kr,el,eq,sh,t) in p.items():
  ex=tuple(map(int,a.split(',')));deg=sum(ex)
  S=kr+el+eq+sh;E=Q(em[a])*scale
  valid=kr>=0 and el>=0 and eq>=0 and sh>=0 and t==(1 if deg<=3 else 0) and S-3<=E<=S+1
  if valid:ok+=1
  else:err.append((a,S,str(E),t))
  degrees[deg]+=1;tight[t]+=1
  breakpoints[max(range(4),key=lambda i:(kr,el,eq,sh)[i])]+=1
 assert set(tm).issubset(set(em))
 print('PARTS_TOTAL',len(p),'PASS',ok,'FAIL',len(err),'SAMPLES',err[:5]);print('DEG_COUNTS',sorted(degrees.items()));print('TIGHT',dict(tight),'DOMINANT_ERROR',dict(breakpoints))
 return ok==len(p) and not err
if __name__=='__main__':
 w,z=load();assert check(w,z)
 ww=copy.deepcopy(w);first=next(iter(ww['Em']));ww['Em'][first]='0'
 assert not check(ww,z);print('TAMPER_EM_ZERO_REJECTED',first)
 zz=copy.deepcopy(z);aa=next(iter(zz['parts']));zz['parts'][aa][1]+=1<<180
 assert not check(w,zz);print('TAMPER_PARTS_REJECTED',aa)

```

## tamper_3.py

```python
#!/usr/bin/env python3
"""Three fail-closed counterfactuals, independent from producer tests."""
import sys,copy,json,lzma
from fractions import Fraction as F
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
import independent_b as B
from parts_audit import load,check

def tamper_input():
 # change a global degree-16 basis coefficient actually used by triangle 0
 p0,g=next((p,g) for p,g in B.dofs(0,B.N,False) if g>=0 and B.CI[0][g]!=0)
 orig=B.CI[0][g];base=B.integral(B.local_poly(0,0,'u'),B.local_poly(0,0,'u'))
 assert base==F(B.G['mass'][0][0][0])
 B.CI[0][g]+=1<<40
 mutated=B.integral(B.local_poly(0,0,'u'),B.local_poly(0,0,'u'))
 B.CI[0][g]=orig
 assert mutated!=F(B.G['mass'][0][0][0]),'failed to detect changed input'
 print('TAMPER_INPUT_REJECTED',g,'mass_diff',float(mutated-base))

def tamper_fup():
 ff=F(B.C['F_lo']);lam=B.C['forms_at_c']['lam_up'];ar=B.C['forms_at_c']['area_c']
 inf=(F(lam['mid'])-F(lam['rad']))*(F(ar['mid'])-F(ar['rad']))
 assert ff<inf
 print('TAMPER_FUP_REJECTED',float(inf-ff))

def tamper_em():
 w,p=load();ww=copy.deepcopy(w);k=next(iter(ww['Em']));ww['Em'][k]='0'
 assert not check(ww,p)
 print('TAMPER_EM_ZERO_REJECTED',k)
if __name__=='__main__':tamper_input();tamper_fup();tamper_em();print('THREE_TAMPERS_PASS')

```

## independent_k_all.py

```python
#!/usr/bin/env python3
"""Independent six-variable all-degree explicit D*K enclosure.
Uses a homegrown fixed-point integer interval polynomial ring. No production imports.
Read-only package coefficients are used only for exact reference integrals and comparison.
"""
import sys,time,json,lzma,math,itertools,collections
from pathlib import Path
from fractions import Fraction as Q
import constants_exact as CE
ROOT=CE.P
B=192;UNIT=1<<B; ZERO=(0,)*6

def fl(x):return x//UNIT

def ceildiv(a,b):return -((-a)//b)
class V:
 __slots__=('l','h')
 def __init__(self,x=0,y=None, raw=False):
  if isinstance(x,V):self.l=x.l;self.h=x.h;return
  if raw:self.l=int(x);self.h=int(y);return
  if isinstance(x,CE.IV):
   x,y=x.a,x.b
  elif y is None:y=x
  x=Q(x);y=Q(y)
  self.l=(x.numerator*UNIT)//x.denominator
  self.h=ceildiv(y.numerator*UNIT,y.denominator)
  assert self.l<=self.h
 @classmethod
 def raw(cls,l,h):return cls(l,h,True)
 def __add__(x,y):
  y=V(y);return V.raw(x.l+y.l,x.h+y.h)
 __radd__=__add__
 def __neg__(x):return V.raw(-x.h,-x.l)
 def __sub__(x,y):return x+-V(y)
 def __rsub__(x,y):return V(y)+-x
 def __mul__(x,y):
  y=V(y);prod=(x.l*y.l,x.l*y.h,x.h*y.l,x.h*y.h)
  return V.raw(min(prod)//UNIT,ceildiv(max(prod),UNIT))
 __rmul__=__mul__
 def reciprocal(x):
  assert x.l*x.h>0,(x.l,x.h)
  return V.raw(UNIT*UNIT//x.h,ceildiv(UNIT*UNIT,x.l))
 def __truediv__(x,y):return x*V(y).reciprocal()
 def __rtruediv__(x,y):return V(y)/x
 def __abs__(x):return V.raw(0,max(abs(x.l),abs(x.h)))
 def mid(x):return Q(x.l+x.h,2*UNIT)
 def rad(x):return Q(x.h-x.l,2*UNIT)
 def upperabs(x):return Q(max(abs(x.l),abs(x.h)),UNIT)
 def f(x):return (x.l+x.h)/(2*UNIT)

def asv(x):return x if isinstance(x,V) else V(x)

class Poly:
 __slots__=('d',)
 def __init__(self,x=0):
  if isinstance(x,Poly):self.d=x.d.copy()
  elif isinstance(x,dict):self.d={k:asv(v) for k,v in x.items() if not (asv(v).l==0 and asv(v).h==0)}
  else:
   v=asv(x);self.d={ZERO:v} if (v.l or v.h) else {}
 @classmethod
 def var(cls,i):
  e=[0]*6;e[i]=1;return cls({tuple(e):V(1)})
 def __add__(x,y):
  y=Poly(y);out=x.d.copy()
  for k,v in y.d.items():out[k]=out.get(k,V(0))+v
  return Poly(out)
 __radd__=__add__
 def __neg__(x):return Poly({k:-v for k,v in x.d.items()})
 def __sub__(x,y):return x+-Poly(y)
 def __rsub__(x,y):return Poly(y)-x
 def __mul__(x,y):
  y=Poly(y);out={}
  if len(x.d)>len(y.d):x,y=y,x
  for a,va in x.d.items():
   for b,vb in y.d.items():
    t=tuple(a[i]+b[i] for i in range(6));val=va*vb
    out[t]=out[t]+val if t in out else val
  return Poly(out)
 __rmul__=__mul__
 def __truediv__(x,y):return x*asv(y).reciprocal()
 def __pow__(x,n):
  assert int(n)==n and n>=0
  z=Poly(1)
  for _ in range(n):z=z*x
  return z
 def upabs(x):return {k:v.upperabs() for k,v in x.d.items()}

def gweight(g,k,w):
 # matrix of seven lists by seven lists, weighted function pairing between block I and block J
 out=Poly(0)
 for b in range(7):
  for c in range(7):
   x=Q(g[b][c])
   if x:out=out+w[b]*w[c]*V(x)
 return out

def run(f0_override=None,save=True):
 t0=time.perf_counter();inp=json.load(open(ROOT/'inputs.json'));cc=json.load(open(ROOT/'constants.json'))
 gg=json.load(lzma.open(ROOT/'gram.json.xz','rt'))['gram'];witness=json.load(open(ROOT/'witness.json'))
 raw=json.load(lzma.open(ROOT/'parts.json.xz','rt'))['parts']
 c0=CE.sqrt_q(5,512);cos=(c0-1)/4;sin=CE.sqrt_iv(10+2*c0,512)/4
 c=[V(1+cos),V(sin),V(Q(1,2)),V(sin/(2*cos)),V(-cos),V(sin)]
 cp=[V(x) for x in inp['Cq']];eta=[c[i]-cp[i] for i in range(6)]
 w=[Poly(1)]+[Poly.var(i)-Poly(eta[i]) for i in range(6)]
 O=[V(q) for q in inp['O']];z=[Poly(cp[i])+Poly.var(i) for i in range(6)]
 vt=[(Poly(0),Poly(0)),(Poly(1),Poly(0)),(z[0],z[1]),(z[2],z[3]),(z[4],z[5])]
 ge=[]
 for k in range(5):
  a=[vt[k][i]-Poly(O[i]) for i in range(2)];b=[vt[(k+1)%5][i]-Poly(O[i]) for i in range(2)]
  n11=a[0]*a[0]+a[1]*a[1];n12=a[0]*b[0]+a[1]*b[1];n22=b[0]*b[0]+b[1]*b[1];det=a[0]*b[1]-a[1]*b[0]
  ge.append((n11,n12,n22,det))
 gc=[];vc=[(V(0),V(0)),(V(1),V(0)),(c[0],c[1]),(c[2],c[3]),(c[4],c[5])]
 for k in range(5):
  a=[vc[k][i]-O[i] for i in range(2)];b=[vc[(k+1)%5][i]-O[i] for i in range(2)]
  gc.append((a[0]*a[0]+a[1]*a[1],a[0]*b[0]+a[1]*b[1],b[0]*b[0]+b[1]*b[1],a[0]*b[1]-a[1]*b[0]))
 A=sum((g[3] for g in ge),Poly(0))*V(Q(1,2));Ac=sum((g[3] for g in gc),V(0))/V(2)
 D=Poly(1)
 for _,_,_,d in ge:D=D*d
 Dh=[]
 for k in range(5):
  q=Poly(1)
  for j in range(5):
   if j!=k:q=q*ge[j][3]
  Dh.append(q)
 Flo=Q(cc['F_lo']);Fup=Q(cc['F_up']);F0=V(Flo,Fup) if f0_override is None else V(f0_override);K=V(cc['KS']);pf=Ac/F0
 mass=Poly(0);grads=[];flux=[];X=Poly(0);Y=Poly(0)
 for k in range(5):
  g=gg[k];gm=json.load(lzma.open(ROOT/'gram.json.xz','rt'))['mass'][k] if False else None
  def norm(i,j):
   mat=[[g[7*i+b][7*j+c] for c in range(7)] for b in range(7)]
   return gweight(mat,k,w)
  n11,n12,n22,det=ge[k]
  # Build only required pairings; group blocks are indexed I*7+b
  p={}
  need=[(i,j) for i,j in itertools.combinations_with_replacement(range(6),2)]
  for i,j in need:p[(i,j)]=norm(i,j)
  def n(i,j):return p[(min(i,j),max(i,j))]
  m=json.load(lzma.open(ROOT/'gram.json.xz','rt'))['mass'][k] if False else None
  # weighted mass form is computed separately once below
  grad=n22*n(4,4)-2*n12*n(4,5)+n11*n(5,5)
  s11=det*det*n(0,0)-2*det*n(0,3)+n(3,3)
  s22=det*det*n(1,1)+2*det*n(1,2)+n(2,2)
  s12=det*det*n(0,1)+det*n(0,2)-det*n(1,3)-n(2,3)
  fl=n11*s11+2*n12*s12+n22*s22
  grads.append(grad);flux.append(fl)
  print('prepared triangle',k,'sec',round(time.perf_counter()-t0,2),flush=True)
 # compute all weighted mass forms using the archived gram mass (already independently checked)
 gm=json.load(lzma.open(ROOT/'gram.json.xz','rt'))['mass']
 for k in range(5):
  mass=mass+ge[k][3]*gweight(gm[k],k,w)
 KD=D*A*(Poly(K)+Poly(F0))*mass
 for k in range(5):
  KD=KD-A*A*Dh[k]*grads[k]-Poly(F0*K)*Dh[k]*flux[k]
 print('base D Psi assembled',len(KD.d),round(time.perf_counter()-t0,2),flush=True)
 # Rho_c m-field independent construction from exact flux of tilde u at c.
 for k in range(5):
  n11c,n12c,n22c,dc=gc[k]
  Ma={0:-dc,3:V(1),4:-(Ac/F0)*(n22c/dc),5:(Ac/F0)*(n12c/dc)}
  Mb={1:-dc,2:V(-1),4:(Ac/F0)*(n12c/dc),5:-(Ac/F0)*(n11c/dc)}
  # The second part of correction contains constant gram of m0 fields, and cross1 is linear in w.
  g=gg[k]
  def cross(i,coefs):
   f=Poly(0)
   for b in range(7):
    s=V(0)
    for j,v in coefs.items():s+=v*V(Q(g[i*7+b][j*7]))
    if s.l or s.h:f+=w[b]*Poly(s)
   return f
  def mcross(u,v):
   s=V(0)
   for i,ui in u.items():
    for j,vj in v.items():s+=ui*vj*V(Q(g[i*7][j*7]))
   return s
  n11,n12,n22,det=ge[k]
  xs1a=-det*cross(0,Ma)+cross(3,Ma)
  xs2a=-det*cross(1,Ma)-cross(2,Ma)
  xs1b=-det*cross(0,Mb)+cross(3,Mb)
  xs2b=-det*cross(1,Mb)-cross(2,Mb)
  ga=cross(4,Ma);gb=cross(5,Mb)
  rho_nm=n11*xs1a+n12*xs2a+n12*xs1b+n22*xs2b
  rho_grad=ga+gb
  correction=2*Poly(F0*K)*Dh[k]*rho_nm-2*Poly(K)*D*A*rho_grad
  tail=n11*Poly(mcross(Ma,Ma))+2*n12*Poly(mcross(Ma,Mb))+n22*Poly(mcross(Mb,Mb))
  KD=KD+correction-Poly(F0*K)*Dh[k]*tail
  print('cross correction',k,'coeffs',len(KD.d),'sec',round(time.perf_counter()-t0,2),flush=True)
 # Direct degreewise necessary consistency tests for the computed K enclosure.
 ok_center=ok_Krad=ok_envelope=0;bad=[];errors=[];by_degree=collections.defaultdict(lambda:[0,0,0])
 bit=witness['gbits'];den=1<<bit
 for ky,(kr,el,eq,sh,t) in raw.items():
  a=tuple(map(int,ky.split(',')));vv=KD.d.get(a,V(0))
  cen=Q(witness['Tm'].get(ky,'0'));allowed=Q(kr,den)
  ck=abs(vv.mid()-cen);rr=vv.rad();d=sum(a)
  by_degree[d][0]+=1
  if ck<=allowed:ok_center+=1;by_degree[d][1]+=1
  if ck+rr<=allowed:ok_Krad+=1;by_degree[d][2]+=1
  if ck+rr<=Q(witness['Em'][ky]):ok_envelope+=1
  if ck+rr>allowed:bad.append((ky,float(ck),float(rr),float(allowed)))
  if ck+rr>Q(witness['Em'][ky]):errors.append((ky,float(ck+rr),float(Q(witness['Em'][ky]))))
 print('K_COUNTS','coeff',len(KD.d),'archive',len(raw),'centres_inside_Krad',ok_center,'K_interval_inside_Krad',ok_Krad,'K_within_total_Em',ok_envelope)
 print('DEGREE_BREAKDOWN',dict(by_degree),'Krad_fail_examples',bad[:12],'Em_fail_examples',errors[:12],flush=True)
 # compare deg 0,1 with exact archives lowdeg
 ref=json.load(open(ROOT/'lowdeg.json'))
 for key,r in ref.items():
  a=tuple(map(int,key.split(',')))
  if sum(a)>2:continue
  v=KD.d.get(a,V(0));k=Q(r['K_mid']);d=abs(v.mid()-k)+v.rad();rad=Q(r['K_rad']);print('LOWDEG',key,'distance',float(d),'archive K_rad',float(rad),'PASS' if d<=rad else 'WIDER',flush=True)
 print('ELAPSED',time.perf_counter()-t0,flush=True)
 # Save sparse independent computable K′ central coefficients and error interval as exact dyadics.
 if save:
  out=Path('/mnt/data/pent21c_audit/delivery/logs/independent_K_coeffs.json.xz')
  payload={','.join(map(str,a)):[str(Q(v.l,UNIT)),str(Q(v.h,UNIT))] for a,v in KD.d.items()}
  with lzma.open(out,'wt') as f:json.dump(payload,f)
  print('COEFFS_FILE',out,'bytes',out.stat().st_size)
 return dict(inp=inp,cc=cc,gg=gg,gm=gm,witness=witness,raw=raw,c=c,cp=cp,eta=eta,w=w,ge=ge,gc=gc,A=A,Ac=Ac,D=D,Dh=Dh,F0=F0,K=K, KD=KD)
if __name__=='__main__':run()

```

## laurent_refine.py

```python
#!/usr/bin/env python3
"""Rigorous Laurent dependency cancellation in the one-dimensional unknown F0.
For D*K and D*Lambda/Theta, algebra shows each scalar coefficient has form aF+b+c/F.
Three exact anchor values reconstruct a,b,c as outward dyadic intervals.  This is
NOT a floating-point interpolation: every division, addition and multiplication
is performed with rationally enclosed integer intervals.
"""
from fractions import Fraction as Q
import contextlib,io,json,lzma,time,sys,collections
from pathlib import Path
import independent_k_all as A
from independent_k_all import V,Poly,UNIT
from independent_B_full_attempt import make_field
P=A.ROOT

def laurent(yminus,y0,yplus,fmid,Factual):
 # c(F) = a*F + b + c/F.  This is a structural algebraic identity,
 # not a numerical approximation; F0 is positive by certificate.
 xm=V(fmid);fm=V(fmid-1);fp=V(fmid+1)
 gm=fm*yminus;g0=xm*y0;gp=fp*yplus
 aa=(gm-2*g0+gp)/2
 bb=(gp-gm)/2-2*xm*aa
 cc=g0-xm*xm*aa-xm*bb
 return y0+(Factual-xm)*(aa-cc/(Factual*xm))

def interpolate_3(Vminus,Vmid,Vplus,fmid,Factual):
 out={}
 for a in set(Vminus)|set(Vmid)|set(Vplus):
  va=Vminus.get(a,V(0));vb=Vmid.get(a,V(0));vc=Vplus.get(a,V(0))
  out[a]=laurent(va,vb,vc,fmid,Factual)
 return out

def run():
 t=time.perf_counter();u=json.load(open(P/'constants.json'));fmid=(Q(u['F_lo'])+Q(u['F_up']))/2
 states=[]
 for f in [fmid-1,fmid,fmid+1]:
  with contextlib.redirect_stdout(io.StringIO()):st=A.run(f0_override=f,save=False)
  states.append(st)
  print('anchor',float(f),'elapsed',time.perf_counter()-t,flush=True)
 Factual=V(Q(u['F_lo']),Q(u['F_up']))
 kd=[s['KD'].d for s in states]; Kref=Poly(interpolate_3(*kd,fmid,Factual))
 w=states[1]['witness'];parts=states[1]['raw'];passK=passEm=0;bad=[];bydeg=collections.defaultdict(lambda:[0,0])
 for k,(kr,ell,eq,sh,tight) in parts.items():
  a=tuple(map(int,k.split(',')));q=Kref.d.get(a,V(0));t=Q(w['Tm'].get(k,'0'));rad=Q(kr,1<<160);r=q.rad()+abs(q.mid()-t)
  aK=r<=rad+Q(1,1<<160)
  bK=r<=Q(w['Em'][k]);passK+=aK;passEm+=bK;d=sum(a);bydeg[d][0]+=1;bydeg[d][1]+=aK
  if not bK and len(bad)<20:bad.append((k,float(r),float(Q(w['Em'][k]))))
 print('K_REFINED',passK,'of',len(parts),'K_part_PLUS_rounding', 'INSIDE_Em',passEm,'bydegree',dict(bydeg),'bad',bad[:7],flush=True)
 print('K_128_WIDTH',[(k,float(Kref.d[tuple(map(int,k.split(',')))].rad())) for k in list(parts)[:4]],flush=True)
 fields=[]
 for s in states:
  fs=[]
  for k in range(5):fs.append(make_field(k,s))
  fields.append(fs)
  print('field',len(fields),'elapsed',time.perf_counter()-t,flush=True)
 improved=[];count=0
 for k in range(5):
  q=[]
  for component in range(4):
   fs=[fields[i][k][component] for i in range(3)]
   cmp={}
   for basis in set(fs[0])|set(fs[1])|set(fs[2]):
    polys=[f.get(basis,Poly(0)).d for f in fs]
    cmp[basis]=Poly(interpolate_3(*polys,fmid,Factual))
   q.append(cmp)
   count+=sum(len(p.d) for p in cmp.values())
  improved.append(tuple(q))
  print('field refine',k,'count',count,'elapsed',time.perf_counter()-t,flush=True)
 print('REFINE_DONE',time.perf_counter()-t)
 return states[1],Kref,improved
if __name__=='__main__':run()

```

## independent_B_full_attempt.py

```python
#!/usr/bin/env python3
"""Independent complete coefficient-bounds attempt: D*K, dual linear residual, q and translation.
All decisions exact dyadic or Fraction; independently implements a rigorous (often looser) majorant.
No user/producer code imported or executed. Level B is FULL only if inclusion or Level A reproof succeeds.
"""
import sys,json,math,time,itertools,collections,lzma
from pathlib import Path
from fractions import Fraction as Q
from functools import lru_cache
import independent_k_all as A
from independent_k_all import V,Poly,UNIT,ZERO
import constants_exact as CE

@lru_cache(None)
def sqrtup(q):
 q=Q(q)
 if q==0:return Q(0)
 assert q>0
 return CE.sqrt_q(q,256).b

def qceil(q,shift=160):
 q=Q(q);n=1<<shift;return Q(-((-q.numerator*n)//q.denominator),n)

class Pos:
 __slots__=('d',)
 def __init__(self,z=0):
  if isinstance(z,Pos):self.d=z.d.copy()
  elif isinstance(z,dict):self.d={k:Q(v) for k,v in z.items() if v}
  else:
   zz=Q(z);self.d={ZERO:zz} if zz else {}
 def __add__(x,y):
  y=Pos(y);r=x.d.copy()
  for a,v in y.d.items():r[a]=r.get(a,Q(0))+v
  return Pos(r)
 __radd__=__add__
 def __mul__(x,y):
  y=Pos(y);v={}
  if len(x.d)>len(y.d):x,y=y,x
  for a,t in x.d.items():
   for b,u in y.d.items():
    ky=tuple(a[i]+b[i] for i in range(6));v[ky]=v.get(ky,Q(0))+t*u
  return Pos(v)
 __rmul__=__mul__
 def __pow__(x,n):
  z=Pos(1)
  for _ in range(n):z=z*x
  return z
 def shift_all(x,h):
  h=Q(h);d=x.d.copy()
  for i in range(6):
   nex={}
   for a,v in d.items():
    for j in range(a[i]+1):
     b=list(a);b[i]=j;ky=tuple(b)
     nex[ky]=nex.get(ky,Q(0))+v*math.comb(a[i],j)*h**(a[i]-j)
   d=nex
  return Pos(d)

def maj(p):return Pos({a:v.upperabs() for a,v in p.d.items()})

def join(a,b):
 z=a.copy()
 for i,p in b.items():z[i]=z.get(i,Poly(0))+p
 return z

def fieldscale(v,p):return {i:p*x for i,x in v.items()}
def fieldadd(*args):
 z={}
 for field in args:z=join(z,field)
 return z

def Fmat_coefs(G,vec):
 # coefficients in the 42-variable basis; original free list basis has b=0..6
 out={}
 for i,v in vec.items():
  for j in range(42):
   gg=Q(G[j][i])
   if gg:out[j]=out.get(j,V(0))+V(gg)*v
 return out

def fpoly(field,ma):
 # for phi_I list field: phi_{I, b} from package gram; coefficient 0 maps to poly directly
 return field

def sqrtGramDiag(G):return [sqrtup(Q(G[i][i])) for i in range(42)]

def make_field(k,st):
 n11,n12,n22,det=st['ge'][k]
 nc11,nc12,nc22,dc=st['gc'][k];D=st['D'];Dh=st['Dh'][k]
 Aarea=st['A'];Ac=st['Ac'];F0=st['F0'];K=st['K'];w=st['w']
 pf=Aarea/F0
 Mc11=nc22/dc;Mc12=-(nc12/dc);Mc22=nc11/dc
 # m=M_c rho_c is independent of list b>=1.
 Ma={0:-dc,21:V(1),28:-(Ac/F0)*(nc22/dc),35:(Ac/F0)*(nc12/dc)}
 Mb={7:-dc,14:V(-1),28:(Ac/F0)*(nc12/dc),35:-(Ac/F0)*(nc11/dc)}
 grad1={28+b:w[b] for b in range(7)}
 grad2={35+b:w[b] for b in range(7)}
 s1={b:-det*w[b] for b in range(7)}
 s1.update({21+b:w[b] for b in range(7)})
 s2={7+b:-det*w[b] for b in range(7)}
 s2.update({14+b:-w[b] for b in range(7)})
 rn1=fieldadd(fieldscale(s1,n11),fieldscale(s2,n12),fieldscale(grad1,-det*pf))
 rn2=fieldadd(fieldscale(s1,n12),fieldscale(s2,n22),fieldscale(grad2,-det*pf))
 # det M_z rho_z = det*s - pf * Mnum * grad
 dma=fieldadd(fieldscale(s1,det),fieldscale(grad1,-n22*pf),fieldscale(grad2,n12*pf))
 dmb=fieldadd(fieldscale(s2,det),fieldscale(grad1,n12*pf),fieldscale(grad2,-n11*pf))
 dna=fieldadd(fieldscale({i:Poly(x) for i,x in Ma.items()},n11),fieldscale({i:Poly(x) for i,x in Mb.items()},n12))
 dnb=fieldadd(fieldscale({i:Poly(x) for i,x in Ma.items()},n12),fieldscale({i:Poly(x) for i,x in Mb.items()},n22))
 kl=K*Ac/F0
 lc=fieldadd(fieldscale(rn1,Poly(Mc11)),fieldscale(rn2,Poly(Mc12)))
 lb=fieldadd(fieldscale(rn1,Poly(Mc12)),fieldscale(rn2,Poly(Mc22)))
 tc=fieldadd(fieldscale(dna,Poly(Mc11)),fieldscale(dnb,Poly(Mc12)))
 tb=fieldadd(fieldscale(dna,Poly(Mc12)),fieldscale(dnb,Poly(Mc22)))
 factor=2*Poly(F0)*Dh
 La=fieldscale(fieldadd(fieldscale(lc,Poly(kl)),fieldscale(dma,-Aarea),fieldscale(tc,-Poly(kl))),factor)
 Lb=fieldscale(fieldadd(fieldscale(lb,Poly(kl)),fieldscale(dmb,-Aarea),fieldscale(tb,-Poly(kl))),factor)
 pre=-2*Poly(F0*K)*Dh*(det-Poly(dc))
 Ta=fieldscale(fieldadd(rn1,fieldscale(dna,Poly(-1))),pre)
 Tb=fieldscale(fieldadd(rn2,fieldscale(dnb,Poly(-1))),pre)
 return La,Lb,Ta,Tb

def metric_support(k,st):
 n11,n12,n22,det=st['gc'][k]
 N11=n11/det;N12=n12/det;N22=n22/det
 # upper bound of lambda_max(N) from infinity norm
 mn=max(N11.upperabs()+N12.upperabs(),N22.upperabs()+N12.upperabs())
 return sqrtup(mn), sqrtup(Q(1,1)/Q(det.l,UNIT)),N11,N12,N22

def norm_field_coeff(field,a,diag):
 # field[k] poly field; at exponent a
 return sum(p.d.get(a,V(0)).upperabs()*diag[j] for j,p in field.items())

def exact_bilinear(g,x,y):
 out=Q(0)
 if len(x)>len(y):x,y=y,x
 for j,v in x.items():
  for k,z in y.items():
   gr=Q(g[j][k]);
   if gr:out+=v*z*gr
 return out

def exact_tight_norm(a,fields,st,idx):
 # Return rigorous upper NL, NT for a single α, independent in mid and coefficient error.
 # Tight formulation: mid Gram quadratic plus coefficient radii times diagonal Gram.
 Na=Q(0);Nt=Q(0)
 for k, (La,Lb,Ta,Tb) in enumerate(fields):
  g=st['gg'][k];diag=sqrtGramDiag(tuple(map(tuple,g)))
  nr,sindet,N11,N12,N22=metric_support(k,st)
  def midrad(f):
   vec={};rad=Q(0)
   for j,p in f.items():
    v=p.d.get(a,V(0));
    if v.l or v.h:
     vec[j]=v.mid();rad+=v.rad()*diag[j]
   return vec,rad
  x,rx=midrad(La);y,ry=midrad(Lb);u,ru=midrad(Ta);v,rv=midrad(Tb)
  # mid metrics using exact rational Q of dyadic mid, interval-metric correction
  xx=exact_bilinear(g,x,x);yy=exact_bilinear(g,y,y);xy=exact_bilinear(g,x,y)
  nmid=N11.mid()*xx+2*N12.mid()*xy+N22.mid()*yy
  ne=abs(xx)*N11.rad()+2*abs(xy)*N12.rad()+abs(yy)*N22.rad()
  un=sqrtup(max(nmid+ne,Q(0)))+nr*(rx+ry)
  uu=exact_bilinear(g,u,u);vv=exact_bilinear(g,v,v)
  tun=sqrtup(max(uu+vv,Q(0)))*sindet+(ru+rv)*sindet
  Na+=un*un;Nt+=tun*tun
 return sqrtup(Na),sqrtup(Nt)

def quadratic_majorant(st):
 D=st['D'];Aarea=st['A'];K=st['K'];Fup=Q(st['cc']['F_up']);e0=Q(st['cc']['eps0'])**2;e1=Q(st['cc']['eps1'])**2;Fl=Q(st['cc']['F_lo'])
 Qq=Pos(0)
 for k in range(5):
  n11,n12,n22,det=st['ge'][k];n11c,n12c,n22c,dc=st['gc'][k]
  detmin=Q(dc.l,UNIT);detmax=Q(dc.h,UNIT)
  # M_c has determinant exactly one. Thus 1/lambda_min(M_c) = lambda_max(N_c) <= (n11+n22)/det_c
  normN=(n11c.upperabs()+n22c.upperabs())/detmin
  normM=(n11c.upperabs()+n22c.upperabs())/detmin
  # M_c and N_c both have trace (n11+n22)/det_c and determinant 1
  Gk=e1*normN
  Gamma=normM*e1*(Q(st['Ac'].h,UNIT)/Fl)**2
  Y=e0/(4*detmin)
  s3=maj(n11)+maj(n22)+maj(n12)
  dd=maj(det-Poly(dc))
  # Conservative bound on physical tensor using the spectral row-sum upper majorant.
  t1=maj(D)*maj(Aarea)*maj(det)*(Q(st['cc']['KS'])+Fup)*e0/detmin if False else None
  Qq=Qq + maj(D)*maj(Aarea)*maj(det)*((Q(st['cc']['KS'])+Fup)*e0/detmin)
  Qq=Qq + maj(Aarea)**2*maj(st['Dh'][k])*s3*Gk
  Qq=Qq + maj(st['Dh'][k])*s3*Fup*Q(st['cc']['KS'])*(Pos(Gamma)+dd*(2*sqrtup(Gamma*Y))+dd**2*Y)
 return Qq

def run(refinement=None):
 t0=time.perf_counter();st=A.run() if refinement is None else refinement[0]
 if refinement is not None: st['KD']=refinement[1]
 fields=[];ml=collections.defaultdict(Q);low={};K=st['K'];Fup=Q(st['cc']['F_up']);eps1=Q(st['cc']['eps1']);eps0=Q(st['cc']['eps0'])
 for k in range(5):
  fs=make_field(k,st) if refinement is None else refinement[2][k];fields.append(fs)
  diag=sqrtGramDiag(tuple(map(tuple,st['gg'][k])));nr,rs,N11,N12,N22=metric_support(k,st)
  for jj,f in enumerate(fs):
   fac=(eps1*nr) if jj<2 else (eps0*rs/2)
   for b,p in f.items():
    dg=diag[b]*fac
    for a,v in p.d.items():
     ml[a]+=v.upperabs()*dg
  print('LINEAR k',k,'elapsed',round(time.perf_counter()-t0,3),'entries',len(ml),flush=True)
 E_lin=Pos(ml)
 for a in [tuple(int(x) for x in kk.split(',')) for kk in st['raw'] if sum(int(x) for x in kk.split(',')) in (2,3)]:
  na,nt=exact_tight_norm(a,fields,st,0)
  low[a]=eps1*na+eps0*nt/2
 print('TIGHT',len(low),'sec',time.perf_counter()-t0,flush=True)
 Mq=quadratic_majorant(st)
 print('QUAD',len(Mq.d),'sec',time.perf_counter()-t0,flush=True)
 Bmaj=maj(st['KD'])+E_lin+Mq
 HB=Q(st['cc']['HB']);HS=Q(st['cc']['HS'])
 shifted=Bmaj.shift_all(HS)
 shift=Pos({a:(v-Bmaj.d.get(a,Q(0)))*HB/HS for a,v in shifted.d.items() if v-Bmaj.d.get(a,Q(0))>0})
 print('SHIFT',len(shift.d),'sec',time.perf_counter()-t0,flush=True)
 w=st['witness'];passed=0;bad=[];tm={};em={};degree=collections.defaultdict(lambda:[0,0]);maxrelative=(Q(0),None)
 for key,v in w['Em'].items():
  a=tuple(map(int,key.split(',')));deg=sum(a)
  Kc=st['KD'].d.get(a,V(0));m=Kc.mid();r=Kc.rad();e1=low.get(a,E_lin.d.get(a,Q(0)))
  e=r+e1+Mq.d.get(a,Q(0))+shift.d.get(a,Q(0)); ref=Q(w['Tm'].get(key,'0'));er=Q(v)
  inc=abs(m-ref)+e<=er
  passed+=inc;degree[deg][0]+=1;degree[deg][1]+=inc
  if not inc and len(bad)<200:bad.append((key,float(m-ref),float(e),float(er),float(e1),float(Mq.d.get(a,Q(0))),float(shift.d.get(a,Q(0)))))
  tm[a]=m;em[a]=e
  if er>0 and (abs(m-ref)+e)/er>maxrelative[0]:maxrelative=((abs(m-ref)+e)/er,key)
 print('INCLUSION',passed,'/',len(w['Em']),'FAIL',len(w['Em'])-passed,'MAX_RATIO',float(maxrelative[0]),maxrelative[1],'BREAKDOWN',dict(degree),'EXAMPLES',bad[:12],flush=True)
 # For the required vanishing constant and gradient, compute independent strict errors including shifts.
 lowzero=[]
 for key,ref in json.load(open(CE.P/'lowdeg.json')).items():
  a=tuple(map(int,key.split(',')))
  if sum(a)>1:continue
  kd=st['KD'].d.get(a,V(0));bound=kd.upperabs()+E_lin.d.get(a,Q(0))+Mq.d.get(a,Q(0))+shift.d.get(a,Q(0))
  lowzero.append((key,float(bound),float(kd.upperabs())))
 print('LOW_DEG',lowzero,flush=True)
 # Own rounded rational enclosure for a conditional reproof attempt; conservatively round to same 2^-160 grid.
 tk={','.join(map(str,a)):str(qceil(v*0+tm[a])) for a,v in tm.items()}
 # centers exact dyadic, and error = actual bound + rounding gap to stored centre
 ownTm={};ownEm={}
 for a,m in tm.items():
  kk=','.join(map(str,a));v=Q(round(m*(1<<160)),1<<160)
  ownTm[kk]=str(v)
  ownEm[kk]=str(qceil(em[a]+abs(m-v)))
 out=Path('/mnt/data/pent21c_audit/delivery/logs/own_levelB_enclosure_refined.json.xz' if refinement is not None else '/mnt/data/pent21c_audit/delivery/logs/own_levelB_enclosure.json.xz')
 with lzma.open(out,'wt') as f:json.dump({'Tm':ownTm,'Em':ownEm,'gbits':160,'rho_in':str(Q(1,128))},f)
 print('OWN_ENCLOSURE_SAVED',out.stat().st_size,'elapsed',time.perf_counter()-t0,flush=True)
 return dict(passed=passed,total=len(w['Em']),ownTm=ownTm,ownEm=ownEm,fields=fields,stats=degree)
if __name__=='__main__':run()

```

## refined_B_check.py

```python
#!/usr/bin/env python3
"""Run independently proven Laurent F0 dependency cancellation and full independent Level B majorant."""
import laurent_refine, independent_B_full_attempt as B
if __name__=='__main__':
 refined=laurent_refine.run()
 result=B.run(refinement=refined)
 print('REFINED_FULL_B',result['passed'],'/',result['total'])

```

## independent_a.py

```python
#!/usr/bin/env python3
"""Independent strict-rational Level A audit: no producer imports."""
import os,json,sys,math,itertools,time,collections,random
from fractions import Fraction as Q
from functools import lru_cache
DIR=os.environ.get('PENT21C_CERT_DIR','/mnt/data/pent21c_audit/PENT21c_cert_3055e81/lines/D-topics/probes/PENT/local_run_20261117/cert')
ZERO=(0,)*6

def load():
 w=json.load(open(f'{DIR}/witness.json'))
 conv=lambda m:{tuple(map(int,k.split(','))):Q(v) for k,v in m.items()}
 return conv(w['Tm']),conv(w['Em'])

def pd(A):
 n=len(A); L=[[Q(0)]*n for i in range(n)];D=[]
 for j in range(n):
  d=A[j][j]-sum((L[j][k]**2)*D[k] for k in range(j))
  if d<=0:return None
  D.append(d)
  for i in range(j+1,n):
   L[i][j]=(A[i][j]-sum(L[i][k]*L[j][k]*D[k] for k in range(j)))/d
 return D

def inner(tm,em,r=Q(1,128)):
 h=[[Q(0)]*6 for _ in range(6)]; t=[[[Q(0)]*6 for _ in range(6)] for _ in range(6)]
 for a,v in tm.items():
  d=sum(a)
  if d==2:
   ix=[j for j in range(6) for _ in range(a[j])]
   if ix[0]==ix[1]:h[ix[0]][ix[1]]+=2*v
   else:h[ix[0]][ix[1]]+=v;h[ix[1]][ix[0]]+=v
  if d==3:
   ix=[j for j in range(6) for _ in range(a[j])]; perms=set(itertools.permutations(ix))
   for i,j,k in perms:t[i][j][k]+=v/len(perms)
 def ee(i,j):
  k=[0]*6;k[i]+=1;k[j]+=1;return em.get(tuple(k),Q(0))
 def wt(a):return Q(1) if max(a)==sum(a) else Q(1,2)
 tau2=max(ee(i,i)+sum(ee(i,j) for j in range(6) if j!=i)/2 for i in range(6))
 tau3=r*sum(v*wt(a) for a,v in em.items() if sum(a)==3)
 tau4=sum(r**(sum(a)-2)*(abs(tm.get(a,Q(0)))+em.get(a,Q(0)))*wt(a) for a in set(tm)|set(em) if sum(a)>=4)
 tau=tau2+tau3+tau4
 piv=[]
 for s in itertools.product([-1,1],repeat=6):
  A=[[h[i][j]/2 + r*sum(s[k]*t[k][i][j] for k in range(6))-(tau if i==j else 0) for j in range(6)]for i in range(6)]
  ds=pd(A)
  if ds is None:return False,{'tau2':tau2,'tau3':tau3,'tau4':tau4,'tau':tau,'failure_sign':s}
  piv.extend(ds)
 return True,{'tau2':tau2,'tau3':tau3,'tau4':tau4,'tau':tau,'min_pivot':min(piv),'H':h,'T':t}

def geometry(lines):
 root=lines[0];W=Q(root['W']);R=Q(root['R']);r=Q(root['rho_in'])
 assert root['t']=='root' and W>R>r>0
 b=[];volume=Q(0);types=collections.Counter()
 lb=[-W,-W,Q(0),-W,-W,-W];ub=[W]*6
 for idx,L in enumerate(lines[1:]):
  typ=L['t'];m=[Q(x) for x in L['m']];h=[Q(x) for x in L['r']]
  if typ not in ['I','O','P'] or len(h)!=6 or min(h)<=0:return False,idx
  lo=[m[i]-h[i] for i in range(6)];hi=[m[i]+h[i] for i in range(6)]
  if any(lo[i]<lb[i] or hi[i]>ub[i] for i in range(6)):return False,('out_of_root',idx)
  if typ=='I' and not all(abs(m[i])+h[i]<=r for i in range(6)):return False,('I',idx)
  if typ=='O' and sum(max(abs(m[i])-h[i],Q(0))**2 for i in range(6))<R*R:return False,('O',idx)
  v=math.prod(hi[i]-lo[i] for i in range(6));volume+=v; b.append((lo,hi,idx));types[typ]+=1
 if volume != (2*W)**5*W:return False,('volume',str(volume/((2*W)**5*W)))
 # Detect overlaps with sweep line along the first dimension.
 active=[]
 for lo,hi,i in sorted(b,key=lambda x:x[0][0]):
  active=[(x,y,j) for (x,y,j) in active if y[0]>lo[0]]
  for x,y,j in active:
   if all(lo[k]<y[k] and x[k]<hi[k] for k in range(6)):
    return False,('overlap',i,j)
  active.append((lo,hi,i))
 return True,dict(types=types,volume=str(volume),n=len(b))

if __name__=='__main__':
 t0=time.time();tm,em=load();print('coefficients',len(tm),len(em),flush=True)
 good,inf=inner(tm,em);print('inner',good,{k:float(v) for k,v in inf.items() if isinstance(v,Q)},'elapsed',time.time()-t0,flush=True)
 ref=json.load(open(f'{DIR}/inner.json'))
 if good:print('inner difference to reference', {k:float(inf[k]-Q(ref['tau_ge4' if k=='tau4' else k])) for k in ['tau2','tau3','tau4','tau','min_pivot']},flush=True)
 lines=[json.loads(s) for s in open(f'{DIR}/leaves.jsonl')];okay,info=geometry(lines);print('geometry',okay,info,'elapsed',time.time()-t0,flush=True)
 if good and okay:
  key=max((k for k in tm if sum(k)==2),key=lambda k:tm[k]);tm2=tm.copy();tm2[key]=-abs(tm[key]);print('tamper: flip diagonal',key,inner(tm2,em)[0],flush=True)
  altered=[x.copy() for x in lines];altered[100]=dict(lines[100]);altered[100]['m']=lines[100]['m'].copy();altered[100]['m'][0]='100';print('tamper: move leaf',geometry(altered)[0],flush=True)
  em2={k:v*100 for k,v in em.items()};print('tamper: inflate Em x100',inner(tm,em2)[0],flush=True)

```

## own_A_inner_refined.py

```python
#!/usr/bin/env python3
"""Attempt independent Level A positive-definite inner test with new conservative Level B coefficients."""
import json,lzma,time
from fractions import Fraction as Q
import independent_a as A
P='/mnt/data/pent21c_audit/delivery/logs/own_levelB_enclosure_refined.json.xz'
t0=time.perf_counter();u=json.load(lzma.open(P,'rt'))
conv=lambda obj:{tuple(map(int,k.split(','))):Q(x) for k,x in obj.items()}
tm=conv(u['Tm']);em=conv(u['Em']);print('coefs',len(tm),len(em),'loaded sec',time.perf_counter()-t0,flush=True)
pass_,info=A.inner(tm,em)
print('OWN_A_INNER_PASS',pass_,'other',[(k,v) for k,v in info.items() if not isinstance(v,Q)])
for k,v in info.items():
 if isinstance(v,Q):print(k,format(float(v),'.17g'))
print('elapsed',time.perf_counter()-t0)

```

## support_audit.py

```python
#!/usr/bin/env python3
"""Independent formal polynomial support audit: all coefficient sources and shift remain in frozen universe.

No producer source imported or run. This is a conservative symbolic degree/support audit,
not a re-computation of certified coefficient magnitudes.
"""
import collections,contextlib,io,sys,json,lzma,time
from fractions import Fraction as Q
import independent_k_all as A
import independent_B_full_attempt as B
P=A.ROOT
start=time.perf_counter()
with contextlib.redirect_stdout(io.StringIO()): st=A.run(save=False)
ref=set(tuple(map(int,k.split(','))) for k in st['witness']['Em'])
assert len(ref)==13024
f=[]
for k in range(5): f.append(B.make_field(k,st))
Mq=B.quadratic_majorant(st)
# Field support, not just list of magnitudes, checks all basis coefficients.
fieldsupport=set()
for ff in f:
 for comp in ff:
  for basis,p in comp.items(): fieldsupport.update(p.d)
Kset=set(st['KD'].d)
Qset=set(Mq.d)
# Full support of coarse linear majorant, before numerical norm calculation.
Lset=fieldsupport
Bset=Kset|Qset|Lset
# Shift by rational constants changes each coordinate exponent downward only.
maxdeg=max(map(sum,Bset)); assert maxdeg<=13
Sshift={tuple(a[i] if i not in () else a[i] for i in range(6)) for a in Bset}
# Downward-closedness of target universe 2<=deg<=13.
missing={a for a in Bset if sum(a)>=2 and a not in ref}
print('ARCHIVED_KEYS',len(ref))
print('RAW_EXPLICIT_K',len(Kset),'MAX_DEG',max(map(sum,Kset)))
print('LINEAR_FIELDS',len(Lset),'MAX_DEG',max(map(sum,Lset)))
print('QUADRATIC',len(Qset),'MAX_DEG',max(map(sum,Qset)))
print('UNION',len(Bset),'MAX_DEG',maxdeg)
print('UNCOVERED_SUPPORT_DEG_GE2',len(missing),'EXAMPLE',sorted(missing)[:5])
print('ASSERT', 'PASS' if len(missing)==0 else 'FAIL')
assert not missing
print('ELAPSED_SEC',round(time.perf_counter()-start,4))

```

## level_a_geometry.py

```python
#!/usr/bin/env python3
"""Original, exact rational geometric Level A audit. No producer code executed."""
import json,time
from pathlib import Path
import independent_a as A
P=Path('/mnt/data/pent21c_audit/PENT21c_cert_3055e81/lines/D-topics/probes/PENT/local_run_20261117/cert')
t=time.perf_counter()
with open(P/'leaves.jsonl') as f: leaves=[json.loads(x) for x in f if x.strip()]
r=A.geometry(leaves)
print('EXACT_GEOMETRY',r,'leaf_records',len(leaves),'elapsed',round(time.perf_counter()-t,4))
assert r[0]

```

## prep_own_a.py

```python
#!/usr/bin/env python3
"""Generate exact 2^-160 multipliers from the independently recomputed coefficient enclosure."""
from fractions import Fraction as Q
from pathlib import Path
import json,lzma
SRC=Path('/mnt/data/pent21c_audit/PENT21c_cert_3055e81/lines/D-topics/probes/PENT/local_run_20261117/cert')
OWN=Path('/mnt/data/pent21c_audit/delivery/logs/own_levelB_enclosure_refined.json.xz')
OUT=Path('/mnt/data/pent21c_audit/delivery/logs/own_levelA_data.txt')
z=json.load(lzma.open(OWN,'rt'))
S=1<<160
assert len(z['Em'])==13024
archive=json.load(open(SRC/'witness.json'))
assert set(z['Em'])==set(archive['Em'])
lines=[json.loads(s) for s in open(SRC/'leaves.jsonl')]
with open(OUT,'w') as out:
 tm=[(tuple(map(int,k.split(','))),Q(v)) for k,v in z['Tm'].items() if sum(map(int,k.split(',')))<=6 and Q(v)]
 out.write(str(len(tm))+'\n')
 for a,v in sorted(tm):
  n=v*S;assert n.denominator==1
  out.write(' '.join(map(str,a))+' '+str(n.numerator)+'\n')
 E={tuple(map(int,k.split(','))):Q(v) for k,v in z['Em'].items()}
 for k,v in z['Tm'].items():
  a=tuple(map(int,k.split(',')))
  if sum(a)>6:E[a]=E.get(a,Q(0))+abs(Q(v))
 out.write(str(len(E))+'\n')
 for a,v in sorted(E.items()):
  n=v*S;assert n.denominator==1 and n>=0
  out.write(' '.join(map(str,a))+' '+str(n.numerator)+'\n')
 ps=[x for x in lines if x['t']=='P'];out.write(str(len(ps))+'\n')
 for L in ps:
  # all supplied dyadic centres and half widths are checked independently in prior Level A
  out.write(' '.join(L['m']+L['r']+L.get('mu',['0']*6))+'\n')
print('READY',OUT,'Tm<=6',len(tm),'E',len(E),'P',len(ps),'size',OUT.stat().st_size)

```

## check_p2.cpp

```cpp
// Standalone strict integer/rational checker for P leaves. No external producer code.
#include <gmpxx.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <array>
#include <algorithm>
#include <chrono>
#include <map>
#include <memory>
using namespace std;
using E=array<int,6>;
static constexpr int BASE=7;
struct Index { E a; int d; int p; };
int code(const E&a){int v=0;for(int i=0;i<6;i++)v=v*BASE+a[i];return v;}
mpq_class parse(string s){mpq_class r(s);r.canonicalize();return r;}
int binom(int n,int k){int b=1;for(int i=1;i<=k;i++)b=b*(n-i+1)/i;return b;}
struct Power { mpz_class n;int e; };
struct Node { std::map<int, std::unique_ptr<Node>> child; mpz_class coeff=0; };
void put(Node &root,const E &a,const mpz_class &v) {
 Node *p=&root;
 for(int i=0;i<6;i++) {auto &q=p->child[a[i]];if(!q)q=std::make_unique<Node>();p=q.get();}
 p->coeff+=v;
}
mpz_class eval(Node &node,int dim,const Power c[6]){
 if(dim==6)return node.coeff;
 auto it=node.child.rbegin();if(it==node.child.rend())return 0;
 int last=it->first;mpz_class res=eval(*it->second,dim+1,c);++it;
 for(int k=last-1;k>=0;k--){
  mpz_class v=res*c[dim].n;
  if(c[dim].e){int shift=c[dim].e; if (v % (mpz_class(1)<<shift) != 0) throw runtime_error("nonexact Horner shift"); res=v>>shift;}else res=v;
  if(it!=node.child.rend() && it->first==k){res+=eval(*it->second,dim+1,c);++it;}
 }
 return res;
}

Power dyad(string s){ mpq_class q=parse(s);mpz_class n=q.get_num();mpz_class d=q.get_den();int e=0;while(d>1){if(mpz_odd_p(d.get_mpz_t()))throw runtime_error("nondyadic");d>>=1;e++;}return {n,e};}
mpz_class zabs(mpz_class n){return n>=0?n:-n;}
// Ordinary exact rational LDL positivity test (7x7 Schur complement test).
bool pd7(vector<vector<mpq_class>> A){
 int n=A.size();
 for(int j=0;j<n;j++){
  if(A[j][j]<=0)return false;
  for(int i=j+1;i<n;i++)for(int k=j+1;k<=i;k++){
    A[i][k]-=A[i][j]*A[k][j]/A[j][j];if(i!=k)A[k][i]=A[i][k];
  }
 }
 return true;
}
int main(int argc,char**argv){
 auto start=chrono::steady_clock::now();ifstream in(argv[1]);if(!in)throw runtime_error("missing file");
 const int SHIFT=320;mpz_class S=mpz_class(1)<<SHIFT;mpq_class SQ(S);
 vector<Index> ids;map<int,int> where;
 for(int a0=0;a0<=6;a0++)for(int a1=0;a1<=6-a0;a1++)for(int a2=0;a2<=6-a0-a1;a2++)for(int a3=0;a3<=6-a0-a1-a2;a3++)for(int a4=0;a4<=6-a0-a1-a2-a3;a4++)for(int a5=0;a5<=6-a0-a1-a2-a3-a4;a5++){
  E a={a0,a1,a2,a3,a4,a5};int d=a0+a1+a2+a3+a4+a5;where[code(a)]=ids.size();ids.push_back({a,d,code(a)});
 }
 int M;in>>M;vector<mpz_class> init(ids.size());for(int n=0;n<M;n++){
  E a;for(int &v:a)in>>v;mpz_class c;in>>c;init[where.at(code(a))]=c<<160;
 }
 int numerr;in>>numerr;Node eroot;
 for(int i=0;i<numerr;i++){E a;for(int &x:a)in>>x;mpz_class v;in>>v;put(eroot,a,v<<(SHIFT-160));}
 int leafN;in>>leafN;int count=0,crudes=0,duals=0;int fails=0;long double minbound=1e100;vector<int>failed;
 for(int li=0;li<leafN;li++){
  array<string,18> str;for(auto &v:str)in>>v;
  Power m[6],r[6],c[6];mpq_class muv[6];
  for(int j=0;j<6;j++){
   m[j]=dyad(str[j]);r[j]=dyad(str[j+6]);muv[j]=parse(str[j+12]); if(muv[j]<0) throw runtime_error("negative P-leaf multiplier"); if(parse(str[j+6])<=0)throw runtime_error("nonpositive leaf halfwidth");
   mpq_class q=zabs(m[j].n); q/=mpz_class(1)<<m[j].e; q+=parse(str[j+6]);
   c[j]=dyad(q.get_str()); if(13*c[j].e>160)throw runtime_error("unproved Horner divisibility budget");
  }
  // Polynomial substitution, dimension by dimension: p(m+r t). Exact dyadic integers scaled by 2^320.
  vector<mpz_class> cur=init, nxt(ids.size());
  for(int i=0;i<6;i++){
   fill(nxt.begin(),nxt.end(),mpz_class(0));
   mpz_class pm[7],pr[7];pm[0]=1;pr[0]=1;
   for(int k=1;k<=6;k++){pm[k]=pm[k-1]*m[i].n;pr[k]=pr[k-1]*r[i].n;}
   for(size_t j=0;j<ids.size();j++){
    if(cur[j]==0)continue;
    auto a=ids[j].a;int deg=a[i];
    for(int k=0;k<=deg;k++){
     a[i]=k;mpz_class num=cur[j]*binom(deg,k)*pm[deg-k]*pr[k];
     int shift=(deg-k)*m[i].e+k*r[i].e;
     if(shift) { mpz_class check = num%(mpz_class(1)<<shift); if(check!=0)throw runtime_error("bad exact shift");num >>= shift; }
     nxt[where.at(code(a))]+=num;
    }
   }
   cur.swap(nxt);
  }
  mpz_class constant=cur[where.at(code(E{}))];mpz_class g[6],H[6][6],tail=0;
  for(int i=0;i<6;i++){
   E a={};a[i]=1;g[i]=cur[where.at(code(a))];
   for(int j=0;j<6;j++){
    E b={};b[i]++;b[j]++;H[i][j]=cur[where.at(code(b))]*(i==j?2:1);
   }
  }
  for(size_t i=0;i<ids.size();i++) if(ids[i].d>=3)tail+=zabs(cur[i]);
  // Evaluate the nonnegative error polynomial at the six true far corners.
  // Fixed-point values use 2^320 as denominator; each Horner shift is exact
  // because the total polynomial degree is at most 13 and inputs are dyadic.
  mpz_class en=eval(eroot,0,c);mpq_class err(en,S);
  mpq_class excess=mpq_class(constant-tail,S)-err;
  mpq_class crude=excess;
  for(int i=0;i<6;i++)crude-=mpq_class(zabs(g[i]),S);
  for(int i=0;i<6;i++)for(int j=0;j<6;j++)crude-=mpq_class(zabs(H[i][j]),S)/2;
  if(crude>0){crudes++;count++;minbound=min(minbound,(long double)crude.get_d());continue;}
  // Dual quadratic lower bound via exact 7x7 Schur positive definiteness.
  mpq_class b=2*excess;
  mpq_class am[6][6];
  for(int i=0;i<6;i++){
   mpq_class rr=parse(str[i+6]);b-=2*muv[i]*rr*rr;
   for(int j=0;j<6;j++)am[i][j]=mpq_class(H[i][j],S)+(i==j?2*muv[i]*rr*rr:mpq_class(0));
  }
  vector<vector<mpq_class>> B(7,vector<mpq_class>(7));B[0][0]=b;
  for(int i=0;i<6;i++){B[0][i+1]=B[i+1][0]=mpq_class(g[i],S);for(int j=0;j<6;j++)B[i+1][j+1]=am[i][j];}
  if(pd7(B)){duals++;count++;}
  else{failed.push_back(li);fails++;if(failed.size()<15)cerr<<"P leaf failed conservative bound "<<li<<" cmax="<<" crude="<<crude.get_d()<<"\n";}
  if(li%500==0)cerr<<"progress "<<li<<"/"<<leafN<<" pass="<<count<<" failed="<<fails<<" elapsed="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"s\n";
 }
 cout<<"P leaves="<<leafN<<" PASS="<<count<<" FAIL_TO_CLOSE="<<fails<<" crude="<<crudes<<" dual="<<duals<<" elapsed="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<" s\n";
 cout<<"failed_indices=";for(auto x:failed)cout<<x<<",";cout<<"\n";
}

```

## lowdeg_fixed_diagnostic.py

```python
#!/usr/bin/env python3
"""Diagnostic: independent dual norm at fixed F0 center versus archived norms."""
import json,contextlib,io,time
from fractions import Fraction as Q
import independent_k_all as A
import independent_B_full_attempt as B
from pathlib import Path
p=A.ROOT
c=json.load(open(p/'constants.json'));r=json.load(open(p/'lowdeg.json'))
f=(Q(c['F_lo'])+Q(c['F_up']))/2
with contextlib.redirect_stdout(io.StringIO()):st=A.run(f0_override=f,save=False)
fs=[B.make_field(k,st) for k in range(5)]
t=time.perf_counter()
for j,k in enumerate([q for q in r if sum(map(int,q.split(',')))==2][:12]):
 a=tuple(map(int,k.split(',')));nl,nt=B.exact_tight_norm(a,fs,st,0)
 an=Q(r[k]['NL']['mid']);at=Q(r[k]['NT']['mid']); print(k,'nl',float(nl),'archive',float(an),'ratio',float(nl/an) if an else None,'nt',float(nt),'ref',float(at),'sec',time.perf_counter()-t,flush=True)

```

## compare_theta_jax.py

```python
"""Independent dual-base cross-check between two self-written derivations (one float diagnostic only)."""
import jax, numpy as np
import independent_k_jax as J
import independent_B_full_attempt as B
import independent_k_all as A
from fractions import Fraction as Q
import json,contextlib,io
p=A.ROOT
r=json.load(open(p/'lowdeg.json'));c=json.load(open(p/'constants.json'))
fmid=(Q(c['F_lo'])+Q(c['F_up']))/2
with contextlib.redirect_stdout(io.StringIO()):st=A.run(f0_override=fmid,save=False)
fields=[B.make_field(k,st) for k in range(5)]
hT=jax.jacfwd(jax.jacfwd(lambda z:J.calc(z,True)[2]))(J.cq)
k='0,0,0,0,0,2';ax=tuple(map(int,k.split(','))); inds=[5,5]
tx=np.array(hT[:,:,:,5,5])/2
for t in range(5):
 print('k',t)
 for j in range(2):
  list_jax=[]
  for I in range(6):
   vals=tx[t,j,I*7:(I+1)*7]
   list_jax.extend(vals)
  our=fields[t][2+j]
  keys=list(range(42));vs=np.array([float(our.get(i,A.Poly(0)).d.get(ax,A.V(0)).mid()) for i in keys]);delta=np.array(list_jax)-vs
  imax=int(np.argmax(abs(delta)))
  print('COMP',j,'max_jax',max(abs(np.array(list_jax))),'max_own',max(abs(vs)),'maxdiff',max(abs(delta)),'worstIdx',imax,'jax',list_jax[imax],'ours',vs[imax])
  if t==0:
   for ii in range(6):print('  basis',ii,'our',vs[ii*7], 'jax',list_jax[ii*7])

```

## independent_k_jax.py

```python
#!/usr/bin/env python3
"""Independent derivative reconstruction of D*K and D*Lambda/Theta using JAX autodiff.
Production .py files are NOT imported nor executed. Gram inputs are sampled independently elsewhere.
"""
import os,json,lzma,time
from fractions import Fraction as F
os.environ['JAX_ENABLE_X64']='True'
import jax
jax.config.update('jax_enable_x64',True)
import jax.numpy as np
P='/mnt/data/pent21c_audit/PENT21c_cert_3055e81/lines/D-topics/probes/PENT/local_run_20261117/cert/'
I=json.load(open(P+'inputs.json'));C=json.load(open(P+'constants.json'));L=json.load(open(P+'lowdeg.json'));R=json.load(open(P+'rho_c.json'))
G=json.loads(lzma.open(P+'gram.json.xz').read())
mat=np.array([[[float(F(q)) for q in row]for row in Gk]for Gk in G['gram']]);mass=np.array([[[float(F(q)) for q in row]for row in Gk]for Gk in G['mass']]);
mid=lambda o: float(F(o['mid']))
c=np.array([mid(t) for t in C['c']]);cq=np.array([float(F(x)) for x in I['Cq']]);origin=np.array([float(F(x)) for x in I['O']]);
kappa=float(F(C['KS']));f0=float((F(C['F_lo'])+F(C['F_up']))/2);area_c=float(F(C['forms_at_c']['area_c']['mid']));l0=f0/area_c
mrho=np.zeros((5,2,42));
for k in range(5):
 for j,field in enumerate(['M_rho_a','M_rho_b']):
  mrho=mrho.at[k,j,np.arange(0,42,7)].set(np.array([mid(v) for v in R[k][field]]))

def gram(k,u,v):return np.dot(u,np.dot(mat[k],v))
def geometry(z):
 verts=np.array([[0.,0.],[1.,0.],[z[0],z[1]],[z[2],z[3]],[z[4],z[5]]]);
 ex=verts-origin[None,:];ey=np.roll(ex,-1,axis=0)
 n11=np.sum(ex*ex,axis=1);n12=np.sum(ex*ey,axis=1);n22=np.sum(ey*ey,axis=1)
 det=ex[:,0]*ey[:,1]-ex[:,1]*ey[:,0];area=np.sum(det)/2
 return n11,n12,n22,det,area

def fill(component,w):
 out=np.zeros(42)
 return out.at[np.arange(component*7,(component+1)*7)].set(w)

def calc(z, needfields=False):
 n11,n12,n22,det,area=geometry(z)
 w=np.concatenate((np.array([1.]),z-c));
 b=0.;a=0.;cflux=0.;cross1=0.;cross2=0.
 Lfields=[];Tfields=[]
 for k in range(5):
  b=b+det[k]*np.dot(w,mass[k]@w)
  ha=fill(0,w);hb=fill(1,w);ch_a=fill(2,w);ch_b=fill(3,w)
  da=fill(4,w);db=fill(5,w)
  s1=-det[k]*ha+ch_b;s2=-det[k]*hb-ch_a
  A=np.array([[n22[k],-n12[k]],[-n12[k],n11[k]]])/det[k]
  N=np.array([[n11[k],n12[k]],[n12[k],n22[k]]])/det[k]
  Ac=np.array([[mid(C['geometry_at_c'][k]['n22']),-mid(C['geometry_at_c'][k]['n12'])],[-mid(C['geometry_at_c'][k]['n12']),mid(C['geometry_at_c'][k]['n11'])]])/mid(C['geometry_at_c'][k]['det'])
  Nc=np.linalg.inv(Ac)
  a=a+(n22[k]*gram(k,da,da)-2*n12[k]*gram(k,da,db)+n11[k]*gram(k,db,db))/det[k]
  cflux=cflux+(n11[k]*gram(k,s1,s1)+2*n12[k]*gram(k,s1,s2)+n22[k]*gram(k,s2,s2))/det[k]
  rho1=N[0,0]*s1+N[0,1]*s2-(area/f0)*da
  rho2=N[1,0]*s1+N[1,1]*s2-(area/f0)*db
  x,y=mrho[k,0],mrho[k,1]
  cross1=cross1+gram(k,rho1,x)+gram(k,rho2,y)
  cross2=cross2+N[0,0]*gram(k,x,x)+2*N[0,1]*gram(k,x,y)+N[1,1]*gram(k,y,y)
  if needfields:
   Rmat=np.stack((rho1,rho2));Wmat=np.stack((x,y))
   tLm=(2*f0)*((kappa/l0)*(Ac@Rmat)-area*(A@Rmat)-(kappa/l0)*(Ac@N@Wmat))
   tTh=(-2*f0*kappa)*(det[k]-mid(C['geometry_at_c'][k]['det']))*(Rmat-N@Wmat)
   Lfields.append(tLm);Tfields.append(tTh)
 D=np.prod(det)
 Psi=area*(kappa+f0)*b-area*area*a-f0*kappa*cflux
 K=Psi+2*f0*kappa*cross1-f0*kappa*cross2
 if needfields:
  return D*K,np.stack(Lfields)*D,np.stack(Tfields)*D
 return D*K

def doit():
 t=time.time();j2=jax.jacfwd(jax.jacfwd(calc))(cq)
 def kval(a):
  inds=[i for i,v in enumerate(a) for _ in range(v)]
  return float(j2[inds[0],inds[1]]/(2 if inds[0]==inds[1] else 1))
 total=0;fail=[]
 for a in L:
  ax=tuple(map(int,a.split(',')))
  if sum(ax)!=2:continue
  x=kval(ax); ref=L[a]
  y=float(F(ref['K_mid']));rad=float(F(ref['K_rad']))
  inside=abs(x-y)<=rad;total+=inside
  if not inside:fail.append((a,x,y,rad))
  print('K',a,'ind=',format(x,'.12g'),'archive=',format(y,'.12g'),'rad=',format(rad,'.3g'),'PASS' if inside else 'FAIL',flush=True)
 print('K total',total,'/',21,'failure',fail,'elapsed',time.time()-t,flush=True)
 print('K constant',float(calc(cq)),'archive',float(F(L['0,0,0,0,0,0']['K_mid'])),flush=True)
 # Analytic first and second derivatives for the dual norms, using exactly the
 # same coefficient basis and bilinear Gram as in the archive.
 q,jl,jt=calc(cq,True)
 hL=jax.jacfwd(jax.jacfwd(lambda z:calc(z,True)[1]))(cq)
 hT=jax.jacfwd(jax.jacfwd(lambda z:calc(z,True)[2]))(cq)
 checked=[]
 for a in L:
  ax=tuple(map(int,a.split(',')))
  if sum(ax)!=2:continue
  ids=[i for i,v in enumerate(ax) for _ in range(v)]
  ll=np.array(hL[:,:,:,ids[0],ids[1]])/(2 if ids[0]==ids[1] else 1)
  tt=np.array(hT[:,:,:,ids[0],ids[1]])/(2 if ids[0]==ids[1] else 1)
  norml=normt=0.
  for k in range(5):
   n11=mid(C['geometry_at_c'][k]['n11']);n12=mid(C['geometry_at_c'][k]['n12']);n22=mid(C['geometry_at_c'][k]['n22']);det=mid(C['geometry_at_c'][k]['det'])
   mm=np.array([[n11,n12],[n12,n22]])/det
   norml+=sum(float(mm[i,j]*gram(k,ll[k,i],ll[k,j])) for i in range(2) for j in range(2))
   normt+=sum(float(gram(k,tt[k,i],tt[k,i])/det) for i in range(2))
  nl=float(np.sqrt(max(0,norml)));nt=float(np.sqrt(max(0,normt)))
  el=L[a]; nlr=float(F(el['NL']['mid']));ntr=float(F(el['NT']['mid']))
  print('NORM',a,'NL',nl,'archive',nlr,'NT',nt,'archive',ntr,'diff',nl-nlr,nt-ntr,flush=True)
  checked.append((nl,nlr,nt,ntr))
 print('NORM total',len(checked),'maxdifferences',max(abs(q[0]-q[1]) for q in checked),max(abs(q[2]-q[3]) for q in checked),'elapsed',time.time()-t,flush=True)

if __name__=='__main__':doit()

```

## independent_b_interval.py

```python
"""Exact rational interval propagation of reference coordinate uncertainty."""
from fractions import Fraction as F
import independent_b as B
import json,time
P=B.P;C=B.C;I=B.I
class IV:
 def __init__(self,a,b=None):
  if isinstance(a,IV):self.lo,self.hi=a.lo,a.hi
  else:self.lo=F(a);self.hi=F(a if b is None else b)
 def __add__(x,y):
  y=IV(y);return IV(x.lo+y.lo,x.hi+y.hi)
 __radd__=__add__
 def __neg__(x):return IV(-x.hi,-x.lo)
 def __sub__(x,y):return x+-IV(y)
 def __rsub__(x,y):return IV(y)+-x
 def __mul__(x,y):
  y=IV(y);v=[a*b for a in (x.lo,x.hi) for b in (y.lo,y.hi)];return IV(min(v),max(v))
 __rmul__=__mul__
 def __truediv__(x,y):
  y=IV(y);assert y.lo*y.hi>0;return x*IV(1/y.hi,1/y.lo)
 def __rtruediv__(x,y):return IV(y)/x
 def intersect(y,rec):
  a=F(rec['mid']);r=F(rec['rad']);return not (y.hi<a-r or y.lo>a+r)
 def inside(y,rec):
  a=F(rec['mid']);r=F(rec['rad']);return a-r<=y.lo<=y.hi<=a+r
 def show(x):return (float(x.lo),float(x.hi))

def run():
 t0=time.time();c=[IV(F(v['mid'])-F(v['rad']),F(v['mid'])+F(v['rad'])) for v in C['c']];v=[(IV(0),IV(0)),(IV(1),IV(0)),(c[0],c[1]),(c[2],c[3]),(c[4],c[5])];o=[IV(x) for x in I['O']]
 allA=[IV(0),IV(0),IV(0)];area=IV(0)
 for k in range(5):
  a=[v[k][i]-o[i] for i in range(2)];b=[v[(k+1)%5][i]-o[i] for i in range(2)]
  n11=a[0]*a[0]+a[1]*a[1];n12=a[0]*b[0]+a[1]*b[1];n22=b[0]*b[0]+b[1]*b[1];det=a[0]*b[1]-a[1]*b[0]
  assert det.lo>0;area+=det/IV(2)
  Bs,u=B.bases(k,0)
  U=[B.integral(Bs[i],Bs[i]) for i in range(6)]
  A0=(n22*U[4]-2*n12*B.integral(Bs[4],Bs[5])+n11*U[5])/det
  A1=det*B.integral(u,u)
  # Flux s = -det*[a h,b h]+curl chi
  A=Bs[0];D=Bs[1];ch_a=Bs[2];ch_b=Bs[3]
  # Assemble invariant quadratic coefficients instead of dynamic field intervals
  s1d=B.integral(A,A);s2d=B.integral(D,D);s12d=B.integral(A,D)
  u13=B.integral(A,ch_b);u12=B.integral(A,ch_a);u23=B.integral(D,ch_b);u22=B.integral(D,ch_a)
  ch33=B.integral(ch_b,ch_b);ch22=B.integral(ch_a,ch_a);ch23=B.integral(ch_a,ch_b)
  s11=det*det*s1d-2*det*u13+ch33
  s22=det*det*s2d+2*det*u22+ch22
  s12=det*det*s12d+det*u12-det*u23-ch23
  A2=(n11*s11+2*n12*s12+n22*s22)/det
  allA[0]+=A0;allA[1]+=A1;allA[2]+=A2
 ks=IV(C['KS']);nu=ks/area;lamup=allA[0]/allA[1];lamlo=(nu*allA[1]-allA[0])/(nu*allA[2]-allA[1]);eps1=(allA[0]-lamlo*allA[1])/(1-lamup/nu);eps0=eps1/nu
 for name,x in [('A0',allA[0]),('A1',allA[1]),('A2',allA[2]),('area_c',area),('nu',nu),('lam_up',lamup),('lam_lo',lamlo),('eps1_sq',eps1),('eps0_sq',eps0)]:
  ref=C['forms_at_c'][name]
  print(name,'lo',format(float(x.lo),'.15g'),'hi',format(float(x.hi),'.15g'),'width',format(float(x.hi-x.lo),'.3g'),'archive_overlap',x.intersect(ref),'inside_archive',x.inside(ref),flush=True)
 print('elapsed',time.time()-t0)
if __name__=='__main__':run()

```

