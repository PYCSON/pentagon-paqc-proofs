# PENT-21c 独立审计 — 复现说明

## 输入与检查器隔离

本轮冻结输入为 `PENT21c_cert_3055e81.zip`，SHA256：
`8f70e45a46ae48189330ac02d13435bf6d852b3bd523539cf85c1caa322ee717`。

解包后先在包根目录运行 `sha256sum -c SHA256SUMS`，应是 **25/25 PASS**。数据位于 `lines/D-topics/probes/PENT/local_run_20261117/cert/`。不要运行/导入上传包里的生产 `.py`，尤其是 `lglocal.py` 和 `tests/lglocal_cert_check.py`。

独立代码在本 Evidence ZIP 的 `code/`，报告在 `HANDOFF-PENT-21c-GPT-20261118.md`；定点区间、`Fraction`、GMP 的程序均为本次独立编写或源自上轮我自己的独立实现。`logs/` 保存每一步原始输出及精确新系数 `own_levelB_enclosure_refined.json.xz`。

依赖：Python 3.11+，`numpy`, `sympy`（完整 Gram 的模素数矩阵计算），C++17 编译器、GMP 开发库（`-lgmpxx -lgmp`）。`python-flint` 与生产程序均**不需要**。`compare_theta_jax.py` 仅是可选数值对照，不参与严格签字。

## 将硬编码的本次会话路径替换为你的本机路径

为保证能完整保留每一条日志中原始文件路径，本轮独立程序原样冻结了容器中的路径。复现时，可运行我们自己的 `configure_paths.py` 生成适配本机路径的**副本**：

```bash
python3 configure_paths.py \
  --cert /absolute/path/to/PENT21c_cert_3055e81/lines/D-topics/probes/PENT/local_run_20261117/cert \
  --output /absolute/path/to/replay_work
cd /absolute/path/to/replay_work
```

此脚本只复制并编辑**独立 `code/`**，不读取、运行或修改任何生产 `.py`。随后所有输出写入工作区 `logs/`。或者直接在本机对应代码中修改 `P`、`ROOT` 常量。

## 分步复现

```bash
python3 code/gram_full_modular.py > logs/gram_full_modular.log
python3 code/constants_exact.py > logs/constants_exact.log
python3 code/parts_audit.py > logs/parts_audit.log
python3 code/tamper_3.py > logs/tamper_3.log
python3 code/support_audit.py > logs/support_audit.log
# 全量严格来源链：计算成本较高；本次纯 Python 原始实测约 1700 秒
python3 code/refined_B_check.py > logs/refined_B_check_afterfix.log
python3 code/own_A_inner_refined.py > logs/own_A_inner_refined_afterfix.log
python3 code/level_a_geometry.py > logs/level_a_geometry.log
python3 code/prep_own_a.py > logs/prep_own_a.log
# 注意：新的精确系数和多项式输入为上一步自己生成的，不是复制档案 Tm/Em
c++ -std=c++17 -O2 code/check_p2.cpp -lgmpxx -lgmp -o code/check_p2_independent
code/check_p2_independent logs/own_levelA_data.txt > logs/own_levelA_p_leaves_final.log 2> logs/own_levelA_p_leaves_final.progress
```

验收输出应出现：Gram 4655/4655，常数四个单向 PASS，支持集漏项 0，`REFINED_FULL_B 7086 / 13024`（路径 i 未通过），新包络 inner 64/64 通过、最小主元正，P leaves 6942 PASS/0 FAIL。这是路径 (ii) 的完整 PASS。3 个篡改均应拒绝。

## 如何只复核最后的严格正性（不用重跑耗时的系数生成）

Evidence ZIP 已包含 `logs/own_levelB_enclosure_refined.json.xz`、`logs/own_levelA_data.txt`。可直接编译 `code/check_p2.cpp` 并运行最后一个命令，约 27 秒；用 `own_A_inner_refined.py` 复算内区约 0.4 秒。**这只能重放最后正性，不能代替从 `inputs.json` 到新 Em′ 的来源验证**。

## 已知差异与不属于本轮的内容

`forms_at_c.eps0_sq` 归档诊断区间与独立值有约 3.1891e−119 的微小错位，不能当作精确包含；证明真正使用的 `eps0` 单向界严格 PASS。验证者应记录两项，而不是改动档案数据隐藏它。

本轮 PENT-22 的冻结包未附到当前对话，所以旧的 far 样本不是 PENT-22 完整覆盖认证。任何正式远区铺砌程序必须同时加载终态 `leaves.jsonl` 与 `cert.jsonl`，并处理断点恢复/各轮累积记录；不能直接把所有历史记录当成无重叠终态盒。

所有严格比较均由整数/有理数决定；Python 打印的小数和图表仅辅助阅读。不做公开发布，不联系外部人员，不修改权威仓库。
