// Standalone strict integer/rational checker for P leaves. No external producer code.
#include <gmpxx.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <array>
#include <algorithm>
#include <chrono>
#include <map>
using namespace std;
using E=array<int,6>;
static constexpr int BASE=7;
struct Index { E a; int d; int p; };
int code(const E&a){int v=0;for(int i=0;i<6;i++)v=v*BASE+a[i];return v;}
mpq_class parse(string s){mpq_class r(s);r.canonicalize();return r;}
int binom(int n,int k){int b=1;for(int i=1;i<=k;i++)b=b*(n-i+1)/i;return b;}
struct Power { mpz_class n;int e; };
Power dyad(string s){ mpq_class q=parse(s);mpz_class n=q.get_num();mpz_class d=q.get_den();int e=0;while(d>1){if(mpz_odd_p(d.get_mpz_t()))throw runtime_error("nondyadic");d>>=1;e++;}return {n,e};}
mpz_class zabs(mpz_class n){return n>=0?n:-n;}
// Ordinary exact rational LDL positivity test (7x7 Schur complement test).
bool pd7(vector<vector<mpq_class>> A){
 int n=A.size();
 for(int j=0;j<n;j++){
  if(A[j][j]<=0)return false;
  for(int i=j+1;i<n;i++)for(int k=j+1;k<=i;k++){
    A[i][k]-=A[i][j]*A[k][j]/A[j][j];if(i!=k)A[k][i]=A[i][k];
  }
 }
 return true;
}
int main(int argc,char**argv){
 auto start=chrono::steady_clock::now();ifstream in(argv[1]);if(!in)throw runtime_error("missing file");
 const int SHIFT=320;mpz_class S=mpz_class(1)<<SHIFT;mpq_class SQ(S);
 vector<Index> ids;map<int,int> where;
 for(int a0=0;a0<=6;a0++)for(int a1=0;a1<=6-a0;a1++)for(int a2=0;a2<=6-a0-a1;a2++)for(int a3=0;a3<=6-a0-a1-a2;a3++)for(int a4=0;a4<=6-a0-a1-a2-a3;a4++)for(int a5=0;a5<=6-a0-a1-a2-a3-a4;a5++){
  E a={a0,a1,a2,a3,a4,a5};int d=a0+a1+a2+a3+a4+a5;where[code(a)]=ids.size();ids.push_back({a,d,code(a)});
 }
 int M;in>>M;vector<mpz_class> init(ids.size());for(int n=0;n<M;n++){
  E a;for(int &v:a)in>>v;mpz_class c;in>>c;init[where.at(code(a))]=c<<160;
 }
 int numerr;in>>numerr;vector<pair<int,mpz_class>> es;
 for(int i=0;i<numerr;i++){int d;mpz_class v;in>>d>>v;es.push_back({d,v});}
 int leafN;in>>leafN;int count=0,crudes=0,duals=0;int fails=0;long double minbound=1e100;vector<int>failed;
 for(int li=0;li<leafN;li++){
  array<string,18> str;for(auto &v:str)in>>v;
  Power m[6],r[6],c[6];mpq_class muv[6];
  for(int j=0;j<6;j++){
   m[j]=dyad(str[j]);r[j]=dyad(str[j+6]);muv[j]=parse(str[j+12]);
   mpq_class q=zabs(m[j].n); q/=mpz_class(1)<<m[j].e; q+=parse(str[j+6]);
   c[j]=dyad(q.get_str());
  }
  // Polynomial substitution, dimension by dimension: p(m+r t). Exact dyadic integers scaled by 2^320.
  vector<mpz_class> cur=init, nxt(ids.size());
  for(int i=0;i<6;i++){
   fill(nxt.begin(),nxt.end(),mpz_class(0));
   mpz_class pm[7],pr[7];pm[0]=1;pr[0]=1;
   for(int k=1;k<=6;k++){pm[k]=pm[k-1]*m[i].n;pr[k]=pr[k-1]*r[i].n;}
   for(size_t j=0;j<ids.size();j++){
    if(cur[j]==0)continue;
    auto a=ids[j].a;int deg=a[i];
    for(int k=0;k<=deg;k++){
     a[i]=k;mpz_class num=cur[j]*binom(deg,k)*pm[deg-k]*pr[k];
     int shift=(deg-k)*m[i].e+k*r[i].e;
     if(shift) { mpz_class check = num%(mpz_class(1)<<shift); if(check!=0)throw runtime_error("bad exact shift");num >>= shift; }
     nxt[where.at(code(a))]+=num;
    }
   }
   cur.swap(nxt);
  }
  mpz_class constant=cur[where.at(code(E{}))];mpz_class g[6],H[6][6],tail=0;
  for(int i=0;i<6;i++){
   E a={};a[i]=1;g[i]=cur[where.at(code(a))];
   for(int j=0;j<6;j++){
    E b={};b[i]++;b[j]++;H[i][j]=cur[where.at(code(b))]*(i==j?2:1);
   }
  }
  for(size_t i=0;i<ids.size();i++) if(ids[i].d>=3)tail+=zabs(cur[i]);
  // Crude safe upper bound for E: replace all six nonnegative coordinates with max(c_i).
  mpq_class C(0);
  for(int i=0;i<6;i++){
   mpq_class q(c[i].n,mpz_class(1)<<c[i].e);if(q>C)C=q;
  }
  mpq_class cp(1),err(0);int last=0;
  for(const auto &ev:es){while(last<ev.first){cp*=C;last++;}err+=mpq_class(ev.second,mpz_class(1)<<160)*cp;}
  mpq_class excess=mpq_class(constant-tail,S)-err;
  mpq_class crude=excess;
  for(int i=0;i<6;i++)crude-=mpq_class(zabs(g[i]),S);
  for(int i=0;i<6;i++)for(int j=0;j<6;j++)crude-=mpq_class(zabs(H[i][j]),S)/2;
  if(crude>0){crudes++;count++;minbound=min(minbound,(long double)crude.get_d());continue;}
  // Dual quadratic lower bound via exact 7x7 Schur positive definiteness.
  mpq_class b=2*excess;
  mpq_class am[6][6];
  for(int i=0;i<6;i++){
   mpq_class rr=parse(str[i+6]);b-=2*muv[i]*rr*rr;
   for(int j=0;j<6;j++)am[i][j]=mpq_class(H[i][j],S)+(i==j?2*muv[i]*rr*rr:mpq_class(0));
  }
  vector<vector<mpq_class>> B(7,vector<mpq_class>(7));B[0][0]=b;
  for(int i=0;i<6;i++){B[0][i+1]=B[i+1][0]=mpq_class(g[i],S);for(int j=0;j<6;j++)B[i+1][j+1]=am[i][j];}
  if(pd7(B)){duals++;count++;}
  else{failed.push_back(li);fails++;if(failed.size()<15)cerr<<"P leaf failed conservative bound "<<li<<" cmax="<<C.get_d()<<" crude="<<crude.get_d()<<"\n";}
  if(li%500==0)cerr<<"progress "<<li<<"/"<<leafN<<" pass="<<count<<" failed="<<fails<<" elapsed="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"s\n";
 }
 cout<<"P leaves="<<leafN<<" PASS="<<count<<" FAIL_TO_CLOSE="<<fails<<" crude="<<crudes<<" dual="<<duals<<" elapsed="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<" s\n";
 cout<<"failed_indices=";for(auto x:failed)cout<<x<<",";cout<<"\n";
}
