"""Independent dual-base cross-check between two self-written derivations (one float diagnostic only)."""
import jax, numpy as np
import independent_k_jax as J
import independent_B_full_attempt as B
import independent_k_all as A
from fractions import Fraction as Q
import json,contextlib,io
p=A.ROOT
r=json.load(open(p/'lowdeg.json'));c=json.load(open(p/'constants.json'))
fmid=(Q(c['F_lo'])+Q(c['F_up']))/2
with contextlib.redirect_stdout(io.StringIO()):st=A.run(f0_override=fmid,save=False)
fields=[B.make_field(k,st) for k in range(5)]
hT=jax.jacfwd(jax.jacfwd(lambda z:J.calc(z,True)[2]))(J.cq)
k='0,0,0,0,0,2';ax=tuple(map(int,k.split(','))); inds=[5,5]
tx=np.array(hT[:,:,:,5,5])/2
for t in range(5):
 print('k',t)
 for j in range(2):
  list_jax=[]
  for I in range(6):
   vals=tx[t,j,I*7:(I+1)*7]
   list_jax.extend(vals)
  our=fields[t][2+j]
  keys=list(range(42));vs=np.array([float(our.get(i,A.Poly(0)).d.get(ax,A.V(0)).mid()) for i in keys]);delta=np.array(list_jax)-vs
  imax=int(np.argmax(abs(delta)))
  print('COMP',j,'max_jax',max(abs(np.array(list_jax))),'max_own',max(abs(vs)),'maxdiff',max(abs(delta)),'worstIdx',imax,'jax',list_jax[imax],'ours',vs[imax])
  if t==0:
   for ii in range(6):print('  basis',ii,'our',vs[ii*7], 'jax',list_jax[ii*7])
