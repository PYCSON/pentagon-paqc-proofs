#!/usr/bin/env python3
"""Fully independent algebraic regular-pentagon geometry and LG norm constants, exact Fraction intervals.
Verified Gram entries are consumed as trusted inputs; their independent recomputation is in gram_full_modular.py.
"""
from fractions import Fraction as Q
from math import isqrt
import json,lzma,time
from pathlib import Path
P=Path('/mnt/data/pent21c_audit/PENT21c_cert_3055e81/lines/D-topics/probes/PENT/local_run_20261117/cert')
C=json.load(open(P/'constants.json'));I=json.load(open(P/'inputs.json'))
G=json.load(lzma.open(P/'gram.json.xz','rt'))

class IV:
 def __init__(self,low,hi=None):
  if isinstance(low,IV):self.a,self.b=low.a,low.b
  else:self.a,self.b=Q(low),Q(low if hi is None else hi)
  if self.a>self.b:raise ValueError('reversed')
 def __add__(x,y):
  y=IV(y);return IV(x.a+y.a,x.b+y.b)
 __radd__=__add__
 def __neg__(x):return IV(-x.b,-x.a)
 def __sub__(x,y):return x+(-IV(y))
 def __rsub__(x,y):return IV(y)-x
 def __mul__(x,y):
  y=IV(y);s=[a*b for a in (x.a,x.b) for b in (y.a,y.b)];return IV(min(s),max(s))
 __rmul__=__mul__
 def __truediv__(x,y):
  y=IV(y)
  if y.a*y.b<=0: raise ZeroDivisionError((str(y.a),str(y.b)))
  return x*IV(1/y.b,1/y.a)
 def __rtruediv__(x,y):return IV(y)/x
 def __pow__(x,n):
  assert n>=0 and int(n)==n
  if n==0:return IV(1)
  if n==1:return IV(x)
  if n%2==1:return x*(x**(n-1))
  # for squares nonnegative; higher even exponents repeated via nonnegative enclosure
  if x.a<=0<=x.b: return IV(0,max(abs(x.a),abs(x.b))**n)
  return IV(min(x.a**n,x.b**n),max(x.a**n,x.b**n))
 def mid(x):return (x.a+x.b)/2
 def intersects(x,y):
  y=IV(y);return max(x.a,y.a)<=min(x.b,y.b)
 def included(x,y):
  y=IV(y);return y.a<=x.a<=x.b<=y.b
 def approx(x):return [format(float(x.a),'.17g'),format(float(x.b),'.17g')]

def sqrt_q(q,bits=256):
 q=Q(q); assert q>=0
 top=(q.numerator<<(2*bits))//q.denominator
 n=isqrt(top)
 assert Q(n*n,1<<(2*bits))<=q and Q((n+1)**2,1<<(2*bits))>q
 return IV(Q(n,1<<bits),Q(n+1,1<<bits))
def sqrt_iv(x,bits=256):
 x=IV(x);return IV(sqrt_q(x.a,bits).a,sqrt_q(x.b,bits).b)
def arcv(v):return IV(Q(v['mid'])-Q(v['rad']),Q(v['mid'])+Q(v['rad']))
def rect(k,a,b):return Q(G['gram'][k][a][b])

def run():
 t=time.perf_counter();bits=512
 root5=sqrt_q(5,bits)
 cos=(root5-1)/4
 sin=sqrt_iv(10+2*root5,bits)/4
 c=[1+cos,sin,IV(Q(1,2)),sin/(2*cos),-cos,sin]
 assert len(c)==6
 chk=[]
 for j,x in enumerate(c):
  arch=arcv(C['c'][j]);inside=x.included(arch)
  chk.append(inside)
  print('C',j,'inside_archive',inside,'width_approx',f'{float(x.b-x.a):.3e}','archive_width',f'{float(arch.b-arch.a):.3e}',flush=True)
 assert all(chk)
 vert=[(IV(0),IV(0)),(IV(1),IV(0)),(c[0],c[1]),(c[2],c[3]),(c[4],c[5])]
 orig=[IV(v) for v in I['O']]
 a0=IV(0);a1=IV(0);a2=IV(0);area=IV(0)
 for k in range(5):
  e1=[vert[k][i]-orig[i] for i in range(2)]
  e2=[vert[(k+1)%5][i]-orig[i] for i in range(2)]
  n11=e1[0]*e1[0]+e1[1]*e1[1]
  n12=e1[0]*e2[0]+e1[1]*e2[1]
  n22=e2[0]*e2[0]+e2[1]*e2[1]
  det=e1[0]*e2[1]-e1[1]*e2[0]
  assert det.a>0
  area+=det/2
  gr=lambda u,v:IV(rect(k,u,v))
  ugrad=(n22*gr(28,28)-2*n12*gr(28,35)+n11*gr(35,35))/det
  a0+=ugrad
  a1+=det*Q(G['mass'][k][0][0])
  s11=det*det*gr(0,0)-2*det*gr(0,21)+gr(21,21)
  s22=det*det*gr(7,7)+2*det*gr(7,14)+gr(14,14)
  s12=det*det*gr(0,7)+det*gr(0,14)-det*gr(21,7)-gr(21,14)
  a2+=(n11*s11+2*n12*s12+n22*s22)/det
 ks=IV(C['KS']);nu=ks/area;lamup=a0/a1;lamlo=(nu*a1-a0)/(nu*a2-a1)
 eps1_sq=(a0-lamlo*a1)/(1-lamup/nu)
 eps0_sq=eps1_sq/nu
 vals={'A0':a0,'A1':a1,'A2':a2,'area_c':area,'nu':nu,'lam_up':lamup,'lam_lo':lamlo,'eps1_sq':eps1_sq,'eps0_sq':eps0_sq}
 for k,x in vals.items():
  archive=arcv(C['forms_at_c'][k]);inside=x.included(archive)
  print('FORM',k,'independent',x.approx(),'width',f'{float(x.b-x.a):.4g}','archive_intersects',x.intersects(archive),'in_archive',inside,'delta_mid',float(x.mid()-archive.mid()),'rad',float((archive.b-archive.a)/2),'lo_minus_hi',float(x.a-archive.b),'hi_minus_archlo',float(x.b-archive.a),flush=True)
  if not x.intersects(archive): print('FAIL mismatched archive',k)
 # One-sided tests use the exact rational limits included in constants.json.
 tests={'F_lo':IV(C['F_lo']).a<=lamlo.a*area.a,
        'F_up':IV(C['F_up']).b>=lamup.b*area.b,
        'eps1':IV(C['eps1']).b**2>=eps1_sq.b,
        'eps0':IV(C['eps0']).b**2>=eps0_sq.b}
 for k,ok in tests.items():
  print('ONE_SIDED',k,'PASS' if ok else 'FAIL',flush=True)
  if not ok:
   if k=='F_lo': delta=Q(C['F_lo'])-lamlo.a*area.a
   elif k=='F_up':delta=lamup.b*area.b-Q(C['F_up'])
   elif k=='eps1':delta=eps1_sq.b-Q(C['eps1'])**2
   else:delta=eps0_sq.b-Q(C['eps0'])**2
   print('FAIL delta',float(delta),flush=True)
 print('ELAPSED',time.perf_counter()-t,flush=True)
 print('STATUS', 'PASS' if all(tests.values()) else 'CHANGES',flush=True)
 return tests
if __name__=='__main__':run()
