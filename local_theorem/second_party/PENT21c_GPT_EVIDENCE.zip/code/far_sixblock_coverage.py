#!/usr/bin/env python3
"""Independent 6D exact box union, includes both leaves.jsonl and cert.jsonl.
Read-only older frozen PENT21 sample ZIP; no producer Python invoked.
"""
from zipfile import ZipFile
from fractions import Fraction as F
from itertools import combinations
from math import prod
import json, collections, time
P='/mnt/data/PENT21_bundle_43939f6 (1).zip'
ROOT='lines/D-topics/probes/PENT/v2_run/tests/far_20261116b/sample_out'
def parse(s):return json.loads(s,parse_float=str)
def mkbox(lo,hi):
 lo=tuple(map(F,lo));hi=tuple(map(F,hi));assert all(x<y for x,y in zip(lo,hi));return lo,hi
def audit(z,chart,name):
 prefix=f'{ROOT}/{chart}/blocks/{name}/'
 leaf=[parse(s) for s in z.read(prefix+'leaves.jsonl').decode().splitlines() if s.strip()]
 cert=[parse(s) for s in z.read(prefix+'cert.jsonl').decode().splitlines() if s.strip()]
 bb=[mkbox(q[2],q[3]) for q in leaf]+[mkbox(q['lo'],q['hi']) for q in cert]
 # Validate each header, status, and no duplicate positive-volume box.
 assert all(len(b[0])==6 for b in bb)
 lower=[min(b[0][i] for b in bb) for i in range(6)]
 upper=[max(b[1][i] for b in bb) for i in range(6)]
 vtot=sum((prod(b[1][i]-b[0][i] for i in range(6)) for b in bb),F(0))
 vroot=prod(upper[i]-lower[i] for i in range(6))
 # Sweep along axis 0 to find any interior overlap, exact rational, no sampling.
 data=sorted(bb,key=lambda x:x[0][0]);active=[];collision=None
 for i,(lo,hi) in enumerate(data):
  active=[(l,h) for l,h in active if h[0]>lo[0]]
  for l,h in active:
   if all(lo[k]<h[k] and l[k]<hi[k] for k in range(6)):
    collision=(lo,hi,l,h);break
  if collision:break
  active.append((lo,hi))
 okay=collision is None and vtot==vroot
 assert lower[-2:]==[0,0] and upper[-2:]==[1,1]
 print(chart,name,'LEAVES',len(leaf),'CERT',len(cert),'TOTAL',len(bb),'root',[[str(a),str(b)] for a,b in zip(lower,upper)],'ratio',str(vtot/vroot),'overlap',bool(collision),'PASS',okay,flush=True)
 assert okay
 return len(bb)
def main():
 t=time.perf_counter();N=0
 with ZipFile(P) as z:
  for ch,name in [('std','27_7'),('std','8_1'),('E2','-4_15'),('E2','12_13'),('E3','24_15'),('E3','15_0')]: N+=audit(z,ch,name)
 print('SIX_BLOCKS_COVERAGE_PASS',N,'elapsed',round(time.perf_counter()-t,3))
if __name__=='__main__': main()
