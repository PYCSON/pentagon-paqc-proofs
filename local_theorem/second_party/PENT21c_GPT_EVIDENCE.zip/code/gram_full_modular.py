#!/usr/bin/env python3
"""Independent exact full Gram via modular integer matrix identities and a proven CRT size bound.
Never executes production code. Monomial re-expansion is independently written in independent_b.py.
"""
import sys,time,json,math,functools,lzma
from fractions import Fraction as F
from pathlib import Path
import numpy as np
from sympy import nextprime
sys.path.insert(0,str(Path(__file__).parent))
import independent_b as B

def run():
 t=time.perf_counter();D=(1<<max(B.CB,-B.xe))*math.lcm(*range(2,max(B.N,B.n)+3))
 # largest monomial degree among all basis polynomials; exact 2D monomial representation
 poly=[];poly_mass=[];maxdeg=0
 for k in range(5):
  rows=[];urs=[];per_b=[]
  for b in range(7):
   f,u=B.bases(k,b);per_b.append(f);urs.append(u)
   for x in f+[u]:
    if x:maxdeg=max(maxdeg,max(sum(a) for a in x))
  rows=[per_b[b][i] for i in range(6) for b in range(7)]
  poly.append(rows);poly_mass.append(urs)
 M=(maxdeg*2+2)
 T=math.factorial(M)
 keys=[(i,j) for i in range(maxdeg+1) for j in range(maxdeg+1-i)]
 N=len(keys)
 H=np.empty((N,N),dtype=object)
 for q,(i,j) in enumerate(keys):
  for r,(k,l) in enumerate(keys):
   tot=i+j+k+l+2
   H[q,r]=T//math.factorial(tot)*math.factorial(i+k)*math.factorial(j+l)
 def makevec(polys):
  out=np.zeros((len(polys),N),dtype=object)
  for q,x in enumerate(polys):
   for a,v in x.items():
    vv=v*D
    if vv.denominator!=1:raise ValueError(('not-integer-coef',q,a,vv))
    out[q,keys.index(a)]=int(vv)
  return out
 Ps=[makevec(v) for v in poly]
 Us=[makevec(v) for v in poly_mass]
 common=D*D*T
 refG=B.G['gram'];refM=B.G['mass']
 for k in range(5):
  assert len(Ps[k])==42 and len(Us[k])==7
  for Z,ref in [(Ps[k],refG[k]),(Us[k],refM[k])]:
   rowabs=[sum(abs(int(x)) for x in row) for row in Z]
   Hmax=max(int(x) for row in H for x in row)
   bound=max(rowabs)**2*Hmax
   targetmax=int(max(abs(F(x)*common) for row in ref for x in row))
   assert all((F(x)*common).denominator==1 for row in ref for x in row)
   nbound=(bound+targetmax)*2+1
   print('block',k,'rows',len(Z),'max difference bound bits',nbound.bit_length(),flush=True)
   # Prime product >2 * absolute upper bound on every independent difference.
   modprod=1;primes=[];q=2**22+int(k)*10000+len(Z)*31
   while modprod<=nbound:
    q=int(nextprime(q+1));primes.append(q);modprod*=q
   for prime in primes:
    hmod=np.asarray(H % prime,dtype=np.int64)
    zmod=np.asarray(Z % prime,dtype=np.int64)
    # dimensions <= 171 and primes <2^23 => int64 matmul cannot overflow
    assert prime<(1<<23) and 2*len(keys)*(prime-1)**2<2**63
    left=(zmod @ hmod)%prime
    got=(left @ zmod.T)%prime
    want=np.array([[int((F(x)*common).numerator%prime) for x in row] for row in ref],dtype=np.int64)
    hit=np.argwhere(got!=want)
    if len(hit):
     a,b=map(int,hit[0]);raise AssertionError(('mod-mismatch',k,len(Z),prime,a,b,int(got[a,b]),int(want[a,b])))
   print('PASS',k,'size',len(Z),'primes',len(primes),'CRT_bits',modprod.bit_length(),'checkable entries',len(Z)*(len(Z)+1)//2,'time_sec',round(time.perf_counter()-t,3),flush=True)
 print('FULL_GRAM_PASS',time.perf_counter()-t)
if __name__=='__main__':run()
