#!/usr/bin/env python3
"""Independent complete coefficient-bounds attempt: D*K, dual linear residual, q and translation.
All decisions exact dyadic or Fraction; independently implements a rigorous (often looser) majorant.
No user/producer code imported or executed. Level B is FULL only if inclusion or Level A reproof succeeds.
"""
import sys,json,math,time,itertools,collections,lzma
from pathlib import Path
from fractions import Fraction as Q
from functools import lru_cache
import independent_k_all as A
from independent_k_all import V,Poly,UNIT,ZERO
import constants_exact as CE

@lru_cache(None)
def sqrtup(q):
 q=Q(q)
 if q==0:return Q(0)
 assert q>0
 return CE.sqrt_q(q,256).b

def qceil(q,shift=160):
 q=Q(q);n=1<<shift;return Q(-((-q.numerator*n)//q.denominator),n)

class Pos:
 __slots__=('d',)
 def __init__(self,z=0):
  if isinstance(z,Pos):self.d=z.d.copy()
  elif isinstance(z,dict):self.d={k:Q(v) for k,v in z.items() if v}
  else:
   zz=Q(z);self.d={ZERO:zz} if zz else {}
 def __add__(x,y):
  y=Pos(y);r=x.d.copy()
  for a,v in y.d.items():r[a]=r.get(a,Q(0))+v
  return Pos(r)
 __radd__=__add__
 def __mul__(x,y):
  y=Pos(y);v={}
  if len(x.d)>len(y.d):x,y=y,x
  for a,t in x.d.items():
   for b,u in y.d.items():
    ky=tuple(a[i]+b[i] for i in range(6));v[ky]=v.get(ky,Q(0))+t*u
  return Pos(v)
 __rmul__=__mul__
 def __pow__(x,n):
  z=Pos(1)
  for _ in range(n):z=z*x
  return z
 def shift_all(x,h):
  h=Q(h);d=x.d.copy()
  for i in range(6):
   nex={}
   for a,v in d.items():
    for j in range(a[i]+1):
     b=list(a);b[i]=j;ky=tuple(b)
     nex[ky]=nex.get(ky,Q(0))+v*math.comb(a[i],j)*h**(a[i]-j)
   d=nex
  return Pos(d)

def maj(p):return Pos({a:v.upperabs() for a,v in p.d.items()})

def join(a,b):
 z=a.copy()
 for i,p in b.items():z[i]=z.get(i,Poly(0))+p
 return z

def fieldscale(v,p):return {i:p*x for i,x in v.items()}
def fieldadd(*args):
 z={}
 for field in args:z=join(z,field)
 return z

def Fmat_coefs(G,vec):
 # coefficients in the 42-variable basis; original free list basis has b=0..6
 out={}
 for i,v in vec.items():
  for j in range(42):
   gg=Q(G[j][i])
   if gg:out[j]=out.get(j,V(0))+V(gg)*v
 return out

def fpoly(field,ma):
 # for phi_I list field: phi_{I, b} from package gram; coefficient 0 maps to poly directly
 return field

def sqrtGramDiag(G):return [sqrtup(Q(G[i][i])) for i in range(42)]

def make_field(k,st):
 n11,n12,n22,det=st['ge'][k]
 nc11,nc12,nc22,dc=st['gc'][k];D=st['D'];Dh=st['Dh'][k]
 Aarea=st['A'];Ac=st['Ac'];F0=st['F0'];K=st['K'];w=st['w']
 pf=Aarea/F0
 Mc11=nc22/dc;Mc12=-(nc12/dc);Mc22=nc11/dc
 # m=M_c rho_c is independent of list b>=1.
 Ma={0:-dc,21:V(1),28:-(Ac/F0)*(nc22/dc),35:(Ac/F0)*(nc12/dc)}
 Mb={7:-dc,14:V(-1),28:(Ac/F0)*(nc12/dc),35:-(Ac/F0)*(nc11/dc)}
 grad1={28+b:w[b] for b in range(7)}
 grad2={35+b:w[b] for b in range(7)}
 s1={b:-det*w[b] for b in range(7)}
 s1.update({21+b:w[b] for b in range(7)})
 s2={7+b:-det*w[b] for b in range(7)}
 s2.update({14+b:-w[b] for b in range(7)})
 rn1=fieldadd(fieldscale(s1,n11),fieldscale(s2,n12),fieldscale(grad1,-det*pf))
 rn2=fieldadd(fieldscale(s1,n12),fieldscale(s2,n22),fieldscale(grad2,-det*pf))
 # det M_z rho_z = det*s - pf * Mnum * grad
 dma=fieldadd(fieldscale(s1,det),fieldscale(grad1,-n22*pf),fieldscale(grad2,n12*pf))
 dmb=fieldadd(fieldscale(s2,det),fieldscale(grad1,n12*pf),fieldscale(grad2,-n11*pf))
 dna=fieldadd(fieldscale({i:Poly(x) for i,x in Ma.items()},n11),fieldscale({i:Poly(x) for i,x in Mb.items()},n12))
 dnb=fieldadd(fieldscale({i:Poly(x) for i,x in Ma.items()},n12),fieldscale({i:Poly(x) for i,x in Mb.items()},n22))
 kl=K*Ac/F0
 lc=fieldadd(fieldscale(rn1,Poly(Mc11)),fieldscale(rn2,Poly(Mc12)))
 lb=fieldadd(fieldscale(rn1,Poly(Mc12)),fieldscale(rn2,Poly(Mc22)))
 tc=fieldadd(fieldscale(dna,Poly(Mc11)),fieldscale(dnb,Poly(Mc12)))
 tb=fieldadd(fieldscale(dna,Poly(Mc12)),fieldscale(dnb,Poly(Mc22)))
 factor=2*Poly(F0)*Dh
 La=fieldscale(fieldadd(fieldscale(lc,Poly(kl)),fieldscale(dma,-Aarea),fieldscale(tc,-Poly(kl))),factor)
 Lb=fieldscale(fieldadd(fieldscale(lb,Poly(kl)),fieldscale(dmb,-Aarea),fieldscale(tb,-Poly(kl))),factor)
 pre=-2*Poly(F0*K)*Dh*(det-Poly(dc))
 Ta=fieldscale(fieldadd(rn1,fieldscale(dna,Poly(-1))),pre)
 Tb=fieldscale(fieldadd(rn2,fieldscale(dnb,Poly(-1))),pre)
 return La,Lb,Ta,Tb

def metric_support(k,st):
 n11,n12,n22,det=st['gc'][k]
 N11=n11/det;N12=n12/det;N22=n22/det
 # upper bound of lambda_max(N) from infinity norm
 mn=max(N11.upperabs()+N12.upperabs(),N22.upperabs()+N12.upperabs())
 return sqrtup(mn), sqrtup(Q(1,1)/Q(det.l,UNIT)),N11,N12,N22

def norm_field_coeff(field,a,diag):
 # field[k] poly field; at exponent a
 return sum(p.d.get(a,V(0)).upperabs()*diag[j] for j,p in field.items())

def exact_bilinear(g,x,y):
 out=Q(0)
 if len(x)>len(y):x,y=y,x
 for j,v in x.items():
  for k,z in y.items():
   gr=Q(g[j][k]);
   if gr:out+=v*z*gr
 return out

def exact_tight_norm(a,fields,st,idx):
 # Return rigorous upper NL, NT for a single α, independent in mid and coefficient error.
 # Tight formulation: mid Gram quadratic plus coefficient radii times diagonal Gram.
 Na=Q(0);Nt=Q(0)
 for k, (La,Lb,Ta,Tb) in enumerate(fields):
  g=st['gg'][k];diag=sqrtGramDiag(tuple(map(tuple,g)))
  nr,sindet,N11,N12,N22=metric_support(k,st)
  def midrad(f):
   vec={};rad=Q(0)
   for j,p in f.items():
    v=p.d.get(a,V(0));
    if v.l or v.h:
     vec[j]=v.mid();rad+=v.rad()*diag[j]
   return vec,rad
  x,rx=midrad(La);y,ry=midrad(Lb);u,ru=midrad(Ta);v,rv=midrad(Tb)
  # mid metrics using exact rational Q of dyadic mid, interval-metric correction
  xx=exact_bilinear(g,x,x);yy=exact_bilinear(g,y,y);xy=exact_bilinear(g,x,y)
  nmid=N11.mid()*xx+2*N12.mid()*xy+N22.mid()*yy
  ne=abs(xx)*N11.rad()+2*abs(xy)*N12.rad()+abs(yy)*N22.rad()
  un=sqrtup(max(nmid+ne,Q(0)))+nr*(rx+ry)
  uu=exact_bilinear(g,u,u);vv=exact_bilinear(g,v,v)
  tun=sqrtup(max(uu+vv,Q(0)))*sindet+(ru+rv)*sindet
  Na+=un*un;Nt+=tun*tun
 return sqrtup(Na),sqrtup(Nt)

def quadratic_majorant(st):
 D=st['D'];Aarea=st['A'];K=st['K'];Fup=Q(st['cc']['F_up']);e0=Q(st['cc']['eps0'])**2;e1=Q(st['cc']['eps1'])**2;Fl=Q(st['cc']['F_lo'])
 Qq=Pos(0)
 for k in range(5):
  n11,n12,n22,det=st['ge'][k];n11c,n12c,n22c,dc=st['gc'][k]
  detmin=Q(dc.l,UNIT);detmax=Q(dc.h,UNIT)
  # M_c has determinant exactly one. Thus 1/lambda_min(M_c) = lambda_max(N_c) <= (n11+n22)/det_c
  normN=(n11c.upperabs()+n22c.upperabs())/detmin
  normM=(n11c.upperabs()+n22c.upperabs())/detmin
  # M_c and N_c both have trace (n11+n22)/det_c and determinant 1
  Gk=e1*normN
  Gamma=normM*e1*(Q(st['Ac'].h,UNIT)/Fl)**2
  Y=e0/(4*detmin)
  s3=maj(n11)+maj(n22)+maj(n12)
  dd=maj(det-Poly(dc))
  # Conservative bound on physical tensor using the spectral row-sum upper majorant.
  t1=maj(D)*maj(Aarea)*maj(det)*(Q(st['cc']['KS'])+Fup)*e0/detmin if False else None
  Qq=Qq + maj(D)*maj(Aarea)*maj(det)*((Q(st['cc']['KS'])+Fup)*e0/detmin)
  Qq=Qq + maj(Aarea)**2*maj(st['Dh'][k])*s3*Gk
  Qq=Qq + maj(st['Dh'][k])*s3*Fup*Q(st['cc']['KS'])*(Pos(Gamma)+dd*(2*sqrtup(Gamma*Y))+dd**2*Y)
 return Qq

def run(refinement=None):
 t0=time.perf_counter();st=A.run() if refinement is None else refinement[0]
 if refinement is not None: st['KD']=refinement[1]
 fields=[];ml=collections.defaultdict(Q);low={};K=st['K'];Fup=Q(st['cc']['F_up']);eps1=Q(st['cc']['eps1']);eps0=Q(st['cc']['eps0'])
 for k in range(5):
  fs=make_field(k,st) if refinement is None else refinement[2][k];fields.append(fs)
  diag=sqrtGramDiag(tuple(map(tuple,st['gg'][k])));nr,rs,N11,N12,N22=metric_support(k,st)
  for jj,f in enumerate(fs):
   fac=(eps1*nr) if jj<2 else (eps0*rs/2)
   for b,p in f.items():
    dg=diag[b]*fac
    for a,v in p.d.items():
     ml[a]+=v.upperabs()*dg
  print('LINEAR k',k,'elapsed',round(time.perf_counter()-t0,3),'entries',len(ml),flush=True)
 E_lin=Pos(ml)
 for a in [tuple(int(x) for x in kk.split(',')) for kk in st['raw'] if sum(int(x) for x in kk.split(',')) in (2,3)]:
  na,nt=exact_tight_norm(a,fields,st,0)
  low[a]=eps1*na+eps0*nt/2
 print('TIGHT',len(low),'sec',time.perf_counter()-t0,flush=True)
 Mq=quadratic_majorant(st)
 print('QUAD',len(Mq.d),'sec',time.perf_counter()-t0,flush=True)
 Bmaj=maj(st['KD'])+E_lin+Mq
 HB=Q(st['cc']['HB']);HS=Q(st['cc']['HS'])
 shifted=Bmaj.shift_all(HS)
 shift=Pos({a:(v-Bmaj.d.get(a,Q(0)))*HB/HS for a,v in shifted.d.items() if v-Bmaj.d.get(a,Q(0))>0})
 print('SHIFT',len(shift.d),'sec',time.perf_counter()-t0,flush=True)
 w=st['witness'];passed=0;bad=[];tm={};em={};degree=collections.defaultdict(lambda:[0,0]);maxrelative=(Q(0),None)
 for key,v in w['Em'].items():
  a=tuple(map(int,key.split(',')));deg=sum(a)
  Kc=st['KD'].d.get(a,V(0));m=Kc.mid();r=Kc.rad();e1=low.get(a,E_lin.d.get(a,Q(0)))
  e=r+e1+Mq.d.get(a,Q(0))+shift.d.get(a,Q(0)); ref=Q(w['Tm'].get(key,'0'));er=Q(v)
  inc=abs(m-ref)+e<=er
  passed+=inc;degree[deg][0]+=1;degree[deg][1]+=inc
  if not inc and len(bad)<200:bad.append((key,float(m-ref),float(e),float(er),float(e1),float(Mq.d.get(a,Q(0))),float(shift.d.get(a,Q(0)))))
  tm[a]=m;em[a]=e
  if er>0 and (abs(m-ref)+e)/er>maxrelative[0]:maxrelative=((abs(m-ref)+e)/er,key)
 print('INCLUSION',passed,'/',len(w['Em']),'FAIL',len(w['Em'])-passed,'MAX_RATIO',float(maxrelative[0]),maxrelative[1],'BREAKDOWN',dict(degree),'EXAMPLES',bad[:12],flush=True)
 # For the required vanishing constant and gradient, compute independent strict errors including shifts.
 lowzero=[]
 for key,ref in json.load(open(CE.P/'lowdeg.json')).items():
  a=tuple(map(int,key.split(',')))
  if sum(a)>1:continue
  kd=st['KD'].d.get(a,V(0));bound=kd.upperabs()+E_lin.d.get(a,Q(0))+Mq.d.get(a,Q(0))+shift.d.get(a,Q(0))
  lowzero.append((key,float(bound),float(kd.upperabs())))
 print('LOW_DEG',lowzero,flush=True)
 # Own rounded rational enclosure for a conditional reproof attempt; conservatively round to same 2^-160 grid.
 tk={','.join(map(str,a)):str(qceil(v*0+tm[a])) for a,v in tm.items()}
 # centers exact dyadic, and error = actual bound + rounding gap to stored centre
 ownTm={};ownEm={}
 for a,m in tm.items():
  kk=','.join(map(str,a));v=Q(round(m*(1<<160)),1<<160)
  ownTm[kk]=str(v)
  ownEm[kk]=str(qceil(em[a]+abs(m-v)))
 out=Path('/mnt/data/pent21c_audit/delivery/logs/own_levelB_enclosure_refined.json.xz' if refinement is not None else '/mnt/data/pent21c_audit/delivery/logs/own_levelB_enclosure.json.xz')
 with lzma.open(out,'wt') as f:json.dump({'Tm':ownTm,'Em':ownEm,'gbits':160,'rho_in':str(Q(1,128))},f)
 print('OWN_ENCLOSURE_SAVED',out.stat().st_size,'elapsed',time.perf_counter()-t0,flush=True)
 return dict(passed=passed,total=len(w['Em']),ownTm=ownTm,ownEm=ownEm,fields=fields,stats=degree)
if __name__=='__main__':run()
