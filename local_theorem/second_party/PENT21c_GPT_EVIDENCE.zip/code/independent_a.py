#!/usr/bin/env python3
"""Independent strict-rational Level A audit: no producer imports."""
import os,json,sys,math,itertools,time,collections,random
from fractions import Fraction as Q
from functools import lru_cache
DIR=os.environ.get('PENT21C_CERT_DIR','/mnt/data/pent21c_audit/PENT21c_cert_3055e81/lines/D-topics/probes/PENT/local_run_20261117/cert')
ZERO=(0,)*6

def load():
 w=json.load(open(f'{DIR}/witness.json'))
 conv=lambda m:{tuple(map(int,k.split(','))):Q(v) for k,v in m.items()}
 return conv(w['Tm']),conv(w['Em'])

def pd(A):
 n=len(A); L=[[Q(0)]*n for i in range(n)];D=[]
 for j in range(n):
  d=A[j][j]-sum((L[j][k]**2)*D[k] for k in range(j))
  if d<=0:return None
  D.append(d)
  for i in range(j+1,n):
   L[i][j]=(A[i][j]-sum(L[i][k]*L[j][k]*D[k] for k in range(j)))/d
 return D

def inner(tm,em,r=Q(1,128)):
 h=[[Q(0)]*6 for _ in range(6)]; t=[[[Q(0)]*6 for _ in range(6)] for _ in range(6)]
 for a,v in tm.items():
  d=sum(a)
  if d==2:
   ix=[j for j in range(6) for _ in range(a[j])]
   if ix[0]==ix[1]:h[ix[0]][ix[1]]+=2*v
   else:h[ix[0]][ix[1]]+=v;h[ix[1]][ix[0]]+=v
  if d==3:
   ix=[j for j in range(6) for _ in range(a[j])]; perms=set(itertools.permutations(ix))
   for i,j,k in perms:t[i][j][k]+=v/len(perms)
 def ee(i,j):
  k=[0]*6;k[i]+=1;k[j]+=1;return em.get(tuple(k),Q(0))
 def wt(a):return Q(1) if max(a)==sum(a) else Q(1,2)
 tau2=max(ee(i,i)+sum(ee(i,j) for j in range(6) if j!=i)/2 for i in range(6))
 tau3=r*sum(v*wt(a) for a,v in em.items() if sum(a)==3)
 tau4=sum(r**(sum(a)-2)*(abs(tm.get(a,Q(0)))+em.get(a,Q(0)))*wt(a) for a in set(tm)|set(em) if sum(a)>=4)
 tau=tau2+tau3+tau4
 piv=[]
 for s in itertools.product([-1,1],repeat=6):
  A=[[h[i][j]/2 + r*sum(s[k]*t[k][i][j] for k in range(6))-(tau if i==j else 0) for j in range(6)]for i in range(6)]
  ds=pd(A)
  if ds is None:return False,{'tau2':tau2,'tau3':tau3,'tau4':tau4,'tau':tau,'failure_sign':s}
  piv.extend(ds)
 return True,{'tau2':tau2,'tau3':tau3,'tau4':tau4,'tau':tau,'min_pivot':min(piv),'H':h,'T':t}

def geometry(lines):
 root=lines[0];W=Q(root['W']);R=Q(root['R']);r=Q(root['rho_in'])
 assert root['t']=='root' and W>R>r>0
 b=[];volume=Q(0);types=collections.Counter()
 lb=[-W,-W,Q(0),-W,-W,-W];ub=[W]*6
 for idx,L in enumerate(lines[1:]):
  typ=L['t'];m=[Q(x) for x in L['m']];h=[Q(x) for x in L['r']]
  if typ not in ['I','O','P'] or len(h)!=6 or min(h)<=0:return False,idx
  lo=[m[i]-h[i] for i in range(6)];hi=[m[i]+h[i] for i in range(6)]
  if any(lo[i]<lb[i] or hi[i]>ub[i] for i in range(6)):return False,('out_of_root',idx)
  if typ=='I' and not all(abs(m[i])+h[i]<=r for i in range(6)):return False,('I',idx)
  if typ=='O' and sum(max(abs(m[i])-h[i],Q(0))**2 for i in range(6))<R*R:return False,('O',idx)
  v=math.prod(hi[i]-lo[i] for i in range(6));volume+=v; b.append((lo,hi,idx));types[typ]+=1
 if volume != (2*W)**5*W:return False,('volume',str(volume/((2*W)**5*W)))
 # Detect overlaps with sweep line along the first dimension.
 active=[]
 for lo,hi,i in sorted(b,key=lambda x:x[0][0]):
  active=[(x,y,j) for (x,y,j) in active if y[0]>lo[0]]
  for x,y,j in active:
   if all(lo[k]<y[k] and x[k]<hi[k] for k in range(6)):
    return False,('overlap',i,j)
  active.append((lo,hi,i))
 return True,dict(types=types,volume=str(volume),n=len(b))

if __name__=='__main__':
 t0=time.time();tm,em=load();print('coefficients',len(tm),len(em),flush=True)
 good,inf=inner(tm,em);print('inner',good,{k:float(v) for k,v in inf.items() if isinstance(v,Q)},'elapsed',time.time()-t0,flush=True)
 ref=json.load(open(f'{DIR}/inner.json'))
 if good:print('inner difference to reference', {k:float(inf[k]-Q(ref['tau_ge4' if k=='tau4' else k])) for k in ['tau2','tau3','tau4','tau','min_pivot']},flush=True)
 lines=[json.loads(s) for s in open(f'{DIR}/leaves.jsonl')];okay,info=geometry(lines);print('geometry',okay,info,'elapsed',time.time()-t0,flush=True)
 if good and okay:
  key=max((k for k in tm if sum(k)==2),key=lambda k:tm[k]);tm2=tm.copy();tm2[key]=-abs(tm[key]);print('tamper: flip diagonal',key,inner(tm2,em)[0],flush=True)
  altered=[x.copy() for x in lines];altered[100]=dict(lines[100]);altered[100]['m']=lines[100]['m'].copy();altered[100]['m'][0]='100';print('tamper: move leaf',geometry(altered)[0],flush=True)
  em2={k:v*100 for k,v in em.items()};print('tamper: inflate Em x100',inner(tm,em2)[0],flush=True)
