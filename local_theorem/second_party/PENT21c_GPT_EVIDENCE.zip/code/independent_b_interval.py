"""Exact rational interval propagation of reference coordinate uncertainty."""
from fractions import Fraction as F
import independent_b as B
import json,time
P=B.P;C=B.C;I=B.I
class IV:
 def __init__(self,a,b=None):
  if isinstance(a,IV):self.lo,self.hi=a.lo,a.hi
  else:self.lo=F(a);self.hi=F(a if b is None else b)
 def __add__(x,y):
  y=IV(y);return IV(x.lo+y.lo,x.hi+y.hi)
 __radd__=__add__
 def __neg__(x):return IV(-x.hi,-x.lo)
 def __sub__(x,y):return x+-IV(y)
 def __rsub__(x,y):return IV(y)+-x
 def __mul__(x,y):
  y=IV(y);v=[a*b for a in (x.lo,x.hi) for b in (y.lo,y.hi)];return IV(min(v),max(v))
 __rmul__=__mul__
 def __truediv__(x,y):
  y=IV(y);assert y.lo*y.hi>0;return x*IV(1/y.hi,1/y.lo)
 def __rtruediv__(x,y):return IV(y)/x
 def intersect(y,rec):
  a=F(rec['mid']);r=F(rec['rad']);return not (y.hi<a-r or y.lo>a+r)
 def inside(y,rec):
  a=F(rec['mid']);r=F(rec['rad']);return a-r<=y.lo<=y.hi<=a+r
 def show(x):return (float(x.lo),float(x.hi))

def run():
 t0=time.time();c=[IV(F(v['mid'])-F(v['rad']),F(v['mid'])+F(v['rad'])) for v in C['c']];v=[(IV(0),IV(0)),(IV(1),IV(0)),(c[0],c[1]),(c[2],c[3]),(c[4],c[5])];o=[IV(x) for x in I['O']]
 allA=[IV(0),IV(0),IV(0)];area=IV(0)
 for k in range(5):
  a=[v[k][i]-o[i] for i in range(2)];b=[v[(k+1)%5][i]-o[i] for i in range(2)]
  n11=a[0]*a[0]+a[1]*a[1];n12=a[0]*b[0]+a[1]*b[1];n22=b[0]*b[0]+b[1]*b[1];det=a[0]*b[1]-a[1]*b[0]
  assert det.lo>0;area+=det/IV(2)
  Bs,u=B.bases(k,0)
  U=[B.integral(Bs[i],Bs[i]) for i in range(6)]
  A0=(n22*U[4]-2*n12*B.integral(Bs[4],Bs[5])+n11*U[5])/det
  A1=det*B.integral(u,u)
  # Flux s = -det*[a h,b h]+curl chi
  A=Bs[0];D=Bs[1];ch_a=Bs[2];ch_b=Bs[3]
  # Assemble invariant quadratic coefficients instead of dynamic field intervals
  s1d=B.integral(A,A);s2d=B.integral(D,D);s12d=B.integral(A,D)
  u13=B.integral(A,ch_b);u12=B.integral(A,ch_a);u23=B.integral(D,ch_b);u22=B.integral(D,ch_a)
  ch33=B.integral(ch_b,ch_b);ch22=B.integral(ch_a,ch_a);ch23=B.integral(ch_a,ch_b)
  s11=det*det*s1d-2*det*u13+ch33
  s22=det*det*s2d+2*det*u22+ch22
  s12=det*det*s12d+det*u12-det*u23-ch23
  A2=(n11*s11+2*n12*s12+n22*s22)/det
  allA[0]+=A0;allA[1]+=A1;allA[2]+=A2
 ks=IV(C['KS']);nu=ks/area;lamup=allA[0]/allA[1];lamlo=(nu*allA[1]-allA[0])/(nu*allA[2]-allA[1]);eps1=(allA[0]-lamlo*allA[1])/(1-lamup/nu);eps0=eps1/nu
 for name,x in [('A0',allA[0]),('A1',allA[1]),('A2',allA[2]),('area_c',area),('nu',nu),('lam_up',lamup),('lam_lo',lamlo),('eps1_sq',eps1),('eps0_sq',eps0)]:
  ref=C['forms_at_c'][name]
  print(name,'lo',format(float(x.lo),'.15g'),'hi',format(float(x.hi),'.15g'),'width',format(float(x.hi-x.lo),'.3g'),'archive_overlap',x.intersect(ref),'inside_archive',x.inside(ref),flush=True)
 print('elapsed',time.time()-t0)
if __name__=='__main__':run()
