#!/usr/bin/env python3
"""Independent six-variable all-degree explicit D*K enclosure.
Uses a homegrown fixed-point integer interval polynomial ring. No production imports.
Read-only package coefficients are used only for exact reference integrals and comparison.
"""
import sys,time,json,lzma,math,itertools,collections
from pathlib import Path
from fractions import Fraction as Q
import constants_exact as CE
ROOT=CE.P
B=192;UNIT=1<<B; ZERO=(0,)*6

def fl(x):return x//UNIT

def ceildiv(a,b):return -((-a)//b)
class V:
 __slots__=('l','h')
 def __init__(self,x=0,y=None, raw=False):
  if isinstance(x,V):self.l=x.l;self.h=x.h;return
  if raw:self.l=int(x);self.h=int(y);return
  if isinstance(x,CE.IV):
   x,y=x.a,x.b
  elif y is None:y=x
  x=Q(x);y=Q(y)
  self.l=(x.numerator*UNIT)//x.denominator
  self.h=ceildiv(y.numerator*UNIT,y.denominator)
  assert self.l<=self.h
 @classmethod
 def raw(cls,l,h):return cls(l,h,True)
 def __add__(x,y):
  y=V(y);return V.raw(x.l+y.l,x.h+y.h)
 __radd__=__add__
 def __neg__(x):return V.raw(-x.h,-x.l)
 def __sub__(x,y):return x+-V(y)
 def __rsub__(x,y):return V(y)+-x
 def __mul__(x,y):
  y=V(y);prod=(x.l*y.l,x.l*y.h,x.h*y.l,x.h*y.h)
  return V.raw(min(prod)//UNIT,ceildiv(max(prod),UNIT))
 __rmul__=__mul__
 def reciprocal(x):
  assert x.l*x.h>0,(x.l,x.h)
  return V.raw(UNIT*UNIT//x.h,ceildiv(UNIT*UNIT,x.l))
 def __truediv__(x,y):return x*V(y).reciprocal()
 def __rtruediv__(x,y):return V(y)/x
 def __abs__(x):return V.raw(0,max(abs(x.l),abs(x.h)))
 def mid(x):return Q(x.l+x.h,2*UNIT)
 def rad(x):return Q(x.h-x.l,2*UNIT)
 def upperabs(x):return Q(max(abs(x.l),abs(x.h)),UNIT)
 def f(x):return (x.l+x.h)/(2*UNIT)

def asv(x):return x if isinstance(x,V) else V(x)

class Poly:
 __slots__=('d',)
 def __init__(self,x=0):
  if isinstance(x,Poly):self.d=x.d.copy()
  elif isinstance(x,dict):self.d={k:asv(v) for k,v in x.items() if not (asv(v).l==0 and asv(v).h==0)}
  else:
   v=asv(x);self.d={ZERO:v} if (v.l or v.h) else {}
 @classmethod
 def var(cls,i):
  e=[0]*6;e[i]=1;return cls({tuple(e):V(1)})
 def __add__(x,y):
  y=Poly(y);out=x.d.copy()
  for k,v in y.d.items():out[k]=out.get(k,V(0))+v
  return Poly(out)
 __radd__=__add__
 def __neg__(x):return Poly({k:-v for k,v in x.d.items()})
 def __sub__(x,y):return x+-Poly(y)
 def __rsub__(x,y):return Poly(y)-x
 def __mul__(x,y):
  y=Poly(y);out={}
  if len(x.d)>len(y.d):x,y=y,x
  for a,va in x.d.items():
   for b,vb in y.d.items():
    t=tuple(a[i]+b[i] for i in range(6));val=va*vb
    out[t]=out[t]+val if t in out else val
  return Poly(out)
 __rmul__=__mul__
 def __truediv__(x,y):return x*asv(y).reciprocal()
 def __pow__(x,n):
  assert int(n)==n and n>=0
  z=Poly(1)
  for _ in range(n):z=z*x
  return z
 def upabs(x):return {k:v.upperabs() for k,v in x.d.items()}

def gweight(g,k,w):
 # matrix of seven lists by seven lists, weighted function pairing between block I and block J
 out=Poly(0)
 for b in range(7):
  for c in range(7):
   x=Q(g[b][c])
   if x:out=out+w[b]*w[c]*V(x)
 return out

def run(f0_override=None,save=True):
 t0=time.perf_counter();inp=json.load(open(ROOT/'inputs.json'));cc=json.load(open(ROOT/'constants.json'))
 gg=json.load(lzma.open(ROOT/'gram.json.xz','rt'))['gram'];witness=json.load(open(ROOT/'witness.json'))
 raw=json.load(lzma.open(ROOT/'parts.json.xz','rt'))['parts']
 c0=CE.sqrt_q(5,512);cos=(c0-1)/4;sin=CE.sqrt_iv(10+2*c0,512)/4
 c=[V(1+cos),V(sin),V(Q(1,2)),V(sin/(2*cos)),V(-cos),V(sin)]
 cp=[V(x) for x in inp['Cq']];eta=[c[i]-cp[i] for i in range(6)]
 w=[Poly(1)]+[Poly.var(i)-Poly(eta[i]) for i in range(6)]
 O=[V(q) for q in inp['O']];z=[Poly(cp[i])+Poly.var(i) for i in range(6)]
 vt=[(Poly(0),Poly(0)),(Poly(1),Poly(0)),(z[0],z[1]),(z[2],z[3]),(z[4],z[5])]
 ge=[]
 for k in range(5):
  a=[vt[k][i]-Poly(O[i]) for i in range(2)];b=[vt[(k+1)%5][i]-Poly(O[i]) for i in range(2)]
  n11=a[0]*a[0]+a[1]*a[1];n12=a[0]*b[0]+a[1]*b[1];n22=b[0]*b[0]+b[1]*b[1];det=a[0]*b[1]-a[1]*b[0]
  ge.append((n11,n12,n22,det))
 gc=[];vc=[(V(0),V(0)),(V(1),V(0)),(c[0],c[1]),(c[2],c[3]),(c[4],c[5])]
 for k in range(5):
  a=[vc[k][i]-O[i] for i in range(2)];b=[vc[(k+1)%5][i]-O[i] for i in range(2)]
  gc.append((a[0]*a[0]+a[1]*a[1],a[0]*b[0]+a[1]*b[1],b[0]*b[0]+b[1]*b[1],a[0]*b[1]-a[1]*b[0]))
 A=sum((g[3] for g in ge),Poly(0))*V(Q(1,2));Ac=sum((g[3] for g in gc),V(0))/V(2)
 D=Poly(1)
 for _,_,_,d in ge:D=D*d
 Dh=[]
 for k in range(5):
  q=Poly(1)
  for j in range(5):
   if j!=k:q=q*ge[j][3]
  Dh.append(q)
 Flo=Q(cc['F_lo']);Fup=Q(cc['F_up']);F0=V(Flo,Fup) if f0_override is None else V(f0_override);K=V(cc['KS']);pf=Ac/F0
 mass=Poly(0);grads=[];flux=[];X=Poly(0);Y=Poly(0)
 for k in range(5):
  g=gg[k];gm=json.load(lzma.open(ROOT/'gram.json.xz','rt'))['mass'][k] if False else None
  def norm(i,j):
   mat=[[g[7*i+b][7*j+c] for c in range(7)] for b in range(7)]
   return gweight(mat,k,w)
  n11,n12,n22,det=ge[k]
  # Build only required pairings; group blocks are indexed I*7+b
  p={}
  need=[(i,j) for i,j in itertools.combinations_with_replacement(range(6),2)]
  for i,j in need:p[(i,j)]=norm(i,j)
  def n(i,j):return p[(min(i,j),max(i,j))]
  m=json.load(lzma.open(ROOT/'gram.json.xz','rt'))['mass'][k] if False else None
  # weighted mass form is computed separately once below
  grad=n22*n(4,4)-2*n12*n(4,5)+n11*n(5,5)
  s11=det*det*n(0,0)-2*det*n(0,3)+n(3,3)
  s22=det*det*n(1,1)+2*det*n(1,2)+n(2,2)
  s12=det*det*n(0,1)+det*n(0,2)-det*n(1,3)-n(2,3)
  fl=n11*s11+2*n12*s12+n22*s22
  grads.append(grad);flux.append(fl)
  print('prepared triangle',k,'sec',round(time.perf_counter()-t0,2),flush=True)
 # compute all weighted mass forms using the archived gram mass (already independently checked)
 gm=json.load(lzma.open(ROOT/'gram.json.xz','rt'))['mass']
 for k in range(5):
  mass=mass+ge[k][3]*gweight(gm[k],k,w)
 KD=D*A*(Poly(K)+Poly(F0))*mass
 for k in range(5):
  KD=KD-A*A*Dh[k]*grads[k]-Poly(F0*K)*Dh[k]*flux[k]
 print('base D Psi assembled',len(KD.d),round(time.perf_counter()-t0,2),flush=True)
 # Rho_c m-field independent construction from exact flux of tilde u at c.
 for k in range(5):
  n11c,n12c,n22c,dc=gc[k]
  Ma={0:-dc,3:V(1),4:-(Ac/F0)*(n22c/dc),5:(Ac/F0)*(n12c/dc)}
  Mb={1:-dc,2:V(-1),4:(Ac/F0)*(n12c/dc),5:-(Ac/F0)*(n11c/dc)}
  # The second part of correction contains constant gram of m0 fields, and cross1 is linear in w.
  g=gg[k]
  def cross(i,coefs):
   f=Poly(0)
   for b in range(7):
    s=V(0)
    for j,v in coefs.items():s+=v*V(Q(g[i*7+b][j*7]))
    if s.l or s.h:f+=w[b]*Poly(s)
   return f
  def mcross(u,v):
   s=V(0)
   for i,ui in u.items():
    for j,vj in v.items():s+=ui*vj*V(Q(g[i*7][j*7]))
   return s
  n11,n12,n22,det=ge[k]
  xs1a=-det*cross(0,Ma)+cross(3,Ma)
  xs2a=-det*cross(1,Ma)-cross(2,Ma)
  xs1b=-det*cross(0,Mb)+cross(3,Mb)
  xs2b=-det*cross(1,Mb)-cross(2,Mb)
  ga=cross(4,Ma);gb=cross(5,Mb)
  rho_nm=n11*xs1a+n12*xs2a+n12*xs1b+n22*xs2b
  rho_grad=ga+gb
  correction=2*Poly(F0*K)*Dh[k]*rho_nm-2*Poly(K)*D*A*rho_grad
  tail=n11*Poly(mcross(Ma,Ma))+2*n12*Poly(mcross(Ma,Mb))+n22*Poly(mcross(Mb,Mb))
  KD=KD+correction-Poly(F0*K)*Dh[k]*tail
  print('cross correction',k,'coeffs',len(KD.d),'sec',round(time.perf_counter()-t0,2),flush=True)
 # Direct degreewise necessary consistency tests for the computed K enclosure.
 ok_center=ok_Krad=ok_envelope=0;bad=[];errors=[];by_degree=collections.defaultdict(lambda:[0,0,0])
 bit=witness['gbits'];den=1<<bit
 for ky,(kr,el,eq,sh,t) in raw.items():
  a=tuple(map(int,ky.split(',')));vv=KD.d.get(a,V(0))
  cen=Q(witness['Tm'].get(ky,'0'));allowed=Q(kr,den)
  ck=abs(vv.mid()-cen);rr=vv.rad();d=sum(a)
  by_degree[d][0]+=1
  if ck<=allowed:ok_center+=1;by_degree[d][1]+=1
  if ck+rr<=allowed:ok_Krad+=1;by_degree[d][2]+=1
  if ck+rr<=Q(witness['Em'][ky]):ok_envelope+=1
  if ck+rr>allowed:bad.append((ky,float(ck),float(rr),float(allowed)))
  if ck+rr>Q(witness['Em'][ky]):errors.append((ky,float(ck+rr),float(Q(witness['Em'][ky]))))
 print('K_COUNTS','coeff',len(KD.d),'archive',len(raw),'centres_inside_Krad',ok_center,'K_interval_inside_Krad',ok_Krad,'K_within_total_Em',ok_envelope)
 print('DEGREE_BREAKDOWN',dict(by_degree),'Krad_fail_examples',bad[:12],'Em_fail_examples',errors[:12],flush=True)
 # compare deg 0,1 with exact archives lowdeg
 ref=json.load(open(ROOT/'lowdeg.json'))
 for key,r in ref.items():
  a=tuple(map(int,key.split(',')))
  if sum(a)>2:continue
  v=KD.d.get(a,V(0));k=Q(r['K_mid']);d=abs(v.mid()-k)+v.rad();rad=Q(r['K_rad']);print('LOWDEG',key,'distance',float(d),'archive K_rad',float(rad),'PASS' if d<=rad else 'WIDER',flush=True)
 print('ELAPSED',time.perf_counter()-t0,flush=True)
 # Save sparse independent computable K′ central coefficients and error interval as exact dyadics.
 if save:
  out=Path('/mnt/data/pent21c_audit/delivery/logs/independent_K_coeffs.json.xz')
  payload={','.join(map(str,a)):[str(Q(v.l,UNIT)),str(Q(v.h,UNIT))] for a,v in KD.d.items()}
  with lzma.open(out,'wt') as f:json.dump(payload,f)
  print('COEFFS_FILE',out,'bytes',out.stat().st_size)
 return dict(inp=inp,cc=cc,gg=gg,gm=gm,witness=witness,raw=raw,c=c,cp=cp,eta=eta,w=w,ge=ge,gc=gc,A=A,Ac=Ac,D=D,Dh=Dh,F0=F0,K=K, KD=KD)
if __name__=='__main__':run()
