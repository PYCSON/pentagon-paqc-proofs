#!/usr/bin/env python3
"""Rigorous Laurent dependency cancellation in the one-dimensional unknown F0.
For D*K and D*Lambda/Theta, algebra shows each scalar coefficient has form aF+b+c/F.
Three exact anchor values reconstruct a,b,c as outward dyadic intervals.  This is
NOT a floating-point interpolation: every division, addition and multiplication
is performed with rationally enclosed integer intervals.
"""
from fractions import Fraction as Q
import contextlib,io,json,lzma,time,sys,collections
from pathlib import Path
import independent_k_all as A
from independent_k_all import V,Poly,UNIT
from independent_B_full_attempt import make_field
P=A.ROOT

def laurent(yminus,y0,yplus,fmid,Factual):
 # c(F) = a*F + b + c/F.  This is a structural algebraic identity,
 # not a numerical approximation; F0 is positive by certificate.
 xm=V(fmid);fm=V(fmid-1);fp=V(fmid+1)
 gm=fm*yminus;g0=xm*y0;gp=fp*yplus
 aa=(gm-2*g0+gp)/2
 bb=(gp-gm)/2-2*xm*aa
 cc=g0-xm*xm*aa-xm*bb
 return y0+(Factual-xm)*(aa-cc/(Factual*xm))

def interpolate_3(Vminus,Vmid,Vplus,fmid,Factual):
 out={}
 for a in set(Vminus)|set(Vmid)|set(Vplus):
  va=Vminus.get(a,V(0));vb=Vmid.get(a,V(0));vc=Vplus.get(a,V(0))
  out[a]=laurent(va,vb,vc,fmid,Factual)
 return out

def run():
 t=time.perf_counter();u=json.load(open(P/'constants.json'));fmid=(Q(u['F_lo'])+Q(u['F_up']))/2
 states=[]
 for f in [fmid-1,fmid,fmid+1]:
  with contextlib.redirect_stdout(io.StringIO()):st=A.run(f0_override=f,save=False)
  states.append(st)
  print('anchor',float(f),'elapsed',time.perf_counter()-t,flush=True)
 Factual=V(Q(u['F_lo']),Q(u['F_up']))
 kd=[s['KD'].d for s in states]; Kref=Poly(interpolate_3(*kd,fmid,Factual))
 w=states[1]['witness'];parts=states[1]['raw'];passK=passEm=0;bad=[];bydeg=collections.defaultdict(lambda:[0,0])
 for k,(kr,ell,eq,sh,tight) in parts.items():
  a=tuple(map(int,k.split(',')));q=Kref.d.get(a,V(0));t=Q(w['Tm'].get(k,'0'));rad=Q(kr,1<<160);r=q.rad()+abs(q.mid()-t)
  aK=r<=rad+Q(1,1<<160)
  bK=r<=Q(w['Em'][k]);passK+=aK;passEm+=bK;d=sum(a);bydeg[d][0]+=1;bydeg[d][1]+=aK
  if not bK and len(bad)<20:bad.append((k,float(r),float(Q(w['Em'][k]))))
 print('K_REFINED',passK,'of',len(parts),'K_part_PLUS_rounding', 'INSIDE_Em',passEm,'bydegree',dict(bydeg),'bad',bad[:7],flush=True)
 print('K_128_WIDTH',[(k,float(Kref.d[tuple(map(int,k.split(',')))].rad())) for k in list(parts)[:4]],flush=True)
 fields=[]
 for s in states:
  fs=[]
  for k in range(5):fs.append(make_field(k,s))
  fields.append(fs)
  print('field',len(fields),'elapsed',time.perf_counter()-t,flush=True)
 improved=[];count=0
 for k in range(5):
  q=[]
  for component in range(4):
   fs=[fields[i][k][component] for i in range(3)]
   cmp={}
   for basis in set(fs[0])|set(fs[1])|set(fs[2]):
    polys=[f.get(basis,Poly(0)).d for f in fs]
    cmp[basis]=Poly(interpolate_3(*polys,fmid,Factual))
   q.append(cmp)
   count+=sum(len(p.d) for p in cmp.values())
  improved.append(tuple(q))
  print('field refine',k,'count',count,'elapsed',time.perf_counter()-t,flush=True)
 print('REFINE_DONE',time.perf_counter()-t)
 return states[1],Kref,improved
if __name__=='__main__':run()
