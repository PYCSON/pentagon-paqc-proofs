#!/usr/bin/env python3
"""Original, exact rational geometric Level A audit. No producer code executed."""
import json,time
from pathlib import Path
import independent_a as A
P=Path('/mnt/data/pent21c_audit/PENT21c_cert_3055e81/lines/D-topics/probes/PENT/local_run_20261117/cert')
t=time.perf_counter()
with open(P/'leaves.jsonl') as f: leaves=[json.loads(x) for x in f if x.strip()]
r=A.geometry(leaves)
print('EXACT_GEOMETRY',r,'leaf_records',len(leaves),'elapsed',round(time.perf_counter()-t,4))
assert r[0]
