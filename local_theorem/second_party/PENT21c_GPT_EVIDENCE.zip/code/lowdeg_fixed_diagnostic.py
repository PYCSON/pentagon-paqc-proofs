#!/usr/bin/env python3
"""Diagnostic: independent dual norm at fixed F0 center versus archived norms."""
import json,contextlib,io,time
from fractions import Fraction as Q
import independent_k_all as A
import independent_B_full_attempt as B
from pathlib import Path
p=A.ROOT
c=json.load(open(p/'constants.json'));r=json.load(open(p/'lowdeg.json'))
f=(Q(c['F_lo'])+Q(c['F_up']))/2
with contextlib.redirect_stdout(io.StringIO()):st=A.run(f0_override=f,save=False)
fs=[B.make_field(k,st) for k in range(5)]
t=time.perf_counter()
for j,k in enumerate([q for q in r if sum(map(int,q.split(',')))==2][:12]):
 a=tuple(map(int,k.split(',')));nl,nt=B.exact_tight_norm(a,fs,st,0)
 an=Q(r[k]['NL']['mid']);at=Q(r[k]['NT']['mid']); print(k,'nl',float(nl),'archive',float(an),'ratio',float(nl/an) if an else None,'nt',float(nt),'ref',float(at),'sec',time.perf_counter()-t,flush=True)
