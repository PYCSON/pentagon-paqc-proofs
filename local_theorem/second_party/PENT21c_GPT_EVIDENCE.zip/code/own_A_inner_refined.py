#!/usr/bin/env python3
"""Attempt independent Level A positive-definite inner test with new conservative Level B coefficients."""
import json,lzma,time
from fractions import Fraction as Q
import independent_a as A
P='/mnt/data/pent21c_audit/delivery/logs/own_levelB_enclosure_refined.json.xz'
t0=time.perf_counter();u=json.load(lzma.open(P,'rt'))
conv=lambda obj:{tuple(map(int,k.split(','))):Q(x) for k,x in obj.items()}
tm=conv(u['Tm']);em=conv(u['Em']);print('coefs',len(tm),len(em),'loaded sec',time.perf_counter()-t0,flush=True)
pass_,info=A.inner(tm,em)
print('OWN_A_INNER_PASS',pass_,'other',[(k,v) for k,v in info.items() if not isinstance(v,Q)])
for k,v in info.items():
 if isinstance(v,Q):print(k,format(float(v),'.17g'))
print('elapsed',time.perf_counter()-t0)
