#!/usr/bin/env python3
"""Exact integer provenance consistency; not an independent PDE coefficient enclosure."""
from pathlib import Path
from fractions import Fraction as Q
import json,lzma,collections,copy,time
ROOT=Path('/mnt/data/pent21c_audit/PENT21c_cert_3055e81/lines/D-topics/probes/PENT/local_run_20261117/cert')
def load():
 w=json.load(open(ROOT/'witness.json'))
 z=json.load(lzma.open(ROOT/'parts.json.xz','rt'))
 return w,z

def check(w,z):
 p=z['parts']; tm=w['Tm']; em=w['Em']; scale=1<<w['gbits']
 assert w['gbits']==z['gbits'] and set(p)==set(em)
 ok=0;err=[];degrees=collections.Counter();tight=collections.Counter();breakpoints=collections.Counter()
 for a, (kr,el,eq,sh,t) in p.items():
  ex=tuple(map(int,a.split(',')));deg=sum(ex)
  S=kr+el+eq+sh;E=Q(em[a])*scale
  valid=kr>=0 and el>=0 and eq>=0 and sh>=0 and t==(1 if deg<=3 else 0) and S-3<=E<=S+1
  if valid:ok+=1
  else:err.append((a,S,str(E),t))
  degrees[deg]+=1;tight[t]+=1
  breakpoints[max(range(4),key=lambda i:(kr,el,eq,sh)[i])]+=1
 assert set(tm).issubset(set(em))
 print('PARTS_TOTAL',len(p),'PASS',ok,'FAIL',len(err),'SAMPLES',err[:5]);print('DEG_COUNTS',sorted(degrees.items()));print('TIGHT',dict(tight),'DOMINANT_ERROR',dict(breakpoints))
 return ok==len(p) and not err
if __name__=='__main__':
 w,z=load();assert check(w,z)
 ww=copy.deepcopy(w);first=next(iter(ww['Em']));ww['Em'][first]='0'
 assert not check(ww,z);print('TAMPER_EM_ZERO_REJECTED',first)
 zz=copy.deepcopy(z);aa=next(iter(zz['parts']));zz['parts'][aa][1]+=1<<180
 assert not check(w,zz);print('TAMPER_PARTS_REJECTED',aa)
