import json
from fractions import Fraction as F
p='/mnt/data/pent21b_audit/lines/D-topics/probes/PENT/local_run_20261117/cert/'
w=json.load(open(p+'witness.json'));lines=[json.loads(s) for s in open(p+'leaves.jsonl')][1:]
S=1<<160
with open('/mnt/data/pent21b_audit/levela_data2.txt','w') as out:
 tm=[(tuple(map(int,k.split(','))),F(v)) for k,v in w['Tm'].items() if sum(map(int,k.split(',')))<=6]
 out.write(f'{len(tm)}\n')
 for a,v in tm:
  n=v*S;assert n.denominator==1
  out.write(' '.join(map(str,a))+' '+str(n.numerator)+'\n')
 E={tuple(map(int,k.split(','))):F(v) for k,v in w['Em'].items()}
 for k,v in w['Tm'].items():
  a=tuple(map(int,k.split(',')))
  if sum(a)>6:E[a]=E.get(a,F(0))+abs(F(v))
 out.write(str(len(E))+'\n')
 for a,v in sorted(E.items()):
  n=v*S;assert n.denominator==1
  out.write(' '.join(map(str,a))+' '+str(n.numerator)+'\n')
 pl=[L for L in lines if L['t']=='P'];out.write(str(len(pl))+'\n')
 for L in pl:out.write(' '.join(L['m']+L['r']+L.get('mu',['0']*6))+'\n')
print('E',len(E))
