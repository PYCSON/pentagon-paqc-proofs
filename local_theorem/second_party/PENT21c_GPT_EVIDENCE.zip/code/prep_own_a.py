#!/usr/bin/env python3
"""Generate exact 2^-160 multipliers from the independently recomputed coefficient enclosure."""
from fractions import Fraction as Q
from pathlib import Path
import json,lzma
SRC=Path('/mnt/data/pent21c_audit/PENT21c_cert_3055e81/lines/D-topics/probes/PENT/local_run_20261117/cert')
OWN=Path('/mnt/data/pent21c_audit/delivery/logs/own_levelB_enclosure_refined.json.xz')
OUT=Path('/mnt/data/pent21c_audit/delivery/logs/own_levelA_data.txt')
z=json.load(lzma.open(OWN,'rt'))
S=1<<160
assert len(z['Em'])==13024
archive=json.load(open(SRC/'witness.json'))
assert set(z['Em'])==set(archive['Em'])
lines=[json.loads(s) for s in open(SRC/'leaves.jsonl')]
with open(OUT,'w') as out:
 tm=[(tuple(map(int,k.split(','))),Q(v)) for k,v in z['Tm'].items() if sum(map(int,k.split(',')))<=6 and Q(v)]
 out.write(str(len(tm))+'\n')
 for a,v in sorted(tm):
  n=v*S;assert n.denominator==1
  out.write(' '.join(map(str,a))+' '+str(n.numerator)+'\n')
 E={tuple(map(int,k.split(','))):Q(v) for k,v in z['Em'].items()}
 for k,v in z['Tm'].items():
  a=tuple(map(int,k.split(',')))
  if sum(a)>6:E[a]=E.get(a,Q(0))+abs(Q(v))
 out.write(str(len(E))+'\n')
 for a,v in sorted(E.items()):
  n=v*S;assert n.denominator==1 and n>=0
  out.write(' '.join(map(str,a))+' '+str(n.numerator)+'\n')
 ps=[x for x in lines if x['t']=='P'];out.write(str(len(ps))+'\n')
 for L in ps:
  # all supplied dyadic centres and half widths are checked independently in prior Level A
  out.write(' '.join(L['m']+L['r']+L.get('mu',['0']*6))+'\n')
print('READY',OUT,'Tm<=6',len(tm),'E',len(E),'P',len(ps),'size',OUT.stat().st_size)
