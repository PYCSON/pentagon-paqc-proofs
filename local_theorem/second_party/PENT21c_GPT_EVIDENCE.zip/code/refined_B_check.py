#!/usr/bin/env python3
"""Run independently proven Laurent F0 dependency cancellation and full independent Level B majorant."""
import laurent_refine, independent_B_full_attempt as B
if __name__=='__main__':
 refined=laurent_refine.run()
 result=B.run(refinement=refined)
 print('REFINED_FULL_B',result['passed'],'/',result['total'])
