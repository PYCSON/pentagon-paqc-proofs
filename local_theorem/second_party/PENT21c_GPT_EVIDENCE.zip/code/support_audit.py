#!/usr/bin/env python3
"""Independent formal polynomial support audit: all coefficient sources and shift remain in frozen universe.

No producer source imported or run. This is a conservative symbolic degree/support audit,
not a re-computation of certified coefficient magnitudes.
"""
import collections,contextlib,io,sys,json,lzma,time
from fractions import Fraction as Q
import independent_k_all as A
import independent_B_full_attempt as B
P=A.ROOT
start=time.perf_counter()
with contextlib.redirect_stdout(io.StringIO()): st=A.run(save=False)
ref=set(tuple(map(int,k.split(','))) for k in st['witness']['Em'])
assert len(ref)==13024
f=[]
for k in range(5): f.append(B.make_field(k,st))
Mq=B.quadratic_majorant(st)
# Field support, not just list of magnitudes, checks all basis coefficients.
fieldsupport=set()
for ff in f:
 for comp in ff:
  for basis,p in comp.items(): fieldsupport.update(p.d)
Kset=set(st['KD'].d)
Qset=set(Mq.d)
# Full support of coarse linear majorant, before numerical norm calculation.
Lset=fieldsupport
Bset=Kset|Qset|Lset
# Shift by rational constants changes each coordinate exponent downward only.
maxdeg=max(map(sum,Bset)); assert maxdeg<=13
Sshift={tuple(a[i] if i not in () else a[i] for i in range(6)) for a in Bset}
# Downward-closedness of target universe 2<=deg<=13.
missing={a for a in Bset if sum(a)>=2 and a not in ref}
print('ARCHIVED_KEYS',len(ref))
print('RAW_EXPLICIT_K',len(Kset),'MAX_DEG',max(map(sum,Kset)))
print('LINEAR_FIELDS',len(Lset),'MAX_DEG',max(map(sum,Lset)))
print('QUADRATIC',len(Qset),'MAX_DEG',max(map(sum,Qset)))
print('UNION',len(Bset),'MAX_DEG',maxdeg)
print('UNCOVERED_SUPPORT_DEG_GE2',len(missing),'EXAMPLE',sorted(missing)[:5])
print('ASSERT', 'PASS' if len(missing)==0 else 'FAIL')
assert not missing
print('ELAPSED_SEC',round(time.perf_counter()-start,4))
