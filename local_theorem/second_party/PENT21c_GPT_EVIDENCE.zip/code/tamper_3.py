#!/usr/bin/env python3
"""Three fail-closed counterfactuals, independent from producer tests."""
import sys,copy,json,lzma
from fractions import Fraction as F
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
import independent_b as B
from parts_audit import load,check

def tamper_input():
 # change a global degree-16 basis coefficient actually used by triangle 0
 p0,g=next((p,g) for p,g in B.dofs(0,B.N,False) if g>=0 and B.CI[0][g]!=0)
 orig=B.CI[0][g];base=B.integral(B.local_poly(0,0,'u'),B.local_poly(0,0,'u'))
 assert base==F(B.G['mass'][0][0][0])
 B.CI[0][g]+=1<<40
 mutated=B.integral(B.local_poly(0,0,'u'),B.local_poly(0,0,'u'))
 B.CI[0][g]=orig
 assert mutated!=F(B.G['mass'][0][0][0]),'failed to detect changed input'
 print('TAMPER_INPUT_REJECTED',g,'mass_diff',float(mutated-base))

def tamper_fup():
 ff=F(B.C['F_lo']);lam=B.C['forms_at_c']['lam_up'];ar=B.C['forms_at_c']['area_c']
 inf=(F(lam['mid'])-F(lam['rad']))*(F(ar['mid'])-F(ar['rad']))
 assert ff<inf
 print('TAMPER_FUP_REJECTED',float(inf-ff))

def tamper_em():
 w,p=load();ww=copy.deepcopy(w);k=next(iter(ww['Em']));ww['Em'][k]='0'
 assert not check(ww,p)
 print('TAMPER_EM_ZERO_REJECTED',k)
if __name__=='__main__':tamper_input();tamper_fup();tamper_em();print('THREE_TAMPERS_PASS')
