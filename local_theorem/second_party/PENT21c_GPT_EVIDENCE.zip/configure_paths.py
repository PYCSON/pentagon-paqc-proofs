#!/usr/bin/env python3
"""Relocate only assistant-authored checker source, never user/producer Python code."""
from pathlib import Path
import argparse, shutil
OLD_CERT='/mnt/data/pent21c_audit/PENT21c_cert_3055e81/lines/D-topics/probes/PENT/local_run_20261117/cert'
OLD_OUT='/mnt/data/pent21c_audit/delivery'
a=argparse.ArgumentParser()
a.add_argument('--cert',type=Path,required=True)
a.add_argument('--output',type=Path,required=True)
v=a.parse_args()
root=Path(__file__).resolve().parent
cert=v.cert.resolve();out=v.output.resolve()
if not cert.is_dir() or not (cert/'inputs.json').is_file():raise SystemExit(f'missing certificate directory {cert}')
if root==out:raise SystemExit('use an independent target directory')
(out/'code').mkdir(parents=True,exist_ok=True)
(out/'logs').mkdir(parents=True,exist_ok=True)
for p in (root/'code').glob('*'):
 if not p.is_file() or p.suffix not in ('.py','.cpp'):continue
 s=p.read_text()
 s=s.replace(OLD_CERT,str(cert)).replace(OLD_OUT,str(out))
 (out/'code'/p.name).write_text(s)
print(f'Prepared independent source in {out}. Only own source files copied; no production files changed.')
